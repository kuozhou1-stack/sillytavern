import remote from '../assets/maps/远程素材.json';
// 使用固定提交的图片链接，保持背景版本稳定并避免卡包内嵌图片。
type RemoteMapAsset = { url: string; rawUrl?: string };

/** 为 jsDelivr / GitHub Raw 地图链接派生多节点回退源，提升不同网络环境下的加载成功率。 */
export function buildMapImageFallbacks(url: string, rawUrl?: string): string[] {
  const candidates: string[] = [];
  const push = (value?: string) => {
    if (value && !candidates.includes(value)) candidates.push(value);
  };
  push(url);
  const jsdelivr = /^https?:\/\/[^/]+\.jsdelivr\.net\/gh\/([^/]+)\/([^/@]+)@([^/]+)\/(.+)$/.exec(url);
  if (jsdelivr) {
    const [, owner, repo, ref, filePath] = jsdelivr;
    push(`https://testingcf.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
    push(`https://fastly.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
    push(rawUrl || `https://raw.githubusercontent.com/${owner}/${repo}/${ref}/${filePath}`);
  } else {
    const raw = /^https?:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/.exec(url);
    if (raw) {
      const [, owner, repo, ref, filePath] = raw;
      push(`https://cdn.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
      push(`https://testingcf.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
      push(`https://fastly.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
    }
    push(rawUrl);
  }
  return candidates;
}

const resolveAsset = (asset: RemoteMapAsset) => ({
  src: asset.url,
  fallbacks: buildMapImageFallbacks(asset.url, asset.rawUrl),
});

const world = resolveAsset(remote.files['world-overview.webp']);
const atlasA = resolveAsset(remote.files['districts-a.webp']);
const atlasB = resolveAsset(remote.files['districts-b.webp']);
const atlasC = resolveAsset(remote.files['districts-c.webp']);
const atlasD = resolveAsset(remote.files['districts-d.webp']);

export const worldMapBackground = world.src;
export const worldMapBackgroundFallbacks = world.fallbacks;
export type DistrictBackground = { src: string; fallbacks: string[]; col: number; row: number };
// 同一画册的四幅地图独立显示；SVG 裁切窗口不改动或复制原始画面。
export const districtBackgrounds: Record<string, DistrictBackground> = Object.fromEntries(
  [
    { asset: atlasA, ids: ['riverside', 'oldtown', 'university', 'residential'] },
    { asset: atlasB, ids: ['market', 'coast', 'demacia', 'noxus'] },
    { asset: atlasC, ids: ['freljord', 'ionia', 'piltover_zaun', 'bilgewater'] },
    { asset: atlasD, ids: ['shurima', 'targon', 'shadow_isles', 'bandle_city'] },
  ].flatMap(({ asset, ids }) =>
    ids.map((id, i) => [id, { src: asset.src, fallbacks: asset.fallbacks, col: i % 2, row: Math.floor(i / 2) }]),
  ),
);
