const STORAGE_KEY = 'valoran-v1-custom-avatars';
const DEFAULT_FORM_KEY = '__default__';
const MAX_DIMENSION = 384;
const MAX_PASSTHROUGH_GIF_BYTES = 600 * 1024;

type SharedCustomAvatarStore = {
  loaded: boolean;
  avatars: Record<string, string>;
  listeners: Set<() => void>;
};

const LOCAL_CUSTOM_AVATAR_STORE: SharedCustomAvatarStore = {
  loaded: false,
  avatars: {},
  listeners: new Set<() => void>(),
};

function getStore(): SharedCustomAvatarStore {
  try {
    if (typeof window !== 'undefined') {
      const host = (window.parent && window.parent !== window ? window.parent : window) as any;
      if (host && typeof host === 'object') {
        if (!host.__valoranCustomAvatarStore) {
          host.__valoranCustomAvatarStore = {
            loaded: false,
            avatars: {},
            listeners: new Set<() => void>(),
          } satisfies SharedCustomAvatarStore;
        }
        return host.__valoranCustomAvatarStore as SharedCustomAvatarStore;
      }
    }
  } catch {
    // 跨域或受限宿主回退到本地内存
  }
  return LOCAL_CUSTOM_AVATAR_STORE;
}

function notify() {
  for (const fn of getStore().listeners) {
    try {
      fn();
    } catch (error) {
      console.warn('[瓦罗兰自定义头像] 订阅回调异常', error);
    }
  }
}

function normalizeHeroKey(name: string | null | undefined): string {
  return String(name ?? '')
    .replace(/[（(][^）)]+[）)]/g, '')
    .trim();
}

function normalizeFormKey(form: string | null | undefined): string {
  const cleaned = String(form ?? '').trim();
  return cleaned || DEFAULT_FORM_KEY;
}

export function buildCustomAvatarKey(heroName: string | null | undefined, formName?: string | null): string | null {
  const hero = normalizeHeroKey(heroName);
  if (!hero) return null;
  return `${hero}::${normalizeFormKey(formName)}`;
}

function getStorage(): Storage | undefined {
  try {
    if (typeof window !== 'undefined' && window.parent && window.parent !== window && window.parent.localStorage) {
      return window.parent.localStorage;
    }
  } catch {
    // 跨域或受限宿主回退到当前窗口存储
  }
  return typeof localStorage !== 'undefined' ? localStorage : undefined;
}

function ensureLoaded() {
  const store = getStore();
  if (store.loaded) return;
  store.loaded = true;
  try {
    const storage = getStorage();
    if (!storage) return;
    const raw = storage.getItem(STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      const next: Record<string, string> = {};
      for (const [k, v] of Object.entries(parsed)) {
        if (typeof v === 'string' && v.startsWith('data:image/')) next[k] = v;
      }
      store.avatars = next;
    }
  } catch (error) {
    console.warn('[瓦罗兰自定义头像] 读取本地缓存失败', error);
  }
}

function persist() {
  const storage = getStorage();
  if (!storage) return;
  try {
    storage.setItem(STORAGE_KEY, JSON.stringify(getStore().avatars));
  } catch (error) {
    throw Error('本地头像存储空间不足，请先恢复部分旧的自定义头像后再试', { cause: error });
  }
}

export function subscribeCustomAvatars(listener: () => void): () => void {
  const { listeners } = getStore();
  listeners.add(listener);
  let active = true;
  const unsub = () => {
    if (!active) return;
    active = false;
    listeners.delete(listener);
    if (typeof window !== 'undefined') window.removeEventListener?.('pagehide', unsub);
  };
  if (typeof window !== 'undefined') window.addEventListener?.('pagehide', unsub, { once: true });
  return unsub;
}

/** 查询自定义头像覆盖：优先匹配「角色 + 具体形态」，其次匹配角色默认覆盖。 */
export function resolveCustomAvatar(
  heroName: string | null | undefined,
  formName?: string | null,
): { url: string; key: string; exactForm: boolean } | null {
  ensureLoaded();
  const store = getStore();
  const hero = normalizeHeroKey(heroName);
  if (!hero) return null;

  const exactKey = `${hero}::${normalizeFormKey(formName)}`;
  if (store.avatars[exactKey]) {
    return { url: store.avatars[exactKey], key: exactKey, exactForm: true };
  }
  const defaultKey = `${hero}::${DEFAULT_FORM_KEY}`;
  if (defaultKey !== exactKey && store.avatars[defaultKey]) {
    return { url: store.avatars[defaultKey], key: defaultKey, exactForm: false };
  }
  return null;
}

export function setCustomAvatar(
  heroName: string | null | undefined,
  formName: string | null | undefined,
  dataUrl: string,
): string {
  ensureLoaded();
  const store = getStore();
  const key = buildCustomAvatarKey(heroName, formName);
  if (!key) throw Error('角色名称为空，无法保存自定义头像');
  if (!dataUrl || !dataUrl.startsWith('data:image/')) throw Error('仅支持有效图片数据');
  const prev = store.avatars[key];
  store.avatars = { ...store.avatars, [key]: dataUrl };
  try {
    persist();
  } catch (error) {
    if (prev !== undefined) store.avatars = { ...store.avatars, [key]: prev };
    else {
      const copy = { ...store.avatars };
      delete copy[key];
      store.avatars = copy;
    }
    throw error;
  }
  notify();
  return key;
}

export function clearCustomAvatar(heroName: string | null | undefined, formName?: string | null): boolean {
  ensureLoaded();
  const store = getStore();
  const resolved = resolveCustomAvatar(heroName, formName);
  if (!resolved) return false;
  const next = { ...store.avatars };
  delete next[resolved.key];
  store.avatars = next;
  try {
    persist();
  } catch (error) {
    console.warn('[瓦罗兰自定义头像] 清理后写入缓存失败', error);
  }
  notify();
  return true;
}

export function clearAllCustomAvatars() {
  const store = getStore();
  store.loaded = true;
  store.avatars = {};
  try {
    getStorage()?.removeItem(STORAGE_KEY);
  } catch {
    // 忽略测试环境无存储异常
  }
  notify();
}

function readFileAsDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ''));
    reader.onerror = () => reject(Error('读取本地图片失败'));
    reader.readAsDataURL(file);
  });
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(Error('图片解码失败，请更换有效图片文件'));
    img.src = src;
  });
}

/**
 * 将本地选中的图片文件标准化为轻量 DataURL（最长边 <= 384px，优先 WebP 保透明且体积小）。
 * 动图 GIF（<= 600KB）直接保留原图，不丢失动态帧。
 */
export async function processAvatarFileToDataUrl(file: File): Promise<string> {
  const mime = (file.type || '').toLowerCase();
  const extOk = /\.(png|jpe?g|webp|gif|avif|bmp)$/i.test(file.name || '');
  if (!mime.startsWith('image/') && !extOk) {
    throw Error('请选择图片文件（支持 PNG / JPG / WebP / GIF 等）');
  }
  const rawUrl = await readFileAsDataUrl(file);
  const isGif = mime === 'image/gif' || (!mime && /\.gif$/i.test(file.name || ''));
  if (isGif && file.size <= MAX_PASSTHROUGH_GIF_BYTES) {
    return rawUrl;
  }
  if (typeof document === 'undefined') return rawUrl;

  const img = await loadImageElement(rawUrl);
  const srcW = img.naturalWidth || img.width || MAX_DIMENSION;
  const srcH = img.naturalHeight || img.height || MAX_DIMENSION;
  const scale = Math.min(1, MAX_DIMENSION / Math.max(srcW, srcH));
  const dstW = Math.max(1, Math.round(srcW * scale));
  const dstH = Math.max(1, Math.round(srcH * scale));

  const canvas = document.createElement('canvas');
  canvas.width = dstW;
  canvas.height = dstH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return rawUrl;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, dstW, dstH);

  const webp = canvas.toDataURL('image/webp', 0.86);
  if (webp.startsWith('data:image/webp')) return webp;
  if (mime === 'image/png') return canvas.toDataURL('image/png');
  return canvas.toDataURL('image/jpeg', 0.86);
}
