<template>
  <g class="cw-map-base" aria-hidden="true">
    <defs>
      <clipPath :id="clipId"><rect width="1000" height="700" /></clipPath>
    </defs>
    <rect x="-2000" y="-2000" width="5000" height="5000" fill="#eee6d5" />
    <g :clip-path="`url(#${clipId})`">
      <image
        v-if="sheet && imageIndex < sheet.urls.length"
        :key="sheet.id + ':' + imageIndex"
        :href="sheet.urls[imageIndex]"
        width="1000"
        height="700"
        preserveAspectRatio="none"
        @error="imageIndex++"
      />
      <text v-else x="500" y="350" text-anchor="middle" class="cw-zone-label">底图未能加载</text>
    </g>
  </g>
</template>

<script setup lang="ts">
import { ref, useId } from 'vue';
import type { MapSheet } from '../../../utils/map-assets';
defineProps<{ sheet?: MapSheet }>();
const clipId = 'cw-map-clip-' + useId().replace(/:/g, '');
const imageIndex = ref(0);
</script>

<style scoped>
.cw-map-base {
  pointer-events: none;
}
.cw-zone-label {
  fill: #665b44;
  font-size: 12px;
  font-weight: 500;
  paint-order: stroke;
  stroke: #fff9e6dd;
  stroke-width: 3px;
  stroke-linejoin: round;
}
</style>
