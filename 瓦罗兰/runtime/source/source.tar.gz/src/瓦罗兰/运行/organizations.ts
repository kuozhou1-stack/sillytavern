import type { State } from './core';
import { getOrganizationSettings, legacyAliases, type ExternalOrganization } from './external-settings';

type Row = State['组织'][string];
type Member = NonNullable<Row['成员变更']>[string];
type Catalog = Record<string, ExternalOrganization>;
export const organizationChangeFields = ['成员变更', '据点变更', '活动日程id'] as const;

export function organizationCatalog(state: State, extraRefs: string[] = []): Catalog {
  const bundle = getOrganizationSettings();
  const catalog: Catalog = { ...bundle.organizations };
  if (bundle.legacyOrganizations) {
    const control = state._系统?.资料加载;
    const refs = [...extraRefs, ...Object.keys(state.组织), ...(control?.组织 ?? []), ...Object.keys(control?.组织覆盖 ?? {}),
      ...(control?.轮候.组织 ?? []), ...(state.玩家?.身份.组织id ?? []), ...Object.values(state.角色 ?? {}).flatMap(p => p.组织id)];
    const aliases = legacyAliases(state, bundle);
    for (const id of refs) if (!aliases.has(id) && bundle.legacyOrganizations[id]) catalog[id] = bundle.legacyOrganizations[id];
  }
  for (const [id, row] of Object.entries(state.组织)) {
    const base = catalog[id];
    catalog[id] = row.名称 && base?.名称 && row.名称 !== base.名称 ? row : { ...base, ...row };
  }
  return catalog;
}

export function isExternalOrganization(state: State, id: string) {
  const settings = getOrganizationSettings();
  const base = settings.organizations[id] ?? settings.legacyOrganizations?.[id];
  const name = state.组织[id]?.名称;
  return !!base && (!name || name === base.名称);
}

export function organizationDetails(record: ExternalOrganization) {
  const members: Record<string, Member> = {};
  for (const [id, item] of Object.entries(record.已知成员 ?? {}))
    members[id] = { 关系: '正式成员', ...(item.职务 ? { 职务: item.职务 } : {}) };
  Object.assign(members, record.成员);
  for (const [id, change] of Object.entries(record.成员变更 ?? {})) {
    if (change.关系 === '退出') delete members[id];
    else members[id] = members[id]?.关系 === change.关系 ? { ...members[id], ...change } : change;
  }
  const places = new Set([...Object.keys(record.据点 ?? {}), ...(record.场所id ?? [])]);
  for (const [id, change] of Object.entries(record.据点变更 ?? {}))
    if (change === '停用') places.delete(id);
    else places.add(id);
  return { ...record, 已知成员: members, 场所id: [...places], 活动日程id: record.活动日程id ?? [] };
}

export function organizationIdsForPerson(state: State, personId: string | null, original: string[], catalog = organizationCatalog(state, original)) {
  const aliases = legacyAliases(state, getOrganizationSettings());
  const ids = new Set(original.map(id => aliases.get(id) ?? id));
  if (personId) for (const [id, row] of Object.entries(catalog)) {
    const relation = row.成员变更?.[personId]?.关系 ?? row.成员?.[personId]?.关系 ?? (row.已知成员?.[personId] && '正式成员');
    if (relation === '正式成员') ids.add(id);
    else if (relation) ids.delete(id);
  }
  return [...ids];
}

export function organizationVisibilityTag(record: ExternalOrganization) {
  if (record.公开性质 === '公开' || record.公开性质 === '隐秘' || record.公开性质 === '双面') return record.公开性质;
  if (!record.公开性质 && !record.象限) return null;
  if (record.类型 === '表世界/公开组织') return '公开';
  if (/象限 [BC]/.test(record.象限 ?? '') || /对外是|明面上是|常规市政治安|跨国中立政务|合法外衣资本寡头/.test(record.简介 ?? '')) return '双面';
  return '隐秘';
}
