import { copy, equal, type State } from './core';
import { storyDateKey } from './novel-system';

type StoryTime = State['世界']['当前时间'];
const worldAnchorPaths = [
  ['世界', '当前场景', '_上次更新场景时间'],
  ['世界', '天气', '_上次检查时间'],
] as const;
const record = (value: unknown): value is Record<string, any> =>
  value !== null && typeof value === 'object' && !Array.isArray(value);
const pointerParts = (path: unknown): string[] | null =>
  typeof path !== 'string' ? null : path === '' ? [] : path.startsWith('/')
    ? path.slice(1).split('/').map(part => part.replaceAll('~1', '/').replaceAll('~0', '~'))
    : null;
const startsWithPath = (path: readonly string[], prefix: readonly string[]) =>
  prefix.length <= path.length && prefix.every((part, index) => part === path[index]);

/** Restore exactly these two script anchors, leaving other private fields visible to validateModel. */
function restoreAnchorValues(before: State, target: unknown, prefix: readonly string[] = []) {
  if (!record(target)) return;
  for (const anchor of worldAnchorPaths) {
    if (!startsWithPath(anchor, prefix) || anchor.length === prefix.length) continue;
    const relative = anchor.slice(prefix.length);
    let parent: Record<string, any> | null = target;
    for (const key of relative.slice(0, -1)) {
      if (!Object.hasOwn(parent, key)) parent[key] = {};
      // Do not conceal malformed business objects by replacing primitives, nulls or arrays.
      if (!record(parent[key])) {
        parent = null;
        break;
      }
      parent = parent[key];
    }
    if (parent) parent[relative.at(-1)!] = copy(anchor[1] === '当前场景'
      ? before.世界.当前场景._上次更新场景时间
      : before.世界.天气._上次检查时间);
  }
}

/** Normalize the commands actually sent to MVU, before its schema validation can reject bad anchor values. */
export function normalizeWorldAnchorPatches(before: State, commands: readonly any[]): any[] {
  return commands.flatMap(command => {
    if (!record(command)) return [command];
    const parts = pointerParts(command.path);
    // A move may also delete a different field: never swallow that operation or hide its source change.
    const localWrite = !Object.hasOwn(command, 'from') &&
      ['add', 'replace', 'insert', 'remove', 'delta'].includes(command.op);
    if (parts && localWrite && worldAnchorPaths.some(anchor => startsWithPath(parts, anchor))) return [];
    const normalized = copy(command);
    if (parts && localWrite && ['add', 'replace', 'insert'].includes(command.op))
      restoreAnchorValues(before, normalized.value, parts);
    return [normalized];
  });
}

/** Call on MVU's raw candidate before validateModel; never persist the model's anchor values. */
export function restoreWorldAnchors<T>(before: State, raw: T): T {
  if (!record(raw) || worldAnchorPaths.every(path => equal(_.get(raw, path), _.get(before, path)))) return raw;
  const result = copy(raw);
  restoreAnchorValues(before, result);
  return result;
}

export function elapsedMinutes(start: StoryTime, end: StoryTime): number | null {
  if (!start || !end) return null;
  const minute = (time: NonNullable<StoryTime>) => {
    const date = new Date(0);
    date.setUTCFullYear(time.年, time.月 - 1, time.日);
    date.setUTCHours(time.时, time.分, 0, 0);
    return date.getTime() / 60000;
  };
  return minute(end) - minute(start);
}
const weatherFacts = (state: State) => {
  const { _上次检查时间, 生效时间, ...facts } = state.世界.天气;
  return facts;
};
export function weatherCheckDue(state: State, end = state.世界.当前时间) {
  const anchor = state.世界.天气._上次检查时间;
  return (
    !!end &&
    (!anchor || !state.世界.天气.天气状况 || storyDateKey(anchor) !== storyDateKey(end) || (elapsedMinutes(anchor, end) ?? 0) >= 180)
  );
}

/** One successful model update acknowledges the requested weather check; no timer or extra model request. */
export function finalizeWorld(before: State, candidate: State): State {
  restoreAnchorValues(before, candidate);
  const time = candidate.世界.当前时间;
  const changed = !equal(weatherFacts(before), weatherFacts(candidate));
  if (changed && equal(before.世界.天气.生效时间, candidate.世界.天气.生效时间))
    candidate.世界.天气.生效时间 = copy(time);
  if (!changed) candidate.世界.天气.生效时间 = copy(before.世界.天气.生效时间);
  if (weatherCheckDue(before, time) || changed) candidate.世界.天气._上次检查时间 = copy(time);
  const scene = (state: State) => {
    const { _上次更新场景时间, ...facts } = state.世界.当前场景;
    return { ...facts, 地点id: state.玩家.当前状态.当前地点id };
  };
  if (!equal(scene(before), scene(candidate))) candidate.世界.当前场景._上次更新场景时间 = copy(time);
  return candidate;
}

export function worldUpdatePrompt(state: State) {
  return `世界动态检查：当前天气检查锚点 ${JSON.stringify(state.世界.天气._上次检查时间)}；请求起点是否应检查天气：${weatherCheckDue(state) ? '是' : '否'}。若本轮跨日、距锚点满180分钟或发生明确天气变化则同步检查天气（允许不变）。`;
}
