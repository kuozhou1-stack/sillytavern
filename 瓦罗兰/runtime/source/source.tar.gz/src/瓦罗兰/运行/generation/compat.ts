export const DEFAULT_TOOL_REASONING_MODES = {
  DISABLED: 'disabled',
  ACTIVE_CHAIN: 'active_chain',
  SINCE_LAST_USER: 'since_last_user',
} as const;

export const DEFAULT_CHAT_COMPLETION_SOURCES = {
  OPENROUTER: 'openrouter',
  CUSTOM: 'custom',
  CLAUDE: 'claude',
} as const;

export type SubstituteParamsOptions = {
  name1Override?: string;
  name2Override?: string;
  original?: string;
  groupOverride?: string;
  replaceCharacterCard?: boolean;
  dynamicMacros?: Record<string, unknown>;
  postProcessFn?: (text: string) => string;
};

/**
 * 识别旧版 SillyTavern（如 1.13.4，Macros 2.0 之前）的位置参数签名：
 * substituteParams(content, _name1, _name2, _original, _group, _replaceCharacterCard = true, additionalMacro = {}, postProcessFn = x => x)
 * 若对旧版函数直接传入 options 对象，第 2 参数会被当成 _name1，导致 {{user}} 被替换为 "[object Object]" 且忽略 dynamicMacros。
 */
export function isLegacySubstituteParams(fn: unknown): boolean {
  if (typeof fn !== 'function') return false;
  if (fn.length >= 3) return true;
  try {
    const src = Function.prototype.toString.call(fn);
    const match = /^[^(]*\(\s*([^)]*)\)/.exec(src);
    if (!match) return false;
    const params = match[1].split(',').map(part => part.trim());
    if (params.length >= 2 && /^_?name1\b/i.test(params[1])) return true;
    if (params.length >= 3 && /^_?name2\b/i.test(params[2])) return true;
  } catch {
    // 忽略无法反编译的宿主包装函数
  }
  return false;
}

/** 兼容新版 SillyTavern（options 对象）与旧版 SillyTavern（位置参数）的 substituteParams 调用。 */
export function callSubstituteParams(
  script: Record<string, any> | undefined,
  text: unknown,
  options: SubstituteParamsOptions = {},
): string {
  const fn = script?.substituteParams;
  if (typeof fn !== 'function') return typeof text === 'string' ? text : String(text ?? '');
  if (isLegacySubstituteParams(fn)) {
    return fn.call(
      script,
      text,
      options.name1Override,
      options.name2Override,
      options.original,
      options.groupOverride,
      options.replaceCharacterCard ?? true,
      options.dynamicMacros ?? {},
      options.postProcessFn,
    );
  }
  return fn.call(script, text, options);
}

const SOURCE_MODEL_FIELDS: Record<string, string> = {
  claude: 'claude_model',
  openai: 'openai_model',
  makersuite: 'google_model',
  vertexai: 'vertexai_model',
  openrouter: 'openrouter_model',
  ai21: 'ai21_model',
  mistralai: 'mistralai_model',
  custom: 'custom_model_id',
  cohere: 'cohere_model',
  perplexity: 'perplexity_model',
  groq: 'groq_model',
  electronhub: 'electronhub_model',
  nanogpt: 'nanogpt_model',
  deepseek: 'deepseek_model',
  aimlapi: 'aimlapi_model',
  xai: 'xai_model',
  pollinations: 'pollinations_model',
  cometapi: 'cometapi_model',
  moonshot: 'moonshot_model',
  fireworks: 'fireworks_model',
  azure_openai: 'azure_openai_model',
  chutes: 'chutes_model',
  zai: 'zai_model',
  zerooneai: 'zerooneai_model',
  windowai: 'windowai_model',
};

/** 识别旧版 SillyTavern（<= 1.14.0）的 getChatCompletionModel(source = null) 签名。 */
export function isLegacyGetChatCompletionModel(fn: unknown): boolean {
  if (typeof fn !== 'function') return false;
  try {
    const src = Function.prototype.toString.call(fn);
    return /^[^(]*\(\s*source\b/.test(src);
  } catch {
    return false;
  }
}

/** 兼容新版（接受 settings）与旧版（<= 1.14.0 接受 source 字符串）的 getChatCompletionModel 调用。 */
export function resolveChatCompletionModel(openai: Record<string, any> | undefined, settings: Record<string, any>): string {
  const fn = openai?.getChatCompletionModel;
  if (typeof fn === 'function' && !isLegacyGetChatCompletionModel(fn)) {
    return fn(settings) || '';
  }
  const source = String(settings.chat_completion_source ?? '');
  const field = SOURCE_MODEL_FIELDS[source];
  if (field && typeof settings[field] === 'string' && settings[field]) {
    if (source === 'openrouter' && settings[field] === 'OR_Website') return '';
    return settings[field];
  }
  if (source === 'custom' && typeof settings.custom_model === 'string' && settings.custom_model) {
    return settings.custom_model;
  }
  if (typeof fn === 'function') {
    try {
      return fn(source || null) || '';
    } catch {
      return '';
    }
  }
  return String(settings.custom_model || settings.custom_model_id || settings.openai_model || '');
}

function legacyReasoningEffort(settings: Record<string, any>, model: string): string | undefined {
  const effort = settings.reasoning_effort;
  if (effort === undefined || effort === null || effort === '' || effort === 'auto') return undefined;
  const source = String(settings.chat_completion_source ?? '');
  const stringEffortSources = [
    'openai', 'azure_openai', 'custom', 'xai', 'aimlapi', 'openrouter',
    'pollinations', 'perplexity', 'cometapi', 'electronhub',
  ];
  if (!stringEffortSources.includes(source)) return effort;
  if (effort === 'min') {
    return ['openai', 'azure_openai'].includes(source) && /^gpt-5/i.test(model) ? 'minimal' : 'low';
  }
  if (effort === 'max') return 'high';
  return effort;
}

/**
 * 兼容旧版 SillyTavern（<= 1.14.0，如 1.13.4）：
 * 当宿主未导出 openai.createGenerationParameters 时，按 ST 1.13.4/1.15.0 原生规则构造 generate_data。
 * ST >= 1.15.0 直接透传调用原生 createGenerationParameters，保持行为零差异。
 */
export async function createGenerationParametersCompat(
  native: Record<string, any>,
  settings: Record<string, any>,
  model: string,
  type: string,
  messages: any[],
  options: { jsonSchema?: unknown } = {},
): Promise<{ generate_data: Record<string, any>; stream?: boolean; canMultiSwipe?: boolean }> {
  if (typeof native.openai?.createGenerationParameters === 'function') {
    return native.openai.createGenerationParameters(settings, model, type, messages, options);
  }
  if (!Array.isArray(messages)) throw Error('messages must be an array');
  const filteredMessages = messages.filter(msg => msg && typeof msg === 'object');
  const source = String(settings.chat_completion_source ?? 'openai');
  const gptSources = ['openai', 'azure_openai', 'openrouter'];
  const seedSupportedSources = [
    'openai', 'azure_openai', 'openrouter', 'mistralai', 'custom', 'cohere', 'groq',
    'electronhub', 'nanogpt', 'xai', 'pollinations', 'aimlapi', 'vertexai', 'makersuite', 'chutes',
  ];
  const multiswipeSources = ['openai', 'azure_openai', 'custom', 'xai', 'aimlapi', 'moonshot'];
  const isO1 = gptSources.includes(source) && ['o1-2024-12-17', 'o1'].includes(model);
  const stream = Boolean(settings.stream_openai) && type !== 'quiet' && !isO1;
  const noMultiSwipeTypes = ['quiet', 'impersonate', 'continue'];
  const canMultiSwipe = Number(settings.n) > 1 && !noMultiSwipeTypes.includes(type) && multiswipeSources.includes(source);
  const stoppingStrings =
    typeof native.powerUser?.getCustomStoppingStrings === 'function' ? native.powerUser.getCustomStoppingStrings() : [];
  const groupNames = typeof native.groupChats?.getGroupNames === 'function' ? native.groupChats.getGroupNames() : [];

  const generate_data: Record<string, any> = {
    type,
    messages: filteredMessages,
    model,
    temperature: settings.temp_openai !== undefined ? Number(settings.temp_openai) : undefined,
    frequency_penalty: settings.freq_pen_openai !== undefined ? Number(settings.freq_pen_openai) : undefined,
    presence_penalty: settings.pres_pen_openai !== undefined ? Number(settings.pres_pen_openai) : undefined,
    top_p: settings.top_p_openai !== undefined ? Number(settings.top_p_openai) : undefined,
    max_tokens: settings.openai_max_tokens,
    stream,
    logit_bias: undefined,
    stop: Array.isArray(stoppingStrings) && stoppingStrings.length ? stoppingStrings.slice(0, 4) : undefined,
    chat_completion_source: source,
    n: canMultiSwipe ? settings.n : undefined,
    user_name: native.script?.name1,
    char_name: native.script?.name2,
    group_names: groupNames,
    include_reasoning: Boolean(settings.show_thoughts),
    reasoning_effort: legacyReasoningEffort(settings, model),
    enable_web_search: Boolean(settings.enable_web_search),
    request_images: Boolean(settings.request_images),
    custom_prompt_post_processing: settings.custom_prompt_post_processing,
  };

  if (!Array.isArray(generate_data.stop) || !generate_data.stop.length) delete generate_data.stop;

  const isVision = (m: string) => m.includes('gpt') && m.includes('vision');
  if (gptSources.includes(source) && isVision(model)) {
    delete generate_data.logit_bias;
    delete generate_data.stop;
    delete generate_data.logprobs;
  }

  if (source === 'azure_openai') {
    generate_data.azure_base_url = settings.azure_base_url;
    generate_data.azure_deployment_name = settings.azure_deployment_name;
    generate_data.azure_api_version = settings.azure_api_version;
    if (/^gpt-[34]/.test(model)) delete generate_data.reasoning_effort;
  }
  if (source === 'claude') {
    if (settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
    generate_data.claude_use_sysprompt = settings.claude_use_sysprompt;
    if (stoppingStrings.length) generate_data.stop = [...stoppingStrings];
  }
  if (source === 'openrouter') {
    if (settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
    if (settings.min_p_openai !== undefined) generate_data.min_p = Number(settings.min_p_openai);
    if (settings.repetition_penalty_openai !== undefined) generate_data.repetition_penalty = Number(settings.repetition_penalty_openai);
    if (settings.top_a_openai !== undefined) generate_data.top_a = Number(settings.top_a_openai);
    generate_data.use_fallback = settings.openrouter_use_fallback;
    generate_data.provider = settings.openrouter_providers;
    generate_data.allow_fallbacks = settings.openrouter_allow_fallbacks;
    generate_data.middleout = settings.openrouter_middleout;
  }
  if (source === 'makersuite' || source === 'vertexai') {
    if (settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
    generate_data.use_makersuite_sysprompt = settings.use_makersuite_sysprompt;
    if (source === 'vertexai') {
      generate_data.vertexai_auth_mode = settings.vertexai_auth_mode;
      generate_data.vertexai_region = settings.vertexai_region;
      generate_data.vertexai_express_project_id = settings.vertexai_express_project_id;
    }
  }
  if (source === 'mistralai') {
    generate_data.safe_prompt = false;
  }
  if (source === 'custom') {
    generate_data.custom_url = settings.custom_url;
    generate_data.custom_include_body = settings.custom_include_body;
    generate_data.custom_exclude_body = settings.custom_exclude_body;
    generate_data.custom_include_headers = settings.custom_include_headers;
  }
  if (source === 'cohere') {
    if (settings.top_p_openai !== undefined) generate_data.top_p = Math.min(Math.max(Number(settings.top_p_openai), 0.01), 0.99);
    if (settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
    if (settings.freq_pen_openai !== undefined) generate_data.frequency_penalty = Math.min(Math.max(Number(settings.freq_pen_openai), 0), 1);
    if (settings.pres_pen_openai !== undefined) generate_data.presence_penalty = Math.min(Math.max(Number(settings.pres_pen_openai), 0), 1);
  }
  if (source === 'perplexity') {
    if (settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
    delete generate_data.stop;
  }
  if (source === 'groq') {
    delete generate_data.logprobs;
    delete generate_data.logit_bias;
    delete generate_data.top_logprobs;
    delete generate_data.n;
  }
  if (source === 'deepseek') {
    generate_data.top_p = generate_data.top_p || Number.EPSILON;
  }
  if (source === 'xai') {
    if (model.includes('grok-3-mini')) {
      delete generate_data.presence_penalty;
      delete generate_data.frequency_penalty;
      delete generate_data.stop;
    } else {
      delete generate_data.reasoning_effort;
    }
    if (model.includes('grok-4') || model.includes('grok-code')) {
      delete generate_data.presence_penalty;
      delete generate_data.frequency_penalty;
      if (!model.includes('grok-4-fast-non-reasoning')) delete generate_data.stop;
    }
  }
  if (source === 'pollinations') delete generate_data.max_tokens;
  if (source === 'electronhub' && settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
  if (source === 'chutes') {
    if (settings.min_p_openai !== undefined) generate_data.min_p = Number(settings.min_p_openai);
    if (Number(settings.top_k_openai) > 0) generate_data.top_k = Number(settings.top_k_openai);
    if (settings.repetition_penalty_openai !== undefined) generate_data.repetition_penalty = Number(settings.repetition_penalty_openai);
  }
  if (source === 'zai') {
    generate_data.top_p = generate_data.top_p || 0.01;
    generate_data.zai_endpoint = settings.zai_endpoint || 'common';
    delete generate_data.presence_penalty;
    delete generate_data.frequency_penalty;
  }
  if (source === 'nanogpt') {
    if (settings.top_k_openai !== undefined) generate_data.top_k = Number(settings.top_k_openai);
    if (settings.min_p_openai !== undefined) generate_data.min_p = Number(settings.min_p_openai);
    if (settings.repetition_penalty_openai !== undefined) generate_data.repetition_penalty = Number(settings.repetition_penalty_openai);
    if (settings.top_a_openai !== undefined) generate_data.top_a = Number(settings.top_a_openai);
  }

  const rawSeed = settings.seed;
  const numericSeed =
    rawSeed !== '' && rawSeed !== null && rawSeed !== undefined && typeof rawSeed !== 'boolean'
      ? Number(rawSeed)
      : NaN;
  if (seedSupportedSources.includes(source) && Number.isFinite(numericSeed) && numericSeed >= 0) {
    generate_data.seed = numericSeed;
  }

  if (
    (['openai', 'azure_openai'].includes(source) && /^(o1|o3|o4)/.test(model)) ||
    (source === 'openrouter' && /^openai\/(o1|o3|o4)/.test(model))
  ) {
    generate_data.max_completion_tokens = generate_data.max_tokens;
    delete generate_data.max_tokens;
    delete generate_data.stop;
    delete generate_data.logit_bias;
    delete generate_data.temperature;
    delete generate_data.top_p;
    delete generate_data.frequency_penalty;
    delete generate_data.presence_penalty;
    if (/^(openai\/)?o1/.test(model)) {
      for (const msg of generate_data.messages) {
        if (msg.role === 'system') msg.role = 'user';
      }
      delete generate_data.n;
    }
  }

  if (gptSources.includes(source) && /gpt-(?:[5-9]|[1-9]\d)/i.test(model)) {
    generate_data.max_completion_tokens = generate_data.max_tokens;
    delete generate_data.max_tokens;
    if (/gpt-5-chat-latest/i.test(model)) {
      // gpt-5-chat-latest retains sampling/stop parameters.
    } else if (/gpt-5\.(1|2)/i.test(model)) {
      delete generate_data.frequency_penalty;
      delete generate_data.presence_penalty;
      delete generate_data.logit_bias;
      delete generate_data.stop;
    } else {
      delete generate_data.temperature;
      delete generate_data.top_p;
      delete generate_data.frequency_penalty;
      delete generate_data.presence_penalty;
      delete generate_data.logit_bias;
      delete generate_data.stop;
    }
  }

  if (options.jsonSchema) {
    generate_data.json_schema = options.jsonSchema;
  }

  return { generate_data, stream, canMultiSwipe };
}

/**
 * 兼容旧版 SillyTavern（<= 1.12.12，缺少 /scripts/custom-request.js）：
 * 当 ChatCompletionService.sendRequest 不可用时，直接向 /api/backends/chat-completions/generate 发请求并解析非流式/SSE 流式返回。
 * ST >= 1.12.13 直接透传调用 ChatCompletionService.sendRequest。
 */
export async function sendChatCompletionCompat(
  native: Record<string, any>,
  requestPayload: Record<string, any>,
  signal: AbortSignal,
): Promise<any> {
  if (typeof native.customRequest?.ChatCompletionService?.sendRequest === 'function') {
    return native.customRequest.ChatCompletionService.sendRequest(requestPayload, false, signal);
  }
  const response = await native.host.fetch('/api/backends/chat-completions/generate', {
    method: 'POST',
    headers: native.script.getRequestHeaders(),
    cache: 'no-cache',
    body: JSON.stringify(requestPayload),
    signal,
  });
  if (!requestPayload.stream) {
    const text = await response.text();
    let json: any;
    try {
      json = text ? JSON.parse(text) : {};
    } catch {
      if (!response.ok) throw Error(`Chat completion request error: ${response.status} ${response.statusText} ${text}`.trim());
      throw Error('Chat completion response is not valid JSON');
    }
    if (!response.ok || json?.error) throw json;
    return json;
  }
  if (!response.ok) {
    const text = await response.text();
    let parsedError: unknown;
    try {
      parsedError = JSON.parse(text);
    } catch {
      parsedError = undefined;
    }
    if (parsedError && typeof parsedError === 'object') throw parsedError;
    throw Error(`Chat completion stream error: ${response.status} ${response.statusText} ${text}`.trim());
  }
  const getStreamingReply = native.openai?.getStreamingReply;
  return async function* legacyStream() {
    const reader = response.body?.getReader();
    if (!reader) return;
    const decoder = new TextDecoder();
    let buffer = '';
    let text = '';
    const state: { reasoning: string } = { reasoning: '' };
    const extractDelta = (parsed: any): string => {
      const beforeReasoning = state.reasoning;
      if (typeof getStreamingReply === 'function') {
        try {
          const piece = getStreamingReply(parsed, state);
          if (typeof piece === 'string' && piece) return piece;
          if (state.reasoning !== beforeReasoning) return '';
        } catch {
          // 回退到通用 SSE 字段解析
        }
      }
      const choice = parsed?.choices?.[0];
      const deltaReasoning = choice?.delta?.reasoning_content ?? choice?.delta?.reasoning ?? '';
      if (typeof deltaReasoning === 'string' && deltaReasoning && state.reasoning === beforeReasoning) {
        state.reasoning += deltaReasoning;
      }
      if (typeof choice?.delta?.content === 'string') return choice.delta.content;
      if (typeof parsed?.delta?.text === 'string') return parsed.delta.text;
      return '';
    };
    const processLine = (rawLine: string) => {
      const line = rawLine.trim();
      if (!line.startsWith('data:')) return null;
      const payload = line.slice(5).trim();
      if (!payload || payload === '[DONE]') return null;
      let parsed: any;
      try {
        parsed = JSON.parse(payload);
      } catch {
        return null;
      }
      if (parsed?.error) throw parsed;
      const prevReasoning = state.reasoning;
      const delta = extractDelta(parsed);
      if (delta || state.reasoning !== prevReasoning) {
        text += delta;
        return { text, state: { ...state } };
      }
      return null;
    };
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split(/\r?\n/);
        buffer = lines.pop() ?? '';
        for (const rawLine of lines) {
          const chunk = processLine(rawLine);
          if (chunk) yield chunk;
        }
      }
      buffer += decoder.decode();
      if (buffer.trim()) {
        for (const rawLine of buffer.split(/\r?\n/)) {
          const chunk = processLine(rawLine);
          if (chunk) yield chunk;
        }
      }
    } finally {
      reader.releaseLock();
    }
  };
}
