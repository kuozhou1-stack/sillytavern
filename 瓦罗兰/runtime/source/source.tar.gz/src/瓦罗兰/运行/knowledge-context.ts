import { mentionsRecordId } from './character-identity';

import type { State } from './core';
import { publicModelData } from './model-history';
import { locationDescription } from './map';
import { completeThoughtEnds, stripProtocol } from './message-protocol';
import { pendingPlayerMapLocations, validPlayerMapPosition } from './player-map-location';
import type { CharacterSelectionContext } from './character-roster';
import type { InformationRosterSettings } from './settings';
import { isExternalOrganization, organizationCatalog, organizationChangeFields, organizationDetails, organizationIdsForPerson, organizationVisibilityTag } from './organizations';
import { getOrganizationSettings, type ExternalOrganization } from './external-settings';
import { getLegalCharacterForms, pruneEmptyFields } from './character-static';
export { organizationVisibilityTag } from './organizations';


export type InformationKind = '地点' | '组织';
export type InformationMode = '自动' | '展开' | '仅名称';
const kinds: InformationKind[] = ['地点', '组织'];
const overridesKey = (kind: InformationKind) => kind === '地点' ? '地点覆盖' : '组织覆盖';
export type CharacterFormSelectionItem = { id: string; 形态: string };
export type InformationSelection = {
  人物?: string[];
  角色形态?: Record<string, string>;
  地点: string[];
  组织: string[];
};
export type InformationSelectionOptions = {
  characters?: CharacterSelectionContext;
  quotas?: Record<InformationKind, InformationRosterSettings>;
  chooseForms?: boolean;
  inputFloor?: number;
};

export function hasActiveMultiFormCharacters(state: State): boolean {
  return Object.entries(state.角色 ?? {}).some(
    ([id, person]) => !!person && !state._系统.角色停用标识[id] && getLegalCharacterForms(state, id, person).forms.length > 1,
  );
}

export const informationRecords = (state: State, kind: InformationKind) =>
  kind === '地点' ? state.地点 : organizationCatalog(state);

function formatLocationDirectoryLabel(state: State, record: State['地点'][string]): string | null {
  if (!record.名称) return record.名称;
  const area = record.片区id ? state.世界.片区[record.片区id] : undefined;
  if (!area?.名称) return record.名称;
  const layerPrefix = area.图层 === '里世界' ? '[里]' : area.图层 === '口袋维度' ? '[口袋]' : '';
  const shortArea = area.名称.replace(/[（(][^）)]*[）)]/g, '').split(/[·・—\-]/)[0].trim().slice(0, 6);
  return shortArea ? `${layerPrefix}${shortArea}·${record.名称}` : `${layerPrefix}${record.名称}`;
}

function formatOrganizationDirectoryLabel(record: ExternalOrganization): string | null {
  if (!record.名称) return null;
  const tag = organizationVisibilityTag(record);
  return (tag ? `[${tag}]` : '') + record.名称 + (record.职能 ? '｜' + record.职能 : '');
}

/** 自由开场（无预设起点且没有选出相应资料）时，按玩家身份/背景锚定表世界核心地标与公开/双面组织兜底。 */
export function ensureFreeOpeningInformation(state: State, quotas?: Record<InformationKind, InformationRosterSettings>): State {
  if (
    !state._系统.建档完成 ||
    Object.keys(state._系统.已计轮事件).length > 0 ||
    state.玩家.当前状态.当前地点id ||
    (state._系统.资料加载.地点.length > 0 && state._系统.资料加载.组织.length > 0)
  ) {
    return state;
  }
  const playerText = [
    state.玩家.身份.身份,
    state.玩家.身份.社会身份,
    state.玩家.身份.工作或就读单位,
    state.玩家.背景.成长背景,
    state.玩家.背景.教育经历,
    state.玩家.背景.当前生活背景,
  ]
    .filter(Boolean)
    .join(' ');
  const surfacePlaces = Object.entries(state.地点).filter(([id, loc]) => {
    if (state._系统.资料加载.地点覆盖[id] === '仅名称') return false;
    const area = loc.片区id ? state.世界.片区[loc.片区id] : undefined;
    return !area || area.图层 === '表世界';
  });
  const placeScore = ([id, loc]: [string, State['地点'][string]]) => {
    let s = loc.片区id && loc.片区id === state._系统.资料加载.开局片区id ? 120 : loc.片区id === 'area_01' ? 40 : 10;
    if (loc.层级 === '建筑') s += 5;
    const label = `${loc.名称 ?? ''} ${loc.类型 ?? ''}`;
    if (/学|校|院|研|课/.test(playerText) && /学院|高中|学园|礼堂/.test(label)) s += 50;
    else if (/音|演|歌|艺|星/.test(playerText) && /星芒|歌剧|音乐|舞台|艺术/.test(label)) s += 50;
    else if (/商|店|甜|咖啡|温泉/.test(playerText) && /甜心|咖啡|温泉|商业|广场/.test(label)) s += 45;
    else if (['01-1', '01-1-01', '01-4-01', '01-2-01'].includes(id)) s += 25;
    return s;
  };
  const placeLimit = state._系统.资料加载.地点.length ? 0 : Math.min(quotas?.地点.limit ?? 4, 4);
  const pickedPlaces = surfacePlaces
    .sort((a, b) => placeScore(b) - placeScore(a))
    .slice(0, placeLimit)
    .map(([id]) => id);

  const surfaceOrgs = Object.entries(organizationCatalog(state)).filter(([id, org]) => {
    if (state._系统.资料加载.组织覆盖[id] === '仅名称') return false;
    const tag = organizationVisibilityTag(org);
    return tag === null || tag === '公开' || tag === '双面';
  });
  const orgScore = ([id, org]: [string, ExternalOrganization]) => {
    let s = organizationVisibilityTag(org) === '公开' ? 25 : 20;
    const label = (org.名称 ?? '') + (org.职能 ?? '');
    if (/学|校|院|研|课/.test(playerText) && /学院|校园|研究/.test(label)) s += 50;
    else if (/音|演|歌|艺|星/.test(playerText) && /音乐|演艺|乐团|偶像/.test(label)) s += 50;
    else if (/甜|咖啡/.test(playerText) && /甜|咖啡/.test(label)) s += 50;
    else if (/温泉/.test(playerText) && /温泉/.test(label)) s += 50;
    else if (id === 'org_star_ring_council') s += 30;
    return s;
  };
  const orgLimit = state._系统.资料加载.组织.length ? 0 : Math.min(quotas?.组织.limit ?? 2, 2);
  const pickedOrgs = surfaceOrgs
    .sort((a, b) => orgScore(b) - orgScore(a))
    .slice(0, orgLimit)
    .map(([id]) => id);

  if (!pickedPlaces.length && !pickedOrgs.length) return state;
  const result: State = JSON.parse(JSON.stringify(state));
  result._系统.资料加载.地点 = [...new Set([...result._系统.资料加载.地点, ...pickedPlaces])];
  result._系统.资料加载.组织 = [...new Set([...result._系统.资料加载.组织, ...pickedOrgs])];
  return result;
}

function informationPins(state: State, kind: InformationKind, input: string) {
  const override = state._系统.资料加载[overridesKey(kind)];
  const records = informationRecords(state, kind);
  const memberships = kind === '组织' ? organizationIdsForPerson(state, state.玩家.id, state.玩家.身份.组织id) : [];
  return Object.keys(records).filter(id => override[id] !== '仅名称' && (
    override[id] === '展开' || (kind === '地点' && id === state.玩家.当前状态.当前地点id) ||
    (kind === '组织' && memberships.includes(id)) ||
    mentionsRecordId(input, id) || (!!records[id].名称 && input.includes(records[id].名称!))));
}

function informationQueue(state: State, kind: InformationKind) {
  const eligible = Object.keys(informationRecords(state, kind)).filter(id => !state._系统.资料加载[overridesKey(kind)][id]);
  return [...new Set([...(state._系统.资料加载.轮候?.[kind] ?? []).filter(id => eligible.includes(id)), ...eligible])];
}

export function informationRosterContext(state: State, input: string, quotas: Record<InformationKind, InformationRosterSettings>) {
  return Object.fromEntries(kinds.map(kind => {
    const previous = effectiveInformationIds(state, kind), pinned = informationPins(state, kind, input);
    return [kind, { 上限: quotas[kind].limit, 每轮最多轮换: quotas[kind].rotation,
      已展开id: [...previous], 保留id: pinned,
      轮候建议id: informationQueue(state, kind).filter(id => !previous.has(id) && !pinned.includes(id)).slice(0, quotas[kind].rotation),
    }];
  }));
}

export class InformationNotLoadedError extends Error {
  constructor(kind: InformationKind, id: string) {
    super('请先展开资料再更新：' + kind + '/' + id);
  }
}

/** Load only explicit references and the current place; manual name-only overrides remain authoritative. */
export function ensureInformationContext(state: State, input: string): State {
  const requests = kinds.flatMap(kind => Object.entries(informationRecords(state, kind))
    .filter(([id, record]) => (kind === '地点' && id === state.玩家.当前状态.当前地点id) ||
      mentionsRecordId(input, id) || (!!record.名称 && input.includes(record.名称)))
    .map(([id]) => ({ kind, id })));
  return expandInformationRecords(state, requests);
}

function expandInformationRecords(state: State, requests: { kind: InformationKind; id: string }[]): State {
  let result = state;
  for (const { kind, id } of requests) {
    if (!Object.hasOwn(informationRecords(state, kind), id) || state._系统.资料加载[overridesKey(kind)][id] === '仅名称' ||
        effectiveInformationIds(result, kind).has(id)) continue;
    if (result === state) result = JSON.parse(JSON.stringify(state));
    result._系统.资料加载[kind].push(id);
  }
  return result;
}

/** A rejected patch identifies missing context, never authority to apply its guessed values. */
export function expandInformationForRetry(state: State, commands: any[]): State {
  const requests = commands.filter(command => command?.op !== 'test').flatMap(command => {
    if (typeof command?.path !== 'string') return [];
    const [kind, id, field] = command.path.split('/').slice(1)
      .map((part: string) => part.replace(/~1/g, '/').replace(/~0/g, '~'));
    const firstOrgChange = kind === '组织' && isExternalOrganization(state, id) && ['insert', 'add'].includes(command.op);
    return kinds.includes(kind as InformationKind) && id && (field || firstOrgChange)
      ? [{ kind: kind as InformationKind, id }] : [];
  });
  return expandInformationRecords(state, requests);
}

export function effectiveInformationIds(state: State, kind: InformationKind): Set<string> {
  const control = state._系统.资料加载;
  const records = informationRecords(state, kind);
  const selected = new Set((control?.[kind] ?? []).filter(id => Object.hasOwn(records, id)));
  for (const [id, mode] of Object.entries(control?.[overridesKey(kind)] ?? {})) {
    if (!Object.hasOwn(records, id)) continue;
    if (mode === '展开') selected.add(id);
    else selected.delete(id);
  }
  return selected;
}

/** Manual expand/name-only choices already decide every record; a model cannot change them. */
export function hasAutomaticInformation(state: State): boolean {
  return kinds.some(kind => Object.keys(informationRecords(state, kind))
    .some(id => !Object.hasOwn(state._系统.资料加载[overridesKey(kind)], id)));
}

const retiredOrganizationFields = ['编号', '象限', '公开性质', '场所id', '已知成员'] as const;

/** Only the request projection is reduced. Never persist it as a complete MVU state. */
export function projectWorldInformation(state: State, result: Record<string, any> = publicModelData(state)) {
  const districts = Object.fromEntries(Object.entries(result.世界.片区).map(([id, area]) =>
    [id, _.omit(area as State['世界']['片区'][string], '地图中心')]));
  const projected: Record<string, any> = { ...result, 世界: { ...result.世界, 片区: districts } };
  const places = effectiveInformationIds(state, '地点');
  projected.地点 = Object.fromEntries(Object.entries(state.地点).map(([id, record]) => {
    if (!places.has(id)) return [id, { 名称: record.名称 }];
    const detail = publicModelData(record, ['地点', id]);
    delete detail.地图位置;
    detail.简介 = locationDescription(detail.简介);
    if (_.isEmpty(detail.动态状态)) delete detail.动态状态;
    if (_.isEmpty(detail.关联人物)) delete detail.关联人物;
    return [id, _.omitBy(detail, value => value == null || value === '')];
  }));
  const selected = effectiveInformationIds(state, '组织');
  const catalog = organizationCatalog(state);
  projected.组织 = Object.fromEntries(Object.entries(catalog).map(([id, row]) =>
    [id, selected.has(id) ? { 名称: row.名称, ...pruneEmptyFields(_.omit(state.组织[id], retiredOrganizationFields)) } : { 名称: row.名称 }]));
  projected.玩家 = { ...projected.玩家, 身份: { ...projected.玩家.身份,
    组织id: organizationIdsForPerson(state, state.玩家.id, state.玩家.身份.组织id, catalog) } };
  projected.角色 = Object.fromEntries(Object.entries(projected.角色).map(([id, person]: [string, any]) =>
    [id, { ...person, 组织id: organizationIdsForPerson(state, id, person.组织id ?? [], catalog) }]));
  return projected;
}

export function organizationReferenceContext(state: State, purpose: 'story' | 'inline' | 'variables') {
  const selected = effectiveInformationIds(state, '组织');
  if (!selected.size) return undefined;
  const catalog = organizationCatalog(state);
  const places = effectiveInformationIds(state, '地点');
  const people = new Set([state.玩家.id, ...Object.keys(state.角色).filter(id => !state._系统.角色停用标识[id])]);
  const profiles = Object.fromEntries([...selected].flatMap(id => {
    const row = catalog[id], details = organizationDetails(row);
    const members = Object.fromEntries(Object.entries(details.已知成员).filter(([person]) => people.has(person)));
    const bases = Object.fromEntries(details.场所id.filter(place => places.has(place)).map(place => [place, row.据点?.[place] ?? '据点']));
    const facts = { 当前成员: members, 当前据点: bases };
    const narrative = purpose !== 'variables' && isExternalOrganization(state, id)
      ? _.pick(row, ['职能', '象限', '公开性质', '对外形象', '活动范围', '内部架构', '日常运作与交互', '情报范围',
        '行事底线', '私密内情', '分支', '内部分歧', '简介', '规则']) : {};
    const info = pruneEmptyFields({ ...narrative, ...facts });
    return info ? [[id, info]] : [];
  }));
  const relations = purpose === 'variables' ? [] : (getOrganizationSettings().organizationRelations ?? [])
    .filter(rel => rel.组织id.every(id => selected.has(id)));
  return pruneEmptyFields({ 档案: profiles, 组织关系: relations });
}

export function prepareInformationCommand(state: State, kind: InformationKind, id: string, mode: InformationMode) {
  if (!kinds.includes(kind) || !['自动', '展开', '仅名称'].includes(mode))
    throw Error('未知的资料开关操作');
  if (!Object.hasOwn(informationRecords(state, kind), id)) throw Error('资料不存在或已变化：' + id);
  const result: State = JSON.parse(JSON.stringify(state));
  const override = result._系统.资料加载[overridesKey(kind)];
  if (mode === '自动') delete override[id];
  else override[id] = mode;
  result._系统.资料加载.选择依据 = null;
  return result;
}

function informationHistoryText(text: string) {
  const story = stripProtocol(text);
  const openings = [...story.matchAll(/<(?:thinking|think)\b/gi)];
  let visible = '', cursor = 0;
  if (openings.length) {
    const ends = completeThoughtEnds(story);
    for (const { index } of openings) {
      const end = ends.get(index);
      if (end === undefined || index < cursor) continue;
      visible += story.slice(cursor, index);
      cursor = end;
    }
  }
  return (visible + story.slice(cursor))
    .replace(/<status_current_variable>[\s\S]*?<\/status_current_variable>/gi, '').trim();
}

export function recentInformationFloors<T extends { role: string; text: string; id?: number }>(recent: T[], inputFloor?: number) {
  const history: T[] = [];
  for (let i = recent.length - 1; i >= 0 && history.length < 2; i--) {
    const item = recent[i];
    if (item.role === 'system' || (inputFloor !== undefined && item.id === inputFloor)) continue;
    const text = informationHistoryText(item.text);
    if (text) history.unshift({ ...item, text });
  }
  return history;
}

export function informationSelectionPrompt(
  state: State, input: string, recent: { role: string; text: string; id?: number }[] = [],
  options: InformationSelectionOptions = {},
): GenerateConfig {
  const chooseCharacters = Boolean(options.characters);
  const chooseForms = options.chooseForms ?? (options.characters?.存在多形态候选 ?? hasActiveMultiFormCharacters(state));
  const activeMultiFormDirectory = !chooseCharacters && chooseForms
    ? Object.fromEntries(
        Object.entries(state.角色 ?? {})
          .filter(([id, person]) => !!person && !state._系统.角色停用标识[id])
          .flatMap(([id, person]) => {
            const spec = getLegalCharacterForms(state, id, person);
            return spec.forms.length > 1
              ? [[id, `${person.姓名 ?? id}|已开|当前:${person.当前形态 ?? spec.defaultForm}|形态:${spec.forms.join(',')}`]]
              : [];
          }),
      )
    : undefined;

  const catalog = organizationCatalog(state, options.characters?.候选组织id);
  const directory = {
    地点: Object.fromEntries(Object.entries(state.地点).map(([id, value]) => [id, formatLocationDirectoryLabel(state, value)])),
    组织: Object.fromEntries(Object.entries(catalog).map(([id, value]) => [id, formatOrganizationDirectoryLabel(value)])),
    ...(options.characters ? { 人物: options.characters.目录 } : activeMultiFormDirectory ? { 人物: activeMultiFormDirectory } : {}),
  };

  const history = recentInformationFloors(recent, options.inputFloor).map(({ role, text }) => ({ role, text }));


  const participants = options.characters
    ? Object.entries(state.角色).filter(([id]) => options.characters!.保留人物id.includes(id))
    : Object.entries(state.角色);
  const activeParticipants = participants.map(([, person]) => person);
  const references = [...new Set([
    state.玩家.当前状态.当前地点id,
    state.玩家.生活.住处id,
    ...(options.characters?.关联地点id ?? []),
    ...activeParticipants.flatMap(person => [
      person.当前地点id, person.生活.住处id, ...person.生活.工作地点id, ...person.生活.常去地点id,
    ]),
  ].filter((id): id is string => !!id && Object.hasOwn(state.地点, id)))];
  const organizations = [...new Set([
    ...organizationIdsForPerson(state, state.玩家.id, state.玩家.身份.组织id, catalog),
    ...(options.characters?.关联组织id ?? []),
    ...participants.flatMap(([id, person]) => organizationIdsForPerson(state, id, person.组织id, catalog)),
  ])].filter(id => Object.hasOwn(catalog, id));

  const isOpening = options.characters?.开局 ?? !Object.keys(state._系统.已计轮事件).length;
  const freeOpeningRule = isOpening && !state.玩家.当前状态.当前地点id
    ? '当前为自由开场（未预设起点）：请结合玩家身份、背景、所选片区与时间，主动从表世界公共枢纽（无[里]前缀）选出2～4处契合切入点的地点、1～2个[公开]或[双面]组织及合理配额的公开形态人物；若玩家设定无明确里世界/黑市线索，严禁落入[里]地点、[隐秘]组织或隐秘变身形态。'
    : '';
  const characterCompactRule = options.characters
    ? '人物目录每项格式为「姓名|主/次|公开身份|常驻地id|组织id|状态与玩家关系|形态:默认,备选...」（第一项是默认形态，当前与默认不同时另列“当前”；单形态省略形态段）。'
    : '';
  const orgLayerRule =
    '地点带[里]/[口袋]前缀为特殊图层（无前缀为表世界）；组织带[公开]/[双面]/[隐秘]标识（表世界日常可正常选用[公开]与[双面]的公开面，无里世界线索勿选[隐秘]）。' +
    '防设定沉睡轮换：在满足本场直接参与者与核心地点后，若人物或组织配额仍有余量，鼓励结合当前片区、当季盛典、背景热搜/周刊线索或玩家关注方向，顺带推荐1位契合环境但近期未活跃的候补人物或1个尚未展开的相关公开/双面组织作自然偶遇或背景引信（保持表世界公开面，不强塞无关人物或剧透隐秘身份）。';
  const formRule = chooseForms
    ? '角色形态数组仅针对本轮选中/已开启的多形态人物按需填写{"id":"人物ID","形态":"合法形态名"}（保持现状时填[]，自由开局优先公开默认形态，上一场处于特殊形态而本场已回归公开日常时应明确选回公开形态）：候选同时含「日常」与角色同名键时，「日常」代表现代都市常服/通勤装，「角色同名」代表本源武装/战斗态（日常起居与社交一律选日常）；职业/舞台形态按营业或演出场景切换；「星之守护者」「黑色玫瑰」等隐秘形态除非本轮明确发生里世界战斗、秘密集会或变身，严禁提前剧透切换。'
    : '';

  const fields = [
    ...(chooseCharacters ? ['人物'] : []),
    ...(chooseForms ? ['角色形态'] : []),
    ...kinds,
  ];
  const schemaProperties: Record<string, any> = {};
  for (const field of fields) {
    schemaProperties[field] = field === '角色形态'
      ? {
          type: 'array',
          items: {
            type: 'object',
            properties: { id: { type: 'string' }, 形态: { type: 'string' } },
            required: ['id', '形态'],
            additionalProperties: false,
          },
        }
      : { type: 'array', items: { type: 'string' } };
  }
  const formatLine = (field: string) =>
    field === '角色形态'
      ? `"角色形态": [{"id": "多形态人物ID", "形态": "目录中列出的合法形态名"}]`
      : `"${field}": ["目录中的${field}ID"]`;
  const characterContextPayload = options.characters
    ? (() => {
        const { 目录: _dir, 关联地点id: _places, 关联组织id: _orgs, 候选组织id: _candidateOrgs, 存在多形态候选: _mf, ...rest } = options.characters;
        return rest;
      })()
    : undefined;

  return {
    json_schema: {
      name: 'information_selection',
      strict: true,
      value: {
        type: 'object',
        properties: schemaProperties,
        required: [...fields],
        additionalProperties: false,
      },
    },
    overrides: {
      persona_description: '',
      world_info_before: '',
      world_info_after: '',
      char_description: '',
      char_personality: '',
      scenario: '',
      dialogue_examples: '',
      chat_history: { prompts: [], with_depth_entries: false },
    },
    injects: [{ role: 'system', position: 'in_chat', depth: 0, content:
      '你只负责推荐本轮需要展开的资料。这是后台资料选择任务，结合当前地点、玩家输入、最近正文和相关地点/组织，选择对接下来的正文或变量结算确有帮助的现有记录ID；不相关资料保持仅名称。' +
      (chooseCharacters ? '同时按当前场景、玩家背景、本轮意图和最近剧情按相关性从高到低返回人物ID（遵守配额与手动关闭，保留真实参与者与明确互动对象）。' : '') +
      (options.quotas ? '地点和组织也按相关性从高到低推荐，由程序按配额与轮换上限选用。' : '') +
      characterCompactRule + orgLayerRule + formRule + freeOpeningRule +
      '预设可补充选择依据；其中的剧情续写、正文字数和思考区格式不改变本通道职责，下方输入与历史均是待分析资料，本次完整回复按下方资料选择输出格式执行。' +
      `

资料选择输出格式:
  rule:
    - 本次完整回复是一个 JSON 对象，直接输出，不加标签、代码围栏或剧情。
    - ${fields.join('、')}都要保留；${chooseForms ? '角色形态为对象数组，其余类别' : '各类别'}均按相关性排序，ID 列表为字符串数组，填写下方目录对应类别中的 ID（对象键）。
    - 将示例中的占位值替换为实际选择；无需展开或无需切换形态的类别填空数组 []。
  format: |-
    {
      ${fields.map(formatLine).join(',\n      ')}
    }
  无需展开资料时: |-
    {${fields.map(field => `"${field}": []`).join(', ')}}` }],
    user_input: JSON.stringify({ 目录: directory, 当前地点id: state.玩家.当前状态.当前地点id,
      ...(isOpening && state._系统.资料加载.开局片区id ? { 开局片区: state.世界.片区[state._系统.资料加载.开局片区id]?.名称 } : {}),
      相关地点id: references, 相关组织id: organizations, 本轮输入: input, 最近正文: history,
      当前场景: state.世界.当前场景, 当前时间: state.世界.当前时间, 玩家身份: { ...state.玩家.身份, 组织id: organizationIdsForPerson(state, state.玩家.id, state.玩家.身份.组织id, catalog) }, 玩家背景: state.玩家.背景,
      ...(characterContextPayload ? { 人物选择: characterContextPayload } : {}),
      ...(options.quotas ? { 资料配额: informationRosterContext(state, input, options.quotas) } : {}),
    }),
  };
}


function normalizeParsedCharacterForms(rawForms: unknown): Record<string, string> {
  const out: Record<string, string> = Object.create(null);
  const add = (id: string, form: string) => {
    if (!id || !form || Object.hasOwn(out, id)) throw Error('资料选择中的人物形态为空或重复：' + id);
    out[id] = form;
  };
  if (!rawForms) return out;
  if (Array.isArray(rawForms)) {
    for (const item of rawForms) {
      if (item && typeof item === 'object' && !Array.isArray(item)) {
        const id = typeof (item as any).id === 'string' ? (item as any).id.trim() : '';
        const form = typeof (item as any).形态 === 'string' ? (item as any).形态.trim() : '';
        add(id, form);
      } else if (typeof item === 'string') {
        const sep = item.indexOf(':');
        if (sep <= 0) throw Error('角色形态缺少人物 ID 或形态名');
        add(item.slice(0, sep).trim(), item.slice(sep + 1).trim());
      }
    }
    return out;
  }
  if (typeof rawForms === 'object') {
    for (const [id, form] of Object.entries(rawForms as Record<string, unknown>)) {
      add(id.trim(), String(form).trim());
    }
  }
  return out;
}

const CharacterFormSchema = z.union([
  z.array(z.union([
    z.strictObject({ id: z.string(), 形态: z.string() }),
    z.string(),
  ])),
  z.record(z.string(), z.string()),
]);

export function parseInformationSelection(text: string, characters = false, allowForms = characters): InformationSelection {
  const openings = [...text.matchAll(/<InformationSelection\b[^<>]*>/gi)];
  const thoughtEnds = [...completeThoughtEnds(text)];
  // Skip thought examples before pairing tags: an unclosed mention there must not consume the real result.
  const outside = openings.filter(opening => !thoughtEnds.some(([start, end]) => opening.index >= start && opening.index < end));
  const readBlock = (candidates: RegExpMatchArray[]) => {
    for (const opening of [...candidates].reverse()) {
      const start = opening.index! + opening[0].length;
      const closing = /<\/InformationSelection\s*>/i.exec(text.slice(start));
      if (closing) return text.slice(start, start + closing.index);
    }
    return undefined;
  };
  // Allow a preset to wrap the whole answer, and keep legacy JSON/fenced replies readable.
  let clean = (readBlock(outside) ?? readBlock(openings) ?? text).trim(), previous: string;
  do {
    previous = clean;
    clean = clean.replace(/^```(?:json)?\s*([\s\S]*?)\s*```$/i, '$1').trim();
    const outer = clean.match(/^<([\w:.-]+)\b[^>]*>\s*([\s\S]*?)\s*<\/\1\s*>$/i);
    if (outer) clean = outer[2].trim();
  } while (clean !== previous);
  let raw: unknown;
  try { raw = JSON.parse(clean); } catch { throw Error('资料选择没有返回有效JSON，原资料保留'); }
  if (characters) {
    const parsed = z.strictObject({
      人物: z.array(z.string()),
      ...(allowForms ? { 角色形态: CharacterFormSchema.optional() } : {}),
      地点: z.array(z.string()),
      组织: z.array(z.string()),
    }).parse(raw);
    return {
      人物: parsed.人物,
      ...(parsed.角色形态 !== undefined ? { 角色形态: normalizeParsedCharacterForms(parsed.角色形态) } : {}),
      地点: parsed.地点,
      组织: parsed.组织,
    };
  }
  if (allowForms) {
    const parsed = z.strictObject({
      角色形态: CharacterFormSchema.optional(),
      地点: z.array(z.string()),
      组织: z.array(z.string()),
    }).parse(raw);
    return {
      ...(parsed.角色形态 !== undefined ? { 角色形态: normalizeParsedCharacterForms(parsed.角色形态) } : {}),
      地点: parsed.地点,
      组织: parsed.组织,
    };
  }
  return z.strictObject({ 地点: z.array(z.string()), 组织: z.array(z.string()) }).parse(raw);
}

export function applyInformationSelectionValues(state: State, selection: InformationSelection, key: string, retain = false,
  quotas?: Record<InformationKind, InformationRosterSettings>, input = '', candidateOrgIds: string[] = []): State {
  const result: State = JSON.parse(JSON.stringify(state));
  for (const kind of kinds) {
    const records = kind === '组织' ? organizationCatalog(state, candidateOrgIds) : state.地点;
    if (selection[kind].some(id => !Object.hasOwn(records, id)))
      throw Error('资料选择包含不存在的' + kind + 'ID，原选择保留');
    if (!quotas || retain) {
      // Settlement may need additional old values; never rotate away its existing context.
      result._系统.资料加载[kind] = [...new Set([
        ...(retain ? state._系统.资料加载[kind] : []), ...selection[kind],
      ])].filter(id => Object.hasOwn(records, id));
      continue;
    }
    const pinned = informationPins(state, kind, input), previous = effectiveInformationIds(state, kind);
    const selected = new Set(pinned), { limit, rotation } = quotas[kind];
    let added = 0;
    const allowance = state._系统.资料加载.选择依据 === null ? limit : Math.max(0, limit - previous.size) + rotation;
    for (const id of selection[kind]) {
      if (selected.size >= limit) break;
      if (selected.has(id) || state._系统.资料加载[overridesKey(kind)][id] === '仅名称') continue;
      if (!previous.has(id) && added >= allowance) continue;
      if (!previous.has(id)) added++;
      selected.add(id);
    }
    result._系统.资料加载[kind] = [...selected];
    const queue = informationQueue(state, kind);
    const offered = queue.filter(id => !previous.has(id) && !pinned.includes(id)).slice(0, rotation);
    const served = new Set([...offered, ...selected]);
    result._系统.资料加载.轮候[kind] = [...queue.filter(id => !served.has(id)), ...queue.filter(id => served.has(id))];
  }
  result._系统.资料加载.选择依据 = key;
  return result;
}

export function applyInformationSelection(state: State, text: string, key: string, retain = false): State {
  return applyInformationSelectionValues(state, parseInformationSelection(text), key, retain);
}

export function needsInformationSelection(state: State, text: string) {
  return kinds.some(kind => {
    const selected = effectiveInformationIds(state, kind);
    const override = state._系统.资料加载[overridesKey(kind)];
    return Object.entries(informationRecords(state, kind)).some(([id, value]) =>
      !selected.has(id) && override[id] !== '仅名称' &&
      (mentionsRecordId(text, id) || (!!value.名称 && text.includes(value.名称))));
  });
}

export const informationPromptRule =
  '地点与组织按需展开。organization_reference 是本轮只读设定。预置组织只写成员变更、据点变更、活动日程id；首次变动可新建该 ID 的本局记录。按当轮行程和事件确定在场人物。只更新已展开资料或定位任务授权的标点。';

/** Keep writes within the information supplied to this request. */
export function assertInformationPatch(state: State, commands: any[]) {
  const mapCompletion = new Set(pendingPlayerMapLocations(state).map(place => place.id));
  const parts = (path: unknown) => typeof path === 'string'
    ? path.split('/').slice(1).map(part => part.replace(/~1/g, '/').replace(/~0/g, '~')) : [];
  for (const command of commands) {
    if (command?.op === 'test') continue;
    const target = parts(command?.path ?? command?.to);
    if (command?.path === '' && kinds.some(kind => Object.keys(informationRecords(state, kind)).length))
      throw Error('不能用局部提示词投影替换整个存档');
    for (const route of [target, ...(command?.op === 'move' ? [parts(command.from)] : [])]) {
      const [root, id] = route;
      if (!kinds.includes(root as InformationKind)) continue;
      const kind = root as InformationKind;
      if (!id) throw Error('不能替换或删除整个地点/组织集合：' + kind);
      const externalOrg = kind === '组织' && isExternalOrganization(state, id);
      if (!externalOrg && !Object.hasOwn(informationRecords(state, kind), id)) continue;
      const authorizedMapField = route === target && kind === '地点' && mapCompletion.has(id) &&
        ['add', 'replace', 'insert'].includes(command.op) && route[2] === '地图位置' &&
        (route.length === 3 || (route.length === 4 && ['x', 'y', '精度'].includes(route[3])));
      if (!effectiveInformationIds(state, kind).has(id) && !authorizedMapField)
        throw new InformationNotLoadedError(kind, id);
      if (externalOrg) {
        if (route.length === 2 && route === target && ['insert', 'add'].includes(command.op) && !state.组织[id] &&
            _.isPlainObject(command.value) && Object.keys(command.value).every(key => organizationChangeFields.some(field => field === key))) continue;
        if (!organizationChangeFields.some(field => field === route[2]))
          throw Error('预置组织只允许写入本局成员变更、据点变更和活动日程id：' + id);
      }
    }
  }
}

/** The full stored records are authoritative even when the request only saw their names. */
export function assertInformationUnchanged(before: State, after: State) {
  const expandedOrgs = effectiveInformationIds(before, '组织');
  for (const id of new Set([...Object.keys(before.组织), ...Object.keys(after.组织)])) {
    const prior = before.组织[id], next = after.组织[id];
    if (_.isEqual(prior, next)) continue;
    if (next && !_.isEqual(_.pick(prior, retiredOrganizationFields), _.pick(next, retiredOrganizationFields)))
      throw Error('停止写入已废弃的组织字段：' + id);
    if (!isExternalOrganization(before, id)) continue;
    if (!expandedOrgs.has(id)) throw new InformationNotLoadedError('组织', id);
    if (!_.isEqual(_.omit(prior, organizationChangeFields), _.omit(next, organizationChangeFields)))
      throw Error('结算改变了预置组织的档案字段：' + id);
  }
  const mapCompletion = new Set(pendingPlayerMapLocations(before).map(place => place.id));
  for (const kind of kinds) {
    const selected = effectiveInformationIds(before, kind);
    for (const [id, record] of Object.entries(before[kind])) {
      if (!Object.hasOwn(after[kind], id)) continue;
      if (kind === '地点' && mapCompletion.has(id) &&
          !_.isEqual(before.地点[id].地图位置, after.地点[id].地图位置) && !validPlayerMapPosition(after.地点[id], after))
        throw Error('玩家自设地点补点必须一次提供所属地区内的完整有效坐标：' + id);
      const authorizedMapChange = kind === '地点' && mapCompletion.has(id) &&
        validPlayerMapPosition(after.地点[id], after) &&
        _.isEqual(record, { ...after.地点[id], 地图位置: before.地点[id].地图位置 });
      if (!selected.has(id) && !authorizedMapChange && !_.isEqual(record, after[kind][id]))
        throw Error('未展开的资料必须保留原记录：' + kind + '/' + id);
    }
  }
}

