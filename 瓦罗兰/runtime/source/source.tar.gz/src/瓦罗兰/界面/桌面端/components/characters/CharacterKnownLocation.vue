<template>
  <div class="cw-known-location">
    <h4>行踪线索</h4>
    <p v-if="char.上次已知地点id">
      上次已知地点 · {{ resolveLocationName(state, char.上次已知地点id) }}
    </p>
    <p v-else>暂无已知地点</p>
    <p v-if="char.位置获知时间">获知时间 · {{ timeText(char.位置获知时间) }}</p>
    <p v-if="char.已明确不在场">已确认对方不在该地点。</p>
  </div>
</template>

<script setup lang="ts">
import { timeText } from '../../../../运行/phone';
import type { State } from '../../../../运行/core';
import { useWorldState } from '../../utils/context';
import { resolveLocationName } from '../../utils/entity';

type KnownPerson = State['玩家']['已知信息']['已认识人物'][string];
defineProps<{ char: Pick<KnownPerson, '上次已知地点id' | '位置获知时间' | '已明确不在场'> }>();
const state = useWorldState();
</script>

<style scoped lang="scss">
.cw-known-location {
  padding: 14px;
  border: 1px solid var(--cw-border);
  border-radius: var(--cw-radius);

  h4 {
    margin: 0 0 6px;
    font-size: 14px;
  }

  p {
    margin: 4px 0 0;
    color: var(--cw-text-secondary);
    font-size: 13px;
  }
}
</style>
