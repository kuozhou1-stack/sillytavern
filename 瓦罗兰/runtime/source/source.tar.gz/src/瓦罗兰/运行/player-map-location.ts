import type { State } from './core';
import { getExternalGeography } from './external-settings';

export function playerMapLocationIds(state: State): string[] {
  return [...new Set([
    state.玩家.当前状态.当前地点id,
    state.玩家.生活.住处id,
    ...state.玩家.生活.工作地点id,
    ...state.玩家.生活.常去地点id,
  ].filter((id): id is string => Boolean(id)))];
}

function resolveDistrict(state: State | undefined, districtId: string | null | undefined) {
  if (!districtId) return undefined;
  const geo = getExternalGeography();
  const ext = geo.districts.find(row => row.id === districtId);
  if (ext) return ext;
  const fallback = state?.世界?.片区?.[districtId];
  if (!fallback) return undefined;
  const cx = fallback.地图中心?.x ?? 500;
  const cy = fallback.地图中心?.y ?? 350;
  return {
    id: districtId,
    name: fallback.名称 ?? districtId,
    map: {
      bounds: {
        x: Math.max(0, cx - 90),
        y: Math.max(0, cy - 70),
        w: Math.min(180, 1000 - Math.max(0, cx - 90)),
        h: Math.min(140, 700 - Math.max(0, cy - 70)),
      },
      zones: [],
    },
  };
}

/** 只补有描述、玩家已知且属于其当前生活引用的自设地址；外置预置点和已有坐标保留。 */
export function pendingPlayerMapLocations(state: State) {
  const geo = getExternalGeography();
  return playerMapLocationIds(state).flatMap(id => {
    const place = state.地点[id];
    const district = resolveDistrict(state, place?.片区id);
    if (!place || !district || (!place.名称?.trim() && !place.简介?.trim()) ||
        !Object.hasOwn(state.玩家.已知信息.已知地点, id) || Object.hasOwn(geo.locationNames, id) ||
        place.地图位置.x !== null || place.地图位置.y !== null || place.地图位置.精度 === '地点') return [];
    return [{ id, 名称: place.名称, 简介: place.简介, 片区id: place.片区id, district }];
  });
}

export function playerMapLocationPrompt(state: State, heading = '玩家') {
  const requests = pendingPlayerMapLocations(state);
  if (!requests.length) return '';
  const districtIds = new Set(requests.map(row => row.片区id));
  const maps = [...districtIds].flatMap(districtId => {
    const row = resolveDistrict(state, districtId);
    if (!row) return [];
    return [{
      片区id: row.id,
      名称: row.name,
      世界范围: row.map.bounds,
      街区地标包围范围_局部坐标: row.map.zones,
      已知参照点: Object.entries(state.地点)
        .filter(([id, place]) => place.片区id === row.id &&
          Object.hasOwn(state.玩家.已知信息.已知地点, id) && place.地图位置.精度 === '地点')
        .map(([id, place]) => ({ id, 名称: place.名称, x: place.地图位置.x, y: place.地图位置.y })),
    }];
  });
  return `【${heading}自设地点定位】
玩家已授权为下列自设地点补齐地图标点（含旧存档尚未定位的开局地址）。按地点名称、描述和所属区域地段先选取1000×700局部坐标(u,v)，再换算写入世界坐标：x=世界范围.x+u/1000*世界范围.w，y=世界范围.y+v/700*世界范围.h（落在所属世界范围内，保留至三位小数，精度填“地点”）。仅更新清单内记录的地图位置，不改动其他字段或已有地点。
待定位地点：${JSON.stringify(requests.map(({ district, ...place }) => place))}
相关区域定位资料：${JSON.stringify(maps)}\n`;
}

export function validPlayerMapPosition(place: State['地点'][string] | undefined, state?: State) {
  const district = resolveDistrict(state, place?.片区id);
  const position = place?.地图位置;
  if (!district || position?.精度 !== '地点' || !Number.isFinite(position.x) || !Number.isFinite(position.y)) return false;
  const bounds = district.map.bounds;
  return position.x! >= bounds.x && position.x! <= bounds.x + bounds.w &&
    position.y! >= bounds.y && position.y! <= bounds.y + bounds.h;
}
