import { Schema } from '../schema';
import { copy, uid, type State } from './core';
import {
  bindTemplatePlayer,
  importCharacter,
  prepareImportedCharacter,
} from './characters';
import {
  applyCharacterFormSelections,
  bindCharacterStaticProfile,
  stageCharacterProfiles,
  splitCharacterAuthoring,
} from './character-static';
import {
  AutomaticRosterSchema,
  DEFAULT_CATEGORY_ID,
  LibrarySchema,
  libraryRevision,
  prepareAutomaticLibrary,
  type CharacterLibrary,
} from './character-library';
import { CharacterRosterSettingsSchema, type CharacterRosterSettings } from './settings';
import { planOpeningCharacters } from './opening';
import { ownAccount } from './phone';
import { ensurePhoneSession } from './phone-management';

/** 表单默认生成的关系槽不算点名；只保留玩家实际填写或勾选的初始联系。 */
export function initialConnectionIds(payload: { characters: any[]; details?: any }): string[] {
  const staged = new Set(payload.characters.map(character => character.id));
  return Object.entries(payload.details?.初始关系 ?? {}).filter(([id, raw]) => {
    if (!staged.has(id) || !raw || typeof raw !== 'object') return false;
    const row = raw as any;
    const entered = (key: 'relation' | 'basis') =>
      typeof row[key] === 'string' && Boolean(row[key].trim()) && (row[`${key}Edited`] ?? true);
    return row.contact === true || entered('relation') || entered('basis');
  }).map(([id]) => id);
}

export function createProfile(before: State, payload: { player: any; characters: any[]; details?: any }): State {
  return stageCharacterProfiles(() => prepareProfile(before, payload));
}

function prepareProfile(before: State, payload: Parameters<typeof createProfile>[1]): State {
  if (before._系统.建档完成) throw Error('已有建档不会被覆盖；请在酒馆新建聊天后建档');
  const draft: any = copy(before),
    p = payload.player;
  if (typeof p.姓名 !== 'string' || !p.姓名.trim()) throw Error('请填写姓名');
  const text = (v: any) => (v === '' || v === undefined ? null : v);
  draft.玩家.id ??= uid('player');
  for (const key of ['姓名', '称呼', '性别', '年龄', '种族'])
    if (p[key] !== undefined) draft.玩家[key] = text(p[key]);
  for (const key of ['身高', '体重', '体型', '面容', '发型', '显著特征', '整体外貌描述'])
    if (p[key] !== undefined) draft.玩家.外貌[key] = text(p[key]);
  for (const key of ['成长背景', '家庭背景', '教育经历', '重要过往', '当前生活背景'])
    if (p[key] !== undefined) draft.玩家.背景[key] = text(p[key]);
  if (p.身份 !== undefined || p.当前职业 !== undefined)
    draft.玩家.身份.身份 = text(p.身份 !== undefined ? p.身份 : p.当前职业);
  if (p.社会身份 !== undefined) draft.玩家.身份.社会身份 = text(p.社会身份);
  if (p.技能栏 !== undefined) draft.玩家.技能栏 = copy(p.技能栏);
  if (p.工作就读单位 !== undefined) draft.玩家.身份.工作或就读单位 = text(p.工作就读单位);
  for (const key of ['饱食度', '水分值', '体力值'])
    if (p[key] !== undefined) draft.玩家.当前状态[key] = text(p[key]);
  if (p.片区id && draft.世界.片区[p.片区id]) draft._系统.资料加载.开局片区id = p.片区id;
  if (p.住处描述 !== undefined) {
    const currentId = draft.玩家.生活.住处id;
    const residence = draft.地点[currentId];
    const name = p.住处描述?.trim();
    if (name) {
      const district = p.片区id === undefined ? residence?.片区id : p.片区id || null;
      if (!district || !draft.世界.片区[district]) throw Error('请选择住所所属片区');
      const id = currentId ?? uid('residence');
      draft.地点[id] = { ...(residence ?? { 类型: '住处' }), 名称: name, 片区id: district ?? null };
      draft.玩家.生活.住处id = id;
    } else if (residence?.名称) {
      // 解除玩家与住所的关联，其他人仍可引用这个地点。
      draft.玩家.生活.住处id = null;
    }
  }
  const details = payload.details ?? {};
  const selectedIds = new Set(payload.characters.map(character => character.id));
  for (const character of payload.characters) {
    const { id, __package, __imported, __staticProfile, ...record } = character;
    if (!id) throw Error('初始角色缺少稳定 ID');
    if (__package || __imported || __staticProfile) importCharacter(draft, id, record, __package, true, __staticProfile);
    else {
      draft.角色[id] = copy(record);
      bindTemplatePlayer(draft.角色[id], draft, id);
    }
  }
  // Advanced starting facts are explicitly entered and previewed, never AI-filled implicitly.
  const replaceArrays = (_obj: unknown, src: unknown) => (Array.isArray(src) ? copy(src) : undefined);
  for (const key of ['世界', '地点', '手机', '约定'])
    if (details[key]) draft[key] = _.mergeWith({}, draft[key], details[key], replaceArrays);
  if (details.玩家) draft.玩家 = _.mergeWith({}, draft.玩家, details.玩家, replaceArrays);
  for (const id of details.移除初始物品 ?? []) delete draft.玩家.物品栏[id];
  // 只有完整建档表单提供移除名单。局部调用未提交的人物继续沿用作者初值。
  for (const id of details.移除初始角色 ?? []) {
    if (selectedIds.has(id) || !Object.hasOwn(before.角色, id)) continue;
    // 姓名与停用标识保留历史引用的身份。既有联系人、投递、约定与其他人的记忆仍指向原 ID。
    const hasAccount = Object.values(draft.手机.账号).some((account: any) => account.人物id === id);
    if (hasAccount) {
      const character = before.角色[id];
      draft._系统.角色停用标识[id] = { 姓名: character.姓名, 版本: character._管理.版本 + 1 };
    }
    delete draft.角色[id];
    draft.世界.当前场景.在场人物 = draft.世界.当前场景.在场人物.filter((personId: string) => personId !== id);
  }
  for (const key of ['饱食度', '水分值', '体力值']) draft.玩家.当前状态[key] ??= 100;
  let playerAccount = ownAccount(draft);
  if (playerAccount && details.星讯账号名 !== undefined) {
    draft.手机.账号[playerAccount].账号名 = details.星讯账号名 || null;
  } else if (!playerAccount && details.星讯账号名) {
    playerAccount = uid('account');
    draft.手机.账号[playerAccount] = { 人物id: draft.玩家.id, 平台: '星讯', 账号名: details.星讯账号名, 昵称: p.姓名 };
  }
  for (const [id, relation] of Object.entries(details.初始关系 ?? {}) as any) {
    // Old browser drafts can retain a relationship after its staged character was removed.
    if (!selectedIds.has(id)) continue;
    if (!draft.角色[id]) throw Error('初始关系人物不存在');
    const network = draft.角色[id].关系网 ??= {};
    const existing = network[draft.玩家.id] ?? {};
    const relationEdited = relation.relationEdited ?? Boolean(relation.relation?.trim());
    const basisEdited = relation.basisEdited ?? Boolean(relation.basis?.trim());
    const relationship = relationEdited ? relation.relation?.trim() || null : existing.关系 ?? null;
    const basis = basisEdited ? relation.basis?.trim() || null : existing.关系备注 ?? null;
    if (((relationEdited && relationship) || (relation.contact && relation.contactEdited !== false)) && !basis)
      throw Error('请填写相识依据');
    if (relationEdited || basisEdited) network[draft.玩家.id] = { ...existing, 关系: relationship, 关系备注: basis };
    if (relation.contactEdited === false || (!relation.contact && !relation.contactEdited)) continue;
    const accounts = Object.entries(draft.手机.账号) as [string, State['手机']['账号'][string]][];
    let account = accounts.find(([, a]) => a.人物id === id && a.平台 === '星讯')?.[0];
    if (relation.contact) {
      if (!playerAccount) throw Error('交换联系方式前请建立玩家星讯账号');
      account ??= uid('account');
      draft.手机.账号[account] ??= { 人物id: id, 平台: '星讯', 昵称: draft.角色[id].姓名 };
      ensurePhoneSession(draft, '私聊', account);
    }
    if (!account || !playerAccount) continue;
    const contacts = Object.values(draft.手机.联系人) as State['手机']['联系人'][string][];
    for (const [owner, target] of [[playerAccount, account], [account, playerAccount]]) {
      const contact = contacts.find(row => row.本人账号id === owner && row.对方账号id === target);
      if (contact) contact.状态 = relation.contact ? '正常' : '移除';
      else if (relation.contact) draft.手机.联系人[uid('contact')] = { 本人账号id: owner, 对方账号id: target };
    }
  }
  draft.世界.开局时间 = copy(draft.世界.当前时间);
  draft.世界.天气._上次检查时间 = copy(draft.世界.当前时间);
  if (['天气状况', '气温', '风况', '适用区域'].some(key => draft.世界.天气[key] !== null))
    draft.世界.天气.生效时间 ??= copy(draft.世界.当前时间);
  for (const character of Object.values(draft.角色) as any[])
    if (character.层级 === '主要' && !character._管理?.来源档案id)
      character._更新循环 = { ...character._更新循环, 上次更新变量时间: copy(draft.世界.当前时间) };
  draft._系统.建档完成 = true;
  const result = Schema.parse(draft);
  const locationIds = [
    result.玩家.当前状态.当前地点id,
    result.玩家.生活.住处id,
    ...result.玩家.生活.工作地点id,
    ...result.玩家.生活.常去地点id,
  ];
  for (const id of locationIds) {
    if (!id) continue;
    if (!result.地点[id]) throw Error('起点引用了不存在的地点：' + id);
    // 玩家明确填写的日常地址是已知地点；其他公共场所与人物住处不随建档公开。
    if (!Object.hasOwn(result.玩家.已知信息.已知地点, id))
      result.玩家.已知信息.已知地点[id] = {
        方式: '玩家填写',
        说明: '开局设定中明确的当前位置、住处或日常地点',
        人物id: result.玩家.id,
        记录id: null,
        获得时间: copy(result.世界.开局时间),
      };
  }
  return planOpeningCharacters(
    result,
    payload.characters.filter(c => c.__package || c.__imported || c.__staticProfile).map(c => c.id),
  );
}

/**
 * 建档保存与角色库一步到位准备（消除 171 人「全量写入 state.角色 -> 全量 disable 导出快照」的冗余往返）：
 * - 默认 `selectionPending === true` 时，非在场导入角色直接生成休眠快照写入 `澄湾角色库` 与 `瓦罗兰静态档案库`；
 * - 保持与 `createProfile + prepareOpeningCharacterRoster` 完全一致的版本号、来源档案及初始关系/星讯联系人结果。
 */
export function createProfileWithRoster(
  before: State,
  payload: { player: any; characters: any[]; details?: any },
  rawLibrary: unknown,
  rosterOptionsInput: CharacterRosterSettings | undefined,
  selectionPending: boolean,
  characterAuto: boolean,
): { state: State; library: CharacterLibrary | null } {
  return stageCharacterProfiles(() => prepareProfileWithRoster(before, payload, rawLibrary, rosterOptionsInput, selectionPending, characterAuto));
}

function prepareProfileWithRoster(...[before, payload, rawLibrary, rosterOptionsInput, selectionPending, characterAuto]: Parameters<typeof createProfileWithRoster>) {
  if (!characterAuto) {
    return { state: createProfile(before, payload), library: null };
  }
  // 若非自动暂存待选模式（例如关闭了自动资料选择，需立即本地地理打分挑选 6 主 3 次），或初始模板中含残留活跃角色，走标准本地挑选链路。
  if (!selectionPending || Object.keys(before.角色).length > 0) {
    return { state: createProfile(before, payload), library: null };
  }
  if (before._系统.建档完成) throw Error('已有建档不会被覆盖；请在酒馆新建聊天后建档');

  const draft: any = copy(before);
  const p = payload.player;
  if (typeof p.姓名 !== 'string' || !p.姓名.trim()) throw Error('请填写姓名');
  const text = (v: any) => (v === '' || v === undefined ? null : v);
  draft._系统.存档id ??= uid('save');
  draft.玩家.id ??= uid('player');

  for (const key of ['姓名', '称呼', '性别', '年龄', '种族'])
    if (p[key] !== undefined) draft.玩家[key] = text(p[key]);
  for (const key of ['身高', '体重', '体型', '面容', '发型', '显著特征', '整体外貌描述'])
    if (p[key] !== undefined) draft.玩家.外貌[key] = text(p[key]);
  for (const key of ['成长背景', '家庭背景', '教育经历', '重要过往', '当前生活背景'])
    if (p[key] !== undefined) draft.玩家.背景[key] = text(p[key]);
  if (p.身份 !== undefined || p.当前职业 !== undefined)
    draft.玩家.身份.身份 = text(p.身份 !== undefined ? p.身份 : p.当前职业);
  if (p.社会身份 !== undefined) draft.玩家.身份.社会身份 = text(p.社会身份);
  if (p.技能栏 !== undefined) draft.玩家.技能栏 = copy(p.技能栏);
  if (p.工作就读单位 !== undefined) draft.玩家.身份.工作或就读单位 = text(p.工作就读单位);
  for (const key of ['饱食度', '水分值', '体力值'])
    if (p[key] !== undefined) draft.玩家.当前状态[key] = text(p[key]);
  if (p.片区id && draft.世界.片区[p.片区id]) draft._系统.资料加载.开局片区id = p.片区id;
  if (p.住处描述 !== undefined) {
    const currentId = draft.玩家.生活.住处id;
    const residence = draft.地点[currentId];
    const name = p.住处描述?.trim();
    if (name) {
      const district = p.片区id === undefined ? residence?.片区id : p.片区id || null;
      if (!district || !draft.世界.片区[district]) throw Error('请选择住所所属片区');
      const id = currentId ?? uid('residence');
      draft.地点[id] = { ...(residence ?? { 类型: '住处' }), 名称: name, 片区id: district ?? null };
      draft.玩家.生活.住处id = id;
    } else if (residence?.名称) {
      draft.玩家.生活.住处id = null;
    }
  }

  const details = payload.details ?? {};
  const replaceArrays = (_obj: unknown, src: unknown) => (Array.isArray(src) ? copy(src) : undefined);
  for (const key of ['世界', '地点', '手机', '约定'])
    if (details[key]) draft[key] = _.mergeWith({}, draft[key], details[key], replaceArrays);
  if (details.玩家) draft.玩家 = _.mergeWith({}, draft.玩家, details.玩家, replaceArrays);
  for (const id of details.移除初始物品 ?? []) delete draft.玩家.物品栏[id];
  for (const key of ['饱食度', '水分值', '体力值']) draft.玩家.当前状态[key] ??= 100;

  let playerAccount = ownAccount(draft);
  if (playerAccount && details.星讯账号名 !== undefined) {
    draft.手机.账号[playerAccount].账号名 = details.星讯账号名 || null;
  } else if (!playerAccount && details.星讯账号名) {
    playerAccount = uid('account');
    draft.手机.账号[playerAccount] = { 人物id: draft.玩家.id, 平台: '星讯', 账号名: details.星讯账号名, 昵称: p.姓名 };
  }

  draft.世界.开局时间 = copy(draft.世界.当前时间);
  draft.世界.天气._上次检查时间 = copy(draft.世界.当前时间);
  if (['天气状况', '气温', '风况', '适用区域'].some(key => draft.世界.天气[key] !== null))
    draft.世界.天气.生效时间 ??= copy(draft.世界.当前时间);

  const library = LibrarySchema.parse(rawLibrary);
  const revision = libraryRevision(before, library);
  const options = CharacterRosterSettingsSchema.parse(rosterOptionsInput ?? {});
  const inSceneIds = new Set<string>(draft.世界.当前场景?.在场人物 ?? []);
  const stagedIds = new Set(payload.characters.map(c => c.id));
  if (stagedIds.size !== payload.characters.length) throw Error('初始名单中存在重复的角色 ID');
  const activeImportedIds: string[] = [];
  const tierMembers: { 主要: string[]; 次要: string[] } = { 主要: [], 次要: [] };

  for (const character of payload.characters) {
    const { id, __package, __imported, __staticProfile, ...record } = character;
    if (!id) throw Error('初始角色缺少稳定 ID');
    const isImported = Boolean(__package || __imported || __staticProfile);
    const keepActiveNow = inSceneIds.has(id);

    if (keepActiveNow) {
      if (isImported) {
        importCharacter(draft, id, record, __package, true, __staticProfile);
        activeImportedIds.push(id);
      } else {
        draft.角色[id] = copy(record);
        bindTemplatePlayer(draft.角色[id], draft, id);
      }
      const relation = details.初始关系?.[id];
      if (relation && typeof relation === 'object') {
        const network = (draft.角色[id].关系网 ??= {});
        const existing = network[draft.玩家.id] ?? {};
        const relationEdited = relation.relationEdited ?? Boolean(relation.relation?.trim());
        const basisEdited = relation.basisEdited ?? Boolean(relation.basis?.trim());
        const relationship = relationEdited ? relation.relation?.trim() || null : existing.关系 ?? null;
        const basis = basisEdited ? relation.basis?.trim() || null : existing.关系备注 ?? null;
        if (((relationEdited && relationship) || (relation.contact && relation.contactEdited !== false)) && !basis)
          throw Error('请填写相识依据');
        if (relationEdited || basisEdited) network[draft.玩家.id] = { ...existing, 关系: relationship, 关系备注: basis };
        if (relation.contactEdited !== false && (relation.contact || relation.contactEdited)) {
          const accounts = Object.entries(draft.手机.账号) as [string, State['手机']['账号'][string]][];
          let account = accounts.find(([, a]) => a.人物id === id && a.平台 === '星讯')?.[0];
          if (relation.contact) {
            if (!playerAccount) throw Error('交换联系方式前请建立玩家星讯账号');
            account ??= uid('account');
            draft.手机.账号[account] ??= { 人物id: id, 平台: '星讯', 昵称: draft.角色[id].姓名 };
            ensurePhoneSession(draft, '私聊', account);
          }
          if (account && playerAccount) {
            const contacts = Object.values(draft.手机.联系人) as State['手机']['联系人'][string][];
            for (const [owner, target] of [[playerAccount, account], [account, playerAccount]]) {
              const contact = contacts.find(row => row.本人账号id === owner && row.对方账号id === target);
              if (contact) contact.状态 = relation.contact ? '正常' : '移除';
              else if (relation.contact) draft.手机.联系人[uid('contact')] = { 本人账号id: owner, 对方账号id: target };
            }
          }
        }
      }
      const tier: '主要' | '次要' = draft.角色[id].层级 === '次要' ? '次要' : '主要';
      tierMembers[tier].push(id);
      revision.meta[id] ??= { categoryId: DEFAULT_CATEGORY_ID, order: Object.keys(revision.meta).length };
      continue;
    }

    // 非在场角色直接构建停用快照入库，不进入 draft.角色 再做 disable 往返。
    const importVersion = Math.max(before.角色[id]?._管理.版本 ?? 0, before._系统.角色停用标识[id]?.版本 ?? 0) + 1;
    const imported = isImported ? prepareImportedCharacter(draft, id, record, importVersion, __package, __staticProfile) : null;
    const local = imported ? null : splitCharacterAuthoring(record, id, record.层级);
    const validated = imported?.person ?? local!.dynamic;
    if (local) {
      bindTemplatePlayer(validated, draft, id);
      bindCharacterStaticProfile(id, validated, local.staticProfile);
      validated._管理.版本 = importVersion;
    }
    if (!isImported && validated.层级 === '主要') {
      validated._更新循环 = { ...validated._更新循环, 上次更新变量时间: copy(draft.世界.当前时间) };
    }

    const relation = details.初始关系?.[id];
    const packAccounts: Record<string, any> = {};
    for (const [accId, acc] of Object.entries(draft.手机.账号) as [string, any][]) {
      if (acc?.人物id === id) {
        packAccounts[accId] = copy(acc);
        acc.头像资源 = null;
        acc.简介 = null;
        acc.公开资料 = {};
      }
    }
    if (relation && typeof relation === 'object') {
      const existing = validated.关系网[draft.玩家.id] ?? {
        姓名: null, 好感度: null, 信任度: null, 关系: null, 关系备注: null,
        来源事件id: [], 当前定位: null, 防御姿态: null, 破壁阶段: null, 已知私密: [],
      };
      const relationEdited = relation.relationEdited ?? Boolean(relation.relation?.trim());
      const basisEdited = relation.basisEdited ?? Boolean(relation.basis?.trim());
      const relationship = relationEdited ? relation.relation?.trim() || null : existing.关系 ?? null;
      const basis = basisEdited ? relation.basis?.trim() || null : existing.关系备注 ?? null;
      if (((relationEdited && relationship) || (relation.contact && relation.contactEdited !== false)) && !basis)
        throw Error('请填写相识依据');
      if (relationEdited || basisEdited) {
        validated.关系网[draft.玩家.id] = Schema.parse({
          角色: {
            [id]: {
              ...validated,
              关系网: { ...validated.关系网, [draft.玩家.id]: { ...existing, 关系: relationship, 关系备注: basis } },
            },
          },
        }).角色[id].关系网[draft.玩家.id];
      }
      if (relation.contactEdited !== false && (relation.contact || relation.contactEdited)) {
        let account = Object.entries(draft.手机.账号).find(([, a]: any) => a?.人物id === id && a?.平台 === '星讯')?.[0];
        if (relation.contact) {
          if (!playerAccount) throw Error('交换联系方式前请建立玩家星讯账号');
          account ??= uid('account');
          const fullAccount = Schema.parse({
            手机: {
              账号: {
                [account]: packAccounts[account] ?? { 人物id: id, 平台: '星讯', 昵称: validated.姓名 },
              },
            },
          }).手机.账号[account];
          packAccounts[account] = copy(fullAccount);
          draft.手机.账号[account] = { ...copy(fullAccount), 头像资源: null, 简介: null, 公开资料: {} };
          ensurePhoneSession(draft, '私聊', account);
        }
        if (account && playerAccount) {
          const contacts = Object.values(draft.手机.联系人) as State['手机']['联系人'][string][];
          for (const [owner, target] of [[playerAccount, account], [account, playerAccount]]) {
            const contact = contacts.find(row => row.本人账号id === owner && row.对方账号id === target);
            if (contact) contact.状态 = relation.contact ? '正常' : '移除';
            else if (relation.contact) draft.手机.联系人[uid('contact')] = { 本人账号id: owner, 对方账号id: target };
          }
        }
      }
    }

    const snapshotVersion = importVersion + 1;
    const snapshotId = uid('character_snapshot');
    library.snapshots[snapshotId] = {
      id,
      saveId: draft._系统.存档id,
      version: snapshotVersion,
      pack: {
        格式版本: '澄湾角色包/1',
        id,
        角色: copy(validated),
        手机: {
          账号: packAccounts,
          消息: {},
          帖子: {},
          评论: {},
          点赞: {},
          转发: {},
        },
        来源: { 来源存档id: draft._系统.存档id, 导出故事时间: copy(draft.世界.当前时间) },
        来源档案: imported ? { [imported.sourceId]: imported.source } : {},
        关联委托: Object.fromEntries(Object.entries(before.委托 ?? {}).filter(([, row]) => row.委托人id === id)),
        关联约定: Object.fromEntries(
          Object.entries(draft.约定 ?? {}).filter(([, r]: any) => Object.hasOwn(r?.参与者 ?? {}, id)),
        ),
        停用时在场: false,
      },
    };
    revision.disabled[id] = snapshotId;
    revision.meta[id] ??= { categoryId: DEFAULT_CATEGORY_ID, order: Object.keys(revision.meta).length };
    draft._系统.角色停用标识[id] = { 姓名: validated.姓名, 版本: snapshotVersion };
    tierMembers[validated.层级 === '次要' ? '次要' : '主要'].push(id);
  }

  for (const character of Object.values(draft.角色) as any[]) {
    if (character.层级 === '主要' && !character._管理?.来源档案id) {
      character._更新循环 = { ...character._更新循环, 上次更新变量时间: copy(draft.世界.当前时间) };
    }
  }
  draft._系统.建档完成 = true;
  let result = Schema.parse(draft);

  const locationIds = [
    result.玩家.当前状态.当前地点id,
    result.玩家.生活.住处id,
    ...result.玩家.生活.工作地点id,
    ...result.玩家.生活.常去地点id,
  ];
  for (const id of locationIds) {
    if (!id) continue;
    if (!result.地点[id]) throw Error('起点引用了不存在的地点：' + id);
    if (!Object.hasOwn(result.玩家.已知信息.已知地点, id))
      result.玩家.已知信息.已知地点[id] = {
        方式: '玩家填写',
        说明: '开局设定中明确的当前位置、住处或日常地点',
        人物id: result.玩家.id,
        记录id: null,
        获得时间: copy(result.世界.开局时间),
      };
  }

  if (!payload.characters.length && Object.keys(revision.meta).length === 0) {
    return { state: planOpeningCharacters(result, [], true), library: null };
  }

  const time = result.世界.当前时间;
  const period = time ? `${time.年}-${time.月}-${time.日}:${Math.floor((time.时 * 60 + time.分) / 180)}` : 'unknown';
  const anchorStr = JSON.stringify([
    result.世界.当前场景.场景id,
    result.玩家.当前状态.当前地点id,
    period,
    0,
    options,
  ]);
  const selectedActive = [...inSceneIds].filter(id => stagedIds.has(id));
  const requestedIds = [...new Set([...initialConnectionIds(payload).filter(id => stagedIds.has(id)), ...selectedActive])];

  const automatic = AutomaticRosterSchema.parse({
    manualOff: revision.automatic?.manualOff ?? [],
    queues: {
      主要: [...tierMembers.主要.filter(id => !selectedActive.includes(id)), ...tierMembers.主要.filter(id => selectedActive.includes(id))],
      次要: [...tierMembers.次要.filter(id => !selectedActive.includes(id)), ...tierMembers.次要.filter(id => selectedActive.includes(id))],
    },
    rotation: {},
    checks: {},
    anchor: anchorStr,
    opening: {
      requestedIds,
      selectedIds: selectedActive,
      selectionPending: true,
    },
  });

  const prepared = prepareAutomaticLibrary(result, library, revision, new Set(selectedActive), automatic, 'opening');
  result = applyCharacterFormSelections(prepared.state);
  result = planOpeningCharacters(result, activeImportedIds, true);
  const openingTask = Object.entries(result._系统.任务).find(
    ([, task]) => task.类别 === '建档' && ['排队', '生成中', '待校验', '待提交', '失败'].includes(task.状态),
  );
  if (openingTask) {
    for (const id of selectedActive) automatic.checks[id] = openingTask[0];
  }
  const revKey = result._系统.角色库版本!;
  prepared.library.revisions[revKey].automatic = AutomaticRosterSchema.parse(automatic);
  return { state: Schema.parse(result), library: prepared.library };
}
