<template>
  <div class="cw-tab-pane cw-char-tab-status">
    <CharacterKnownLocation v-if="char" :char="char" />

    <!-- 3. 近期社交动态与交集 -->
    <div v-if="recentEncounters.length > 0" class="cw-status-card">
      <h4 class="cw-section-title">
        <SvgIcon name="users" :size="16" />
        <span>近期社交交集与回响</span>
      </h4>
      <div class="cw-sub-card-list">
        <div v-for="(enc, idx) in recentEncounters" :key="idx" class="cw-sub-card cw-encounter-card">
          <div class="cw-sub-header">
            <span class="cw-sub-title">与 {{ resolveCharName(enc.与) }}</span>
            <span v-if="enc.时间" class="cw-badge">{{ enc.时间 }}</span>
          </div>
          <p class="cw-sub-desc">{{ enc.交集事项 }}</p>
        </div>
      </div>
    </div>

    <div v-if="characterPromises.length" class="cw-status-card">
      <h4 class="cw-section-title">
        <SvgIcon name="target" :size="16" />
        <span>与我的约定</span>
      </h4>
      <div class="cw-sub-card-list">
        <div v-for="p in characterPromises" :key="p.id" class="cw-sub-card cw-promise-card">
          <div class="cw-sub-header">
            <span class="cw-sub-title">{{ p.内容 || '待办约定' }}</span>
            <span class="cw-badge" :class="getPromiseBadgeClass(p.状态)">{{ p.状态 || '拟议' }}</span>
          </div>
          <div class="cw-promise-meta">
            <span v-if="p.时间说明 || p.时间">🕒 {{ p.时间说明 || formatTime(p.时间) }}</span>
            <span v-if="p.地点id">📍 {{ place(p.地点id) }}</span>
            <span v-if="p.myRole?.称呼">👤 称呼：{{ p.myRole.称呼 }}</span>
            <span v-if="p.myRole?.响应" class="cw-badge cw-badge-sm">响应：{{ p.myRole.响应 }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref, toRaw } from 'vue';
import type { State } from '../../../../../运行/core';
import { useWorldState } from '../../../utils/context';
import { resolveLocationName } from '../../../utils/entity';
import { recentSocialEncounters } from '../../../../../运行/character-read';
import { subscribeExternalSettings } from '../../../../../运行/external-settings';
import SvgIcon from '../../icons/SvgIcon.vue';
import CharacterKnownLocation from '../CharacterKnownLocation.vue';

const worldState = useWorldState<State>();
const externalRevision = ref(0);
const stopExternalWatch = subscribeExternalSettings(() => {
  externalRevision.value++;
});
onBeforeUnmount(stopExternalWatch);

const place = (id: any) => {
  void externalRevision.value;
  return resolveLocationName(worldState?.value, id);
};

const props = defineProps<{
  char: any;
}>();

const charId = computed(() => {
  if (props.char?.id) return props.char.id;
  const chars = worldState?.value?.角色 || {};
  const rawChar = toRaw(props.char);
  return Object.keys(chars).find(k => toRaw(chars[k]) === rawChar) || '';
});

const recentEncounters = computed(() => recentSocialEncounters(worldState.value, charId.value));

function resolveCharName(id: string): string {
  if (!id) return '未知人物';
  if (id === worldState.value.玩家.id) return worldState.value.玩家.姓名 ?? '玩家';
  const c = worldState?.value?.角色?.[id];
  return c?.姓名 || id;
}

function formatTime(t: any): string {
  if (!t) return '';
  if (typeof t === 'string') return t;
  if (typeof t.年 === 'number' && typeof t.月 === 'number' && typeof t.日 === 'number') {
    const date = `${t.年}年${t.月}月${t.日}日`;
    return typeof t.时 === 'number' && typeof t.分 === 'number'
      ? `${date} ${t.时}:${String(t.分).padStart(2, '0')}`
      : date;
  }
  return '';
}

function getPromiseBadgeClass(status: string) {
  switch (status) {
    case '已确认':
    case '完成':
      return 'cw-badge-success';
    case '取消':
    case '未履行':
      return 'cw-badge-danger';
    case '待确认':
      return 'cw-badge-warning';
    default:
      return 'cw-badge-info';
  }
}

const characterPromises = computed(() => {
  const allPromises = worldState?.value?.约定;
  if (!allPromises || typeof allPromises !== 'object') return [];
  const cid = charId.value;
  const playerId = worldState.value.玩家.id;
  if (!cid || !playerId) return [];
  return Object.entries(allPromises)
    .filter(([, promise]) => Object.hasOwn(promise.参与者, cid) && Object.hasOwn(promise.参与者, playerId))
    .map(([id, p]) => ({
      id,
      ...p,
      myRole: p.参与者?.[cid],
    }));
});

</script>

<style scoped lang="scss">
.cw-char-tab-status {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-status-card {
  padding: 16px 20px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-sub-card-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-sub-card {
  padding: 11px 14px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);

  .cw-sub-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 6px;

    .cw-sub-title {
      flex: 1;
      min-width: 0;
      font-size: 13.5px;
      font-weight: 600;
      line-height: 1.55;
      color: var(--cw-text-primary);
      word-break: break-word;
      overflow-wrap: anywhere;
    }
  }

  .cw-sub-desc {
    margin: 0;
    font-size: 12.5px;
    color: var(--cw-text-secondary);
    line-height: 1.6;
    word-break: break-word;
  }

  .cw-sub-desc-muted {
    color: var(--cw-text-muted);
  }
}

.cw-promise-meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 12px;
  font-size: 12px;
  color: var(--cw-text-secondary);
}

.cw-badge-sm {
  font-size: 11px;
  padding: 1px 6px;
}

.cw-encounter-card {
  border-left: 3px solid var(--cw-info);
}

</style>
