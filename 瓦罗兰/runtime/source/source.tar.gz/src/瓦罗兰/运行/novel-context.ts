import type { State } from './core';
import { getExternalGeography } from './external-settings';
import { completedQuests, highestUnlockedQuality, storyDateKey } from './novel-system';

// 《瓦罗兰奥术纪元》公开世界背景摘要；具体区域与地点目录从外置设定动态读取。
export const novelPublicSetting =
  '瓦罗兰奥术纪元是由瓦罗兰市等15大物理与维度区域构成的现代奥术共存世界；瓦罗兰市为世界和平中心，周边文明、外海自治飞地诺克斯维加斯、远古召唤师峡谷荒野禁区、班德尔口袋维度与里世界异空间域各具风貌。' +
  '演艺海滨与乐团生活、咖啡甜心与莲华温泉日常、五大神之武器学院竞技与公开课（落位于瓦罗兰市、诺克萨斯、比尔吉沃特、恕瑞玛与以绪塔尔本土）、萌宠照护（魄罗与峡谷温和生态）、奥术与海克斯科技、炼金工艺、诺克斯维加斯赌城商贸、恶魔怪谈查证、荒野寻宝与三线异界救援均可成为主题，并呼应四季盛典与年度节律。' +
  '繁荣区依赖海克斯高速磁浮与奥术飞艇高效通勤，偏远险地与跨洲荒野须真实长途跋涉与补给，班德尔树门与四大里世界异空间域须经特定通道进入；异空间伤势、消耗与记忆全部带回现世。' +
  '虚空活跃度、暗星渗漏度、星陨侵蚀度三条独立局势指标各自按0–9潜伏、10–29预警、30–59高危、60–89危机、90–100全面崩溃演进；低阶保持轻松现代都市生活、盛典奇货与都市怪谈感，高阶转向救援、封锁、联防与战斗。' +
  '三线局势只是系统后台标尺，不等于普通市民或角色全知；世界观背景不等于玩家知情，不据此给玩家添加身份、能力、已知地点或既往经历。' +
  '日常通用货币为以1金币为单位的非负整数，奇遇系统货币为蓝色精粹，两者独立不互兑；系统商品按英雄联盟装备体系分为基础、史诗、传说、神话四阶品质，所有强力装备与神话禁忌神器均按来源、冷却、耗能、携械管制与世界因果叙事结算。';

function publicDistrictDirectory(state: State) {
  const geo = getExternalGeography();
  if (geo.districts.length) {
    return geo.districts.map(({ id, name, scope, role, layer, trafficTier }) => ({
      id,
      名称: name,
      地理层级: scope,
      图层: layer,
      交通等级: trafficTier,
      功能: role,
    }));
  }
  return Object.entries(state.世界.片区 ?? {}).map(([id, area]) => ({
    id,
    名称: area.名称 ?? id,
    地理层级: area.图层 ?? '表世界',
    图层: area.图层 ?? '表世界',
    交通等级: area.交通等级 ?? '繁荣快线',
    功能: area.功能 ?? '',
  }));
}

function seasonFromMonth(month?: number | null): string | null {
  if (!month) return null;
  if (month >= 3 && month <= 5) return '春季';
  if (month >= 6 && month <= 8) return '夏季';
  if (month >= 9 && month <= 11) return '秋季';
  return '冬季';
}

/** 奇遇刷新仅提供当前区域、季节日期、三线独立入侵态势、已解锁品质、避重清单与公开区域目录，不泄露玩家/人物隐私。 */
export function novelCreationContext(state: State) {
  const districts = publicDistrictDirectory(state);
  const placeId = state.玩家.当前状态.当前地点id;
  const districtId = placeId ? state.地点[placeId]?.片区id : null;
  const existingTasks = Object.entries(state.奇遇系统.任务)
    .filter(([id]) => {
      const status = state.奇遇系统._任务记录[id]?.状态;
      return !status || status === '进行中';
    })
    .map(([, task]) => task.名称)
    .filter(Boolean);
  const existingGoods = Object.values(state.奇遇系统._商店商品)
    .map(good => good.名称)
    .filter(Boolean);
  return {
    当前地区id: districts.find(district => district.id === districtId)?.id ?? null,
    当前故事日期: storyDateKey(state.世界.当前时间),
    当前季节: seasonFromMonth(state.世界.当前时间?.月),
    已领取任务数: completedQuests(state),
    当前已解锁最高品质: highestUnlockedQuality(state),
    虚空活跃度: state.世界.虚空活跃度,
    暗星渗漏度: state.世界.暗星渗漏度,
    星陨侵蚀度: state.世界.星陨侵蚀度,
    已有任务名称: existingTasks,
    已有商品名称: existingGoods,
    地区目录: districts,
  };
}
