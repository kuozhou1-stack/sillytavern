import { getExternalGeography, getOrganizationSettings } from '../../../运行/external-settings';

/**
 * 通用实体引用解析与格式化工具函数
 * 地点与组织名称从当前存档或外置设定动态读取，不在源码内硬编码具体世界资料。
 */

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function resolveCharacterName(state: any, id: string | null | undefined): string {
  if (!id) return '未知人物';
  if (state?.玩家?.id === id) {
    return state.玩家.姓名 || '玩家本人';
  }
  const cleanId = id.replace(/^(task_|char_|opening_|schedule_|cw_)/, '').toLowerCase();

  const char = state?.角色?.[id] || state?.角色?.[cleanId];
  if (char) {
    return char.姓名 || id;
  }
  if (state?._系统?.角色停用标识?.[id]) return (state._系统.角色停用标识[id].姓名 || id) + '（已停用）';
  if (state?._系统?.角色停用标识?.[cleanId]) return (state._系统.角色停用标识[cleanId].姓名 || cleanId) + '（已停用）';

  return id;
}

export function resolveLocationName(state: any, id: string | null | undefined): string {
  if (!id) return '未知地点';
  const loc = state?.地点?.[id];
  if (loc && loc.名称) {
    return loc.名称;
  }
  const extName = getExternalGeography().locationNames?.[id];
  if (extName) return extName;
  return id;
}

export function resolveAccountName(state: any, id: string | null | undefined): string {
  if (!id) return '未知账号';
  const acc = state?.手机?.账号?.[id];
  if (acc) {
    const nick = acc.昵称 || acc.账号名 || '';
    const plat = acc.平台 ? ` (${acc.平台})` : '';
    return nick ? `${nick}${plat}` : id;
  }
  return id;
}

export function resolveOrganizationName(state: any, id: string | null | undefined): string {
  if (!id) return '未知组织';
  const settings = getOrganizationSettings();
  const org = state?.组织?.[id]?.名称 ? state.组织[id] : settings.organizations[id] ?? settings.legacyOrganizations?.[id];
  if (org) {
    return org.名称 || id;
  }
  return id;
}

export function resolveEntityName(state: any, id: string | null | undefined): string {
  if (!id) return '未知';
  if (state?.玩家?.id === id) return state.玩家.姓名 || '玩家本人';
  if (state?.角色?.[id]) return state.角色[id].姓名 || id;
  if (state?._系统?.角色停用标识?.[id]) return (state._系统.角色停用标识[id].姓名 || id) + '（已停用）';
  if (state?.地点?.[id]) return state.地点[id].名称 || id;
  const extLoc = getExternalGeography().locationNames?.[id];
  if (extLoc) return extLoc;
  if (state?.手机?.账号?.[id]) return state.手机.账号[id].昵称 || state.手机.账号[id].账号名 || id;
  return resolveOrganizationName(state, id);
}

/** 《瓦罗兰奥术纪元》通用货币最小单位为 1 金币（正整数/非负整数），不使用小数分。 */
export function formatGoldAmount(amount: number | null | undefined): string {
  if (typeof amount !== 'number' || !Number.isFinite(amount)) return '金额未定';
  return `${Math.trunc(amount).toLocaleString('zh-CN')} 金币`;
}

export function formatTimeObj(time: any): string {
  if (!time || typeof time !== 'object') return '时间未定';
  const { 年, 月, 日, 时, 分 } = time;
  if (年 == null || 月 == null || 日 == null) return '时间未定';
  const timePart = 时 != null ? ` ${时}:${String(分 ?? 0).padStart(2, '0')}` : '';
  return `${年}年${月}月${日}日${timePart}`;
}

export function formatTimeRange(start: any, end: any): string {
  if (!start && !end) return '时段未知';
  if (start && !end) return `${formatTimeObj(start)} 起`;
  if (!start && end) return `至 ${formatTimeObj(end)}`;
  return `${formatTimeObj(start)} ~ ${formatTimeObj(end)}`;
}
