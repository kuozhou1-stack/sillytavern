<template>
  <span v-if="publicTags.length || (showHidden && hiddenTags.length)" class="cw-occupation-tags" :class="{ compact }" aria-label="身份">
    <span v-for="tag in publicTags" :key="'pub:' + tag" class="cw-occupation-tag">{{ tag }}</span>
    <template v-if="showHidden">
      <span
        v-for="tag in hiddenTags"
        :key="'hid:' + tag"
        class="cw-occupation-tag cw-occupation-tag-hidden"
        title="隐秘身份"
      >
        隐 · {{ tag }}
      </span>
    </template>
  </span>
  <span v-else class="cw-occupation-unknown">{{ emptyText || '身份未知' }}</span>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import { normalizeIdentityInput } from '../../../../运行/character-identity';

const props = defineProps<{
  value?: unknown;
  compact?: boolean;
  emptyText?: string;
  showHidden?: boolean;
}>();

const parsed = computed(() => normalizeIdentityInput(props.value));
const publicTags = computed(() => [...new Set(parsed.value.公开)]);
const hiddenTags = computed(() => [...new Set(parsed.value.隐秘)]);
</script>
<style scoped>
.cw-occupation-tags {
  display: inline-flex;
  flex-wrap: wrap;
  gap: 5px;
  vertical-align: middle;
  max-width: 100%;
  min-width: 0;
}
.cw-occupation-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 9px;
  border: 1px solid var(--cw-tag-accent-border, var(--cw-accent-border));
  border-radius: 5px;
  background: var(--cw-tag-accent-bg, var(--cw-accent-bg));
  color: var(--cw-tag-accent-text, var(--cw-accent));
  font-size: 12px;
  font-weight: 500;
  line-height: 1.45;
  overflow-wrap: anywhere;
}
.cw-occupation-tag-hidden {
  border-style: dashed;
  border-color: var(--cw-tag-hidden-border, var(--cw-info));
  background: var(--cw-tag-hidden-bg, var(--cw-info-bg));
  color: var(--cw-tag-hidden-text, var(--cw-info));
}
.compact .cw-occupation-tag {
  padding: 2px 5px;
  font-size: 11px;
}
.cw-occupation-unknown {
  font-size: 12px;
  color: var(--cw-text-muted);
}
</style>
