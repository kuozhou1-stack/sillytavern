<template>
  <div class="cw-chat-viewport">
    <div ref="scrollContainer" class="cw-chat-scroll" @scroll="handleScroll">
      <!-- 楼层消息流 -->
      <div class="cw-message-list">
        <div v-if="hasEarlierMessages" class="cw-load-earlier-bar">
          <button
            type="button"
            class="cw-load-earlier-btn"
            :disabled="loadingEarlier"
            @click="handleLoadEarlier"
          >
            <SvgIcon name="chevronUp" :size="14" />
            <span>{{ loadingEarlier ? '正在加载更早楼层…' : earlierButtonText }}</span>
          </button>
        </div>
        <CreationReceipt v-if="!messages.length" />
        <MessageItem
          v-for="msg in messages"
          :key="msg.id"
          :message="msg"
          :is-latest="msg.id === messages.at(-1)?.id"
          :actions-blocked="actionsBlocked"
          :has-variable-output="hasFloorVariableOutput(msg)"
          @trigger-action="handleActionTrigger"
          @inspect-variable="payload => emit('inspectVariable', payload)"
        />
      </div>
    </div>

    <!-- 到达最新楼层悬浮定位按钮（回看前文时显示，点击平滑滚动到底部） -->
    <transition name="cw-fade">
      <button
        v-if="showScrollToBottom"
        class="cw-scroll-to-bottom-btn"
        title="快速滚动定位至最新楼层"
        @click="scrollToBottom"
      >
        <SvgIcon name="arrowDown" :size="16" />
        <span>到达最新楼层</span>
      </button>
    </transition>

    <!-- 操作二次确认弹窗 -->
    <MessageConfirmModal
      v-if="activeAction"
      :action-type="activeAction.type"
      :message="activeAction.message"
      :has-variable-output="hasFloorVariableOutput(activeAction.message)"
      @confirm="handleActionConfirmed"
      @cancel="activeAction = null"
      @inspect-variable="handleInspectFromConfirm"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from 'vue';
import SvgIcon from '../icons/SvgIcon.vue';
import MessageItem, { type ChatMessageItem } from './MessageItem.vue';
import MessageConfirmModal from './MessageConfirmModal.vue';
import CreationReceipt from './CreationReceipt.vue';

const props = defineProps<{
  messages: ChatMessageItem[];
  actionsBlocked?: boolean;
  variableOutputIndex?: Record<string, { id: string; state: string }>;
  hasEarlierMessages?: boolean;
  totalMessages?: number;
}>();

const emit = defineEmits<{
  (e: 'executeAction', payload: { actionType: string; messageId: number; newContent?: string }): void;
  (e: 'inspectVariable', payload: { floor: number; swipe?: number }): void;
  (e: 'loadEarlier'): void;
}>();

const loadingEarlier = ref(false);
let preserveScrollAnchor: { scrollHeight: number; scrollTop: number; firstId: number | undefined } | null = null;
const earlierCount = computed(() => {
  const firstId = props.messages[0]?.id;
  if (typeof firstId === 'number' && firstId > 1) return firstId - 1;
  if (typeof props.totalMessages === 'number') return Math.max(0, props.totalMessages - props.messages.length);
  return 0;
});
const earlierButtonText = computed(() =>
  earlierCount.value > 0 ? `加载更早楼层（还有 ${earlierCount.value} 楼）` : '加载更早楼层',
);

function handleLoadEarlier() {
  if (!props.hasEarlierMessages || loadingEarlier.value) return;
  if (scrollContainer.value) {
    preserveScrollAnchor = {
      scrollHeight: scrollContainer.value.scrollHeight,
      scrollTop: scrollContainer.value.scrollTop,
      firstId: props.messages[0]?.id,
    };
  }
  isFollowingBottom.value = false;
  loadingEarlier.value = true;
  emit('loadEarlier');
  void nextTick(() => {
    loadingEarlier.value = false;
    if (preserveScrollAnchor && props.messages[0]?.id === preserveScrollAnchor.firstId) {
      preserveScrollAnchor = null;
    }
  });
}

function handleInspectFromConfirm(payload: { floor: number; swipe?: number }) {
  activeAction.value = null;
  emit('inspectVariable', payload);
}

function hasFloorVariableOutput(msg: ChatMessageItem): boolean {
  if (msg.role !== 'assistant' || msg.id <= 0) return false;
  return Boolean(props.variableOutputIndex?.[`${msg.id}:${msg.swipe ?? 0}`]);
}

const scrollContainer = ref<HTMLElement | null>(null);
const showScrollToBottom = ref(false);
const isFollowingBottom = ref(true);

const activeAction = ref<{ type: any; message: ChatMessageItem } | null>(null);

function handleScroll() {
  if (!scrollContainer.value) return;
  const { scrollTop, scrollHeight, clientHeight } = scrollContainer.value;
  const distanceToBottom = scrollHeight - (scrollTop + clientHeight);
  // 玩家回看前文时，流式输出不强行拉到底；主动回到底部后恢复跟随
  if (distanceToBottom > 40) {
    isFollowingBottom.value = false;
  } else {
    isFollowingBottom.value = true;
  }
  showScrollToBottom.value = distanceToBottom > 160;
}

watch(
  () => props.messages,
  () => {
    if (!scrollContainer.value) return;
    if (preserveScrollAnchor) {
      const anchor = preserveScrollAnchor;
      preserveScrollAnchor = null;
      if (props.messages[0]?.id !== anchor.firstId) {
        nextTick(() => {
          if (!scrollContainer.value) return;
          const delta = scrollContainer.value.scrollHeight - anchor.scrollHeight;
          scrollContainer.value.scrollTop = Math.max(0, anchor.scrollTop + delta);
          loadingEarlier.value = false;
        });
        return;
      }
    }
    if (isFollowingBottom.value) {
      nextTick(() => {
        if (!scrollContainer.value) return;
        scrollContainer.value.scrollTop = scrollContainer.value.scrollHeight;
      });
    }
  },
  { deep: true, flush: 'post' },
);

function scrollToBottom() {
  if (!scrollContainer.value) return;
  isFollowingBottom.value = true;
  scrollContainer.value.scrollTo({
    top: scrollContainer.value.scrollHeight,
    behavior: 'smooth',
  });
  showScrollToBottom.value = false;
}

function handleActionTrigger(payload: { type: string; message: ChatMessageItem }) {
  if (props.actionsBlocked) return;
  activeAction.value = {
    type: payload.type as any,
    message: payload.message,
  };
}

function handleActionConfirmed(payload: { actionType: string; messageId: number; newContent?: string }) {
  emit('executeAction', payload);
  activeAction.value = null;
}

onMounted(() => {
  handleScroll();
});
</script>

<style scoped lang="scss">
.cw-chat-viewport {
  flex: 1;
  width: 100%;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.cw-chat-scroll {
  flex: 1;
  overflow-y: auto;
  scrollbar-gutter: stable both-edges;
  padding: 16px 14px calc(var(--cw-composer-height, 100px) + 20px);
  scroll-padding-bottom: calc(var(--cw-composer-height, 100px) + 16px);
  box-sizing: border-box;
}

.cw-message-list {
  display: flex;
  flex-direction: column;
}

.cw-load-earlier-bar {
  display: flex;
  justify-content: center;
  margin-bottom: 12px;
}

.cw-load-earlier-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  border-radius: var(--cw-radius-full);
  border: 1px solid var(--cw-border);
  background: var(--cw-bg-card-subtle);
  color: var(--cw-text-secondary);
  font-size: 12px;
  cursor: pointer;
  transition: all 0.16s ease;

  &:hover:not(:disabled) {
    border-color: var(--cw-accent);
    color: var(--cw-accent);
    background: var(--cw-bg-card);
  }

  &:disabled {
    opacity: 0.6;
    cursor: wait;
  }
}

.cw-scroll-to-bottom-btn {
  position: absolute;
  bottom: calc(var(--cw-composer-height, 100px) + 24px);
  right: 18px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  border-radius: var(--cw-radius-full);
  background: var(--cw-accent);
  color: var(--cw-text-inverse);
  border: 1px solid var(--cw-accent-hover);
  box-shadow: var(--cw-shadow);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  z-index: 30;
  transition: all 0.2s ease;

  &:hover {
    background: var(--cw-accent-hover);
    transform: translateY(-2px);
    box-shadow: var(--cw-shadow-lg);
  }

  &:active {
    transform: translateY(0);
  }
}

.cw-fade-enter-active,
.cw-fade-leave-active {
  transition:
    opacity 0.2s,
    transform 0.2s;
}

.cw-fade-enter-from,
.cw-fade-leave-to {
  opacity: 0;
  transform: translateY(8px);
}
</style>
