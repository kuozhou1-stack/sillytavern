/** Only failures at the provider boundary may send the same operation to another connection. */
export class ApiProviderError extends Error {}

function extractErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    const cause = (error as { cause?: unknown }).cause;
    if (error.message && error.message !== '[object Object]') return error.message;
    if (cause) return extractErrorMessage(cause);
    return String(error);
  }
  if (error && typeof error === 'object') {
    const obj = error as Record<string, any>;
    const nested = obj.error?.message ?? obj.message ?? obj.detail ?? obj.statusText;
    if (typeof nested === 'string' && nested.trim()) return nested;
    try {
      return JSON.stringify(obj);
    } catch {
      return String(error);
    }
  }
  return String(error);
}

export async function withApiProviderError<T>(signal: AbortSignal, send: () => Promise<T>, key?: string): Promise<T> {
  signal.throwIfAborted();
  try {
    return await send();
  } catch (error) {
    signal.throwIfAborted();
    if (error instanceof ApiProviderError || (error as Error)?.name === 'AbortError') throw error;
    const message = extractErrorMessage(error);
    throw new ApiProviderError(key ? message.replaceAll(key, '[密钥已隐藏]') : message, { cause: error });
  }
}
