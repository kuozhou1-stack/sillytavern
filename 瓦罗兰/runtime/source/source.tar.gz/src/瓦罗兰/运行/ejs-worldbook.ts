/**
 * 卡内安全 EJS 世界书条件求值器（零 eval / 零 new Function）。
 * 基于本次请求的权威 stat_data 预先展开本卡世界书中的 `# :<%_ ... _%>` 条件块，
 * 避免依赖宿主 ST-Prompt-Template 沙盒（会阻断出站 EJS）与后台变量通道的楼层错位。
 * 遇到非本卡语法的任意宿主 EJS 模板时返回 handled: false 并原样透传给宿主处理。
 */

export type CardEjsEvalResult = {
  text: string;
  handled: boolean;
};

type TokenType =
  | 'num'
  | 'str'
  | 'id'
  | 'op'
  | 'punc'
  | 'eof';

type Token = {
  type: TokenType;
  value: string;
};

type EvalFn = (...args: unknown[]) => unknown;

type Scope = {
  vars: Map<string, unknown>;
  parent: Scope | null;
};

const BLOCKED_KEYS = new Set(['__proto__', 'prototype', 'constructor']);
const MULTI_CHAR_OPS = ['===', '!==', '=>', '<=', '>=', '==', '!=', '&&', '||', '??', '?.'];
const SINGLE_CHAR_OPS = new Set(['<', '>', '!', '+', '-', '*', '/', '%', '=']);
const PUNCS = new Set(['(', ')', '[', ']', '{', '}', ',', '.', ':', ';', '?']);

class UnsupportedEjsError extends Error {}

function tokenize(code: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const len = code.length;
  while (i < len) {
    const ch = code[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    // Line comment
    if (ch === '/' && code[i + 1] === '/') {
      while (i < len && code[i] !== '\n') i++;
      continue;
    }
    // String literal
    if (ch === "'" || ch === '"') {
      const quote = ch;
      let str = '';
      i++;
      let closed = false;
      while (i < len) {
        const c = code[i++];
        if (c === '\\') {
          if (i >= len) throw new UnsupportedEjsError('Unterminated escape');
          const esc = code[i++];
          if (esc === 'n') str += '\n';
          else if (esc === 'r') str += '\r';
          else if (esc === 't') str += '\t';
          else str += esc;
        } else if (c === quote) {
          closed = true;
          break;
        } else {
          str += c;
        }
      }
      if (!closed) throw new UnsupportedEjsError('Unterminated string');
      tokens.push({ type: 'str', value: str });
      continue;
    }
    // Number literal
    if (/\d/.test(ch) || (ch === '.' && /\d/.test(code[i + 1] ?? ''))) {
      let start = i;
      while (i < len && /\d/.test(code[i])) i++;
      if (code[i] === '.' && /\d/.test(code[i + 1] ?? '')) {
        i++;
        while (i < len && /\d/.test(code[i])) i++;
      }
      tokens.push({ type: 'num', value: code.slice(start, i) });
      continue;
    }
    // Identifier / keyword
    if (/[A-Za-z_$]/.test(ch)) {
      const start = i;
      i++;
      while (i < len && /[A-Za-z0-9_$]/.test(code[i])) i++;
      tokens.push({ type: 'id', value: code.slice(start, i) });
      continue;
    }
    // Multi-char operators
    const multi = MULTI_CHAR_OPS.find(op => code.startsWith(op, i));
    if (multi) {
      tokens.push({ type: 'op', value: multi });
      i += multi.length;
      continue;
    }
    if (SINGLE_CHAR_OPS.has(ch)) {
      tokens.push({ type: 'op', value: ch });
      i++;
      continue;
    }
    if (PUNCS.has(ch)) {
      tokens.push({ type: 'punc', value: ch });
      i++;
      continue;
    }
    throw new UnsupportedEjsError(`Unexpected char: ${ch}`);
  }
  tokens.push({ type: 'eof', value: '' });
  return tokens;
}

function createScope(parent: Scope | null = null): Scope {
  return { vars: new Map(), parent };
}

function lookupVar(scope: Scope, name: string): { found: boolean; value: unknown } {
  let cur: Scope | null = scope;
  while (cur) {
    if (cur.vars.has(name)) return { found: true, value: cur.vars.get(name) };
    cur = cur.parent;
  }
  return { found: false, value: undefined };
}

function readStatVar(statData: unknown, path: unknown, fallback?: unknown): unknown {
  if (typeof path !== 'string' || !path.trim()) return fallback;
  const cleaned = path.trim().replace(/^stat_data(?:\.|$)/, '');
  if (!cleaned) return statData ?? fallback;
  const parts = cleaned.split('.').filter(Boolean);
  let cur: unknown = statData;
  for (const part of parts) {
    if (BLOCKED_KEYS.has(part) || cur === null || cur === undefined || typeof cur !== 'object') {
      return fallback;
    }
    if (!Object.hasOwn(cur as object, part)) return fallback;
    cur = (cur as Record<string, unknown>)[part];
  }
  return cur === undefined ? fallback : cur;
}

type ReturnSignal = { returned: true; value: unknown };

class SafeJsRunner {
  private tokens: Token[];
  private pos = 0;

  constructor(code: string) {
    this.tokens = tokenize(code);
  }

  private peek(offset = 0): Token {
    return this.tokens[this.pos + offset] ?? { type: 'eof', value: '' };
  }

  private next(): Token {
    return this.tokens[this.pos++] ?? { type: 'eof', value: '' };
  }

  private match(type: TokenType, value?: string): boolean {
    const t = this.peek();
    if (t.type !== type || (value !== undefined && t.value !== value)) return false;
    this.pos++;
    return true;
  }

  private expect(type: TokenType, value?: string): Token {
    const t = this.next();
    if (t.type !== type || (value !== undefined && t.value !== value)) {
      throw new UnsupportedEjsError(`Expected ${value ?? type}, got ${t.value || t.type}`);
    }
    return t;
  }

  isAtEnd(): boolean {
    return this.peek().type === 'eof';
  }

  evalExpression(scope: Scope): unknown {
    return this.parseTernary(scope);
  }

  private parseTernary(scope: Scope): unknown {
    const cond = this.parseNullishOr(scope);
    if (this.match('punc', '?')) {
      const truthy = Boolean(cond);
      if (truthy) {
        const val = this.parseTernary(scope);
        this.expect('punc', ':');
        this.skipExpression();
        return val;
      }
      this.skipExpressionUntil(':');
      this.expect('punc', ':');
      return this.parseTernary(scope);
    }
    return cond;
  }

  private parseNullishOr(scope: Scope): unknown {
    let left = this.parseLogicalAnd(scope);
    while (true) {
      if (this.match('op', '||')) {
        if (left) {
          this.skipLogicalAnd();
        } else {
          left = this.parseLogicalAnd(scope);
        }
      } else if (this.match('op', '??')) {
        if (left !== null && left !== undefined) {
          this.skipLogicalAnd();
        } else {
          left = this.parseLogicalAnd(scope);
        }
      } else {
        break;
      }
    }
    return left;
  }

  private parseLogicalAnd(scope: Scope): unknown {
    let left = this.parseEquality(scope);
    while (this.match('op', '&&')) {
      if (!left) {
        this.skipEquality();
      } else {
        left = this.parseEquality(scope);
      }
    }
    return left;
  }

  private parseEquality(scope: Scope): unknown {
    let left = this.parseComparison(scope);
    while (true) {
      if (this.match('op', '===')) left = left === this.parseComparison(scope);
      else if (this.match('op', '!==')) left = left !== this.parseComparison(scope);
      else if (this.match('op', '==')) left = left == this.parseComparison(scope);
      else if (this.match('op', '!=')) left = left != this.parseComparison(scope);
      else break;
    }
    return left;
  }

  private parseComparison(scope: Scope): unknown {
    let left = this.parseAdditive(scope);
    while (true) {
      if (this.match('op', '<')) left = (left as any) < (this.parseAdditive(scope) as any);
      else if (this.match('op', '<=')) left = (left as any) <= (this.parseAdditive(scope) as any);
      else if (this.match('op', '>')) left = (left as any) > (this.parseAdditive(scope) as any);
      else if (this.match('op', '>=')) left = (left as any) >= (this.parseAdditive(scope) as any);
      else break;
    }
    return left;
  }

  private parseAdditive(scope: Scope): unknown {
    let left = this.parseMultiplicative(scope);
    while (true) {
      if (this.match('op', '+')) left = (left as any) + (this.parseMultiplicative(scope) as any);
      else if (this.match('op', '-')) left = Number(left) - Number(this.parseMultiplicative(scope));
      else break;
    }
    return left;
  }

  private parseMultiplicative(scope: Scope): unknown {
    let left = this.parseUnary(scope);
    while (true) {
      if (this.match('op', '*')) left = Number(left) * Number(this.parseUnary(scope));
      else if (this.match('op', '/')) left = Number(left) / Number(this.parseUnary(scope));
      else if (this.match('op', '%')) left = Number(left) % Number(this.parseUnary(scope));
      else break;
    }
    return left;
  }

  private parseUnary(scope: Scope): unknown {
    if (this.match('op', '!')) return !this.parseUnary(scope);
    if (this.match('op', '-')) return -Number(this.parseUnary(scope));
    if (this.match('op', '+')) return +Number(this.parseUnary(scope));
    if (this.match('id', 'typeof')) return typeof this.parseUnary(scope);
    return this.parsePostfix(scope);
  }

  private parsePostfix(scope: Scope): unknown {
    let value = this.parsePrimary(scope);
    while (true) {
      if (this.match('punc', '.')) {
        const prop = this.expect('id').value;
        value = this.readMember(value, prop, false);
      } else if (this.match('op', '?.')) {
        const prop = this.expect('id').value;
        value = this.readMember(value, prop, true);
      } else if (this.match('punc', '[')) {
        const idx = this.evalExpression(scope);
        this.expect('punc', ']');
        if (value === null || value === undefined) {
          throw new UnsupportedEjsError('Cannot read index of null/undefined');
        }
        const key = String(idx);
        if (BLOCKED_KEYS.has(key)) throw new UnsupportedEjsError('Blocked key');
        value = (value as Record<string, unknown>)[key];
      } else if (this.match('punc', '(')) {
        const args: unknown[] = [];
        if (!this.match('punc', ')')) {
          do {
            args.push(this.evalExpression(scope));
          } while (this.match('punc', ','));
          this.expect('punc', ')');
        }
        if (typeof value !== 'function') {
          throw new UnsupportedEjsError('Attempted to call non-function');
        }
        value = (value as EvalFn)(...args);
      } else {
        break;
      }
    }
    return value;
  }

  private readMember(target: unknown, prop: string, optional: boolean): unknown {
    if (BLOCKED_KEYS.has(prop)) throw new UnsupportedEjsError('Blocked property');
    if (target === null || target === undefined) {
      if (optional) return undefined;
      throw new UnsupportedEjsError(`Cannot read '${prop}' of null/undefined`);
    }
    if (Array.isArray(target)) {
      if (prop === 'length') return target.length;
      if (prop === 'filter') return (fn: EvalFn) => target.filter((item, idx) => Boolean(fn(item, idx)));
      if (prop === 'some') return (fn: EvalFn) => target.some((item, idx) => Boolean(fn(item, idx)));
      if (prop === 'every') return (fn: EvalFn) => target.every((item, idx) => Boolean(fn(item, idx)));
      if (prop === 'map') return (fn: EvalFn) => target.map((item, idx) => fn(item, idx));
      if (prop === 'includes') return (item: unknown) => target.includes(item);
      throw new UnsupportedEjsError(`Unsupported array member: ${prop}`);
    }
    if (typeof target === 'string') {
      if (prop === 'length') return target.length;
      if (prop === 'trim') return () => target.trim();
      if (prop === 'includes') return (sub: unknown) => target.includes(String(sub));
      if (prop === 'startsWith') return (sub: unknown) => target.startsWith(String(sub));
      if (prop === 'endsWith') return (sub: unknown) => target.endsWith(String(sub));
      if (prop === 'toLowerCase') return () => target.toLowerCase();
      if (prop === 'toUpperCase') return () => target.toUpperCase();
      throw new UnsupportedEjsError(`Unsupported string member: ${prop}`);
    }
    if (typeof target === 'object' || typeof target === 'function') {
      if (Object.hasOwn(target as object, prop)) {
        return (target as Record<string, unknown>)[prop];
      }
      return undefined;
    }
    throw new UnsupportedEjsError(`Unsupported member access: ${prop}`);
  }

  private parsePrimary(scope: Scope): unknown {
    // Arrow function: x => ...
    if (this.peek().type === 'id' && this.peek(1).type === 'op' && this.peek(1).value === '=>') {
      const param = this.next().value;
      this.next(); // =>
      return this.captureArrowFunction([param], scope);
    }
    // Arrow function: (a, b) => ...
    if (this.peek().type === 'punc' && this.peek().value === '(') {
      const arrowParams = this.tryConsumeArrowParams();
      if (arrowParams !== null) {
        return this.captureArrowFunction(arrowParams, scope);
      }
      this.next(); // (
      const val = this.evalExpression(scope);
      this.expect('punc', ')');
      return val;
    }
    // Array literal
    if (this.match('punc', '[')) {
      const items: unknown[] = [];
      if (!this.match('punc', ']')) {
        do {
          if (this.peek().type === 'punc' && this.peek().value === ']') break;
          items.push(this.evalExpression(scope));
        } while (this.match('punc', ','));
        this.expect('punc', ']');
      }
      return items;
    }
    const tok = this.next();
    if (tok.type === 'num') return Number(tok.value);
    if (tok.type === 'str') return tok.value;
    if (tok.type === 'id') {
      if (tok.value === 'true') return true;
      if (tok.value === 'false') return false;
      if (tok.value === 'null') return null;
      if (tok.value === 'undefined') return undefined;
      const found = lookupVar(scope, tok.value);
      if (found.found) return found.value;
      throw new UnsupportedEjsError(`Unknown identifier: ${tok.value}`);
    }
    throw new UnsupportedEjsError(`Unexpected token: ${tok.value || tok.type}`);
  }

  private tryConsumeArrowParams(): string[] | null {
    const saved = this.pos;
    if (!this.match('punc', '(')) return null;
    const params: string[] = [];
    if (!this.match('punc', ')')) {
      while (true) {
        const t = this.peek();
        if (t.type !== 'id') {
          this.pos = saved;
          return null;
        }
        params.push(this.next().value);
        if (this.match('punc', ',')) continue;
        if (this.match('punc', ')')) break;
        this.pos = saved;
        return null;
      }
    }
    if (!this.match('op', '=>')) {
      this.pos = saved;
      return null;
    }
    return params;
  }

  private captureArrowFunction(params: string[], closure: Scope): EvalFn {
    const isBlock = this.peek().type === 'punc' && this.peek().value === '{';
    const bodyStart = this.pos;
    if (isBlock) {
      this.skipBalanced('{', '}');
    } else {
      this.skipExpression();
    }
    const bodyTokens = [...this.tokens.slice(bodyStart, this.pos), { type: 'eof' as const, value: '' }];
    return (...args: unknown[]) => {
      const fnScope = createScope(closure);
      params.forEach((p, idx) => fnScope.vars.set(p, args[idx]));
      const sub = Object.create(SafeJsRunner.prototype) as SafeJsRunner;
      sub.tokens = bodyTokens;
      sub.pos = 0;
      if (isBlock) {
        const result = sub.execBlock(fnScope);
        return result?.returned ? result.value : undefined;
      }
      return sub.evalExpression(fnScope);
    };
  }

  private skipBalanced(open: string, close: string) {
    this.expect('punc', open);
    let depth = 1;
    while (depth > 0 && !this.isAtEnd()) {
      const t = this.next();
      if (t.type === 'punc' && t.value === open) depth++;
      else if (t.type === 'punc' && t.value === close) depth--;
    }
    if (depth !== 0) throw new UnsupportedEjsError(`Unbalanced ${open}${close}`);
  }

  private skipExpression() {
    let paren = 0, bracket = 0, brace = 0;
    while (!this.isAtEnd()) {
      const t = this.peek();
      if (paren === 0 && bracket === 0 && brace === 0) {
        if (t.type === 'punc' && (t.value === ',' || t.value === ';' || t.value === ')' || t.value === ']' || t.value === '}')) {
          break;
        }
      }
      this.next();
      if (t.type === 'punc') {
        if (t.value === '(') paren++;
        else if (t.value === ')') paren--;
        else if (t.value === '[') bracket++;
        else if (t.value === ']') bracket--;
        else if (t.value === '{') brace++;
        else if (t.value === '}') brace--;
      }
    }
  }

  private skipExpressionUntil(stopPunc: string) {
    let paren = 0, bracket = 0, brace = 0;
    while (!this.isAtEnd()) {
      const t = this.peek();
      if (paren === 0 && bracket === 0 && brace === 0 && t.type === 'punc' && t.value === stopPunc) break;
      this.next();
      if (t.type === 'punc') {
        if (t.value === '(') paren++;
        else if (t.value === ')') paren--;
        else if (t.value === '[') bracket++;
        else if (t.value === ']') bracket--;
        else if (t.value === '{') brace++;
        else if (t.value === '}') brace--;
      }
    }
  }

  private skipLogicalAnd() {
    this.skipOperandUntil(['||', '??']);
  }

  private skipEquality() {
    this.skipOperandUntil(['&&', '||', '??']);
  }

  private skipOperandUntil(stopOps: string[]) {
    let paren = 0, bracket = 0, brace = 0;
    while (!this.isAtEnd()) {
      const t = this.peek();
      if (paren === 0 && bracket === 0 && brace === 0) {
        if (t.type === 'op' && stopOps.includes(t.value)) break;
        if (t.type === 'punc' && [',', ';', ')', ']', '}', '?', ':'].includes(t.value)) break;
      }
      this.next();
      if (t.type === 'punc') {
        if (t.value === '(') paren++;
        else if (t.value === ')') paren--;
        else if (t.value === '[') bracket++;
        else if (t.value === ']') bracket--;
        else if (t.value === '{') brace++;
        else if (t.value === '}') brace--;
      }
    }
  }

  private execBlock(scope: Scope): ReturnSignal | null {
    this.expect('punc', '{');
    const inner = createScope(scope);
    while (!this.match('punc', '}')) {
      if (this.isAtEnd()) throw new UnsupportedEjsError('Unterminated block');
      const res = this.execSimpleStatement(inner);
      if (res?.returned) return res;
    }
    return null;
  }

  execSimpleStatement(scope: Scope): ReturnSignal | null {
    while (this.match('punc', ';')) {
      // empty statement
    }
    if (this.isAtEnd() || (this.peek().type === 'punc' && this.peek().value === '}')) return null;

    const tok = this.peek();
    if (tok.type === 'id' && (tok.value === 'const' || tok.value === 'let')) {
      this.next();
      const name = this.expect('id').value;
      this.expect('op', '=');
      const val = this.evalExpression(scope);
      this.match('punc', ';');
      scope.vars.set(name, val);
      return null;
    }
    if (tok.type === 'id' && tok.value === 'return') {
      this.next();
      if (this.match('punc', ';') || (this.peek().type === 'punc' && this.peek().value === '}')) {
        return { returned: true, value: undefined };
      }
      const val = this.evalExpression(scope);
      this.match('punc', ';');
      return { returned: true, value: val };
    }
    if (tok.type === 'id' && tok.value === 'if') {
      this.next();
      this.expect('punc', '(');
      const cond = Boolean(this.evalExpression(scope));
      this.expect('punc', ')');
      if (this.peek().type === 'punc' && this.peek().value === '{') {
        if (cond) {
          const res = this.execBlock(scope);
          if (this.match('id', 'else')) this.skipStatementOrBlock();
          return res;
        }
        this.skipBalanced('{', '}');
        if (this.match('id', 'else')) {
          return this.peek().type === 'punc' && this.peek().value === '{'
            ? this.execBlock(scope)
            : this.execSimpleStatement(scope);
        }
        return null;
      }
      if (cond) {
        const res = this.execSimpleStatement(scope);
        if (this.match('id', 'else')) this.skipStatementOrBlock();
        return res;
      }
      this.skipStatementOrBlock();
      if (this.match('id', 'else')) {
        return this.peek().type === 'punc' && this.peek().value === '{'
          ? this.execBlock(scope)
          : this.execSimpleStatement(scope);
      }
      return null;
    }
    throw new UnsupportedEjsError(`Unsupported statement: ${tok.value || tok.type}`);
  }

  private skipStatementOrBlock() {
    if (this.peek().type === 'punc' && this.peek().value === '{') {
      this.skipBalanced('{', '}');
      return;
    }
    while (!this.isAtEnd()) {
      const t = this.next();
      if (t.type === 'punc' && t.value === ';') break;
      if (t.type === 'punc' && t.value === '{') {
        this.pos--;
        this.skipBalanced('{', '}');
        break;
      }
    }
  }
}

function createRootScope(statData: unknown): Scope {
  const scope = createScope(null);
  const numberHelper = Object.assign((v: unknown) => Number(v), {
    isFinite: (v: unknown) => Number.isFinite(v),
    isNaN: (v: unknown) => Number.isNaN(v),
  });
  const mathHelper = {
    max: (...nums: unknown[]) => Math.max(...nums.map(Number)),
    min: (...nums: unknown[]) => Math.min(...nums.map(Number)),
    floor: (v: unknown) => Math.floor(Number(v)),
    ceil: (v: unknown) => Math.ceil(Number(v)),
    round: (v: unknown) => Math.round(Number(v)),
    abs: (v: unknown) => Math.abs(Number(v)),
  };
  scope.vars.set('getvar', (path: unknown, fallback?: unknown) => readStatVar(statData, path, fallback));
  scope.vars.set('Number', numberHelper);
  scope.vars.set('String', (v: unknown) => String(v));
  scope.vars.set('Boolean', (v: unknown) => Boolean(v));
  scope.vars.set('Math', mathHelper);
  return scope;
}

type BranchFrame = {
  parentActive: boolean;
  matched: boolean;
  active: boolean;
};

const DIRECTIVE_LINE_RE = /^\s*(?:#\s*:)?<%[-_]?\s*([\s\S]*?)\s*[-_]?%>\s*$/;
const INLINE_EXPR_RE = /<%[=-]\s*([\s\S]*?)\s*[-_]?%>/g;

function runDirectiveStatements(code: string, scope: Scope, stack: BranchFrame[]) {
  const isActive = () => stack.length === 0 || stack[stack.length - 1].active;
  let rest = code.trim();
  while (rest) {
    // 1. Closing brace with optional else / else if
    const closeElseIf = /^\}\s*else\s+if\s*\(/.exec(rest);
    if (closeElseIf) {
      if (!stack.length) throw new UnsupportedEjsError('Unexpected else if');
      const frame = stack[stack.length - 1];
      const condRange = extractBalancedParens(rest, closeElseIf[0].length - 1);
      const afterCond = rest.slice(condRange.end).trimStart();
      if (!afterCond.startsWith('{')) throw new UnsupportedEjsError('Expected { after else if');
      if (frame.parentActive && !frame.matched) {
        const cond = Boolean(evalSingleExpr(condRange.inner, scope));
        frame.active = cond;
        if (cond) frame.matched = true;
      } else {
        frame.active = false;
      }
      rest = afterCond.slice(1).trimStart();
      continue;
    }
    const closeElse = /^\}\s*else\s*\{/.exec(rest);
    if (closeElse) {
      if (!stack.length) throw new UnsupportedEjsError('Unexpected else');
      const frame = stack[stack.length - 1];
      frame.active = frame.parentActive && !frame.matched;
      frame.matched = true;
      rest = rest.slice(closeElse[0].length).trimStart();
      continue;
    }
    if (rest.startsWith('}')) {
      if (!stack.length) throw new UnsupportedEjsError('Unexpected }');
      stack.pop();
      rest = rest.slice(1).trimStart();
      continue;
    }
    // 2. Opening if (...) {
    const openIf = /^if\s*\(/.exec(rest);
    if (openIf) {
      const condRange = extractBalancedParens(rest, openIf[0].length - 1);
      const afterCond = rest.slice(condRange.end).trimStart();
      if (!afterCond.startsWith('{')) throw new UnsupportedEjsError('Expected { after if');
      const parentActive = isActive();
      const cond = parentActive ? Boolean(evalSingleExpr(condRange.inner, scope)) : false;
      stack.push({ parentActive, matched: cond, active: cond });
      rest = afterCond.slice(1).trimStart();
      continue;
    }
    // 3. Variable declaration statements (`const` / `let`) up to the next top-level control-flow boundary or end
    const runner = new SafeJsRunner(rest);
    while (!runner.isAtEnd()) {
      if (isActive()) {
        runner.execSimpleStatement(scope);
      } else {
        // Inactive branch: still validate syntax of declarations without mutating scope
        runner.execSimpleStatement(createScope(scope));
      }
    }
    break;
  }
}

function extractBalancedParens(src: string, openIndex: number): { inner: string; end: number } {
  let depth = 0;
  let quote = '';
  for (let i = openIndex; i < src.length; i++) {
    const ch = src[i];
    if (quote) {
      if (ch === '\\') {
        i++;
      } else if (ch === quote) {
        quote = '';
      }
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      continue;
    }
    if (ch === '(') depth++;
    else if (ch === ')') {
      depth--;
      if (depth === 0) {
        return { inner: src.slice(openIndex + 1, i), end: i + 1 };
      }
    }
  }
  throw new UnsupportedEjsError('Unbalanced parentheses in condition');
}

function evalSingleExpr(expr: string, scope: Scope): unknown {
  const runner = new SafeJsRunner(expr);
  const val = runner.evalExpression(scope);
  if (!runner.isAtEnd()) throw new UnsupportedEjsError('Trailing tokens in expression');
  return val;
}

/**
 * 尝试在卡内基于权威 stat_data 安全展开 EJS 条件世界书条目。
 * - 若文本不含 `<%`：原样返回 `{ text, handled: true }`。
 * - 若文本为本卡支持的 `# :<%_ ... _%>` / `<%= ... %>` 模板：展开后返回 `{ text, handled: true }`。
 * - 若包含非本卡支持的任意 EJS 语法：安全退回 `{ text, handled: false }`，交由宿主处理。
 */
export function evaluateCardEjsWorldbook(text: string, statData: unknown): CardEjsEvalResult {
  if (!text || !text.includes('<%')) {
    return { text, handled: true };
  }
  const hasNewline = text.includes('\r\n');
  const lines = text.split(/\r?\n/);
  const scope = createRootScope(statData);
  const stack: BranchFrame[] = [];
  const output: string[] = [];

  try {
    for (const line of lines) {
      const directive = DIRECTIVE_LINE_RE.exec(line);
      if (directive) {
        // Reject `<%= ... %>` or `<%- ... %>` mistakenly matched as directive when starting with `=`
        if (/^\s*(?:#\s*:)?<%[=-]/.test(line)) {
          // Treat as normal line with inline expression
        } else {
          runDirectiveStatements(directive[1], scope, stack);
          continue;
        }
      }
      const active = stack.length === 0 || stack[stack.length - 1].active;
      if (!active) continue;
      if (line.includes('<%')) {
        let unsupported = false;
        const expanded = line.replace(INLINE_EXPR_RE, (_m, expr: string) => {
          const val = evalSingleExpr(expr, scope);
          return val === null || val === undefined ? '' : String(val);
        });
        if (expanded.includes('<%')) unsupported = true;
        if (unsupported) throw new UnsupportedEjsError('Unrecognized inline EJS tag');
        output.push(expanded);
      } else {
        output.push(line);
      }
    }
    if (stack.length !== 0) {
      throw new UnsupportedEjsError('Unclosed conditional block');
    }
    return { text: output.join(hasNewline ? '\r\n' : '\n'), handled: true };
  } catch (error) {
    if (error instanceof UnsupportedEjsError) {
      return { text, handled: false };
    }
    throw error;
  }
}
