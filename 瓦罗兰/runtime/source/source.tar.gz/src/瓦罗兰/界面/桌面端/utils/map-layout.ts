import { detailedMaps } from './city';

type Point = { x: number; y: number };
type Box = { x: number; y: number; w: number; h: number };
export type MapView = Box & {
  scale: number; selected?: string | null; actions?: { id: string; markerId: string }[];
};

// 在 00-世界总图原图（1500 × 1050）上选取可见地标的像素。地区详情仍使用存档自己的坐标系。
const overviewLandmarks: Record<string, { pixel: [number, number]; name?: string }> = {
  area_01: { pixel: [552, 378] },  // 黄金海岸的星环与巨剑
  area_02: { pixel: [746, 447] },  // 海湾内的金色半岛城
  area_03: { pixel: [873, 551] },  // 地峡东侧山脊间的绿色河谷
  area_04: { pixel: [402, 215] },  // 西北麦田中的白石王城
  area_05: { pixel: [944, 232] },  // 红土高地的黑色堡垒
  area_06: { pixel: [656, 114] },  // 极北冰原中央的冰渊
  area_07: { pixel: [529, 538] },  // 运河上城与青绿下城之间的崖沿
  area_08: { pixel: [1292, 176] }, // 东北群岛的翠绿主岛
  area_09: { pixel: [1181, 574] }, // 蟒行群岛北段的自由港
  area_10: { pixel: [579, 815] },  // 沙海古都的太阳圆盘
  area_11: { pixel: [1015, 752] }, // 雨林的阶梯瀑布
  area_12: { pixel: [178, 643] },  // 西南云环中的主雪峰
  area_13: { pixel: [1320, 953] }, // 东南黑雾间的岛体
  area_14: { pixel: [1382, 433], name: '远洋东大陆' }, // 迷雾商站灯塔
};

// 区域 14 只有远洋航线属于实体世界。区域 15 与班德尔口袋域等待独立点位设计。
export function isMappedLocation(area: string | null, id: string, parent?: string | null) {
  return area !== 'area_15' && (area !== 'area_14' || [id, parent].some(key => /^14-2(?:-|$)/.test(key ?? '')));
}

/** 固定图上锚点，只移动名称，避开所有圆点及已排好的标签。 */
export function layoutDistrictLabels(districts: { id: string; name: string }[], scale: number) {
  const pins = districts.flatMap(({ id, name }) => {
    const landmark = overviewLandmarks[id];
    if (!landmark) return [];
    const [px, py] = landmark.pixel;
    return [{ id, name: landmark.name ?? name, anchor: { x: px / 1.5, y: py / 1.5 } }];
  });
  const boxes: Box[] = pins.map(({ anchor }) => ({ ...anchor, w: 14 * scale, h: 14 * scale }));
  return pins.map(district => {
    const w = (district.name.length * 12 + 26) * scale;
    const h = 28 * scale;
    const { x, y } = district.anchor;
    const candidates: Point[] = [{ x, y: y + 24 * scale }, { x, y: y - 24 * scale }];
    for (let radius = h + 8 * scale; radius <= 1000; radius += h + 8 * scale)
      for (let i = 0; i < 16; i++)
        candidates.push({
          x: x + Math.cos((i * Math.PI) / 8) * radius,
          y: y + Math.sin((i * Math.PI) / 8) * radius,
        });
    const clampedCandidates = candidates.map(point => ({
      x: Math.max(w / 2 + 4, Math.min(996 - w / 2, point.x)),
      y: Math.max(h / 2 + 4, Math.min(696 - h / 2, point.y)),
      w: w + 6,
      h: h + 6,
    }));
    const position = clampedCandidates.find(candidate => !boxes.some(box => overlaps(box, candidate))) ?? clampedCandidates[0];
    boxes.push(position);
    return { ...district, x: position.x, y: position.y };
  });
}

export function hasPrecisePosition(spot: any) {
  return spot?.地图位置?.精度 === '地点' && Number.isFinite(spot.地图位置.x) && Number.isFinite(spot.地图位置.y);
}

/** 保留存档中的实际世界坐标；详情只投影所属区域，不挪动地点或代填未知位置。 */
export function mapPositions(
  spots: Record<string, any>,
  _districts: Record<string, any>,
  districtId?: string,
): Record<string, Point> {
  const result: Record<string, Point> = {};
  const frame = districtId ? detailedMaps[districtId]?.bounds : undefined;
  if (districtId && !frame) return result;
  for (const [id, spot] of Object.entries(spots).sort(([a], [b]) => a.localeCompare(b))) {
    if (!hasPrecisePosition(spot) || (districtId && spot.片区id !== districtId)) continue;
    if (!isMappedLocation(spot.片区id, id, spot.上级地点id)) continue;
    const point = { x: spot.地图位置.x, y: spot.地图位置.y };
    if (frame) {
      if (!(frame.w > 0 && frame.h > 0)) continue;
      point.x = ((point.x - frame.x) / frame.w) * 1000;
      point.y = ((point.y - frame.y) / frame.h) * 700;
      if (!Number.isFinite(point.x) || !Number.isFinite(point.y) || point.x < 0 || point.x > 1000 || point.y < 0 || point.y > 700) continue;
    }
    result[id] = point;
  }
  return result;
}

/** 同一建筑保留一个精确点，内部场所仍能独立选择，避免制造相邻假楼宇。 */
export function groupMapPoints(spots: Record<string, any>, positions: Record<string, Point>, selected?: string | null) {
  const groups = new Map<string, string[]>();
  for (const id of Object.keys(positions)
    .filter(id => spots[id])
    .sort()) {
    const p = positions[id];
    const key = `${spots[id].片区id}:${p.x.toFixed(3)}:${p.y.toFixed(3)}`;
    groups.set(key, [...(groups.get(key) ?? []), id]);
  }
  return [...groups.values()].map(members => {
    const id =
      members.find(id => id === selected) ?? members.find(id => !members.includes(spots[id].上级地点id)) ?? members[0];
    return { id, spot: spots[id], members, ...positions[id] };
  });
}

function overlaps(a: Box, b: Box) {
  return Math.abs(a.x - b.x) < (a.w + b.w) / 2 && Math.abs(a.y - b.y) < (a.h + b.h) / 2;
}

/** 地区标签按实际屏幕像素避让其他标签及点位热区。 */
export function layoutMapLabels(spots: Record<string, any>, positions: Record<string, Point>, view: MapView) {
  const s = view.scale;
  const items = Object.entries(spots).filter(([id]) => {
    const p = positions[id];
    return p && p.x >= view.x && p.x <= view.x + view.w && p.y >= view.y && p.y <= view.y + view.h;
  });
  const boxes: Box[] = items.map(([id]) => ({ ...positions[id], w: 25 * s, h: 25 * s }));
  boxes.push({ x: view.x + 23 * s, y: view.y + 32 * s, w: 46 * s, h: 64 * s });
  boxes.push({ x: view.x + view.w - 24 * s, y: view.y + 58 * s, w: 48 * s, h: 116 * s });
  // 先为相邻按钮留出独立触区，后排的地点名称会自然避让。
  const actionPoints: { id: string; markerId: string; point: Point }[] = [];
  for (const action of view.actions ?? []) {
    if (!items.some(([id]) => id === action.markerId)) continue;
    const p = positions[action.markerId];
    const offsets = [[27, 0], [-27, 0], [0, -27], [0, 27], [26, -26], [-26, -26], [26, 26], [-26, 26]];
    const candidates = offsets.map(([dx, dy]) => ({
      x: p.x + dx * s, y: p.y + dy * s, w: 26 * s, h: 26 * s,
    })).filter(b => b.x - b.w / 2 >= view.x && b.x + b.w / 2 <= view.x + view.w
      && b.y - b.h / 2 >= view.y && b.y + b.h / 2 <= view.y + view.h);
    const actionBox = candidates.find(b => !boxes.some(other => overlaps(b, other)));
    if (actionBox) {
      boxes.push(actionBox);
      actionPoints.push({ ...action, point: actionBox });
    }
  }
  items.sort(([a], [b]) => Number(b === view.selected) - Number(a === view.selected) || a.localeCompare(b));
  return items
    .map(([id, spot]) => {
      const p = positions[id];
      const name = spot.名称 ?? '未命名地点';
      const label = name.length > 10 ? name.slice(0, 9) + '…' : name;
      const w = Math.max(54, label.length * 11 + 16),
        h = 23;
      let labelPoint = { x: p.x, y: p.y + 24 * s };
      const candidates = [
        [0, 24], [0, -24], [w / 2 + 16, 0], [-(w / 2 + 16), 0],
        [w / 2 + 14, 22], [-(w / 2 + 14), 22], [w / 2 + 14, -22], [-(w / 2 + 14), -22],
        [0, 44], [0, -44],
      ];
      let showLabel = id === view.selected;
      for (const [dx, dy] of candidates) {
        const cx = Math.max(view.x + (w / 2 + 6) * s, Math.min(view.x + view.w - (w / 2 + 6) * s, p.x + dx * s));
        const cy = Math.max(view.y + (h / 2 + 6) * s, Math.min(view.y + view.h - (h / 2 + 6) * s, p.y + dy * s));
        const box = { x: cx, y: cy, w: w * s, h: h * s };
        if (!boxes.some(other => overlaps(other, box))) {
          labelPoint = { x: cx, y: cy };
          showLabel = true;
          break;
        }
      }
      if (showLabel) boxes.push({ x: labelPoint.x, y: labelPoint.y, w: w * s, h: h * s });
      return { id, spot, anchor: p, label, width: w, height: h, ...labelPoint, showLabel,
        actions: actionPoints.filter(action => action.markerId === id),
        hasLeader: showLabel && Math.hypot(labelPoint.x - p.x, labelPoint.y - p.y) > 25 * s };
    });
}
