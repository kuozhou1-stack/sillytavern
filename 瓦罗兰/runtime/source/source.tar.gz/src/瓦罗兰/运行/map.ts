import { getExternalGeography } from './external-settings';
import type { State } from './core';

export const dragonRiftLinkId = 'rift_03-3-01_15-2-03';
export const iceWellPassageId = 'passage_06-1-03_15-4-01';
export const stillwaterPassageId = 'passage_03-3-03_15-4-02';
export const dragonRiftSettlementRule =
  '地图通路仅随已发生的剧情登记。玩家亲历龙脊凹谷（03-3-01）血战，并亲眼见到血玫瑰撕开通往杀戮荒林（15-2-03）的裂口时，'
  + `将玩家列入该事件的参与者，在关联记录id中追加「${dragonRiftLinkId}」，并按现场见闻登记两端已知地点。`
  + '旧事件已明确记载同一亲历事实时可在原事件补记关联。传闻、计划、普通龙战和别处的裂口均不登记这条通路。';

export const hiddenPassageSettlementRule =
  '按已发生的见闻结算秘密通路。玩家实际查明某一条的起点与去向时，在玩家.已知信息.获知事项用该条固定键登记性质“事实”、对象id为起点、内容及实际来源，并登记两端已知地点。'
  + `极北瓷冰秘殿（06-1-03）底层锁链井通冰封监视者视界（15-4-01）：${iceWellPassageId}。\n`
  + `深渊死水潭（03-3-03）潭底暗支通地下紫菌迷宫（15-4-02）：${stillwaterPassageId}。\n`
  + '两条独立。知道两端、主线到访、未证实的传言均不足以登记；查明路线即可，无须实际穿越。旧档已有明确查证记录可据原来源补记。';

export function witnessedMapLink(state: Pick<State, '玩家' | '事件'>, linkId: string) {
  const playerId = state.玩家?.id;
  if (!playerId || !state.事件) return false;
  const events = Object.entries(state.事件);
  const correctedIds = new Set(events.map(([, event]) => event.更正自事件id));
  return events.some(([id, event]) => {
    if (correctedIds.has(id) || !event.关联记录id?.includes(linkId) || !event.事实?.trim()
      || !(playerId in event.参与者)) return false;
    const source = event.各人可知来源?.[playerId]?.方式;
    return !source || source === '未设定' || source === '观察' || source === '事件';
  });
}

export function locationDescription(text: string | null) {
  // 旧版建筑简介在交通和交互之间拼接了一行固定人物名单。
  return text?.replace(/\r?\n常驻与高频人物：[^\r\n]*(?=\r?\n交互与暗流：)/g, '') ?? null;
}

/**
 * 依据外置区域与交通等级估算常规通行耗时（分钟）；
 * 偏远长途跋涉、跨洲航行、口袋维度与里世界通道返回 null，由叙事按真实长途/接引条件处理。
 */
export function estimateTravel(from: any, to: any, mode: string): number | null {
  if (!from?.片区id || !to?.片区id) return null;
  if ([from, to].some(spot => /里世界|异空间|异域|维度|荒野|禁区|天界|封印/.test(spot?.类型 ?? ''))) return null;

  const { districts } = getExternalGeography();
  const areaA = districts.find(d => d.id === from.片区id);
  const areaB = districts.find(d => d.id === to.片区id);
  if (areaA?.trafficTier !== '繁荣快线' || areaB?.trafficTier !== '繁荣快线') return null;

  // 同区域内部通勤（如瓦罗兰市 7 大地点间 10–35 分钟磁浮/快艇）
  if (from.片区id === to.片区id) {
    const sameParent = Boolean(from.上级地点id && from.上级地点id === to.上级地点id);
    if (sameParent) return mode === '步行' ? 10 : 5;
    if (mode === '步行') return 45;
    return mode === '网约车' ? 15 : 20;
  }

  // 瓦罗兰市 ⇄ 诺克斯维加斯（近海高速磁浮/观光飞艇 40–60 分钟）
  const pair = new Set([from.片区id, to.片区id]);
  if (pair.has('area_01') && pair.has('area_02')) {
    return mode === '步行' ? null : 50;
  }
  // 瓦罗兰市 ⇄ 皮尔特沃夫上城（1.5–2 小时高速城际磁浮）
  if (pair.has('area_01') && pair.has('area_07')) {
    return mode === '步行' ? null : 105;
  }
  // 其余跨洲繁荣快线由外部设定/剧情按 2–6 小时航线与车次推进，不套用市内短距通勤表
  return null;
}

export function visibleLocations(state: any): Record<string, any> {
  if (!state) return {};
  const knownIds = new Set(Object.keys(state.玩家?.已知信息?.已知地点 ?? {}));
  return Object.fromEntries(Object.entries(state.地点 ?? {}).filter(([id]) => knownIds.has(id)));
}

export function wheelView(
  view: { x: number; y: number; width: number; ratio: number; maxWidth?: number },
  point: { x: number; y: number },
  delta: number,
  mode = 0,
) {
  const pixels = delta * (mode === 1 ? 16 : mode === 2 ? 400 : 1);
  const maxWidth = view.maxWidth ?? 1000;
  const width = Math.max(
    Math.min(280, maxWidth),
    Math.min(maxWidth, view.width * Math.exp(Math.max(-100, Math.min(100, pixels)) * 0.002)),
  );
  const scale = width / view.width;
  return {
    width,
    center: {
      x: point.x - (point.x - view.x) * scale + width / 2,
      y: point.y - (point.y - view.y) * scale + (width * view.ratio) / 2,
    },
  };
}
