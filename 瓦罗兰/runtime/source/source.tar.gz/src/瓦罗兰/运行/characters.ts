import { Schema } from '../schema';
import { copy, uid, type State } from './core';
import {
  resolveCharacterStaticProfile,
  normalizeIdentityInput,
  parseStaticProfileEntry,
  bindCharacterStaticProfile,
  splitCharacterAuthoring,
} from './character-static';

/** 导入兼容：标准化身份、专属标识，并移除已明确退役的旧键。 */
export function normalizeCharacterImport(character: any) {
  const normalized = copy(character ?? {});
  delete normalized.id;
  if (normalized.身份 !== undefined) {
    normalized.身份 = normalizeIdentityInput(normalized.身份);
  }
  const signature = normalized?.专属标识;
  if (signature && typeof signature === 'object' && !Array.isArray(signature)) {
    for (const key of ['身体印记', '随身信物']) {
      const value = signature[key];
      if (typeof value === 'string') signature[key] = value.trim() ? [value] : [];
    }
  }
  if (normalized?.生活 && typeof normalized.生活 === 'object') {
    delete normalized.生活.联系方式;
    delete normalized.生活.约定;
    delete normalized.生活.近期社交交集;
  }
  if (normalized?.性特征?.性经验 && typeof normalized.性特征.性经验 === 'object') {
    delete normalized.性特征.性经验.依据事件id;
  }
  if (normalized?.性经验 && typeof normalized.性经验 === 'object') {
    delete normalized.性经验.依据事件id;
  }
  return normalized;
}

/** Bare authoring templates use `player`; exported packages retain their source identities. */
export function bindTemplatePlayer(character: any, state: State, characterId: string) {
  const playerId = state.玩家.id;
  const relations = character.关系网;
  if (
    !playerId ||
    playerId === 'player' ||
    characterId === 'player' ||
    state.角色.player ||
    !relations ||
    !Object.hasOwn(relations, 'player')
  )
    return;
  relations[playerId] = { ...relations.player, ...relations[playerId] };
  delete relations.player;
  // Remap identity references, never narrative text, event IDs or source snapshots.
  const visit = (value: any) => {
    if (!value || typeof value !== 'object') return;
    for (const [key, child] of Object.entries(value)) {
      if (key.startsWith('_')) continue;
      if (['人物id', '对象id'].includes(key) && child === 'player') value[key] = playerId;
      else visit(child);
    }
  };
  visit(character);
}

const STATIC_ROUTED_TOP_KEYS = new Set([
  '默认形态',
  '简介',
  '超凡能力',
  '伴生体',
  '心理年龄',
  '称呼',
  '形态衣橱',
  '性格',
  '专属标识',
  '网络倾向',
  '认知边界',
  '财力与消费观',
  '季节驻留',
  '静态关系锚点',
]);

const STATIC_ROUTED_APPEARANCE_KEYS = new Set([
  '身高',
  '体重',
  '整体体型',
  '三围信息',
  '罩杯',
  '主色调与高光焦点',
  '详细外表',
]);

export function assertCharacterMapped(source: any, parsed: any) {
  const missing: string[] = [];
  const genderText = String(parsed?.性别 ?? source?.性别 ?? '').trim();
  const isMale = ['男', '男性'].includes(genderText);
  const sexualApplicable = parsed?.层级 === '主要' && parsed?.性特征适用 !== false && !isMale;
  // 路由至静态档案库的字段及已明确退役字段不视作丢失；男性/次要角色的性特征仍严格拒绝。
  const allowedOutsideDynamic = (parts: string[]) =>
    (parts.length === 1 && STATIC_ROUTED_TOP_KEYS.has(parts[0])) ||
    (parts.length === 1 && sexualApplicable && ['性特征', '静态性特征'].includes(parts[0])) ||
    (parts.length === 1 && ['年龄确认时间', '籍贯'].includes(parts[0])) ||
    (parts.length === 2 && parts[0] === '外貌' && STATIC_ROUTED_APPEARANCE_KEYS.has(parts[1])) ||
    (parts.length === 2 && parts[0] === '生活' && ['联系方式', '约定', '近期社交交集', '财力与消费观', '季节驻留'].includes(parts[1])) ||
    (parts.length === 2 && parts[0] === '经历' && parts[1] === '人生经历') ||
    (parts.length === 3 && parts[0] === '性特征' && parts[1] === '性经验' && parts[2] === '依据事件id') ||
    (parts.length === 2 && parts[0] === '性经验' && parts[1] === '依据事件id') ||
    (parts.length === 4 && parts[0] === '生活' && parts[1] === '目标' && parts[3] === '来源') ||
    (parts.length === 3 && parts[0] === '重要记录' && parts[2] === '来源') ||
    (parts.length === 3 && parts[0] === '关系网' && parts[2] === '姓名');

  const scan = (before: any, after: any, parts: string[]) => {
    if (!before || typeof before !== 'object' || Array.isArray(before)) return;
    for (const [key, value] of Object.entries(before)) {
      const field = [...parts, key];
      if (!Object.hasOwn(after ?? {}, key)) {
        if (!allowedOutsideDynamic(field)) missing.push(field.join('.'));
      } else scan(value, after[key], field);
    }
  };
  scan(source, parsed, []);
  if (missing.length) throw Error('导入字段会被 Schema 删除，请修正：' + missing.join('、'));
}

export function validateCharacterPackage(pack: any) {
  if (!pack || pack.格式版本 !== '澄湾角色包/1' || typeof pack.id !== 'string' || !pack.角色)
    throw Error('角色包结构不完整');
  const normalized = normalizeCharacterImport(pack.角色);
  const { dynamic } = splitCharacterAuthoring(normalized, pack.id, normalized.层级 === '次要' ? '次要' : '主要');
  const data = Schema.parse({
    角色: { [pack.id]: dynamic },
    手机: { 账号: pack.手机?.账号, 原文: pack.手机 },
    世界: { 当前时间: pack.来源?.导出故事时间 },
  });
  assertCharacterMapped(normalized, data.角色[pack.id]);
  if (pack.静态档案) parseStaticProfileEntry(pack.静态档案, pack.id);
  for (const account of Object.values(data.手机.账号))
    if (account.人物id !== pack.id) throw Error('角色包包含其他人物账号');
  const ids = new Set(Object.keys(data.手机.账号));
  for (const [root, field] of Object.entries({
    消息: '发送账号id',
    帖子: '发布账号id',
    评论: '评论账号id',
    点赞: '账号id',
    转发: '账号id',
  }))
    for (const item of Object.values((data.手机.原文 as any)[root]) as any[])
      if (!ids.has(item[field])) throw Error('角色包包含非本人源内容：' + root);
  return pack;
}

export function exportCharacter(state: State, id: string, includeStatic = true) {
  if (!state.角色[id]) throw Error('人物不存在');
  const accounts = Object.fromEntries(Object.entries(state.手机.账号).filter(([, a]) => a.人物id === id));
  const accountIds = Object.keys(accounts);
  const own: Record<string, any> = { 账号: accounts };
  for (const [root, field] of Object.entries({
    消息: '发送账号id',
    帖子: '发布账号id',
    评论: '评论账号id',
    点赞: '账号id',
    转发: '账号id',
  })) {
    own[root] = Object.fromEntries(
      Object.entries((state.手机.原文 as any)[root]).filter(([, r]: any) => accountIds.includes(r[field])),
    );
  }
  const staticProfile = includeStatic ? resolveCharacterStaticProfile(state, id) : undefined;
  return copy({
    格式版本: '澄湾角色包/1',
    id,
    角色: state.角色[id],
    ...(staticProfile ? { 静态档案: staticProfile } : {}),
    手机: own,
    来源: { 来源存档id: state._系统.存档id, 导出故事时间: state.世界.当前时间 },
    来源档案: Object.fromEntries(Object.entries(state._系统.来源档案).filter(([, r]) => r.人物id === id)),
    关联约定: Object.fromEntries(Object.entries(state.约定).filter(([, r]) => Object.hasOwn(r.参与者, id))),
    关联委托: Object.fromEntries(Object.entries(state.委托).filter(([, row]) => row.委托人id === id)),
  });
}

export function deleteCharacter(state: State, id: string) {
  const person = state.角色[id];
  if (!person) throw Error('人物不存在');
  const pack = exportCharacter(state, id);
  const removedMessages = new Set(Object.keys(pack.手机.消息 ?? {}));
  const removedPosts = new Set(Object.keys(pack.手机.帖子 ?? {}));
  for (const [root, records] of Object.entries(pack.手机))
    for (const key of Object.keys(records)) {
      if (root === '账号') delete state.手机.账号[key];
      else delete (state.手机.原文 as any)[root][key];
    }
  if (removedMessages.size) {
    for (const session of Object.values(state.手机.会话)) {
      session._窗口._近期id = session._窗口._近期id.filter(mid => !removedMessages.has(mid));
    }
  }
  if (removedPosts.size) {
    for (const feed of Object.values(state.手机._动态流)) {
      feed._近期id = feed._近期id.filter(pid => !removedPosts.has(pid));
    }
  }
  for (const [key, source] of Object.entries(state._系统.来源档案))
    if (source.人物id === id) delete state._系统.来源档案[key];
  const invalidatedTasks = new Set<string>();
  for (const [taskId, task] of Object.entries(state._系统.任务))
    if (task.目标id.includes(id) && task.状态 !== '已提交') {
      task.状态 = '失效';
      task.候选结果JSON = null;
      invalidatedTasks.add(taskId);
    }
  if (invalidatedTasks.size) {
    for (const other of Object.values(state.角色)) {
      if (other.层级 === '主要' && other._更新循环.待处理任务id && invalidatedTasks.has(other._更新循环.待处理任务id)) {
        other._更新循环.待处理任务id = null;
      }
    }
  }
  state.世界.当前场景.在场人物 = state.世界.当前场景.在场人物.filter(personId => personId !== id);
  state._系统.角色停用标识[id] = { 姓名: person.姓名, 版本: person._管理.版本 + 1 };
  delete state.角色[id];
}

export function importCharacter(
  state: State,
  id: string,
  character: any,
  pack?: any,
  hasDisabledSnapshot = true,
  staticProfileOverride?: any,
) {
  if (hasDisabledSnapshot && state._系统.角色库版本 && state._系统.角色停用标识[id])
    throw Error('该 ID 已停用，请在角色库重新开启，不能用导入覆盖关闭快照');
  const version = Math.max(state.角色[id]?._管理.版本 ?? 0, state._系统.角色停用标识[id]?.版本 ?? 0) + 1;
  const { person, sourceId, source } = prepareImportedCharacter(state, id, character, version, pack, staticProfileOverride);
  if (state.角色[id]) deleteCharacter(state, id);
  state.角色[id] = person;
  delete state._系统.角色停用标识[id];
  state._系统.来源档案[sourceId] = source;
}

/** 外档手机记录随来源材料保存，启用人物时只恢复本存档建立的账号。 */
export function prepareImportedCharacter(
  state: State, id: string, character: any, version: number, pack?: any, staticProfileOverride?: any,
) {
  if (pack) {
    validateCharacterPackage(pack);
    if (pack.id !== id) throw Error('角色包 ID 不一致');
  }
  const sourceId = uid('source');
  const normalized = normalizeCharacterImport(character);
  const { dynamic: validated, staticProfile } = splitCharacterAuthoring(
    normalized,
    id,
    normalized.层级 === '次要' ? '次要' : '主要',
  );
  assertCharacterMapped(normalized, validated);
  if (!pack) bindTemplatePlayer(validated, state, id);
  validated._管理.版本 = version;
  validated._管理.来源档案id = sourceId;
  const finalStatic = pack?.静态档案
    ? parseStaticProfileEntry(pack.静态档案, id)
    : staticProfileOverride
      ? parseStaticProfileEntry(staticProfileOverride, id)
      : staticProfile;
  bindCharacterStaticProfile(id, validated, finalStatic);
  const source: State['_系统']['来源档案'][string] = {
    人物id: id,
    格式版本: pack?.格式版本 ?? '裸角色资料',
    来源存档id: pack?.来源?.来源存档id ?? null,
    导出故事时间: pack?.来源?.导出故事时间 ?? null,
    原时间锚点: validated.层级 === '主要' ? validated._更新循环.上次更新变量时间 : null,
    原始快照JSON: JSON.stringify(pack ?? { id, 角色: validated }),
    当前融入状态: '待融入',
    资源清单: {},
  };
  return { person: validated, sourceId, source };
}
