import { reactive } from 'vue';
import {
  getExternalGeography,
  subscribeExternalSettings,
  type ExternalDistrict,
} from '../../../运行/external-settings';

export type DistrictMap = {
  bounds: { x: number; y: number; w: number; h: number };
  theme: string;
  zones: { id?: string; name: string; kind: string; x: number; y: number; w: number; h: number }[];
};

/** 区域与地图配置全部来自外置设定（外置设定/地点/区域与地图.json），随外置资料加载自动响应式刷新。 */
export const worldDistricts = reactive<ExternalDistrict[]>([]);
export const cityDistricts = reactive<ExternalDistrict[]>([]);
export const cityDistrictNames = reactive<Record<string, string>>({});
export const detailedMaps = reactive<Record<string, DistrictMap>>({});

function syncFromExternal() {
  const { districts } = getExternalGeography();
  worldDistricts.splice(0, worldDistricts.length, ...districts);
  const livable = districts.filter(d => d.layer === '表世界' && d.trafficTier === '繁荣快线');
  cityDistricts.splice(0, cityDistricts.length, ...(livable.length ? livable : districts));

  for (const key of Object.keys(cityDistrictNames)) delete cityDistrictNames[key];
  for (const key of Object.keys(detailedMaps)) delete detailedMaps[key];
  for (const d of districts) {
    cityDistrictNames[d.id] = d.name;
    detailedMaps[d.id] = d.map;
  }
}

syncFromExternal();
subscribeExternalSettings(syncFromExternal);
