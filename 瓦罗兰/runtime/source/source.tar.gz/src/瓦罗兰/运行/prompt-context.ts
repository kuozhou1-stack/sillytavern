import { organizationReferenceContext } from './knowledge-context';
import { isMap, isScalar, isSeq, parseDocument } from 'yaml';

import type { State } from './core';
import { modelState } from './character-activity';
import { projectCharacterStaticContext } from './character-static';
import { createSourceContextProjector } from './source-context';
import { workerTask } from './worker-task';
import { sha256 } from './browser-crypto';
import { evaluateCardEjsWorldbook } from './ejs-worldbook';

export type PromptPurpose = 'story' | 'inline' | 'variables' | 'knowledge' | 'novel';
export type VariableRuleFilterContext = {
  state: State;
  input?: string;
  recentText?: string;
  phoneActive?: boolean;
  archiveOnly?: 'person' | 'phone';
};
type PromptContext = {
  purpose: PromptPurpose;
  state: State;
  projection?: Record<string, any>;
  input?: string;
  recentText?: string;
  phoneActive?: boolean;
  archiveOnly?: 'person' | 'phone';
};
export type PromptRequestContext = {
  purpose?: PromptPurpose;
  expandPrompt: (text: string) => string;
  updateWorldInfo: boolean;
};
const contextMacro = /\{\{valoran_context\}\}/g;
const ruleMacro = /#\s*\{\{valoran_variables\}\}\s*([\s\S]*?)#\s*\{\{valoran_variables_end\}\}/g;

export function promptContextText(readState: () => State, context?: PromptContext) {
  if (context && !['story', 'inline', 'variables'].includes(context.purpose)) return '';
  const state = context?.state ?? readState();
  const data = context?.projection ?? modelState(state);
  const status = (projected: unknown) => `<status_current_variable>\n${JSON.stringify(projected)}\n</status_current_variable>`;
  const organizations = organizationReferenceContext(state, context?.purpose === 'variables' ? 'variables' : context?.purpose === 'inline' ? 'inline' : 'story');
  const orgBlock = organizations ? `\n<organization_reference>\n${JSON.stringify(organizations)}\n</organization_reference>` : '';
  if (context?.purpose === 'variables') return status(data) + orgBlock;
  const activeIds = Object.keys(data.角色 ?? {});
  const staticProfiles = projectCharacterStaticContext(state, activeIds, {
    purpose: context?.purpose ?? 'story',
    input: context?.input,
    recentText: context?.recentText,
    phoneActive: context?.phoneActive,
  });
  const staticBlock = staticProfiles
    ? `\n<character_static_context>\n${JSON.stringify(staticProfiles)}\n</character_static_context>`
    : '';
  const project = createSourceContextProjector(state, data);
  const sources = Object.fromEntries(activeIds.flatMap(id => {
    const sourceId = state.角色[id]?._管理.来源档案id, source = sourceId && state._系统.来源档案[sourceId];
    const missing = source && project(sourceId, source);
    return missing ? [[sourceId, missing]] : [];
  }));
  const people = { ...data.角色 };
  for (const [id, card] of Object.entries(staticProfiles ?? {})) {
    if (!card.当前形态详情?.表现 || !people[id]) continue;
    const person = { ...people[id] };
    delete person.当前形态;
    if (person.外貌 && /星守|星之守护者|战衣|战甲|战裙|黑色玫瑰/.test(person.外貌.今日穿搭 ?? '')) {
      person.外貌 = { ...person.外貌 };
      delete person.外貌.今日穿搭;
    }
    people[id] = person;
  }
  return status({ ...data, 角色: people }) + staticBlock + orgBlock + (Object.keys(sources).length
    ? `\n<readonly_source_context>\n${JSON.stringify(sources)}\n</readonly_source_context>` : '');
}

const PHONE_RULE_SIGNAL_RE =
  /手机|星讯|星声|发帖|动态|热搜|朋友圈|点赞|评论|转发|私聊|消息|群聊|建群|拉.{0,8}进群|入群|退群|群公告|群昵称|直播|网购|语音|视频通话|好友申请|联系人|关注|撤回/;
const NOVEL_RULE_SIGNAL_RE = /奇遇|系统币|商店|蓝色精粹|日常任务|(?:买|兑换|领取).{0,8}(?:史诗|传说|神话)(?:装备|奇物|商品)/;

function pruneSharedTypeDefinitions(shared: string, remainingYaml: string): string {
  const lines = shared.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  // Custom multiline declarations can carry dependencies on continuation lines.
  if (lines.some(line => !/^type\s+[^\s=]+\s*=.*;\s*$/.test(line))) return shared;
  const defs = lines.map(line => {
    const match = line.match(/^type\s+([^\s=]+)\s*=/);
    return { name: match?.[1] ?? '', line };
  });
  const keep = new Set<string>();
  const usedIn = (text: string, name: string) =>
    Boolean(name) && new RegExp(`(?<![\\p{L}\\p{N}_])${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![\\p{L}\\p{N}_])`, 'u').test(text);
  for (const def of defs) {
    if (usedIn(remainingYaml, def.name)) keep.add(def.name);
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const def of defs) {
      if (!keep.has(def.name)) continue;
      for (const dep of defs) {
        if (!keep.has(dep.name) && usedIn(def.line, dep.name)) {
          keep.add(dep.name);
          changed = true;
        }
      }
    }
  }
  return defs.filter(def => !def.name || keep.has(def.name)).map(def => def.line).join('\n');
}

/** 按当前请求通道裁剪未涉及的规则区块（奇遇/手机/摘要/纯归档）；非常规或用户自定义非标文本原样保留。 */
export function filterVariableRulesForContext(content: string, context?: VariableRuleFilterContext): string {
  if (!context || !/^\s*变量更新规则\s*:/m.test(content)) return content;
  const doc = parseDocument(content);
  if (doc.errors.length) return content;
  const rules = doc.get('变量更新规则', true);
  if (!isMap(rules) || rules.flow) return content;

  const { state } = context;
  const tasks = Object.values(state._系统?.任务 ?? {});
  const activeTasks = tasks.filter(task => !['已提交', '取消', '失效'].includes(task.状态));
  const hasOpeningOrIntegration =
    !state._系统?.建档完成 || activeTasks.some(task => task.类别 === '建档' || task.类别 === '自然融入');
  const hasPendingPhoneArchive = activeTasks.some(
    task => task.类别 === '摘要' && !String(task.触发来源 ?? '').startsWith('人物'),
  );
  const signalText = [
    context.input ?? '',
    context.recentText ?? '',
    state.世界?.当前场景?.正在进行的事 ?? '',
    state.世界?.当前场景?.环境状态 ?? '',
  ].join('\n');

  let changed = false;
  const removeKey = (map: any, key: string) => {
    if (isMap(map) && map.has(key)) {
      map.delete(key);
      changed = true;
    }
  };

  if (context.archiveOnly === 'person') {
    for (const key of ['奇遇系统', '世界', '玩家', '地点', '约定', '委托', '事件', '组织', '手机']) removeKey(rules, key);
  } else if (context.archiveOnly === 'phone') {
    for (const key of ['奇遇系统', '世界', '玩家', '角色', '地点', '约定', '委托', '事件', '组织']) removeKey(rules, key);
    const phone = rules.get('手机', true);
    if (isMap(phone)) {
      for (const pair of [...phone.items]) {
        const key = isScalar(pair.key) ? String(pair.key.value) : '';
        if (key && key !== '摘要') removeKey(phone, key);
      }
    }
  } else {
    const needNovel =
      Boolean(state.奇遇系统?._启用) ||
      Object.keys(state.奇遇系统?.任务 ?? {}).length > 0 ||
      NOVEL_RULE_SIGNAL_RE.test(signalText);
    if (!needNovel) removeKey(rules, '奇遇系统');

    const needPhone =
      Boolean(context.phoneActive) ||
      hasOpeningOrIntegration ||
      hasPendingPhoneArchive ||
      PHONE_RULE_SIGNAL_RE.test(signalText);
    if (!needPhone) {
      removeKey(rules, '手机');
    } else if (!hasPendingPhoneArchive) {
      const phone = rules.get('手机', true);
      removeKey(phone, '摘要');
    }
  }

  if (!changed) return content;

  const sharedNode = rules.get('公共类型定义', true);
  if (isScalar(sharedNode) && typeof sharedNode.value === 'string') {
    const snapshot = doc.clone();
    const snapRules = snapshot.get('变量更新规则', true);
    if (isMap(snapRules)) snapRules.delete('公共类型定义');
    const remainingText = snapshot.toString({ lineWidth: 0 });
    const pruned = pruneSharedTypeDefinitions(sharedNode.value, remainingText);
    if (!pruned) rules.delete('公共类型定义');
    else if (pruned !== sharedNode.value) {
      const node = doc.createNode(pruned);
      node.type = 'BLOCK_LITERAL';
      rules.set('公共类型定义', node);
    }
  }
  return doc.toString({ lineWidth: 0 }).trim();
}

export function variableRuleContent(content: string, worker = true, filter?: VariableRuleFilterContext) {
  const text = content.replace(/#\s*\{\{(?:valoran_variables(?:_end)?|\/valoran_variables)\}\}/g, '').trim();
  const filtered = filter ? filterVariableRulesForContext(text, filter) : text;
  return worker && /^\s*变量输出格式\s*:/m.test(filtered) ? `${workerTask}\n${filtered}` : filtered;
}

export function variableRuleText(content: string, filter?: VariableRuleFilterContext) {
  return variableRuleContent(content, false, filter);
}

/** Expand card EJS conditionals and card macros before entering shared native events; no request state lives in page macros. */
export function createPromptRequestContext(context: PromptContext): PromptRequestContext {
  return {
    purpose: context.purpose,
    updateWorldInfo: context.purpose === 'story' || context.purpose === 'inline',
    expandPrompt: text =>
      evaluateCardEjsWorldbook(text, context.state).text
        .replace(contextMacro, () => promptContextText(() => context.state, context))
        .replace(ruleMacro, (_match, content: string) =>
          context.purpose === 'inline' ? variableRuleText(content, context) : '',
        ),
  };
}

/** Content expansion only: Tavern owns the entry's role, position, depth and order. */
export function registerPromptMacros(readState: () => State) {
  const context = registerMacroLike(contextMacro, () => promptContextText(readState));
  const rules = registerMacroLike(
    ruleMacro,
    (_context, _match, content: string) => variableRuleText(content),
  );
  return () => { context.unregister(); rules.unregister(); };
}

type RuleEdit = { start: number; end: number; text: string };

/** Retain the exact spelling and layout outside the migrated YAML fields. */
function applyRuleEdits(content: string, edits: RuleEdit[]) {
  for (const { start, end, text } of edits.sort((a, b) => b.start - a.start || b.end - a.end))
    content = content.slice(0, start) + text + content.slice(end);
  return content;
}

function upgradeVariableFormat(content: string) {
  const oldReply = '回复只写一个 JSON 对象，唯一字段 JSONPatch 是补丁数组序列化后的字符串。对象前后不写计划、解释、正文或代码围栏。';
  const oldEmpty = '没有变化时直接返回 {"JSONPatch":"[]"}。';
  const inlineFormat = 'JSONPatch 内直接写 JSON 数组。正文中的说明和代码示例不作为变量更新。';
  const oldInline = 'JSONPatch 内直接写 JSON 数组；没有变化时写 []。正文中的说明和代码示例不作为变量更新。';
  if (!content.includes("'" + oldReply + "'") && !content.includes(oldEmpty) && !content.includes(oldInline)) return content;
  const contract = parseDocument(content).get('变量输出格式', true);
  if (!isMap(contract) || contract.flow) return content;
  const edits: RuleEdit[] = [];
  const inline = contract.get('正文同次', true);
  if (isSeq(inline)) {
    const item = inline.items.find(item => isScalar(item) && item.value === oldInline);
    if (isScalar(item) && item.range) {
      const [start, end] = item.range;
      edits.push({ start, end, text: content.slice(start, end).replace(oldInline, inlineFormat) });
    }
  }
  const rules = contract.get('rule', true);
  if (!isSeq(rules)) return applyRuleEdits(content, edits);
  const empty = rules.items.find(item => isScalar(item) && (item.value === oldEmpty || item.value === '后台结算' + oldEmpty));
  if (isScalar(empty) && empty.range && !rules.flow) {
    const [start, end, lineEnd] = empty.range;
    const lineStart = content.lastIndexOf('\n', start - 1) + 1;
    const prefix = content.slice(lineStart, start);
    if (/^ *- +$/.test(prefix)) {
      const onlyItem = rules.items.length === 1;
      const text = onlyItem || empty.comment
        ? prefix.slice(0, prefix.indexOf('-')) + (onlyItem ? '[]' : '') + content.slice(end, lineEnd) : '';
      edits.push({ start: lineStart, end: lineEnd, text });
    }
  }
  const reply = rules.items.find(item => isScalar(item) && item.value === oldReply);
  if (!isScalar(reply) || !reply.range) return applyRuleEdits(content, edits);
  edits.push({ start: reply.range[0], end: reply.range[1], text: "'本轮为后台变量结算时，" + oldReply + "'" });
  if (!contract.has('正文同次') && contract.range) {
    const start = contract.range[0], indent = content.slice(content.lastIndexOf('\n', start - 1) + 1, start);
    const newline = content.includes('\r\n') ? '\r\n' : '\n';
    const text = [
      '正文同次:',
      '  - 本轮同时生成剧情和变量时，先写正文，再在末尾输出 <UpdateVariable><JSONPatch>补丁数组</JSONPatch></UpdateVariable>。',
      '  - ' + inlineFormat,
      '  - \'同次示例：<UpdateVariable><JSONPatch>[{"op":"replace","path":"/玩家/当前状态/体力值","value":79}]</JSONPatch></UpdateVariable>\'',
      '',
    ].join(newline + indent);
    edits.push({ start, end: start, text });
  }
  const format = contract.items.find(pair => isScalar(pair.key) && pair.key.value === 'format');
  if (format && isScalar(format.key) && format.key.range && isScalar(format.value) &&
      format.value.type === 'BLOCK_LITERAL' && !contract.has('后台结算示例'))
    edits.push({ start: format.key.range[0], end: format.key.range[1], text: '后台结算示例' });
  return applyRuleEdits(content, edits);
}

/** Migrate the two shipped rule lines; edited sentences and all other text retain their owner. */
function upgradeVariableRules(content: string) {
  const oldGeneral = '下列类型描述保存后的字段，不是每轮填写清单。新增认知记实际来源，性质变化须有新依据。';
  const oldDebt = '仅有实际借款、欠款、待退款、应收应付时建立，保存对象、金额与条件；实际清偿或取消才改状态，并引用对应交易。不计入当前金币余额，不再另存获知来源。';
  if (!content.includes(oldGeneral) && !content.includes(oldDebt)) return content;
  const doc = parseDocument(content);
  const edits: RuleEdit[] = [];
  const general = doc.getIn(['变量更新规则', '通用约定'], true);
  if (isScalar(general) && general.range && general.type === 'BLOCK_LITERAL') {
    const [start, end] = general.range;
    const text = content.slice(start, end).replace(/^([ ]+)下列类型描述保存后的字段，不是每轮填写清单。新增认知记实际来源，性质变化须有新依据。(?=\r?$)/m,
      '$1写入变量的每项正文事实都保留原来的主语、人数和确定程度，在目标、计划或人物感受中转述时也一样。例如两名旅客一同进站，领队丢了行李，记作“两人进站，领队丢失行李”，其余人的行李状况未知。新增认知记实际来源，转述和推测保留原性质，性质变化须有新依据。下列字段按需填写。');
    edits.push({ start, end, text });
  }
  const debtRules = doc.getIn(['变量更新规则', '玩家', '资金', '未结事项', 'check'], true);
  if (isSeq(debtRules) && !debtRules.flow) {
    const debt = debtRules.items.find(item => isScalar(item) && item.value === oldDebt);
    if (isScalar(debt) && debt.range && debt.type === 'PLAIN') {
      const [start, end] = debt.range;
      const prefix = content.slice(content.lastIndexOf('\n', start - 1) + 1, start);
      const newline = content.includes('\r\n') ? '\r\n' : '\n';
      edits.push({ start, end, text:
        '实际借款、欠款、待退款或已确认的应收应付，写入本清单。明确答应支付或报销但尚未付款时记录对方与条件；只谈妥倍率就把倍率写在条件中，金额留null。单方报价不建应付，同一承诺再次确认沿用原id。' + newline +
        prefix + '未结事项不计入余额，不另存获知来源。实际清偿后改为已结并关联对应交易；明确取消才改为取消。' });
    }
  }
  return applyRuleEdits(content, edits);
}

const historicalRuleHashes = new Set([
  '7f64f424738ed1c867bcf7e7f9f2de8da8448b202299b5c021ea5355d3d86df7',
  '495c3fcf9dad4ac0e055c26e518e7b458205a7f32e02c29a3b1bbbc1c0bb98df',
  'b0ff893e776356d26d8a1193f9e9681bcde774589eaf9786bb458c828a9fddad',
  'f272a8e0e842e9b00e58148cd84745b62aa2974098a144883ec9b00c1c969727',
  'edba3dc92aea392a9a1e93f481ca50adfb299df3ec524f45815ba1767285d85b',
]);
let lastRuleCheck: { text: string; result: Promise<boolean> } | undefined;
function isHistoricalOfficialRule(text: string) {
  if (lastRuleCheck?.text === text) return lastRuleCheck.result;
  const normalized = text.replaceAll('\r\n', '\n').trim();
  const result = sha256(new TextEncoder().encode(normalized)).then(digest => historicalRuleHashes.has(digest));
  lastRuleCheck = { text, result };
  return result;
}

/** Sync the saved story mode while retaining edited rule text and native placement. */
export async function preparePromptWorldbook(inline = false, assertActive?: () => void) {
  assertActive?.();
  const book = getCharWorldbookNames('current').primary;
  if (!book) throw Error('角色卡未绑定世界书');
  const entries = await getWorldbook(book);
  assertActive?.();
  // 仅迁移新旧瓦罗兰卡中未经编辑的官方规则原文；其他角色卡或已手工编辑的条目保持原样。
  const hasValoranSetting = (rows: WorldbookEntry[]) =>
    rows.some(entry => entry.name === '世界设定｜瓦洛兰' || ['世界设定｜现代奥术都市与表里维稳', '世界设定｜现代魔导都市与表里维稳'].includes(entry.name));
  const oldRule = hasValoranSetting(entries)
    ? entries.find(entry => entry.name.replace(/\s+/g, '') === '[mvu_update]变量更新规则') : undefined;
  const shippedRule = oldRule && await isHistoricalOfficialRule(oldRule.content) ? oldRule : undefined;
  const maintainedRules = shippedRule
    ? (await import(/* webpackMode: "eager" */ '../世界书/变量/变量更新规则.yaml?raw')).default : undefined;
  const prepareEntry = (entry: WorldbookEntry, hasSetting: boolean) => {
    let content = entry.content;
    if (entry.name === '变量列表')
      content = content.replace(/---\s*<status_current_variable>\s*\{\{format_message_variable::stat_data\}\}\s*<\/status_current_variable>/,
        '{{valoran_context}}');
    const variableRule = ['[mvu_update]变量更新规则', '[mvu_update]变量输出格式'].includes(entry.name.replace(/\s+/g, ''));
    if (entry.name.replace(/\s+/g, '') === '[mvu_update]变量输出格式') content = upgradeVariableFormat(content);
    if (entry.name.replace(/\s+/g, '') === '[mvu_update]变量更新规则') {
      content = hasSetting && maintainedRules && shippedRule && entry.uid === shippedRule.uid && content === shippedRule.content
        ? maintainedRules : upgradeVariableRules(content);
    }
    if (variableRule) {
      content = content.replaceAll('# {{/valoran_variables}}', '# {{valoran_variables_end}}');
      if (!/^#\s*\{\{valoran_variables\}\}/.test(content.trimStart()))
        content = `# {{valoran_variables}}\n${content.trimEnd()}\n# {{valoran_variables_end}}\n`;
    }
    return content === entry.content && (!variableRule || entry.enabled === inline)
      ? entry : { ...entry, content, enabled: variableRule ? inline : entry.enabled };
  };
  if (entries.every(entry => prepareEntry(entry, Boolean(shippedRule)) === entry)) return;
  if (book !== getCharWorldbookNames('current').primary) throw Error('准备资料时世界书已切换');
  let changed: WorldbookEntry[] = [];
  await updateWorldbookWith(book, currentEntries => {
    assertActive?.();
    const hasSetting = Boolean(shippedRule) && hasValoranSetting(currentEntries);
    const prepared = currentEntries.map(entry => prepareEntry(entry, hasSetting));
    changed = prepared.filter((entry, index) => entry !== currentEntries[index]);
    return prepared;
  }, { render: 'immediate' });
  const saved = await getWorldbook(book);
  assertActive?.();
  if (book !== getCharWorldbookNames('current').primary || changed.some(item =>
    saved.find(entry => entry.uid === item.uid)?.content !== item.content ||
    saved.find(entry => entry.uid === item.uid)?.enabled !== item.enabled))
    throw Error('请求资料世界书保存读回不一致');
}
