<template>
  <div
    class="cw-character-avatar"
    :class="[`cw-avatar-${shape}`, { 'is-editable': canEdit, 'is-uploading': uploading }]"
    :style="avatarStyle"
    :title="avatarTooltip"
    :aria-label="canEdit ? `点击更换 ${name || '角色'} 头像` : (name || '角色头像')"
    :role="canEdit ? 'button' : undefined"
    :tabindex="canEdit ? 0 : undefined"
    @click="handleAvatarClick"
    @keydown.enter.self.prevent="handleAvatarClick"
    @keydown.space.self.prevent="handleAvatarClick"
  >
    <img
      v-if="src"
      :src="src"
      :alt="name || '头像'"
      class="cw-avatar-img"
      @error="handleImageError"
    />
    <span v-else class="cw-avatar-text">{{ initialText }}</span>

    <!-- 可点击替换本地头像的悬浮遮罩与隐藏文件选择器 -->
    <template v-if="canEdit">
      <div class="cw-avatar-edit-overlay" aria-hidden="true">
        <span class="cw-avatar-edit-label">{{ uploading ? '处理中' : '更换' }}</span>
      </div>
      <button
        v-if="hasCustomOverride"
        type="button"
        class="cw-avatar-reset-btn"
        title="恢复默认头像"
        aria-label="恢复默认头像"
        @click.stop="handleResetAvatar"
      >
        ×
      </button>
      <input
        ref="fileInputRef"
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif,image/avif,image/*"
        class="cw-avatar-file-input"
        @click.stop
        @change="handleFileChange"
      />
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from 'vue';
import {
  resolveCharacterAvatar,
  subscribeExternalSettings,
} from '../../../../运行/external-settings';
import {
  clearCustomAvatar,
  processAvatarFileToDataUrl,
  resolveCustomAvatar,
  setCustomAvatar,
  subscribeCustomAvatars,
} from '../../../../运行/custom-avatars';

const props = withDefaults(
  defineProps<{
    name?: string;
    form?: string | null;
    avatarUrl?: string | null;
    size?: number;
    shape?: 'circle' | 'rounded';
    colorIndex?: number;
    editable?: boolean;
  }>(),
  {
    name: '',
    form: null,
    avatarUrl: null,
    size: 36,
    shape: 'circle',
    colorIndex: undefined,
    editable: false,
  },
);

const externalRevision = ref(0);
const unsubscribeExternal = subscribeExternalSettings(() => {
  externalRevision.value++;
});
const customRevision = ref(0);
const unsubscribeCustom = subscribeCustomAvatars(() => {
  customRevision.value++;
});
onBeforeUnmount(() => {
  unsubscribeExternal();
  unsubscribeCustom();
});

const fileInputRef = ref<HTMLInputElement | null>(null);
const uploading = ref(false);
const fallbackIndex = ref(0);

const canEdit = computed(() => Boolean(props.editable && props.name?.trim()));

const customOverride = computed(() => {
  void customRevision.value;
  if (props.avatarUrl) return null;
  return resolveCustomAvatar(props.name, props.form);
});

const hasCustomOverride = computed(() => Boolean(customOverride.value));

const resolvedCandidates = computed<string[]>(() => {
  void externalRevision.value;
  void customRevision.value;
  if (props.avatarUrl) return [props.avatarUrl];
  if (customOverride.value) return [customOverride.value.url];
  const resolved = resolveCharacterAvatar(props.name, props.form);
  if (!resolved) return [];
  return resolved.fallbacks.length ? resolved.fallbacks : [resolved.url];
});

const matchedFormLabel = computed(() => {
  void externalRevision.value;
  if (props.avatarUrl) return props.form || '';
  return resolveCharacterAvatar(props.name, props.form)?.matchedForm || props.form || '';
});

watch(
  () => [props.avatarUrl, props.name, props.form, externalRevision.value, customRevision.value],
  () => {
    fallbackIndex.value = 0;
  },
);

const src = computed(() => {
  const list = resolvedCandidates.value;
  if (!list.length || fallbackIndex.value >= list.length) return null;
  return list[fallbackIndex.value];
});

function handleImageError() {
  fallbackIndex.value++;
}

function notifyToast(kind: 'success' | 'error' | 'info', message: string) {
  const globalToastr = (globalThis as any).toastr;
  if (globalToastr && typeof globalToastr[kind] === 'function') {
    globalToastr[kind](message);
  }
}

function handleAvatarClick(event: Event) {
  if (!canEdit.value || uploading.value) return;
  event.stopPropagation();
  fileInputRef.value?.click();
}

async function handleFileChange(event: Event) {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  input.value = '';
  if (!file || !canEdit.value) return;

  const targetName = props.name;
  const targetForm = matchedFormLabel.value || props.form || null;
  uploading.value = true;
  try {
    const dataUrl = await processAvatarFileToDataUrl(file);
    setCustomAvatar(targetName, targetForm, dataUrl);
    notifyToast('success', targetForm ? `已替换「${targetName} · ${targetForm}」头像` : `已替换「${targetName}」头像`);
  } catch (error) {
    console.warn('[瓦罗兰自定义头像] 本地导入替换失败', error);
    notifyToast('error', error instanceof Error ? error.message : String(error));
  } finally {
    uploading.value = false;
  }
}

function handleResetAvatar() {
  if (!canEdit.value) return;
  const targetForm = matchedFormLabel.value || props.form || null;
  if (clearCustomAvatar(props.name, targetForm)) {
    notifyToast('info', targetForm ? `已恢复「${props.name} · ${targetForm}」默认头像` : `已恢复「${props.name}」默认头像`);
  }
}

const avatarTooltip = computed(() => {
  const base = props.name || '角色';
  const label = matchedFormLabel.value ? `${base} · ${matchedFormLabel.value}` : base;
  return canEdit.value ? `${label}（点击从本地选择图片替换头像）` : label;
});

const palette = [
  { bg: '#e8f0fe', color: '#1a73e8', border: 'rgba(26, 115, 232, 0.25)' },
  { bg: '#fef3e6', color: '#c4783c', border: 'rgba(196, 120, 60, 0.3)' },
  { bg: '#e6f4ea', color: '#188038', border: 'rgba(24, 128, 56, 0.25)' },
  { bg: '#fce8e6', color: '#d93025', border: 'rgba(217, 48, 37, 0.25)' },
  { bg: '#f3e8fd', color: '#9334e6', border: 'rgba(147, 52, 230, 0.25)' },
  { bg: '#e0f7fa', color: '#00838f', border: 'rgba(0, 131, 143, 0.25)' },
  { bg: '#fff8e1', color: '#f57f17', border: 'rgba(245, 127, 23, 0.25)' },
  { bg: '#f1f8e9', color: '#558b2f', border: 'rgba(85, 139, 47, 0.25)' },
];

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

const chosenColor = computed(() => {
  if (typeof props.colorIndex === 'number') {
    return palette[Math.abs(props.colorIndex) % palette.length];
  }
  const str = props.name || '玩家';
  const idx = hashString(str) % palette.length;
  return palette[idx];
});

const initialText = computed(() => {
  const raw = (props.name || '人').trim();
  if (!raw) return '人';
  if (/^[\u4e00-\u9fa5]+$/.test(raw)) {
    return raw.length >= 2 ? raw.slice(-1) : raw;
  }
  return raw.slice(0, 1).toUpperCase();
});

const avatarStyle = computed(() => {
  const c = chosenColor.value;
  return {
    width: `${props.size}px`,
    height: `${props.size}px`,
    minWidth: `${props.size}px`,
    fontSize: `${Math.max(11, Math.round(props.size * 0.44))}px`,
    backgroundColor: src.value ? 'transparent' : c.bg,
    color: c.color,
    border: `1px solid ${c.border}`,
  };
});
</script>

<style scoped lang="scss">
.cw-character-avatar {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  user-select: none;
  flex-shrink: 0;
  box-sizing: border-box;
  overflow: hidden;
  line-height: 1;
  transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;

  &.cw-avatar-circle {
    border-radius: var(--cw-radius-full, 9999px);
  }

  &.cw-avatar-rounded {
    border-radius: var(--cw-radius, 10px);
  }

  &.is-editable {
    cursor: pointer;

    &:hover,
    &:focus-visible {
      border-color: var(--cw-accent);
      box-shadow: 0 0 0 2px var(--cw-accent-bg);
      outline: none;

      .cw-avatar-edit-overlay {
        opacity: 1;
      }

      .cw-avatar-reset-btn {
        opacity: 1;
      }
    }
  }

  &.is-uploading {
    .cw-avatar-edit-overlay {
      opacity: 1;
    }
  }

  .cw-avatar-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .cw-avatar-text {
    display: inline-block;
  }

  .cw-avatar-edit-overlay {
    position: absolute;
    inset: 0;
    background: rgba(18, 22, 28, 0.56);
    display: flex;
    align-items: flex-end;
    justify-content: center;
    padding-bottom: 4px;
    opacity: 0;
    transition: opacity 0.16s ease;
    pointer-events: none;
  }

  .cw-avatar-edit-label {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.04em;
    color: #ffffff;
    line-height: 1.2;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.65);
  }

  .cw-avatar-reset-btn {
    position: absolute;
    top: 2px;
    right: 2px;
    width: 16px;
    height: 16px;
    padding: 0;
    border: none;
    border-radius: 9999px;
    background: rgba(18, 22, 28, 0.78);
    color: #ffffff;
    font-size: 12px;
    line-height: 16px;
    text-align: center;
    cursor: pointer;
    opacity: 0;
    transition: opacity 0.16s ease, background-color 0.15s ease;
    z-index: 2;

    &:hover {
      background: var(--cw-danger, #c94a4a);
    }
  }

  .cw-avatar-file-input {
    display: none;
  }
}
</style>
