import { jsonrepair } from 'jsonrepair';
import { extractProtocolPatchText, protocolJson } from './message-protocol';
import type { VariableReplyFormat } from './variable-response';

export type VariableOutputChannel = 'story-main' | 'story-extra' | 'phone';
export type VariableOutputState = 'failed' | 'pending' | 'saved';

export interface StoredVariableOutput {
  id: string;
  channel: VariableOutputChannel;
  state: VariableOutputState;
  floor?: number;
  swipe?: number;
  updatedAt: string;
  rawText: string;
  replyFormat?: VariableReplyFormat;
  error?: string;
  edited?: boolean;
}

export interface VariableOutputRecord {
  id: string;
  channel: VariableOutputChannel;
  state: VariableOutputState;
  floor?: number;
  swipe?: number;
  updatedAt: string;
  /** Editable patch text (unwrapped JSONPatch string when possible). */
  patchText: string;
  /** Original raw variable output (without narrative prose for story-main). */
  rawText: string;
  /** True if patchText is pure unwrapped JSONPatch array text. */
  unwrapped: boolean;
  replyFormat?: VariableReplyFormat;
  error?: string;
  /** True when user can immediately edit & settle (pending/failed). */
  editable: boolean;
  /** True when this is the latest settled assistant floor that can opt-in to edit & re-settle. */
  canResummarize?: boolean;
  /** True when user can discard local edits and re-call the independent variable/phone API. */
  canReRequestApi?: boolean;
  edited?: boolean;
  missingUpdateBlock?: boolean;
  missingClosingTag?: boolean;
}

export interface VariableOutputIndexEntry {
  id: string;
  channel: VariableOutputChannel;
  state: VariableOutputState;
  floor?: number;
  swipe?: number;
  updatedAt: string;
  edited?: boolean;
}

export interface VariableErrorHighlight {
  /** 0-based start offset in the displayed editor text. */
  start: number;
  /** 0-based exclusive end offset in the displayed editor text. */
  end: number;
  /** 1-based line number. */
  line: number;
  /** 1-based column number. */
  column: number;
  message: string;
  hint?: string;
  kind: 'syntax' | 'protocol' | 'semantic';
  patchIndex?: number;
}

export interface VariableDiagnosis {
  validSyntax: boolean;
  validProtocol: boolean;
  patchCount: number | null;
  status: 'ok' | 'syntax-error' | 'protocol-error' | 'backend-error' | 'backend-error-edited';
  summary: string;
  detail: string;
  highlight: VariableErrorHighlight | null;
}

export interface HighlightSegment {
  text: string;
  kind: 'normal' | 'error' | 'error-eof';
}

export function offsetToLineColumn(text: string, rawOffset: number): { line: number; column: number } {
  const offset = Math.max(0, Math.min(text.length, rawOffset));
  let line = 1;
  let lastLineStart = 0;
  for (let i = 0; i < offset; i++) {
    if (text.charCodeAt(i) === 10) {
      line++;
      lastLineStart = i + 1;
    }
  }
  return { line, column: offset - lastLineStart + 1 };
}

export function lineColumnToOffset(text: string, targetLine: number, targetColumn: number): number {
  const lineWanted = Math.max(1, targetLine);
  const colWanted = Math.max(1, targetColumn);
  let line = 1;
  let i = 0;
  while (i < text.length && line < lineWanted) {
    if (text.charCodeAt(i) === 10) line++;
    i++;
  }
  return Math.min(text.length, i + colWanted - 1);
}

export function extractEditableVariableOutput(
  rawText: string,
  channel: VariableOutputChannel,
  replyFormat?: VariableReplyFormat,
): {
  patchText: string;
  rawText: string;
  unwrapped: boolean;
  missingUpdateBlock: boolean;
  missingClosingTag: boolean;
} {
  if (channel === 'story-main') {
    const extracted = extractProtocolPatchText(rawText);
    return {
      patchText: extracted.patchText,
      rawText: extracted.rawBlock || rawText,
      unwrapped: extracted.unwrapped,
      missingUpdateBlock: !extracted.hasUpdateBlock && !extracted.patchText,
      missingClosingTag: extracted.missingClosingTag,
    };
  }

  const trimmed = rawText.trim();
  if (replyFormat === 'structured' || (!replyFormat && trimmed.startsWith('{'))) {
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed) && typeof (parsed as any).JSONPatch === 'string') {
        return {
          patchText: (parsed as any).JSONPatch,
          rawText,
          unwrapped: true,
          missingUpdateBlock: false,
          missingClosingTag: false,
        };
      }
    } catch {
      // Fall through to protocol/raw checks when outer JSON is malformed.
    }
  }

  if (replyFormat === 'structured-v2') {
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed && typeof parsed === 'object' && Array.isArray((parsed as any).JSONPatch)) {
        return {
          patchText: rawText,
          rawText,
          unwrapped: false,
          missingUpdateBlock: false,
          missingClosingTag: false,
        };
      }
    } catch {
      // Fall through to protocol/raw checks when outer JSON is malformed.
    }
  }

  if (/<(?:UpdateVariable|JSONPatch)\b/i.test(rawText)) {
    const extracted = extractProtocolPatchText(rawText);
    return {
      patchText: extracted.patchText,
      rawText,
      unwrapped: extracted.unwrapped,
      missingUpdateBlock: false,
      missingClosingTag: extracted.missingClosingTag,
    };
  }

  if (replyFormat === 'structured-v2') {
    return {
      patchText: rawText,
      rawText,
      unwrapped: false,
      missingUpdateBlock: false,
      missingClosingTag: false,
    };
  }

  const startsLikeArray = trimmed.startsWith('[');
  return {
    patchText: rawText,
    rawText,
    unwrapped: startsLikeArray,
    missingUpdateBlock: false,
    missingClosingTag: false,
  };
}

/** Assemble user-edited text back into the transport representation expected by host.ts. */
export function assembleEditedVariableOutput(
  editedText: string,
  channel: VariableOutputChannel,
  originalFormat?: VariableReplyFormat,
): { transportText: string; replyFormat?: VariableReplyFormat; rawRecordText: string } {
  const trimmed = editedText.trim();

  // Try parsing JSON first so string values containing literal <UpdateVariable> aren't misclassified as XML.
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) {
      const block = `<UpdateVariable><JSONPatch>${protocolJson(parsed)}</JSONPatch></UpdateVariable>`;
      return {
        transportText: block,
        replyFormat: undefined,
        rawRecordText: JSON.stringify(parsed),
      };
    }
    if (parsed && typeof parsed === 'object') {
      if (typeof (parsed as any).JSONPatch === 'string' && channel !== 'story-main') {
        return {
          transportText: JSON.stringify(parsed),
          replyFormat: 'structured',
          rawRecordText: JSON.stringify(parsed),
        };
      }
      if (Array.isArray((parsed as any).JSONPatch) && originalFormat === 'structured-v2' && channel !== 'story-main') {
        return {
          transportText: JSON.stringify(parsed),
          replyFormat: 'structured-v2',
          rawRecordText: JSON.stringify(parsed),
        };
      }
    }
  } catch {
    // Allow saving incomplete/invalid drafts cleanly when user clicks "仅保存修改".
  }

  if (/<UpdateVariable\b/i.test(trimmed)) {
    return {
      transportText: editedText,
      replyFormat: undefined,
      rawRecordText: editedText,
    };
  }

  if (channel === 'story-main') {
    const safeInner = editedText.replace(/<\/JSONPatch\s*>/gi, '').replace(/<\/UpdateVariable\s*>/gi, '');
    const block = `<UpdateVariable><JSONPatch>${safeInner}</JSONPatch></UpdateVariable>`;
    return { transportText: block, replyFormat: undefined, rawRecordText: block };
  }

  return {
    transportText: editedText,
    replyFormat: undefined,
    rawRecordText: editedText,
  };
}

function parseNativeSyntaxErrorOffset(text: string, message: string): number | null {
  const posMatch = /at position (\d+)/i.exec(message);
  if (posMatch) {
    const pos = Number(posMatch[1]);
    if (Number.isSafeInteger(pos) && pos >= 0 && pos <= text.length) return pos;
  }
  const lcMatch = /line (\d+) column (\d+)/i.exec(message);
  if (lcMatch) {
    return lineColumnToOffset(text, Number(lcMatch[1]), Number(lcMatch[2]));
  }
  return null;
}

interface ScanError {
  start: number;
  end: number;
  message: string;
  hint?: string;
}

/**
 * Lightweight RFC 8259 JSON recursive-descent scanner that always reports an exact [start, end]
 * highlight span and human-friendly Chinese diagnostics, even on engines without error positions.
 */
export function scanJsonSyntaxError(text: string): ScanError | null {
  let i = 0;
  const n = text.length;

  const isWs = (ch: number) => ch === 32 || ch === 9 || ch === 10 || ch === 13;
  const skipWs = () => {
    while (i < n && isWs(text.charCodeAt(i))) i++;
  };

  const tokenEnd = (start: number): number => {
    if (start >= n) return n;
    const ch = text[start];
    if ('{}[],:'.includes(ch)) return start + 1;
    if (ch === '"' || ch === "'") {
      let j = start + 1;
      while (j < n && text[j] !== ch && text[j] !== '\n' && text[j] !== '\r' && j - start < 24) {
        if (text[j] === '\\') j++;
        j++;
      }
      return Math.min(n, j < n && text[j] === ch ? j + 1 : j);
    }
    let j = start;
    while (j < n && !isWs(text.charCodeAt(j)) && !'{}[],:"'.includes(text[j]) && j - start < 20) j++;
    return Math.max(start + 1, j);
  };

  const eofSpan = (openPos?: number): { start: number; end: number } => {
    let end = n;
    while (end > 0 && isWs(text.charCodeAt(end - 1))) end--;
    if (end === 0) return { start: 0, end: 0 };
    const start = openPos !== undefined && end - openPos <= 24 ? openPos : Math.max(0, end - 12);
    return { start, end };
  };

  const fail = (start: number, end: number, message: string, hint?: string): never => {
    throw { start: Math.max(0, Math.min(n, start)), end: Math.max(0, Math.min(n, end)), message, hint } as ScanError;
  };

  const parseString = (): void => {
    const startQuote = i;
    i++; // consume opening '"'
    while (i < n) {
      const code = text.charCodeAt(i);
      if (code === 34) {
        i++;
        return;
      }
      if (code === 92) {
        // backslash escape
        if (i + 1 >= n) {
          const span = eofSpan(startQuote);
          fail(span.start, span.end, '字符串在转义反斜杠处意外结束', '请补全转义字符与闭合双引号 "');
        }
        const next = text[i + 1];
        if ('"\\/bfnrt'.includes(next)) {
          i += 2;
          continue;
        }
        if (next === 'u') {
          const hex = text.slice(i + 2, i + 6);
          if (!/^[0-9a-fA-F]{4}$/.test(hex)) {
            fail(i, Math.min(n, i + 6), '无效的 \\uXXXX Unicode 转义序列', '请使用 4 位十六进制字符，或双写反斜杠 \\\\');
          }
          i += 6;
          continue;
        }
        fail(i, i + 2, `字符串中包含无效转义字符「\\${next}」`, 'JSON 字符串中若需表示反斜杠请写为 \\\\，不要直接转义普通字符');
      }
      if (code < 0x20) {
        const label = code === 10 || code === 13 ? '未转义的换行符' : `非法控制字符 (0x${code.toString(16)})`;
        const spanEnd = Math.min(n, i + 1);
        fail(
          Math.max(startQuote, i - 1),
          spanEnd,
          `字符串内部包含${label}`,
          'JSON 字符串内不能直接换行，请改为 \\n 或补上缺失的闭合双引号 "',
        );
      }
      i++;
    }
    const lc = offsetToLineColumn(text, startQuote);
    const span = eofSpan(startQuote);
    fail(
      span.start,
      span.end,
      `字符串未闭合（起点位于第 ${lc.line} 行第 ${lc.column} 列）`,
      '可能是模型输出被截断，或缺少末尾的闭合双引号 " 与括号',
    );
  };

  const parseNumber = (): void => {
    const start = i;
    if (text[i] === '-') i++;
    if (i >= n || text[i] < '0' || text[i] > '9') {
      fail(start, tokenEnd(start), '无效的数字格式', '负号后面必须紧跟数字');
    }
    if (text[i] === '0') {
      i++;
      if (i < n && text[i] >= '0' && text[i] <= '9') {
        fail(start, tokenEnd(start), 'JSON 数字不允许前导零', '请去掉多余的前导 0，或用双引号包裹成字符串');
      }
    } else {
      while (i < n && text[i] >= '0' && text[i] <= '9') i++;
    }
    if (i < n && text[i] === '.') {
      i++;
      if (i >= n || text[i] < '0' || text[i] > '9') {
        fail(start, Math.min(n, i + 1), '小数点后缺少数字');
      }
      while (i < n && text[i] >= '0' && text[i] <= '9') i++;
    }
    if (i < n && (text[i] === 'e' || text[i] === 'E')) {
      i++;
      if (i < n && (text[i] === '+' || text[i] === '-')) i++;
      if (i >= n || text[i] < '0' || text[i] > '9') {
        fail(start, Math.min(n, i + 1), '科学计数法指数部分缺少数字');
      }
      while (i < n && text[i] >= '0' && text[i] <= '9') i++;
    }
  };

  const parseValue = (): void => {
    skipWs();
    if (i >= n) {
      const span = eofSpan();
      fail(span.start, span.end, 'JSON 内容意外结束，缺少值', '可能是模型输出在末尾被截断');
    }
    const ch = text[i];
    if (ch === '{') {
      parseObject();
      return;
    }
    if (ch === '[') {
      parseArray();
      return;
    }
    if (ch === '"') {
      parseString();
      return;
    }
    if (ch === '-' || (ch >= '0' && ch <= '9')) {
      parseNumber();
      return;
    }
    if (text.startsWith('true', i)) {
      i += 4;
      return;
    }
    if (text.startsWith('false', i)) {
      i += 5;
      return;
    }
    if (text.startsWith('null', i)) {
      i += 4;
      return;
    }
    if (ch === "'") {
      fail(i, tokenEnd(i), 'JSON 字符串必须使用英文双引号 "，不能使用单引号', '请将单引号改为英文双引号 "');
    }
    if (ch === ']' || ch === '}') {
      fail(i, i + 1, `此处出现了多余的闭合符号「${ch}」或前面有多余逗号`, '请检查前一项末尾是否多写了逗号「,」');
    }
    fail(
      i,
      tokenEnd(i),
      `意外的字符「${text.slice(i, Math.min(n, i + 12))}」`,
      '请检查是否遗漏双引号、逗号，或混入了非 JSON 文本',
    );
  };

  const parseArray = (): void => {
    const openPos = i;
    i++; // consume '['
    skipWs();
    if (i < n && text[i] === ']') {
      i++;
      return;
    }
    while (true) {
      parseValue();
      const afterValue = i;
      skipWs();
      if (i >= n) {
        const lc = offsetToLineColumn(text, openPos);
        const span = eofSpan(openPos);
        fail(
          span.start,
          span.end,
          `数组未闭合（起点「[」位于第 ${lc.line} 行第 ${lc.column} 列）`,
          '可能是模型输出被截断，请在末尾补全缺失的括号',
        );
      }
      if (text[i] === ',') {
        const commaPos = i;
        i++;
        skipWs();
        if (i < n && text[i] === ']') {
          fail(commaPos, i + 1, '数组末尾存在多余的逗号「,」', 'JSON 不允许在最后一个元素后面加逗号，请删除该逗号');
        }
        continue;
      }
      if (text[i] === ']') {
        i++;
        return;
      }
      const prevQuote = afterValue > 0 && text[afterValue - 1] === '"';
      const errStart = prevQuote ? afterValue - 1 : i;
      const rawEnd = tokenEnd(i);
      const errEnd = prevQuote && text[rawEnd] === '"' ? rawEnd + 1 : rawEnd;
      fail(
        errStart,
        errEnd,
        `数组元素后预期逗号「,」或闭合括号「]」，实际遇到「${text.slice(i, Math.min(n, i + 12))}」`,
        prevQuote
          ? '此处紧跟在双引号后，很可能是字符串内混入了未转义的英文双引号 "（请改为 \\" 或中文引号），或缺少逗号'
          : '请检查两项之间是否遗漏逗号「,」',
      );
    }
  };

  const parseObject = (): void => {
    const openPos = i;
    i++; // consume '{'
    skipWs();
    if (i < n && text[i] === '}') {
      i++;
      return;
    }
    while (true) {
      skipWs();
      if (i >= n) {
        const lc = offsetToLineColumn(text, openPos);
        const span = eofSpan(openPos);
        fail(
          span.start,
          span.end,
          `对象未闭合（起点「{」位于第 ${lc.line} 行第 ${lc.column} 列）`,
          '可能是模型输出被截断，请补全末尾缺失的「}」和「]」',
        );
      }
      if (text[i] !== '"') {
        fail(
          i,
          tokenEnd(i),
          `对象键名必须以英文双引号 " 开头，实际遇到「${text.slice(i, Math.min(n, i + 12))}」`,
          text[i] === '}' ? '请检查前一项末尾是否多写了逗号「,」' : '请为属性键名加上英文双引号 "',
        );
      }
      parseString();
      skipWs();
      if (i >= n || text[i] !== ':') {
        fail(
          i,
          i < n ? tokenEnd(i) : i,
          `对象键名后缺少冒号「:」`,
          '请检查键名和键值之间是否遗漏了英文冒号「:」，或前面的字符串内有未转义的双引号 "',
        );
      }
      i++; // consume ':'
      parseValue();
      const afterValue = i;
      skipWs();
      if (i >= n) {
        const lc = offsetToLineColumn(text, openPos);
        const span = eofSpan(openPos);
        fail(
          span.start,
          span.end,
          `对象未闭合（起点「{」位于第 ${lc.line} 行第 ${lc.column} 列）`,
          '可能是模型输出被截断，请补全末尾缺失的括号',
        );
      }
      if (text[i] === ',') {
        const commaPos = i;
        i++;
        skipWs();
        if (i < n && text[i] === '}') {
          fail(commaPos, i + 1, '对象末尾存在多余的逗号「,」', 'JSON 不允许在最后一个属性后面加逗号，请删除该逗号');
        }
        continue;
      }
      if (text[i] === '}') {
        i++;
        return;
      }
      const prevQuote = afterValue > 0 && text[afterValue - 1] === '"';
      const errStart = prevQuote ? afterValue - 1 : i;
      const rawEnd = tokenEnd(i);
      const errEnd = prevQuote && text[rawEnd] === '"' ? rawEnd + 1 : rawEnd;
      fail(
        errStart,
        errEnd,
        `对象属性后预期逗号「,」或闭合括号「}」，实际遇到「${text.slice(i, Math.min(n, i + 12))}」`,
        prevQuote
          ? '此处紧跟在双引号后，极可能是字符串值内包含了未转义的英文双引号 "（请改为 \\" 或中文引号 “”），或缺少逗号'
          : '请检查属性之间是否遗漏逗号「,」或多余符号',
      );
    }
  };

  try {
    skipWs();
    if (i >= n) {
      return { start: 0, end: 0, message: '变量内容为空', hint: '请输入合法的 JSONPatch 数组（无变化请填 []）' };
    }
    parseValue();
    skipWs();
    if (i < n) {
      return {
        start: i,
        end: Math.min(n, Math.max(tokenEnd(i), i + 1)),
        message: `JSON 结束后存在多余内容「${text.slice(i, Math.min(n, i + 20))}」`,
        hint: '请删除数组外多余的括号、标签或说明文字',
      };
    }
    return null;
  } catch (err) {
    if (err && typeof err === 'object' && 'start' in err && 'end' in err && 'message' in err) {
      return err as ScanError;
    }
    return null;
  }
}

export interface ArrayItemSpan {
  index: number;
  start: number;
  end: number;
}

/** Find [start, end] offsets for each top-level element inside a syntactically valid JSON array string. */
export function findJsonArrayItemSpans(text: string): ArrayItemSpan[] {
  const spans: ArrayItemSpan[] = [];
  const n = text.length;
  let i = 0;
  const isWs = (ch: number) => ch === 32 || ch === 9 || ch === 10 || ch === 13;
  while (i < n && isWs(text.charCodeAt(i))) i++;
  if (i >= n || text[i] !== '[') return spans;
  i++;

  let depth = 1;
  let inString = false;
  let escaped = false;
  let itemStart: number | null = null;
  let index = 0;

  for (; i < n && depth > 0; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (itemStart === null && !isWs(text.charCodeAt(i)) && ch !== ']' && ch !== ',') {
      itemStart = i;
    }
    if (ch === '"') {
      inString = true;
    } else if (ch === '{' || ch === '[') {
      depth++;
    } else if (ch === '}' || ch === ']') {
      depth--;
      if (depth === 0) {
        if (itemStart !== null) {
          let end = i;
          while (end > itemStart && isWs(text.charCodeAt(end - 1))) end--;
          spans.push({ index: index++, start: itemStart, end });
        }
        break;
      }
    } else if (ch === ',' && depth === 1) {
      if (itemStart !== null) {
        let end = i;
        while (end > itemStart && isWs(text.charCodeAt(end - 1))) end--;
        spans.push({ index: index++, start: itemStart, end });
        itemStart = null;
      }
    }
  }
  return spans;
}

function normalizePathKey(raw: string): string {
  return raw
    .trim()
    .replace(/^["'`]+|["'`]+$/g, '')
    .replace(/^(?:stat_data|status_current_variables)\./, '')
    .replace(/^\/+/, '')
    .replace(/~1/g, '/')
    .replace(/~0/g, '~')
    .replace(/\./g, '/');
}

function matchBackendErrorToPatchIndex(backendError: string, items: unknown[]): number | null {
  if (!backendError || !items.length) return null;

  // 1. Explicit 1-based patch index ("第 N 条补丁")
  const idxMatch = /第\s*(\d+)\s*条补丁/.exec(backendError);
  if (idxMatch) {
    const idx = Number(idxMatch[1]) - 1;
    if (idx >= 0 && idx < items.length) return idx;
  }

  // 2. Extract candidate paths from MVU command strings, Zod errors, or JSON pointers.
  const candidatePaths: string[] = [];
  const patterns = [
    /"(?:path|from|to)"\s*:\s*"([^"]+)"/g,
    /_\.(?:set|add|insert|delete|move)\(\s*['"]([^'"]+)['"]/g,
    /→\s*(?:路径|at)[:：]?\s*([^\s\n]+)/g,
    /(\/(?:角色|玩家|世界|地点|组织|事件|约定|手机|奇遇系统|_系统)[^\s"'`，。；：)\]]*)/g,
    /((?:角色|玩家|世界|地点|组织|事件|约定|手机|奇遇系统|_系统)(?:\.[^.\s"'`，。；：)\]]+)+)/g,
  ];
  for (const regex of patterns) {
    let m: RegExpExecArray | null;
    while ((m = regex.exec(backendError))) {
      const normalized = normalizePathKey(m[1]);
      if (normalized) candidatePaths.push(normalized);
    }
  }

  if (candidatePaths.length) {
    // Prefer exact or longest prefix match.
    let bestIdx: number | null = null;
    let bestScore = 0;
    for (let idx = 0; idx < items.length; idx++) {
      const item = items[idx];
      if (!item || typeof item !== 'object') continue;
      const obj = item as Record<string, unknown>;
      const fields = [obj.path, obj.from, obj.to, obj.replace, obj.add, obj.insert, obj.remove, obj.delta, obj.move]
        .filter((v): v is string => typeof v === 'string')
        .map(normalizePathKey);
      for (const fieldPath of fields) {
        for (const cand of candidatePaths) {
          if (fieldPath === cand) return idx;
          if (fieldPath.startsWith(cand + '/') || cand.startsWith(fieldPath + '/')) {
            const score = Math.min(fieldPath.length, cand.length);
            if (score > bestScore) {
              bestScore = score;
              bestIdx = idx;
            }
          }
        }
      }
    }
    if (bestIdx !== null) return bestIdx;
  }

  // 3. InformationNotLoadedError or entity IDs mentioned in error ("请先展开资料再更新：xxx")
  const infoMatch = /请先展开资料再更新[：:]\s*([^\n。]+)/.exec(backendError);
  if (infoMatch) {
    const tokens = infoMatch[1]
      .split(/[、,，\s]+/)
      .map(s => s.trim())
      .filter(s => s.length >= 2);
    for (let idx = 0; idx < items.length; idx++) {
      const serialized = JSON.stringify(items[idx]);
      if (tokens.some(token => serialized.includes(token))) return idx;
    }
  }

  return null;
}

const VALID_PATCH_OPS = new Set(['replace', 'add', 'insert', 'remove', 'delta', 'move', 'copy', 'test']);

export function diagnoseVariableOutput(
  text: string,
  options: {
    unwrapped: boolean;
    replyFormat?: VariableReplyFormat;
    backendError?: string;
    unchangedFromBackend?: boolean;
  },
): VariableDiagnosis {
  const trimmed = text.trim();
  if (!trimmed) {
    return {
      validSyntax: false,
      validProtocol: false,
      patchCount: null,
      status: 'syntax-error',
      summary: '变量内容为空',
      detail: '请输入合法的 JSONPatch 数组（本轮若无变量变化可填写 []）。',
      highlight: {
        start: 0,
        end: 0,
        line: 1,
        column: 1,
        message: '变量内容为空',
        hint: '无变量变化可直接填写 []',
        kind: 'syntax',
      },
    };
  }

  // Allow wrapped <UpdateVariable> block when not unwrapped
  if (!options.unwrapped && /<UpdateVariable\b/i.test(trimmed)) {
    const extracted = extractProtocolPatchText(text);
    if (extracted.unwrapped && extracted.patchText) {
      const innerOffset = text.indexOf(extracted.patchText);
      const innerDiag = diagnoseVariableOutput(extracted.patchText, { ...options, unwrapped: true });
      if (innerDiag.highlight && innerOffset >= 0) {
        const start = innerOffset + innerDiag.highlight.start;
        const end = innerOffset + innerDiag.highlight.end;
        const lc = offsetToLineColumn(text, start);
        return {
          ...innerDiag,
          highlight: { ...innerDiag.highlight, start, end, line: lc.line, column: lc.column },
        };
      }
      return { ...innerDiag, highlight: null };
    }
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch (err) {
    const scanned = scanJsonSyntaxError(text);
    const nativeMsg = err instanceof Error ? err.message : String(err);
    if (scanned) {
      const lc = offsetToLineColumn(text, scanned.start);
      return {
        validSyntax: false,
        validProtocol: false,
        patchCount: null,
        status: 'syntax-error',
        summary: `JSON 语法错误 · 第 ${lc.line} 行，第 ${lc.column} 列（偏移 ${scanned.start}）`,
        detail: scanned.hint ? `${scanned.message}。${scanned.hint}。` : scanned.message,
        highlight: {
          start: scanned.start,
          end: scanned.end,
          line: lc.line,
          column: lc.column,
          message: scanned.message,
          hint: scanned.hint,
          kind: 'syntax',
        },
      };
    }
    const nativeOffset = parseNativeSyntaxErrorOffset(text, nativeMsg) ?? Math.max(0, text.length - 1);
    const lc = offsetToLineColumn(text, nativeOffset);
    return {
      validSyntax: false,
      validProtocol: false,
      patchCount: null,
      status: 'syntax-error',
      summary: `JSON 语法错误 · 第 ${lc.line} 行，第 ${lc.column} 列（偏移 ${nativeOffset}）`,
      detail: nativeMsg,
      highlight: {
        start: nativeOffset,
        end: Math.min(text.length, nativeOffset + 1),
        line: lc.line,
        column: lc.column,
        message: nativeMsg,
        kind: 'syntax',
      },
    };
  }

  // Check root structure
  let patches: unknown[];
  let arraySource = text;
  let arrayOffset = 0;

  if (Array.isArray(parsed)) {
    patches = parsed;
  } else if (
    !options.unwrapped &&
    parsed &&
    typeof parsed === 'object' &&
    Array.isArray((parsed as any).JSONPatch) &&
    options.replyFormat === 'structured-v2'
  ) {
    patches = (parsed as any).JSONPatch;
    const keyIdx = text.indexOf('[');
    if (keyIdx >= 0) {
      arraySource = text.slice(keyIdx);
      arrayOffset = keyIdx;
    }
  } else if (
    !options.unwrapped &&
    parsed &&
    typeof parsed === 'object' &&
    typeof (parsed as any).JSONPatch === 'string'
  ) {
    // Nested string in structured envelope
    const inner = (parsed as any).JSONPatch as string;
    const innerDiag = diagnoseVariableOutput(inner, { ...options, unwrapped: true });
    if (!innerDiag.validSyntax) {
      return {
        ...innerDiag,
        summary: `内层 JSONPatch 字符串语法错误（第 ${innerDiag.highlight?.line ?? 1} 行第 ${innerDiag.highlight?.column ?? 1} 列）`,
        highlight: null,
      };
    }
    return { ...innerDiag, highlight: null };
  } else {
    return {
      validSyntax: true,
      validProtocol: false,
      patchCount: null,
      status: 'protocol-error',
      summary: '变量根结构不是 JSONPatch 数组',
      detail: '变量更新必须是一个 JSON 数组，例如 [] 或 [{"op":"replace","path":"/玩家/当前状态/体力值","value":80}]。',
      highlight: {
        start: 0,
        end: Math.min(text.length, 1),
        line: 1,
        column: 1,
        message: '根结构必须是 JSON 数组 [...]',
        kind: 'protocol',
      },
    };
  }

  // Validate individual patch objects lightly (standard JSONPatch array)
  const spans = findJsonArrayItemSpans(arraySource);
  if (Array.isArray(parsed)) {
    for (let idx = 0; idx < patches.length; idx++) {
      const item = patches[idx];
      const span = spans[idx];
      const start = span ? arrayOffset + span.start : 0;
      const end = span ? arrayOffset + span.end : Math.min(text.length, 1);
      const lc = offsetToLineColumn(text, start);
      if (!item || typeof item !== 'object' || Array.isArray(item)) {
        return {
          validSyntax: true,
          validProtocol: false,
          patchCount: patches.length,
          status: 'protocol-error',
          summary: `第 ${idx + 1} 条补丁格式无效 · 第 ${lc.line} 行`,
          detail: `第 ${idx + 1} 条补丁必须是 JSON 对象（包含 "op" 与 "path" 字段）。`,
          highlight: {
            start,
            end,
            line: lc.line,
            column: lc.column,
            message: `第 ${idx + 1} 条补丁不是对象`,
            kind: 'protocol',
            patchIndex: idx,
          },
        };
      }
      const obj = item as Record<string, unknown>;
      if (typeof obj.op !== 'string' || !VALID_PATCH_OPS.has(obj.op)) {
        return {
          validSyntax: true,
          validProtocol: false,
          patchCount: patches.length,
          status: 'protocol-error',
          summary: `第 ${idx + 1} 条补丁缺少有效 op 操作名 · 第 ${lc.line} 行`,
          detail: `第 ${idx + 1} 条补丁的 "op" 为 ${JSON.stringify(obj.op)}，合法操作名应为 replace / add / insert / remove / delta / move。`,
          highlight: {
            start,
            end,
            line: lc.line,
            column: lc.column,
            message: `第 ${idx + 1} 条补丁 op 无效`,
            kind: 'protocol',
            patchIndex: idx,
          },
        };
      }
      if (obj.op === 'move') {
        if (typeof obj.from !== 'string' || typeof obj.to !== 'string') {
          return {
            validSyntax: true,
            validProtocol: false,
            patchCount: patches.length,
            status: 'protocol-error',
            summary: `第 ${idx + 1} 条 move 补丁缺少 from 或 to 路径 · 第 ${lc.line} 行`,
            detail: `第 ${idx + 1} 条补丁使用 move 操作时必须同时提供字符串类型的 "from" 与 "to"。`,
            highlight: {
              start,
              end,
              line: lc.line,
              column: lc.column,
              message: `第 ${idx + 1} 条 move 补丁缺少 from/to`,
              kind: 'protocol',
              patchIndex: idx,
            },
          };
        }
      } else if (typeof obj.path !== 'string') {
        return {
          validSyntax: true,
          validProtocol: false,
          patchCount: patches.length,
          status: 'protocol-error',
          summary: `第 ${idx + 1} 条补丁缺少 path 路径 · 第 ${lc.line} 行`,
          detail: `第 ${idx + 1} 条补丁必须包含字符串类型的 "path" 字段。`,
          highlight: {
            start,
            end,
            line: lc.line,
            column: lc.column,
            message: `第 ${idx + 1} 条补丁缺少 path`,
            kind: 'protocol',
            patchIndex: idx,
          },
        };
      }
    }
  }

  // Syntax & basic patch shape are valid. Check backend semantic error if still present.
  if (options.backendError) {
    if (options.unchangedFromBackend) {
      const matchedIdx = matchBackendErrorToPatchIndex(options.backendError, patches);
      const span = matchedIdx !== null ? spans[matchedIdx] : undefined;
      let highlight: VariableErrorHighlight | null = null;
      if (span && matchedIdx !== null) {
        const start = arrayOffset + span.start;
        const end = arrayOffset + span.end;
        const lc = offsetToLineColumn(text, start);
        highlight = {
          start,
          end,
          line: lc.line,
          column: lc.column,
          message: `第 ${matchedIdx + 1} 条补丁触发校验失败`,
          kind: 'semantic',
          patchIndex: matchedIdx,
        };
      }
      return {
        validSyntax: true,
        validProtocol: true,
        patchCount: patches.length,
        status: 'backend-error',
        summary: highlight
          ? `后端校验未通过 · 已定位到第 ${(highlight.patchIndex ?? 0) + 1} 条相关补丁（第 ${highlight.line} 行）`
          : 'JSON 语法有效，但后端规则校验未通过',
        detail: options.backendError,
        highlight,
      };
    }
    return {
      validSyntax: true,
      validProtocol: true,
      patchCount: patches.length,
      status: 'backend-error-edited',
      summary: `JSON 格式校验通过（共 ${patches.length} 条补丁）· 待重新提交校验`,
      detail: '内容已修改，点击「保存并立即结算」将重新运行完整的变量与规则校验。',
      highlight: null,
    };
  }

  return {
    validSyntax: true,
    validProtocol: true,
    patchCount: patches.length,
    status: 'ok',
    summary: `JSON 格式校验通过（共 ${patches.length} 条补丁）`,
    detail: '',
    highlight: null,
  };
}

export function buildHighlightSegments(text: string, highlight: VariableErrorHighlight | null): HighlightSegment[] {
  if (!highlight) {
    return text ? [{ text, kind: 'normal' }] : [];
  }
  const n = text.length;
  const start = Math.max(0, Math.min(n, highlight.start));
  const end = Math.max(start, Math.min(n, highlight.end));

  const segments: HighlightSegment[] = [];
  if (start > 0) segments.push({ text: text.slice(0, start), kind: 'normal' });
  if (end > start) {
    segments.push({ text: text.slice(start, end), kind: 'error' });
  } else {
    segments.push({ text: ' ', kind: 'error-eof' });
  }
  if (end < n) segments.push({ text: text.slice(end), kind: 'normal' });
  return segments;
}

/** Format JSON with 2-space indent; when syntax is broken, performs safe string-aware structural line breaks. */
export function tolerantFormatJson(text: string): { text: string; exact: boolean } {
  try {
    const parsed = JSON.parse(text);
    return { text: JSON.stringify(parsed, null, 2), exact: true };
  } catch {
    // Structural whitespace-only formatting outside strings.
  }

  let out = '';
  let indent = 0;
  let inString = false;
  let escaped = false;
  const n = text.length;
  const nextNonWs = (from: number) => {
    for (let k = from; k < n; k++) {
      const code = text.charCodeAt(k);
      if (code !== 32 && code !== 9 && code !== 10 && code !== 13) return text[k];
    }
    return '';
  };

  for (let i = 0; i < n; i++) {
    const ch = text[i];
    if (inString) {
      out += ch;
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n') {
      // Preserve single spaces between unexpected non-structural tokens (e.g., broken unescaped quotes).
      const prev = out.at(-1) ?? '';
      const next = nextNonWs(i + 1);
      if (prev && next && !'{}[],:\n \t'.includes(prev) && !'{}[],:'.includes(next)) {
        out += ' ';
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
      out += ch;
    } else if (ch === '{' || ch === '[') {
      const next = nextNonWs(i + 1);
      if ((ch === '{' && next === '}') || (ch === '[' && next === ']')) {
        out += ch;
      } else {
        indent++;
        out += ch + '\n' + '  '.repeat(indent);
      }
    } else if (ch === '}' || ch === ']') {
      const lastChar = out.at(-1);
      if ((ch === '}' && lastChar === '{') || (ch === ']' && lastChar === '[')) {
        out += ch;
      } else {
        indent = Math.max(0, indent - 1);
        out = out.replace(/[ \t]+$/, '');
        if (out.length && !out.endsWith('\n')) out += '\n';
        out += '  '.repeat(indent) + ch;
      }
    } else if (ch === ',') {
      out += ',\n' + '  '.repeat(indent);
    } else if (ch === ':') {
      out += ': ';
    } else {
      out += ch;
    }
  }
  return { text: out, exact: false };
}

export function tryRepairVariableJson(text: string): { ok: true; text: string } | { ok: false; error: string } {
  try {
    const repaired = jsonrepair(text);
    const parsed = JSON.parse(repaired);
    if (!Array.isArray(parsed) && !(parsed && typeof parsed === 'object')) {
      return { ok: false, error: '自动修复后的内容不是有效的 JSON 结构' };
    }
    return { ok: true, text: JSON.stringify(parsed, null, 2) };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

export function variableChannelLabel(channel: VariableOutputChannel): string {
  return (
    {
      'story-main': '正文同次',
      'story-extra': '正文独立变量 API',
      phone: '手机变量',
    }[channel] ?? '变量更新'
  );
}
