const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const { createHash } = require('node:crypto');
const ts = require('typescript');
const settingsPaths = require('../运行/设定路径.json');
const root = path.resolve(__dirname, '..');
const resolve = Module._resolveFilename;
Module._resolveFilename = function (name, parent, ...args) {
  if (name.startsWith('.') && parent && fs.existsSync(path.resolve(path.dirname(parent.filename), name + '.ts'))) name += '.ts';
  return resolve.call(this, name, parent, ...args);
};
require.extensions['.ts'] = (module, file) => module._compile(ts.transpileModule(fs.readFileSync(file, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
}).outputText, file);
global.z = require('zod').z;
global._ = require('lodash');
const { parseAndValidateCharacterJson } = require('../界面/桌面端/utils/char_importer.ts');

function readCharacterAssets(source = path.resolve(root, settingsPaths.角色作者目录)) {
  const entries = [], characters = {};
  let sourceBytes = 0;
  for (const name of fs.readdirSync(source, { recursive: true }).filter(name => name.endsWith('.json')).sort((a, b) => a.localeCompare(b, 'zh-CN'))) {
    const bytes = fs.readFileSync(path.join(source, name));
    const raw = JSON.parse(bytes.toString('utf8'));
    if (!raw.id?.trim()) throw Error(name + ': 作者档案缺少稳定 ID');
    const parsed = parseAndValidateCharacterJson(raw);
    if (!parsed.success) throw Error(name + ': ' + parsed.error);
    const id = parsed.charId;
    if (Object.hasOwn(characters, id)) throw Error('角色ID重复：' + id);
    characters[id] = raw;
    const identityObj = parsed.mappedCharacter.身份;
    const publicIdentity =
      identityObj && typeof identityObj === 'object'
        ? (Array.isArray(identityObj.公开) ? identityObj.公开.join('、') : '') || null
        : typeof identityObj === 'string'
          ? identityObj
          : null;
    entries.push({
      id,
      name: parsed.charName,
      tier: parsed.charLayer,
      identity: publicIdentity,
      race: parsed.mappedCharacter.种族,
      defaultForm: parsed.staticProfile?.默认形态 ?? parsed.mappedCharacter.当前形态 ?? null,
    });
    sourceBytes += bytes.length;
  }
  const content = JSON.stringify({ format: '符文都市角色资源/1', characters });
  const sha256 = createHash('sha256').update(content).digest('hex');
  const file = 'characters-' + sha256.slice(0, 16) + '.json';
  const manifest = { format: '符文都市角色名录/1', data: file, sha256, entries };
  return { manifest, content, sourceBytes };
}

function buildCharacterAssets(source, output = path.resolve(root, '../../dist/瓦罗兰/角色资源')) {
  const { manifest, content, sourceBytes } = readCharacterAssets(source);
  const { sha256, data: file, entries } = manifest;
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, file), content, 'utf8');
  fs.writeFileSync(path.join(output, 'index.json'), JSON.stringify(manifest), 'utf8');
  return { output, count: entries.length, sourceBytes, dataBytes: Buffer.byteLength(content),
    indexBytes: Buffer.byteLength(JSON.stringify(manifest)), sha256, file };
}
module.exports = { readCharacterAssets, buildCharacterAssets };
if (require.main === module) console.log(JSON.stringify(buildCharacterAssets(undefined, process.argv[2]), null, 2));
