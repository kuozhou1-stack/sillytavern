import { copy, type State } from './core';

type Quest = State['奇遇系统']['任务'][string];
export const GOOD_QUALITIES = ['基础', '史诗', '传说', '神话'] as const;
export type GoodQuality = (typeof GOOD_QUALITIES)[number];

export const GOOD_QUALITY_META: Record<
  GoodQuality,
  {
    label: string;
    unlockCount: number;
    priceRange: [number, number];
    subtitle: string;
  }
> = {
  基础: {
    label: '基础',
    unlockCount: 0,
    priceRange: [15, 75],
    subtitle: '初始装、生态耗材、都市体验凭证与日常海克斯工具',
  },
  史诗: {
    label: '史诗',
    unlockCount: 2,
    priceRange: [80, 200],
    subtitle: '进阶组件、禁魔石护具、五校通行凭证与特色魔导器具',
  },
  传说: {
    label: '传说',
    unlockCount: 5,
    priceRange: [240, 500],
    subtitle: '典故名匠成装、地区管制重武备与诅咒秘器',
  },
  神话: {
    label: '神话',
    unlockCount: 9,
    priceRange: [650, 1200],
    subtitle: '破败王者之刃、世界符文、圣裁双刃等终局神话与禁忌神器',
  },
};

export type NovelAction = { kind: 'enable' | 'accept' | 'abandon' | 'claim' | 'buy'; id?: string; operationId: string };
export type SystemGood = {
  id: string;
  name: string;
  price: number;
  category: string;
  quality: GoodQuality;
  unit?: string;
  description: string;
  rare: boolean;
  limit?: number;
};

// 已移除固定商品目录，商品全部由奇遇商店动态刷新按瓦罗兰世界观生成。
export const SYSTEM_GOODS: readonly SystemGood[] = [];
export const novelNameKey = (name: string) => name.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, '');

export function resolveGoodQuality(good: { 品质?: string | null; 稀有?: boolean }): GoodQuality {
  if (good.品质 && (GOOD_QUALITIES as readonly string[]).includes(good.品质)) return good.品质 as GoodQuality;
  return good.稀有 ? '传说' : '基础';
}

export function goodUnlockCount(quality: GoodQuality): number {
  return GOOD_QUALITY_META[quality].unlockCount;
}

export function highestUnlockedQuality(state: State): GoodQuality {
  const done = completedQuests(state);
  let best: GoodQuality = '基础';
  for (const quality of GOOD_QUALITIES) {
    if (done >= GOOD_QUALITY_META[quality].unlockCount) best = quality;
  }
  return best;
}

/** Shop catalog comes entirely from saved dynamically generated goods. */
export function systemGoods(state: State): SystemGood[] {
  return Object.entries(state.奇遇系统._商店商品).map(([id, good]) => {
    const quality = resolveGoodQuality(good);
    return {
      id,
      name: good.名称,
      price: good.价格,
      category: good.类别,
      quality,
      unit: good.单位,
      description: good.描述,
      rare: quality !== '基础',
      limit: good.品质 === '神话' ? 1 : good.限购,
    };
  });
}

export function storyDateKey(t: State['世界']['当前时间']): string | null {
  return t
    ? `${String(t.年).padStart(4, '0')}-${String(t.月).padStart(2, '0')}-${String(t.日).padStart(2, '0')}`
    : null;
}

export function storyDay(state: State): string | null {
  return storyDateKey(state.世界.当前时间);
}

export const MAX_AVAILABLE_QUESTS = 8;
export function availableNovelTasks(state: State, day = storyDay(state)) {
  const system = state.奇遇系统;
  return Object.entries(system.任务).filter(
    ([id, task]) => !system._任务记录[id] && (!task.有效日 || !day || task.有效日 === day),
  );
}

export function activeNovelTaskCount(state: State) {
  const day = storyDay(state);
  return Object.entries(state.奇遇系统._任务记录).filter(([id, record]) => {
    const task = state.奇遇系统.任务[id];
    return record.状态 === '进行中' && task && (!task.有效日 || !day || task.有效日 === day);
  }).length;
}

function definition(task: Quest) {
  const { 进度, 进展说明, 完成依据事件id, ...fixed } = task;
  return JSON.stringify(fixed);
}

export function questReward(task: Quest) {
  if (task.难度 === '稀有') return 90;
  if (task.难度 === '进阶') return 45;
  return task.类型 === '日常' ? 15 : task.类型 === '成长' ? 30 : 25;
}

export function completedQuests(state: State) {
  return Object.values(state.奇遇系统._任务记录).filter(t => t.状态 === '已领取').length;
}

// Older accepted tasks stored fingerprints of player events and permitted a later material update.
function legacyEventStamp(event: State['事件'][string]) {
  const text = JSON.stringify([event.事实, event.参与者, event.关联记录id]);
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
  return (hash >>> 0).toString(16);
}

export function questIssue(state: State, id: string): string {
  const system = state.奇遇系统,
    task = system.任务[id],
    record = system._任务记录[id];
  if (!system._启用) return '请先开启奇遇系统';
  if (!task) return '任务已不存在';
  if (!record || record.状态 !== '进行中') return '任务未接取或已经结束';
  if (task.进度 < 100) return '目标尚未完成';
  if (task.有效日 && storyDay(state) && task.有效日 !== storyDay(state)) return '该日常任务已经过期';
  if (definition(task) !== record.定义快照) return '已接取任务的目标或奖励档位发生变化';
  const proof = task.完成依据事件id;
  if (
    !proof.length ||
    proof.some(eventId => {
      const event = state.事件[eventId];
      return (
        !event?.事实?.trim() ||
        !state.玩家.id ||
        !Object.hasOwn(event.参与者, state.玩家.id) ||
        (record.依据规则版本 === 1
          ? Object.hasOwn(record.接取时事件摘要, eventId) || !event.关联记录id.includes(id)
          : record.接取时事件摘要[eventId] === legacyEventStamp(event)) ||
        Object.entries(system._任务记录).some(([other, entry]) => other !== id && entry.状态 === '已领取' &&
          system.任务[other]?.完成依据事件id.includes(eventId))
      );
    })
  )
    return '需要接取后新记、与玩家及本任务有关、且未用于领取其他任务的完成事件';
  return '';
}

export function shopIssue(state: State, good: SystemGood): string {
  const system = state.奇遇系统;
  if (!system._启用) return '请先开启奇遇系统';
  const required = goodUnlockCount(good.quality);
  if (required > 0 && completedQuests(state) < required)
    return `完成并领取 ${required} 项任务后解锁${good.quality}品质`;
  const limit = good.quality === '神话' ? 1 : good.limit;
  if (limit !== undefined && (system._商店已购[good.id] ?? 0) >= limit) return '已达到本存档购买上限';
  if (system._系统币 < good.price) return '蓝色精粹不足';
  return '';
}

function changeCoins(
  state: State,
  amount: number,
  id: string,
  type: State['奇遇系统']['_流水'][string]['类型'],
  description: string,
  related: string | null,
) {
  const system = state.奇遇系统;
  if (system._流水[id]) throw Error('本次结算已经记录');
  const balance = system._系统币 + amount;
  if (!Number.isSafeInteger(balance) || balance < 0) throw Error('蓝色精粹数额无效');
  system._系统币 = balance;
  system._流水[id] = { 类型: type, 数额: amount, 说明: description, 关联id: related };
}

/** Called only by the state writer after a successful candidate, never by Schema parsing/rendering. */
export function refreshNovelSystem(state: State): State {
  const system = state.奇遇系统;
  if (!system._启用) return state;
  const day = storyDay(state);
  const key = day ?? '未定日';
  if (day) {
    // 首次确认故事日期时，只为尚未定日的日常任务衔接有效日，不生成固定模板、不重置进度或接取记录。
    for (const [id, task] of Object.entries(system.任务)) {
      if (task.类型 !== '日常' || task.有效日 !== null) continue;
      const accepted = system._任务记录[id];
      if (accepted && accepted.状态 !== '进行中') continue;
      task.有效日 = day;
      if (accepted && accepted.状态 === '进行中') accepted.定义快照 = definition(task);
    }
  }
  system._刷新日期 = key;
  return state;
}

function defaultGoodUnit(good: SystemGood): string {
  if (good.unit?.trim()) return good.unit.trim();
  if (good.category === '消耗品') return '份';
  if (good.category === '资料凭证') return '张';
  return '件';
}

export function applyNovelAction(state: State, action: NovelAction): State {
  if (!state._系统.建档完成 || !state.玩家.id) throw Error('请先完成玩家建档');
  if (!action.operationId?.trim()) throw Error('操作缺少结算标识');
  const system = state.奇遇系统;
  if (action.kind === 'buy' && system._流水[`buy:${action.operationId}`]) return state;
  if (action.kind === 'enable') {
    if (system._启用) return state;
    changeCoins(state, 30, 'welcome', '启用赠礼', '奇遇系统初次开启赠礼', null);
    system._启用 = true;
    return refreshNovelSystem(state);
  }
  if (!system._启用) throw Error('请先开启奇遇系统');
  const id = action.id;
  if (!id) throw Error('请选择任务或商品');
  if (action.kind === 'buy') {
    const good = systemGoods(state).find(g => g.id === id);
    if (!good) throw Error('商品不存在');
    const issue = shopIssue(state, good);
    if (issue) throw Error(issue);
    const itemId = `cw_system_item_${good.id}`;
    const existing = state.玩家.物品栏[itemId];
    if (existing && (existing.名称 !== good.name || existing.数量 === null))
      throw Error('该系统物品记录不一致，请检查存档');
    const quantity = (existing?.数量 ?? 0) + 1;
    if (!Number.isSafeInteger(quantity)) throw Error('物品数量无效');
    changeCoins(state, -good.price, `buy:${action.operationId}`, '商店购买', `购买 ${good.name}`, good.id);
    system._商店已购[good.id] = (system._商店已购[good.id] ?? 0) + 1;
    state.玩家.物品栏[itemId] = {
      ...existing,
      名称: good.name,
      类别: good.category,
      品质: good.quality,
      单位: existing?.单位 ?? defaultGoodUnit(good),
      描述: good.description,
      状态: '可用',
      数量: quantity,
      获得时间: copy(state.世界.当前时间),
      关联事项id: existing?.关联事项id ?? [],
    } as State['玩家']['物品栏'][string];
    return state;
  }
  const task = system.任务[id];
  if (!task?.名称.trim() || !task.目标.trim()) throw Error('任务名称或目标不完整');
  const record = system._任务记录[id];
  if (action.kind === 'accept') {
    if (record) throw Error('该任务已经接取或结束');
    if (task.有效日 && storyDay(state) && task.有效日 !== storyDay(state)) throw Error('任务已经过期');
    if (activeNovelTaskCount(state) >= 5)
      throw Error('最多同时接取 5 项任务，请先完成或放弃已有任务');
    system._任务记录[id] = {
      状态: '进行中',
      定义快照: definition(task),
      依据规则版本: 1,
      接取时事件摘要: Object.fromEntries(Object.keys(state.事件).map(eventId => [eventId, ''])),
    };
    task.进度 = 0;
    task.进展说明 = null;
    task.完成依据事件id = [];
  } else if (action.kind === 'abandon') {
    if (!record || record.状态 !== '进行中') throw Error('该任务没有进行中');
    record.状态 = '已放弃';
  } else if (action.kind === 'claim') {
    if (record?.状态 === '已领取' && system._流水[`reward:${id}`]) return state;
    const issue = questIssue(state, id);
    if (issue) throw Error(issue);
    changeCoins(state, questReward(task), `reward:${id}`, '任务奖励', `完成 ${task.名称}`, id);
    record.状态 = '已领取';
  } else throw Error('未知的奇遇系统操作');
  // Release the comparison cache only during an explicit, atomic end action.
  // Actual events, completion IDs, task definitions, ledger and old saved states are untouched.
  // Schema parsing never sweeps legacy records or changes their recovery fingerprint.
  if (record && record.状态 !== '进行中') record.接取时事件摘要 = {};
  return state;
}

/** Public task progress may be authored by the worker; accepted definitions and system items cannot be forged. */
export function assertNovelModel(before: State, after: State) {
  const old = before.奇遇系统,
    next = after.奇遇系统;
  if (!old._启用 && !_.isEqual(old.任务, next.任务)) throw Error('奇遇系统尚未开启，不能生成或结算任务');
  for (const [id, record] of Object.entries(old._任务记录)) {
    if (old.任务[id] && _.isEqual(old.任务[id], next.任务[id])) continue;
    if (!next.任务[id] || definition(next.任务[id]) !== record.定义快照)
      throw Error('模型不能改写或删除已接取任务：' + id);
    if (record.状态 !== '进行中' && !_.isEqual(old.任务[id], next.任务[id]))
      throw Error('已结束任务不可重新结算：' + id);
  }
  const day = storyDay(after);
  const available = availableNovelTasks(after, day);
  if (available.length > MAX_AVAILABLE_QUESTS) {
    const previous = new Set(availableNovelTasks(before, day).map(([id]) => id));
    if (available.some(([id]) => !previous.has(id))) throw Error('可接取任务最多 8 项');
  }
  for (const [id, task] of Object.entries(old.任务)) {
    if (task.类型 === '日常' && !next.任务[id]) throw Error('正文不能删除日常任务：' + id);
  }
  for (const [id, task] of Object.entries(next.任务)) {
    if (old._任务记录[id]) continue;
    const prior = old.任务[id];
    if (_.isEqual(prior, task)) continue;
    if (task.进度 || task.完成依据事件id.length) throw Error('未接取任务不能提前完成：' + id);
    if (!task.名称.trim() || !task.目标.trim()) throw Error('任务名称与目标不能为空');
    if (task.类型 === '日常' || prior?.类型 === '日常') throw Error('日常任务由奇遇刷新发布，正文不能新建或改写待接日常');
    if (task.有效日 !== null) throw Error('正文新增奇遇任务不能指定有效日：' + id);
    if (Object.entries(next.任务).some(([other, row]) => other !== id && novelNameKey(row.名称) === novelNameKey(task.名称)))
      throw Error('奇遇任务名称已存在：' + task.名称);
  }
  for (const [id, previous] of Object.entries(before.玩家.物品栏)) {
    if (!id.startsWith('cw_system_item_')) continue;
    const item = after.玩家.物品栏[id];
    if (!item || (item.数量 !== null && previous.数量 !== null && item.数量 < previous.数量)) {
      const evidence = Object.entries(after.事件).some(([eventId, event]) => event.事实?.trim() &&
        event.关联记录id.includes(id) && !_.isEqual(event, before.事件[eventId]));
      if (!evidence) throw Error('系统物品扣减或移除须有本轮关联事件：' + id);
    }
  }
  for (const [id, item] of Object.entries(after.玩家.物品栏)) {
    if (!id.startsWith('cw_system_item_')) continue;
    const previous = before.玩家.物品栏[id];
    if (_.isEqual(previous, item)) continue;
    if (
      !previous ||
      (item.数量 ?? 0) > (previous.数量 ?? 0) ||
      (item.数量 === null && previous.数量 !== null) ||
      item.名称 !== previous.名称 ||
      item.类别 !== previous.类别 ||
      item.品质 !== previous.品质 ||
      item.描述 !== previous.描述
    )
      throw Error('系统商品只能由实际购买增加，不得改写效果：' + id);
  }
}

export function novelPrompt(state: State, worker = true) {
  if (!state.奇遇系统._启用)
    return '玩家尚未开启奇遇系统，奇遇任务保持为空；剧情中玩家答应 NPC 或组织的办事请求记于顶层「委托」。';
  return worker
    ? '奇遇系统已开启：日常仅由奇遇刷新发布。剧情可提出非日常引导任务，有效日留空。已接任务只按实际行动推进，完成依据须引用接取后独立新记的玩家参与事件，并在该事件的关联记录id写入任务ID。可接取奇遇任务上限8项，下划线字段与商店购销由程序维护，不能发币、扣币、代领或代买；正文中玩家答应 NPC 或组织的办事请求记于顶层「委托」，不混入奇遇任务或约定。'
    : '玩家奇遇系统已开启：奇遇任务与多品质商店（基础/史诗/传说/神话）仅供玩家自主操作，已购系统物品按物品栏品质与描述结算效果及代价，蓝色精粹与金币独立不互兑。';
}
