import type { State } from './core';

/** 已切换至外置设定坐标体系，不再在代码中硬编码旧预置地标补齐表。 */
export function normalizeMapLandmarks(state: State): State {
  return state;
}
