import { buildExternalAssetFallbacks, defaultExternalSettingsUrl } from '../../../运行/external-settings';
import atlas from '../../../运行/地图资源.json';

export type MapSheet = { id: string; name: string; urls: string[] };
const directory = new URL('../' + atlas.目录 + '/', defaultExternalSettingsUrl + '/');
const sheets = Object.entries(atlas.图幅).map(([id, name]): MapSheet => ({
  id,
  name,
  urls: buildExternalAssetFallbacks(new URL(id + '-' + name + '.webp', directory).href),
}));
export const worldSheet = sheets.find(sheet => sheet.id === '00')!;

export function districtSheets(districtId: string) {
  return sheets.filter(sheet => sheet !== worldSheet && 'area_' + sheet.id.split('-')[0] === districtId);
}

// 建筑使用所属地点的分图。自建地点没有已知归属时保留区域坐标。
export function locationSheet(id: string, places: Record<string, { 上级地点id?: string | null }>, options: MapSheet[]) {
  const seen = new Set<string>();
  let current: string | null | undefined = id;
  while (current && !seen.has(current)) {
    const sheet = options.find(option => option.id === current);
    if (sheet) return sheet;
    seen.add(current);
    current = places[current]?.上级地点id;
  }
  return undefined;
}
