import type { State } from './core';
import { organizationCatalog } from './organizations';

export function assertCommissionUpdates(before: State, after: State) {
  for (const [id, row] of Object.entries(before.委托)) {
    if (!Object.hasOwn(after.委托, id)) throw Error('委托历史须保留：' + id);
    if (row.状态 !== '进行中' && !_.isEqual(row, after.委托[id])) throw Error('已结束委托不能改写：' + id);
  }
  for (const [id, row] of Object.entries(after.委托)) {
    const previous = before.委托[id];
    if (_.isEqual(row, previous)) continue;
    if (!previous || row.委托人id !== previous.委托人id || row.委托组织id !== previous.委托组织id) {
      if (previous) throw Error('已承接委托不能更换委托方：' + id);
      if (row.委托人id && !Object.hasOwn(after.角色, row.委托人id)) throw Error('委托人不存在或已停用：' + id);
      if (row.委托组织id && !Object.hasOwn(organizationCatalog(after), row.委托组织id))
        throw Error('委托组织不存在：' + id);
    }
    if (!previous && (row.状态 !== '进行中' || !row.内容?.trim() ||
        !(row.委托人称呼?.trim() || row.委托人id || row.委托组织id)))
      throw Error('新增委托须记录已承接的具体事务与委托方：' + id);
    const oldRefs = new Set(previous?.关联事件id ?? []);
    const addedRefs = row.关联事件id.filter(ref => !oldRefs.has(ref));
    if (addedRefs.some(ref => !Object.hasOwn(after.事件, ref))) throw Error('委托引用的事件不存在：' + id);
    if ([...oldRefs].some(ref => !row.关联事件id.includes(ref))) throw Error('委托已有事件依据须保留：' + id);
    if (!previous || previous.状态 !== row.状态) {
      if (!after.玩家.id || !addedRefs.some(ref => !Object.hasOwn(before.事件, ref) &&
          after.事件[ref]?.事实?.trim() && Object.hasOwn(after.事件[ref].参与者, after.玩家.id!)))
        throw Error('委托承接或结束须有本轮新记且玩家参与的事件：' + id);
    }
  }
}

export function abandonCommission(state: State, id: string) {
  const row = state.委托[id];
  if (!row || row.状态 !== '进行中') throw Error('委托已结束或不存在');
  row.状态 = '已放弃';
}
