<template>
  <div class="cw-tab-pane cw-char-tab-personality">
    <!-- 1. 心理内核（深度动机三支柱） -->
    <div v-if="psychCoreEntries.length" class="cw-char-section-card cw-section-core">
      <h4 class="cw-section-title">
        <SvgIcon name="target" :size="15" />
        <span>心理内核</span>
      </h4>
      <div class="cw-core-grid">
        <div v-for="entry in psychCoreEntries" :key="entry.key" class="cw-core-item">
          <span class="cw-core-k">{{ entry.label }}</span>
          <p class="cw-prose-paragraph">{{ entry.value }}</p>
        </div>
      </div>
    </div>

    <!-- 2. 表里性格与日常毛边 -->
    <div v-if="hasSurfacePersonality" class="cw-char-section-card">
      <h4 class="cw-section-title">
        <SvgIcon name="smile" :size="15" />
        <span>性格侧写与生活毛边</span>
      </h4>

      <div v-if="surfacePair.length" class="cw-dual-grid">
        <div v-for="item in surfacePair" :key="item.key" class="cw-dual-card">
          <span class="cw-pill-label">{{ item.label }}</span>
          <div class="cw-long-text-block">
            <p class="cw-prose-paragraph" :class="{ 'is-clamped': !isExpanded(item.key) && item.isLong }">
              {{ item.value }}
            </p>
            <button
              v-if="item.isLong"
              type="button"
              class="cw-expand-toggle-btn"
              @click="toggleExpand(item.key)"
            >
              <span>{{ isExpanded(item.key) ? '收起' : '展开全文' }}</span>
              <SvgIcon :name="isExpanded(item.key) ? 'chevronUp' : 'chevronDown'" :size="12" />
            </button>
          </div>
        </div>
      </div>

      <div v-if="habitEntries.length || char?.专属标识?.破防弱点" class="cw-stack-list" :style="{ marginTop: surfacePair.length ? '12px' : '0' }">
        <div v-for="item in habitEntries" :key="item.key" class="cw-stack-box">
          <span class="cw-stack-k">{{ item.label }}</span>
          <p class="cw-prose-paragraph">{{ item.value }}</p>
        </div>
        <div v-if="char?.专属标识?.破防弱点" class="cw-stack-box cw-weakness-box">
          <span
            class="cw-stack-k cw-tooltip-label"
            tabindex="0"
            :data-cw-tooltip="emotionalTriggerDescription"
            data-cw-tooltip-touch
          >
            {{ emotionalTriggerLabel }}
          </span>
          <p class="cw-prose-paragraph">{{ char.专属标识.破防弱点 }}</p>
        </div>
      </div>
    </div>

    <!-- 3. 情境触发机制 (If-Then) -->
    <div v-if="triggerEntries.length" class="cw-char-section-card">
      <h4 class="cw-section-title">
        <SvgIcon name="sparkles" :size="15" />
        <span>情境触发机制 (If-Then)</span>
      </h4>
      <div class="cw-trigger-list">
        <div v-for="trig in triggerEntries" :key="trig.key" class="cw-trigger-row">
          <span class="cw-trigger-badge">{{ trig.key }}</span>
          <p class="cw-prose-paragraph">{{ trig.value }}</p>
        </div>
      </div>
    </div>

    <!-- 4. 语言指纹 -->
    <div v-if="hasVoiceFingerprint" class="cw-char-section-card">
      <h4 class="cw-section-title">
        <SvgIcon name="messageSquare" :size="15" />
        <span>语言指纹</span>
      </h4>
      <div class="cw-stack-list">
        <div v-if="voiceFingerprint.句法与口吻" class="cw-stack-box">
          <span class="cw-stack-k">句法与口吻</span>
          <p class="cw-prose-paragraph">{{ voiceFingerprint.句法与口吻 }}</p>
        </div>
        <div v-if="voiceLexiconChips.length" class="cw-stack-box">
          <span class="cw-stack-k">高频意象词库</span>
          <div class="cw-chip-wrap">
            <span v-for="(chip, idx) in voiceLexiconChips" :key="idx" class="cw-lexicon-chip">
              {{ chip }}
            </span>
          </div>
        </div>
        <div v-if="voiceFingerprint.称呼梯度" class="cw-stack-box">
          <span class="cw-stack-k">称呼梯度</span>
          <p class="cw-prose-paragraph">{{ voiceFingerprint.称呼梯度 }}</p>
        </div>
      </div>
    </div>

    <!-- 若所有结构化性格项均为空 -->
    <div v-if="!hasAnyPersonality" class="cw-char-section-card">
      <h4 class="cw-section-title">
        <SvgIcon name="smile" :size="15" />
        <span>性格与习惯</span>
      </h4>
      <div class="cw-empty-sub">尚未登记性格与习惯特征</div>
    </div>

    <!-- 5. 反全知认知边界 -->
    <div v-if="hasKnowledgeBoundary" class="cw-char-section-card">
      <h4 class="cw-section-title">
        <SvgIcon name="lock" :size="15" />
        <span>认知边界（反全知基准）</span>
      </h4>
      <div class="cw-stack-list">
        <div v-if="char?.认知边界?.已知范围" class="cw-stack-box cw-boundary-known">
          <span class="cw-stack-k">已知范围</span>
          <p class="cw-prose-paragraph">{{ char.认知边界.已知范围 }}</p>
        </div>
        <div v-if="char?.认知边界?.信息盲区" class="cw-stack-box cw-boundary-blind">
          <span class="cw-stack-k">信息盲区</span>
          <p class="cw-prose-paragraph">{{ char.认知边界.信息盲区 }}</p>
        </div>
        <div v-if="char?.认知边界?.保密红线" class="cw-stack-box cw-boundary-redline">
          <span class="cw-stack-k">保密红线</span>
          <p class="cw-prose-paragraph">{{ char.认知边界.保密红线 }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { emotionalTriggerDescription, emotionalTriggerLabel } from '../../../utils/relationship-labels';
import SvgIcon from '../../icons/SvgIcon.vue';

const props = defineProps<{
  char: any;
  expandedFields: Record<string, boolean>;
}>();

const emit = defineEmits<{
  (e: 'toggleExpand', field: string): void;
}>();

const isExpanded = (key: string) => !!props.expandedFields[`personality:${key}`];
const toggleExpand = (key: string) => emit('toggleExpand', `personality:${key}`);
const isLongText = (text: string) => text.length > 160 || (text.match(/\n/g) || []).length >= 4;

const rawPersonality = computed(() => {
  const p = props.char?.性格;
  return p && typeof p === 'object' ? p : {};
});

const psychCoreEntries = computed(() => {
  const core = rawPersonality.value.心理内核;
  if (!core || typeof core !== 'object') return [];
  const order = ['旧伤与执念', '外在面具与隐秘渴求', '结构性矛盾'];
  const entries: Array<{ key: string; label: string; value: string }> = [];
  for (const k of order) {
    const v = core[k];
    if (typeof v === 'string' && v.trim()) entries.push({ key: k, label: k, value: v.trim() });
  }
  for (const [k, v] of Object.entries(core)) {
    if (!order.includes(k) && typeof v === 'string' && v.trim()) {
      entries.push({ key: k, label: k, value: v.trim() });
    }
  }
  return entries;
});

const surfacePair = computed(() => {
  const out: Array<{ key: string; label: string; value: string; isLong: boolean }> = [];
  for (const key of ['表性格', '里性格']) {
    const v = rawPersonality.value[key];
    if (typeof v === 'string' && v.trim()) {
      const value = v.trim();
      out.push({ key, label: key, value, isLong: isLongText(value) });
    }
  }
  return out;
});

const habitEntries = computed(() => {
  const keys = ['爱好', '厌恶', '小习惯'];
  const out: Array<{ key: string; label: string; value: string }> = [];
  for (const k of keys) {
    const v = rawPersonality.value[k];
    if (typeof v === 'string' && v.trim()) out.push({ key: k, label: k, value: v.trim() });
  }
  const known = new Set(['心理内核', '表性格', '里性格', '爱好', '厌恶', '小习惯', '情境触发', '语言指纹', '语言习惯']);
  for (const [k, v] of Object.entries(rawPersonality.value)) {
    if (!known.has(k) && typeof v === 'string' && v.trim()) {
      out.push({ key: k, label: k, value: v.trim() });
    }
  }
  return out;
});

const hasSurfacePersonality = computed(
  () => surfacePair.value.length > 0 || habitEntries.value.length > 0 || Boolean(props.char?.专属标识?.破防弱点),
);

const triggerEntries = computed(() => {
  const triggers = rawPersonality.value.情境触发;
  if (!triggers || typeof triggers !== 'object') return [];
  return Object.entries(triggers)
    .filter(([, v]) => typeof v === 'string' && v.trim())
    .map(([k, v]) => ({ key: k, value: String(v).trim() }));
});

const voiceFingerprint = computed(() => {
  const vf = rawPersonality.value.语言指纹;
  const legacy = typeof rawPersonality.value.语言习惯 === 'string' ? rawPersonality.value.语言习惯.trim() : '';
  return {
    句法与口吻: (vf?.句法与口吻 && String(vf.句法与口吻).trim()) || legacy || '',
    高频意象词库: (vf?.高频意象词库 && String(vf.高频意象词库).trim()) || '',
    称呼梯度: (vf?.称呼梯度 && String(vf.称呼梯度).trim()) || '',
  };
});

const voiceLexiconChips = computed(() => {
  const raw = voiceFingerprint.value.高频意象词库;
  if (typeof raw !== 'string') return [];
  return raw
    .split(/[、,，/；;]+/)
    .map(s => s.trim())
    .filter(Boolean);
});

const hasVoiceFingerprint = computed(() =>
  Boolean(voiceFingerprint.value.句法与口吻 || voiceLexiconChips.value.length || voiceFingerprint.value.称呼梯度),
);

const hasAnyPersonality = computed(
  () =>
    psychCoreEntries.value.length > 0 ||
    hasSurfacePersonality.value ||
    triggerEntries.value.length > 0 ||
    hasVoiceFingerprint.value,
);

const hasKnowledgeBoundary = computed(() => {
  const b = props.char?.认知边界;
  return Boolean(b && (b.已知范围 || b.信息盲区 || b.保密红线));
});
</script>

<style scoped lang="scss">
.cw-char-tab-personality {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-char-section-card {
  padding: 16px 18px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-section-core {
  border-left: 3px solid var(--cw-accent);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-core-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-core-item {
  padding: 10px 13px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.cw-core-k {
  font-size: 11.5px;
  font-weight: 700;
  color: var(--cw-tag-accent-text, var(--cw-accent));
}

.cw-dual-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.cw-dual-card {
  padding: 12px 14px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 7px;
}

.cw-pill-label {
  align-self: flex-start;
  font-size: 11.5px;
  font-weight: 600;
  color: var(--cw-tag-accent-text, var(--cw-accent));
  background: var(--cw-tag-accent-bg, var(--cw-accent-bg));
  padding: 2px 9px;
  border-radius: 5px;
  border: 1px solid var(--cw-tag-accent-border, var(--cw-accent-border));
}

.cw-stack-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-stack-box {
  padding: 10px 13px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.cw-stack-k {
  font-size: 11px;
  font-weight: 600;
  color: var(--cw-text-secondary);
}

.cw-tooltip-label {
  align-self: flex-start;
  cursor: help;
  border-bottom: 1px dashed currentColor;
}

.cw-trigger-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cw-trigger-row {
  padding: 10px 13px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.cw-trigger-badge {
  align-self: flex-start;
  font-size: 11.5px;
  font-weight: 600;
  color: var(--cw-tag-info-text, var(--cw-info));
  background: var(--cw-tag-info-bg, var(--cw-info-bg));
  border: 1px solid var(--cw-tag-info-border, var(--cw-info));
  padding: 2px 9px;
  border-radius: 5px;
}

.cw-chip-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.cw-lexicon-chip {
  padding: 3px 10px;
  border-radius: var(--cw-radius-full);
  background: var(--cw-tag-neutral-bg, var(--cw-bg-card));
  border: 1px solid var(--cw-tag-neutral-border, var(--cw-border));
  font-size: 12px;
  font-weight: 500;
  color: var(--cw-tag-neutral-text, var(--cw-text-primary));
}

.cw-long-text-block {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 100%;
}

.cw-prose-paragraph {
  margin: 0;
  font-size: 13.5px;
  line-height: 1.74;
  color: var(--cw-text-primary);
  white-space: pre-wrap;
  word-break: break-word;
  overflow-wrap: anywhere;

  &.is-clamped {
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

.cw-expand-toggle-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-top: 6px;
  padding: 3px 10px;
  border-radius: var(--cw-radius-sm);
  border: 1px solid var(--cw-tag-accent-border, var(--cw-border));
  background: var(--cw-tag-accent-bg, var(--cw-bg-card));
  color: var(--cw-tag-accent-text, var(--cw-accent));
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
}

.cw-weakness-box {
  border: 1px solid var(--cw-tag-danger-border, var(--cw-border));
  border-left: 3px solid var(--cw-danger);
  background: var(--cw-tag-danger-bg, var(--cw-danger-bg));

  .cw-stack-k {
    color: var(--cw-tag-danger-text, var(--cw-danger));
  }
}

.cw-boundary-known {
  border-left: 3px solid var(--cw-info);
}

.cw-boundary-blind {
  border-style: dashed;
}

.cw-boundary-redline {
  border: 1px solid var(--cw-tag-danger-border, var(--cw-border));
  border-left: 3px solid var(--cw-danger);
  background: var(--cw-tag-danger-bg, var(--cw-danger-bg));

  .cw-stack-k {
    color: var(--cw-tag-danger-text, var(--cw-danger));
  }
}

.cw-empty-sub {
  font-size: 13px;
  color: var(--cw-text-muted);
  padding: 8px 0;
}

@media (max-width: 640px) {
  .cw-dual-grid {
    grid-template-columns: 1fr;
  }
}
</style>
