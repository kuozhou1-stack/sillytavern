import { registerMvuSchema } from '../../运行/mvu-schema';
import { Schema } from '../../schema';

$(() => {
  let disposed = false;
  let unregister: (() => void) | undefined;
  $(window).one('pagehide.cwMvuSchema', () => {
    disposed = true;
    unregister?.();
    unregister = undefined;
  });
  errorCatched(async () => {
    await waitGlobalInitialized('Mvu');
    if (disposed) return;
    unregister = registerMvuSchema(Schema);
    console.info('[瓦洛兰] MVU 变量结构已注册');
  })();
});
