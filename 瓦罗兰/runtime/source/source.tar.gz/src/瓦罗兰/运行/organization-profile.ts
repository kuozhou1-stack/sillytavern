import { z } from 'zod';

const text = z.string().trim().min(1);
const semanticId = z.string().regex(/^org_[a-z][a-z0-9_]*$/);
const member = z.strictObject({
  关系: z.enum(['正式成员', '合作者']),
  职务: text.optional(),
  小队: text.optional(),
});

export const OrganizationFile = z.strictObject({
  id: semanticId,
  编号: text,
  名称: text,
  象限: z.enum(['A', 'B', 'C', 'D']),
  公开性质: z.enum(['公开', '双面', '隐秘']),
  职能: text,
  对外形象: text.optional(),
  据点: z.record(text, text).optional(),
  活动范围: text.optional(),
  内部架构: text.optional(),
  成员: z.record(text, member).optional(),
  日常运作与交互: text.optional(),
  情报范围: text.optional(),
  行事底线: text.optional(),
  私密内情: text.optional(),
  分支: z.record(text, text).optional(),
  内部分歧: text.optional(),
  旧版id: z.string().regex(/^org_\d+$/).optional(),
});

export type OrganizationProfile = Omit<z.infer<typeof OrganizationFile>, 'id'>;
export const OrganizationRelations = z.array(z.strictObject({
  组织id: z.array(semanticId).min(2),
  公开态度: text,
  隐秘利益: text.optional(),
  触发红线: text.optional(),
}));
export type OrganizationRelation = z.infer<typeof OrganizationRelations>[number];
