<template>
  <div
    class="cw-modal-backdrop cw-var-inspector-backdrop"
    @click.self="!isSubmitting && emit('close')"
    @keydown.esc.stop.prevent="!isSubmitting && emit('close')"
  >
    <div class="cw-modal-box cw-var-inspector-modal" @click.stop>
      <!-- 顶栏 -->
      <div class="cw-modal-header">
        <div class="cw-header-left">
          <div class="cw-header-title">
            <SvgIcon name="terminal" :size="18" class="cw-header-icon" />
            <span>变量输出查看与修正</span>
          </div>
          <div v-if="record" class="cw-header-badges">
            <span class="cw-badge cw-badge-accent">{{ channelLabel }}</span>
            <span v-if="record.floor !== undefined" class="cw-badge">#{{ record.floor }} 楼</span>
            <span
              class="cw-badge"
              :class="{
                'cw-badge-danger': record.state === 'failed',
                'cw-badge-warning': record.state === 'pending',
                'cw-badge-success': record.state === 'saved',
              }"
            >
              {{ stateLabel }}
            </span>
            <span v-if="record.edited" class="cw-badge">已手动修改</span>
          </div>
        </div>
        <div class="cw-header-right">
          <select
            v-if="availableRecords.length > 1"
            :value="selectedId"
            class="cw-record-select"
            aria-label="切换查看最近的变量输出记录"
            :disabled="isSubmitting"
            @change="handleSelectRecord(($event.target as HTMLSelectElement).value)"
          >
            <option v-for="item in availableRecords" :key="item.id" :value="item.id">
              {{ formatRecordOption(item) }}
            </option>
          </select>
          <button
            type="button"
            class="cw-btn cw-btn-ghost cw-close-btn"
            aria-label="关闭变量输出窗口"
            :disabled="isSubmitting"
            @click="!isSubmitting && emit('close')"
          >
            <SvgIcon name="close" :size="18" />
          </button>
        </div>
      </div>

      <!-- 主体 -->
      <div v-if="!record" class="cw-modal-body cw-empty-body">
        <div class="cw-callout cw-callout-info">
          <SvgIcon name="info" :size="16" class="cw-callout-icon" />
          <div class="cw-callout-body">
            <strong class="cw-callout-title">暂无可查看的变量输出记录</strong>
            <p>本轮尚未收到新的变量更新回包。待正文或手机完成一次变量更新（或发生解析异常）后，可在此查看并修正原始输出。</p>
          </div>
        </div>
      </div>

      <div v-else class="cw-modal-body cw-inspector-body">
        <!-- 诊断状态条 -->
        <div
          class="cw-callout cw-diag-banner"
          :class="{
            'cw-callout-danger':
              diagnosis.status === 'syntax-error' ||
              diagnosis.status === 'protocol-error' ||
              diagnosis.status === 'backend-error',
            'cw-callout-success':
              diagnosis.status === 'ok' || diagnosis.status === 'backend-error-edited',
          }"
          :role="diagnosis.highlight ? 'alert' : 'status'"
        >
          <SvgIcon
            :name="
              diagnosis.status === 'ok' || diagnosis.status === 'backend-error-edited'
                ? 'checkCircle'
                : 'alertCircle'
            "
            :size="16"
            class="cw-callout-icon"
          />
          <div class="cw-callout-body">
            <div class="cw-diag-title-row">
              <strong class="cw-callout-title">{{ diagnosis.summary }}</strong>
              <button
                v-if="diagnosis.highlight"
                type="button"
                class="cw-btn cw-btn-sm cw-btn-danger cw-jump-btn"
                @click="jumpToError(true)"
              >
                <SvgIcon name="target" :size="13" />
                <span>定位到红字</span>
              </button>
            </div>
            <p v-if="diagnosis.detail" class="cw-diag-detail">{{ diagnosis.detail }}</p>
            <p v-else-if="record.missingUpdateBlock && isEditing" class="cw-diag-detail">
              本次同次回复未包含 &lt;UpdateVariable&gt; 变量块。你可以直接填写 JSONPatch 数组（无变化填 []）并结算。
            </p>
            <p v-else-if="record.missingClosingTag" class="cw-diag-detail">
              原始输出的闭合标签不完整，修正完下方 JSON 后点击「保存并立即结算」会自动补齐协议标签。
            </p>
            <p v-else-if="!isEditing && record.canResummarize" class="cw-diag-detail">
              当前为最新已结算楼层的原始变量输出（只读预览）。如需调整变量并重新结算本楼，可点击右侧「开启编辑重算」。
            </p>
            <p v-else-if="!isEditing" class="cw-diag-detail">
              此记录为已保存的变量输出（只读查看）。历史楼层不支持直接修改重算，仅待结算或最新楼层可编辑重算。
            </p>
          </div>
        </div>

        <!-- 内联操作反馈提示 -->
        <div v-if="inlineNotice" class="cw-inline-notice" :class="`is-${inlineNotice.level}`" role="status">
          <SvgIcon :name="inlineNotice.level === 'error' ? 'alertTriangle' : 'info'" :size="14" />
          <span>{{ inlineNotice.text }}</span>
        </div>

        <!-- 工具栏 -->
        <div class="cw-editor-toolbar">
          <div class="cw-toolbar-left">
            <button
              v-if="diagnosis.highlight"
              type="button"
              class="cw-btn cw-btn-sm"
              title="滚动到红色标错位置并聚焦光标"
              @click="jumpToError(true)"
            >
              <SvgIcon name="target" :size="13" />
              <span>定位红字</span>
            </button>

            <button
              type="button"
              class="cw-btn cw-btn-sm"
              :disabled="!draft.trim() || isSubmitting"
              :title="
                diagnosis.validSyntax
                  ? '将 JSON 格式化为多行缩进'
                  : '对损坏的单行长 JSON 按括号/逗号断行缩进，便于查找红字'
              "
              @click="handleFormat"
            >
              <SvgIcon name="list" :size="13" />
              <span>格式化缩进</span>
            </button>

            <button
              v-if="isEditing && !diagnosis.validSyntax"
              type="button"
              class="cw-btn cw-btn-sm"
              :disabled="isSubmitting"
              title="使用 jsonrepair 尝试自动修补语法错误，仅填入编辑框供人工核对，不会自动提交"
              @click="handleTryRepair"
            >
              <SvgIcon name="sparkles" :size="13" />
              <span>尝试自动修复</span>
            </button>

            <button
              v-if="hasLocalChanges"
              type="button"
              class="cw-btn cw-btn-sm"
              :disabled="isSubmitting"
              title="恢复为打开窗口时的原始内容"
              @click="handleReset"
            >
              <SvgIcon name="rotateCcw" :size="13" />
              <span>还原原文</span>
            </button>

            <button
              v-if="!isEditing && record.canResummarize"
              type="button"
              class="cw-btn cw-btn-sm cw-btn-secondary"
              :disabled="isSubmitting"
              @click="unlockResummarize"
            >
              <SvgIcon name="edit" :size="13" />
              <span>开启编辑重算</span>
            </button>

            <button type="button" class="cw-btn cw-btn-sm" @click="handleCopy">
              <SvgIcon name="layers" :size="13" />
              <span>复制</span>
            </button>

            <button
              v-if="hasDistinctRaw"
              type="button"
              class="cw-btn cw-btn-sm cw-btn-ghost"
              @click="showRawDrawer = !showRawDrawer"
            >
              <SvgIcon :name="showRawDrawer ? 'eyeOff' : 'eye'" :size="13" />
              <span>{{ showRawDrawer ? '隐藏原始回包' : '查看原始回包' }}</span>
            </button>
          </div>

          <div class="cw-toolbar-right">
            <span v-if="isLongSingleLine" class="cw-single-line-tip">单行长文本 · 可点「格式化缩进」</span>
            <span class="cw-cursor-meta">
              第 {{ cursorPos.line }} 行，第 {{ cursorPos.column }} 列 · {{ draft.length.toLocaleString() }} 字
            </span>
          </div>
        </div>

        <!-- 高亮叠加代码编辑区（底层 <pre> 标红 + 顶层透明 <textarea> 原生编辑） -->
        <div
          class="cw-code-editor"
          :class="{
            'has-error': !!diagnosis.highlight,
            'is-readonly': !isEditing,
          }"
        >
          <pre ref="backdropRef" class="cw-code-layer cw-code-backdrop" aria-hidden="true"><template
            v-if="draft"
          ><template
            v-for="(seg, idx) in segments"
            :key="idx"
          ><mark v-if="seg.kind === 'error'" class="cw-code-error-mark">{{ seg.text }}</mark><mark
            v-else-if="seg.kind === 'error-eof'"
            class="cw-code-error-eof"
          >⏎</mark><template v-else>{{ seg.text }}</template></template></template>{{ '\n' }}</pre>

          <textarea
            ref="textareaRef"
            v-model="draft"
            class="cw-code-layer cw-code-textarea"
            :readonly="!isEditing"
            :disabled="isSubmitting"
            spellcheck="false"
            autocomplete="off"
            autocorrect="off"
            autocapitalize="off"
            aria-label="变量输出 JSONPatch 编辑器"
            placeholder="在此输入或修正 JSONPatch 数组（本轮若无变量变化请填写 []）"
            @scroll="syncScroll"
            @click="updateCursor"
            @keyup="updateCursor"
            @select="updateCursor"
          ></textarea>
        </div>

        <!-- 可选：原始完整回包只读预览（含外层壳子或协议标签） -->
        <div v-if="showRawDrawer && hasDistinctRaw" class="cw-raw-drawer">
          <div class="cw-raw-drawer-header">
            <span>原始模型变量回包（只读参考）</span>
            <button type="button" class="cw-btn cw-btn-ghost cw-btn-sm" @click="copyText(record.rawText, '已复制原始回包')">
              复制原始回包
            </button>
          </div>
          <pre class="cw-raw-pre">{{ record.rawText }}</pre>
        </div>
      </div>

      <!-- 底栏 -->
      <div class="cw-modal-footer">
        <div class="cw-footer-left">
          <button
            v-if="record?.canReRequestApi"
            type="button"
            class="cw-btn cw-btn-sm"
            :disabled="isSubmitting"
            :title="
              record.channel === 'story-main'
                ? '保留当前正文，自动展开缺失资料并单次重算本楼变量（不重写正文）'
                : '放弃手动修改，重新向独立变量/手机 API 请求一份新的变量补丁'
            "
            @click="handleReRequestApi"
          >
            <SvgIcon name="refresh" :size="13" :class="{ 'cw-spin': isSubmitting && submitAction === 'rerequest' }" />
            <span>{{ record.channel === 'story-main' ? '展开资料并重算变量' : '重新请求变量 API' }}</span>
          </button>
        </div>

        <div class="cw-footer-right">
          <button type="button" class="cw-btn cw-btn-ghost" :disabled="isSubmitting" @click="emit('close')">
            关闭
          </button>
          <template v-if="record && isEditing">
            <button
              type="button"
              class="cw-btn"
              :disabled="isSubmitting || (!hasLocalChanges && record.state !== 'failed')"
              title="保存修改后的变量文本到当前待结算记录，稍后再点击「立即重试」"
              @click="handleSave(false)"
            >
              <span>仅保存修改</span>
            </button>
            <button
              type="button"
              class="cw-btn cw-btn-primary"
              :disabled="isSubmitting || !diagnosis.validSyntax || !diagnosis.validProtocol"
              :title="
                !diagnosis.validSyntax || !diagnosis.validProtocol
                  ? '请先修正红色标出的 JSON 格式错误'
                  : '保存修改后的变量块并立即运行完整校验与结算'
              "
              @click="handleSave(true)"
            >
              <SvgIcon
                :name="isSubmitting && submitAction === 'settle' ? 'refresh' : 'check'"
                :size="14"
                :class="{ 'cw-spin': isSubmitting && submitAction === 'settle' }"
              />
              <span>{{ isSubmitting && submitAction === 'settle' ? '正在结算…' : '保存并立即结算' }}</span>
            </button>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, inject, nextTick, onMounted } from 'vue';
import SvgIcon from '../icons/SvgIcon.vue';
import { RuntimeKey, type Runtime } from '../../../../运行/host';
import {
  buildHighlightSegments,
  diagnoseVariableOutput,
  offsetToLineColumn,
  tolerantFormatJson,
  tryRepairVariableJson,
  variableChannelLabel,
  type VariableOutputChannel,
  type VariableOutputIndexEntry,
  type VariableOutputRecord,
} from '../../../../运行/variable-inspector';

export interface VariableInspectorTarget {
  floor?: number;
  swipe?: number;
  id?: string;
  channel?: VariableOutputChannel;
}

const props = defineProps<{
  initialTarget?: VariableInspectorTarget | null;
}>();

const emit = defineEmits<{
  (e: 'close'): void;
  (e: 'feedback', message: string): void;
}>();

const runtime = inject<Runtime | null>(RuntimeKey, null);

const activeTarget = ref<VariableInspectorTarget | undefined>(props.initialTarget ?? undefined);
const record = ref<VariableOutputRecord | null>(null);
const draft = ref('');
const initialText = ref('');
const editUnlocked = ref(false);
const showRawDrawer = ref(false);
const isSubmitting = ref(false);
const submitAction = ref<'save' | 'settle' | 'rerequest' | null>(null);
const inlineNotice = ref<{ level: 'info' | 'error'; text: string } | null>(null);

const textareaRef = ref<HTMLTextAreaElement | null>(null);
const backdropRef = ref<HTMLElement | null>(null);
const cursorPos = ref({ line: 1, column: 1 });

const availableRecords = computed<VariableOutputIndexEntry[]>(() => {
  // Touch reactive view fields so list updates when backend changes.
  void runtime?.view.variableOutput;
  void runtime?.view.variableOutputIndex;
  return runtime?.listVariableOutputs?.() ?? [];
});

const selectedId = computed(() => record.value?.id ?? '');
const isEditing = computed(() => !!record.value && (record.value.editable || editUnlocked.value));
const hasLocalChanges = computed(() => draft.value !== initialText.value);
const hasDistinctRaw = computed(
  () => !!record.value && !!record.value.rawText && record.value.rawText.trim() !== record.value.patchText.trim(),
);
const isLongSingleLine = computed(() => draft.value.length > 260 && !draft.value.includes('\n'));

const channelLabel = computed(() => (record.value ? variableChannelLabel(record.value.channel) : ''));
const stateLabel = computed(() => {
  if (!record.value) return '';
  return { failed: '校验失败', pending: '待结算', saved: '已保存' }[record.value.state];
});

const diagnosis = computed(() =>
  diagnoseVariableOutput(draft.value, {
    unwrapped: record.value?.unwrapped ?? true,
    replyFormat: record.value?.replyFormat,
    backendError: record.value?.error,
    unchangedFromBackend: draft.value === initialText.value,
  }),
);

const segments = computed(() => buildHighlightSegments(draft.value, diagnosis.value.highlight));

function formatRecordOption(item: VariableOutputIndexEntry): string {
  const floorPart = item.channel === 'phone' ? '手机' : item.floor !== undefined ? `#${item.floor} 楼` : '正文';
  const ch = variableChannelLabel(item.channel);
  const st = { failed: '失败', pending: '待结算', saved: '已保存' }[item.state];
  return `${floorPart} · ${ch}（${st}）`;
}

function loadRecord(target?: VariableInspectorTarget, preserveDraftIfSame = false) {
  const fetched = runtime?.getVariableOutput?.(target) ?? runtime?.view.variableOutput ?? null;
  const previousId = record.value?.id;
  const previousPatch = record.value?.patchText;
  record.value = fetched;
  if (!fetched) {
    draft.value = '';
    initialText.value = '';
    editUnlocked.value = false;
    return;
  }
  const sameContent = previousId === fetched.id && previousPatch === fetched.patchText;
  if (!preserveDraftIfSame || !sameContent) {
    draft.value = fetched.patchText;
    initialText.value = fetched.patchText;
    editUnlocked.value = fetched.editable;
    showRawDrawer.value = false;
    inlineNotice.value = null;
    cursorPos.value = { line: 1, column: 1 };
    void nextTick(() => {
      syncScroll();
      if (diagnosis.value.highlight) jumpToError(false);
    });
  }
}

function handleSelectRecord(id: string) {
  const hadDraft = hasLocalChanges.value && isEditing.value;
  activeTarget.value = { id };
  loadRecord(activeTarget.value, false);
  if (hadDraft) {
    inlineNotice.value = { level: 'info', text: '已切换到另一条记录，未保存的草稿已重置。' };
  }
}

function unlockResummarize() {
  editUnlocked.value = true;
  inlineNotice.value = {
    level: 'info',
    text: '已开启最新楼层编辑模式。修改后点击「保存并立即结算」将重算本楼变量（若校验失败仍可取消并恢复原楼层）。',
  };
  void nextTick(() => textareaRef.value?.focus());
}

function syncScroll() {
  const ta = textareaRef.value;
  const bp = backdropRef.value;
  if (!ta || !bp) return;
  bp.scrollTop = ta.scrollTop;
  bp.scrollLeft = ta.scrollLeft;
}

function updateCursor() {
  const ta = textareaRef.value;
  if (!ta) return;
  cursorPos.value = offsetToLineColumn(draft.value, ta.selectionStart ?? 0);
}

function jumpToError(focusEditor = true) {
  const h = diagnosis.value.highlight;
  const ta = textareaRef.value;
  const bp = backdropRef.value;
  if (!h || !ta || !bp) return;
  const mark = bp.querySelector('.cw-code-error-mark, .cw-code-error-eof') as HTMLElement | null;
  if (mark) {
    const targetTop = Math.max(0, mark.offsetTop - ta.clientHeight * 0.36);
    ta.scrollTop = targetTop;
    bp.scrollTop = targetTop;
  }
  if (focusEditor) {
    ta.focus({ preventScroll: true });
    ta.setSelectionRange(h.start, Math.max(h.start, h.end));
    updateCursor();
  }
}

function handleFormat() {
  const formatted = tolerantFormatJson(draft.value);
  draft.value = formatted.text;
  inlineNotice.value = formatted.exact
    ? { level: 'info', text: '已按标准 JSON 缩进格式化。' }
    : {
        level: 'info',
        text: '已对当前损坏 JSON 按结构断行缩进并重新定位红字（若因缺引号导致断行偏差，可点「还原原文」）。',
      };
  void nextTick(() => {
    syncScroll();
    if (diagnosis.value.highlight) jumpToError(false);
  });
}

function handleTryRepair() {
  const result = tryRepairVariableJson(draft.value);
  if (!result.ok) {
    inlineNotice.value = { level: 'error', text: `自动修复未能解析该文本：${result.error}` };
    return;
  }
  draft.value = result.text;
  inlineNotice.value = {
    level: 'info',
    text: '已填入自动修复结果（未提交）。请核对修改的字段与数值无误后，再点击「保存并立即结算」。',
  };
  void nextTick(() => syncScroll());
}

function handleReset() {
  draft.value = initialText.value;
  inlineNotice.value = null;
  void nextTick(() => {
    syncScroll();
    if (diagnosis.value.highlight) jumpToError(false);
  });
}

async function copyText(content: string, successText: string) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(content);
    } else {
      const helper = document.createElement('textarea');
      helper.value = content;
      helper.style.position = 'fixed';
      helper.style.opacity = '0';
      document.body.appendChild(helper);
      try {
        helper.select();
        document.execCommand('copy');
      } finally {
        helper.remove();
      }
    }
    inlineNotice.value = { level: 'info', text: successText };
  } catch {
    inlineNotice.value = { level: 'error', text: '复制到剪贴板失败，请手动全选复制。' };
  }
}

function handleCopy() {
  void copyText(draft.value, '已复制变量文本到剪贴板');
}

function currentSaveTarget(): VariableInspectorTarget | undefined {
  if (!record.value) return activeTarget.value;
  return {
    id: record.value.id,
    floor: record.value.floor,
    swipe: record.value.swipe,
    channel: record.value.channel,
  };
}

async function handleSave(retryNow: boolean) {
  if (!runtime || !record.value || isSubmitting.value) return;
  isSubmitting.value = true;
  submitAction.value = retryNow ? 'settle' : 'save';
  inlineNotice.value = null;
  const submittedText = draft.value;
  const target = currentSaveTarget();
  try {
    await runtime.saveEditedVariableOutput({
      text: submittedText,
      target,
      retryNow,
    });
    if (retryNow) {
      emit('feedback', '变量修正已校验并完成结算');
      emit('close');
      return;
    }
    const updated = runtime.getVariableOutput?.(target) ?? runtime.view.variableOutput ?? null;
    if (updated) {
      record.value = updated;
      activeTarget.value = { id: updated.id, floor: updated.floor, swipe: updated.swipe, channel: updated.channel };
      editUnlocked.value = updated.editable;
    }
    initialText.value = submittedText;
    inlineNotice.value = { level: 'info', text: '变量修改已保存，可点击「保存并立即结算」或返回主界面点击「立即重试」。' };
    emit('feedback', '变量修改已保存');
  } catch (error) {
    // Re-read the updated record (which now carries the latest backend validation error)
    // while keeping the user's submitted draft visible for immediate correction.
    const latest = runtime.getVariableOutput?.(target) ?? runtime.view.variableOutput ?? null;
    if (latest) {
      record.value = {
        ...latest,
        error: latest.error || String(error),
      };
    } else if (record.value) {
      record.value = { ...record.value, state: 'failed', error: String(error), editable: true };
    }
    initialText.value = submittedText;
    draft.value = submittedText;
    editUnlocked.value = true;
    inlineNotice.value = { level: 'error', text: `结算未通过，请按上方标红提示继续修正。` };
    void nextTick(() => {
      syncScroll();
      if (diagnosis.value.highlight) jumpToError(false);
    });
  } finally {
    isSubmitting.value = false;
    submitAction.value = null;
  }
}

async function handleReRequestApi() {
  if (!runtime || isSubmitting.value) return;
  isSubmitting.value = true;
  submitAction.value = 'rerequest';
  inlineNotice.value = null;
  try {
    await runtime.reRequestPendingVariables();
    emit('feedback', '已重新请求变量 API 并完成结算');
    emit('close');
  } catch (error) {
    loadRecord(undefined, false);
    inlineNotice.value = { level: 'error', text: `重新请求后仍未完成结算：${String(error)}` };
  } finally {
    isSubmitting.value = false;
    submitAction.value = null;
  }
}

watch(draft, () => {
  void nextTick(syncScroll);
});

watch(
  () => props.initialTarget,
  target => {
    activeTarget.value = target ?? undefined;
    loadRecord(activeTarget.value, false);
  },
);

watch(
  () => runtime?.view.variableOutput,
  () => {
    if (!isSubmitting.value && !hasLocalChanges.value) {
      loadRecord(activeTarget.value, true);
    }
  },
);

onMounted(() => {
  loadRecord(activeTarget.value, false);
});
</script>

<style scoped lang="scss">
.cw-var-inspector-backdrop {
  z-index: 1100;
}

.cw-var-inspector-modal {
  width: min(920px, calc(100% - 24px));
  height: min(760px, calc(100% - 24px));
  max-width: min(920px, calc(100% - 24px));
  max-height: calc(100% - 24px);
}

.cw-modal-header {
  padding: 13px 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  border-bottom: 1px solid var(--cw-border);
  background: var(--cw-bg-card-subtle);
}

.cw-header-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  min-width: 0;
}

.cw-header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 600;
  color: var(--cw-text-primary);
}

.cw-header-icon {
  color: var(--cw-accent);
}

.cw-header-badges {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}

.cw-header-right {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

.cw-record-select {
  max-width: 240px;
  padding: 4px 8px;
  font-size: 12px;
  border-radius: var(--cw-radius-sm);
  border: 1px solid var(--cw-border);
  background: var(--cw-bg-input);
  color: var(--cw-text-primary);
}

.cw-empty-body {
  padding: 20px;
}

.cw-inspector-body {
  padding: 14px 18px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  overflow: hidden;
  min-height: 0;
}

.cw-diag-banner {
  flex-shrink: 0;
  padding: 9px 12px;
  max-height: 130px;
  overflow-y: auto;
}

.cw-diag-title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  flex-wrap: wrap;
}

.cw-diag-detail {
  white-space: pre-wrap;
  word-break: break-word;
  margin-top: 4px !important;
  font-size: 12px !important;
  line-height: 1.5 !important;
}

.cw-jump-btn {
  flex-shrink: 0;
  padding: 3px 8px;
  font-size: 11px;
}

.cw-inline-notice {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: var(--cw-radius-sm);
  font-size: 12px;
  line-height: 1.45;
  background: var(--cw-info-bg);
  color: var(--cw-info);
  border: 1px solid rgba(61, 122, 184, 0.25);

  &.is-error {
    background: var(--cw-danger-bg);
    color: var(--cw-danger);
    border-color: rgba(201, 74, 74, 0.3);
  }
}

.cw-editor-toolbar {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  flex-wrap: wrap;
}

.cw-toolbar-left,
.cw-toolbar-right {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}

.cw-single-line-tip {
  font-size: 11px;
  padding: 2px 7px;
  border-radius: var(--cw-radius-full);
  background: var(--cw-warning-bg);
  color: var(--cw-warning);
}

.cw-cursor-meta {
  font-size: 11px;
  font-variant-numeric: tabular-nums;
  color: var(--cw-text-muted);
}

/* 双层同步高亮编辑器：保持 <pre> 与 <textarea> 的字体、字重、换行与滚动槽位完全一致 */
.cw-code-editor {
  position: relative;
  flex: 1 1 auto;
  min-height: 220px;
  border-radius: var(--cw-radius);
  border: 1px solid var(--cw-border);
  background: var(--cw-bg-input);
  overflow: hidden;
  transition: border-color 0.15s ease;

  &.has-error {
    border-color: rgba(239, 68, 68, 0.55);
  }

  &.is-readonly {
    background: var(--cw-bg-card-subtle);
  }

  &:focus-within {
    border-color: var(--cw-accent);
  }
}

.cw-code-layer {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 12px 14px;
  border: 0;
  box-sizing: border-box;
  font-family: ui-monospace, 'Cascadia Code', 'JetBrains Mono', Consolas, 'SFMono-Regular', 'PingFang SC', 'Microsoft YaHei', monospace;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.65;
  letter-spacing: 0;
  tab-size: 2;
  white-space: pre-wrap;
  word-break: break-all;
  overflow-wrap: anywhere;
  overflow-y: scroll;
  overflow-x: hidden;
}

.cw-code-backdrop {
  z-index: 1;
  pointer-events: none;
  color: var(--cw-text-primary);
  background: transparent;
  user-select: none;
}

/* 覆盖 common.scss 中 .cw-desktop-shell textarea 的全局文本与背景色 */
.cw-code-textarea {
  z-index: 2;
  resize: none;
  outline: none !important;
  color: transparent !important;
  -webkit-text-fill-color: transparent !important;
  background: transparent !important;
  background-color: transparent !important;
  caret-color: var(--cw-text-primary) !important;

  &::selection {
    background: rgba(56, 148, 242, 0.28);
    color: transparent;
    -webkit-text-fill-color: transparent;
  }

  &::placeholder {
    color: var(--cw-text-muted);
    -webkit-text-fill-color: var(--cw-text-muted);
  }
}

/* 重要：不修改 font-weight / padding / border，避免影响字符宽度导致光标错位 */
.cw-code-error-mark {
  margin: 0;
  padding: 0;
  color: #e11d48;
  background: rgba(239, 68, 68, 0.2);
  border-radius: 2px;
  box-shadow: inset 0 -2px 0 #ef4444;
  font-weight: inherit;
}

.cw-code-error-eof {
  margin: 0;
  padding: 0;
  color: #ffffff;
  background: #ef4444;
  border-radius: 2px;
  font-weight: inherit;
}

[data-theme='dark'] .cw-code-error-mark {
  color: #ff6b6b;
  background: rgba(248, 81, 73, 0.28);
  box-shadow: inset 0 -2px 0 #ff6b6b;
}

.cw-raw-drawer {
  flex-shrink: 0;
  max-height: 140px;
  display: flex;
  flex-direction: column;
  border: 1px solid var(--cw-border);
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  overflow: hidden;
}

.cw-raw-drawer-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px 10px;
  font-size: 11px;
  color: var(--cw-text-muted);
  border-bottom: 1px solid var(--cw-border);
}

.cw-raw-pre {
  margin: 0;
  padding: 8px 10px;
  overflow: auto;
  font-family: ui-monospace, 'Cascadia Code', Consolas, monospace;
  font-size: 11.5px;
  line-height: 1.5;
  color: var(--cw-text-secondary);
  white-space: pre-wrap;
  word-break: break-all;
}

.cw-modal-footer {
  padding: 12px 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  flex-wrap: wrap;
  border-top: 1px solid var(--cw-border);
  background: var(--cw-bg-card-subtle);
}

.cw-footer-left,
.cw-footer-right {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.cw-spin {
  animation: cwVarSpin 1.2s linear infinite;
}

@keyframes cwVarSpin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

@media (max-width: 640px) {
  .cw-var-inspector-modal {
    width: calc(100% - 14px);
    height: calc(100% - 16px);
    max-width: calc(100% - 14px);
    max-height: calc(100% - 16px);
  }
  .cw-modal-header {
    padding: 10px 12px;
  }
  .cw-inspector-body {
    padding: 10px 12px;
  }
  .cw-modal-footer {
    padding: 10px 12px;
  }
  .cw-record-select {
    max-width: 170px;
  }
}
</style>
