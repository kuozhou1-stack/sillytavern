import type { State } from './core';

/** 已切换至外置设定 15 区域 / 42 地点 / 144 建筑体系，不再内置旧英文地点改名表。 */
export function normalizeGeographicNames(state: State): State {
  return state;
}
