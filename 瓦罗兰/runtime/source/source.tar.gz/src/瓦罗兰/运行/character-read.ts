import type { State } from './core';
import { storyMinute, timeText } from './phone';
import { normalizeIdentityInput } from './character-identity';
import { organizationCatalog, organizationIdsForPerson, organizationVisibilityTag } from './organizations';

// 旧角色包的字符串身份可能同时包含公开职业和里世界头衔。
const legacySecret = /星之守护者|星守|黑色玫瑰|黑玫瑰|暗星|恶魔本体|本源武装/;
const dailyForm = /日常|常服|通勤|便装/;

export function playerOccupation(value: unknown) {
  const identity = normalizeIdentityInput(value);
  return identity.公开.filter(tag => !legacySecret.test(tag) && !identity.隐秘.includes(tag));
}

/** 常规档案按玩家视角取值；原档案仍供私密页、管理和剧情使用。 */
export function projectCharacterForPlayer(state: State, id: string, raw: Record<string, any>, staticDefaultForm?: string | null) {
  const identity = normalizeIdentityInput(raw.身份);
  const revealsIdentity = (value: unknown) => typeof value === 'string' &&
    (legacySecret.test(value) || identity.隐秘.some(secret => value.includes(secret)));
  const publicText = (value: unknown) => typeof value === 'string' && !revealsIdentity(value) ? value : null;

  const known = state.玩家.已知信息.已认识人物[id];
  const playerId = state.玩家.id;
  const relation = playerId ? raw.关系网?.[playerId] : undefined;
  const directRelation = relation ? {
    ...relation,
    关系: publicText(relation.关系),
    关系备注: publicText(relation.关系备注),
    当前定位: publicText(relation.当前定位),
    防御姿态: publicText(relation.防御姿态),
  } : undefined;

  const catalog = organizationCatalog(state, raw.组织id ?? []);
  const organizations = organizationIdsForPerson(state, id, raw.组织id ?? [], catalog)
    .filter(orgId => catalog[orgId] && organizationVisibilityTag(catalog[orgId]) === '公开');

  const wardrobe = raw.形态衣橱 ?? {};
  const publicWardrobe = Object.fromEntries(Object.entries(wardrobe).filter(([name, form]: [string, any]) =>
    (name === staticDefaultForm || dailyForm.test(name)) && !revealsIdentity(name) && !revealsIdentity(form?.对应身份),
  ));
  const hasWardrobe = Object.keys(wardrobe).length > 0;
  const visibleForm = (name: unknown) => typeof name === 'string' && !revealsIdentity(name) &&
    (hasWardrobe ? Object.hasOwn(publicWardrobe, name) : name === staticDefaultForm || dailyForm.test(name));
  const defaultForm = visibleForm(staticDefaultForm) ? staticDefaultForm : Object.keys(publicWardrobe)[0] ?? null;

  const knowsEvent = (eventId: string) => !!playerId && Object.hasOwn(state.事件[eventId]?.各人可知来源 ?? {}, playerId);
  const records = Object.fromEntries(Object.entries(raw.重要记录 ?? {}).filter(([, record]: [string, any]) =>
    (record?.事件id && knowsEvent(record.事件id)) ||
    (record?.约定id && playerId && Object.hasOwn(state.约定[record.约定id]?.参与者 ?? {}, playerId)),
  ));
  const recent = Object.fromEntries(Object.entries(raw.经历?.最近经历 ?? {}).filter(([, record]: [string, any]) =>
    record?.来源事件id?.length && record.来源事件id.every(knowsEvent),
  ));
  const appearance = raw.外貌;
  const personality = raw.性格;
  const markers = raw.专属标识;
  return {
    id,
    姓名: raw.姓名,
    性别: raw.性别,
    年龄: raw.年龄,
    心理年龄: raw.心理年龄,
    种族: publicText(raw.种族),
    身份: { ...identity, 公开: playerOccupation(raw.身份), 隐秘: [], 保密底线: null },
    组织id: organizations,
    简介: publicText(raw.简介),
    玩家已知资料: known?.已知资料?.trim() || null,
    当前形态: visibleForm(raw.当前形态) ? raw.当前形态 : null,
    默认形态: defaultForm,
    形态衣橱: publicWardrobe,
    超凡能力: raw.超凡能力 ? {
      力量体系: publicText(raw.超凡能力.力量体系),
      核心能力与媒介: publicText(raw.超凡能力.核心能力与媒介),
    } : null,
    外貌: appearance ? {
      身高: appearance.身高,
      体重: appearance.体重,
      整体体型: publicText(appearance.整体体型),
      主色调与高光焦点: publicText(appearance.主色调与高光焦点),
      详细外表: publicText(appearance.详细外表),
    } : null,
    性格: typeof personality === 'string' ? publicText(personality) : {
      表性格: publicText(personality?.表性格),
      爱好: publicText(personality?.爱好),
      厌恶: publicText(personality?.厌恶),
      小习惯: publicText(personality?.小习惯),
    },
    专属标识: markers ? { 感官特征: publicText(markers.感官特征) } : null,
    关系网: playerId && directRelation ? { [playerId]: directRelation } : {},
    上次已知地点id: known?.上次已知地点id ?? null,
    位置获知时间: known?.位置获知时间 ?? null,
    已明确不在场: known?.已明确不在场 ?? false,
    重要记录: records,
    经历: { 最近经历: recent },
  };
}

/** 阅读投影，不再让模型重复维护社交交集列表。未获知的后台事件不进入玩家界面。 */
export function recentSocialEncounters(state: State, characterId: string) {
  if (!characterId) return [];
  return Object.values(state.事件)
    .filter(
      event =>
        Object.hasOwn(event.参与者, characterId) &&
        !!state.玩家.id &&
        Object.hasOwn(event.各人可知来源, state.玩家.id) &&
        Object.keys(event.参与者).some(id => id !== characterId),
    )
    .sort((a, b) => storyMinute(b.结束时间 ?? b.起始时间) - storyMinute(a.结束时间 ?? a.起始时间))
    .slice(0, 3)
    .map(event => ({
      与: Object.keys(event.参与者).find(id => id !== characterId)!,
      时间: timeText(event.结束时间 ?? event.起始时间),
      交集事项: event.事实 ?? '',
    }));
}
