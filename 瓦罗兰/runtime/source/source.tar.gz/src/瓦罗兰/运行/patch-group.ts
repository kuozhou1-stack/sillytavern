type Patch = { op?: string; path?: string; to?: string };

export function patchGroup(item: Patch | null, index: number) {
  const path = item?.path ?? item?.to;
  if (typeof path !== 'string' || !path.startsWith('/')) return '补丁 ' + (index + 1);
  const [root, field, id, record] = path.slice(1).split('/');
  if (root === '玩家' && (field === '资金' || field === '物品栏')) return '玩家/资金与物品栏';
  if (root === '手机') return [root, field, id, field === '原文' ? record : undefined].filter(Boolean).join('/');
  if (root === '奇遇系统') return [root, field, field === '任务' ? id : undefined].filter(Boolean).join('/');
  const parts = [root, field];
  if (root === '玩家' && id && ['技能栏', '当前状态'].includes(field)) parts.push(id);
  return parts.filter(Boolean).join('/');
}

// A replacement of an entire object shares a fate with writes to its descendants.
export function relatedPatchGroups(left: string, right: string) {
  return left === right || left.startsWith(right + '/') || right.startsWith(left + '/');
}
