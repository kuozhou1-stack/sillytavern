<template>
  <div class="cw-tab-pane cw-char-tab-private">
    <!-- 判断是否适用 -->
    <div v-if="isApplicable" class="cw-private-content">
      <!-- 身体生理档案 -->
      <div class="cw-private-card">
        <h4 class="cw-section-title">
          <SvgIcon name="lock" :size="16" />
          <span>身体私密特征</span>
        </h4>
        <div class="cw-private-grid">
          <div class="cw-priv-cell cw-cell-full">
            <span class="cw-priv-k">胸部体征信息</span>
            <span class="cw-priv-v">{{ sexFeature?.奶子信息 || '未知 / 未记录' }}</span>
          </div>
          <div class="cw-priv-cell cw-cell-full">
            <span class="cw-priv-k">下体密处信息</span>
            <span class="cw-priv-v">{{ sexFeature?.蜜穴信息 || '未知 / 未记录' }}</span>
          </div>
          <div v-if="sexFeature?.敏感与特殊体质 || sexFeature?.其他" class="cw-priv-cell cw-cell-full">
            <span class="cw-priv-k">敏感与特殊体质</span>
            <span class="cw-priv-v">{{ sexFeature.敏感与特殊体质 || sexFeature.其他 }}</span>
          </div>
        </div>
      </div>

      <!-- 亲密反应模式（三正交轴：防止偏离原有人设） -->
      <div v-if="hasIntimacyReaction" class="cw-private-card cw-reaction-card">
        <h4 class="cw-section-title">
          <SvgIcon name="smile" :size="16" />
          <span>亲密反应模式（性格一致三轴）</span>
        </h4>
        <div class="cw-reaction-axes">
          <div v-if="sexFeature?.亲密反应模式?.主导权与姿态" class="cw-axis-card">
            <span class="cw-axis-tag">主导权与姿态</span>
            <p class="cw-priv-v">{{ sexFeature.亲密反应模式.主导权与姿态 }}</p>
          </div>
          <div v-if="sexFeature?.亲密反应模式?.快感外露方式" class="cw-axis-card">
            <span class="cw-axis-tag">快感外露方式</span>
            <p class="cw-priv-v">{{ sexFeature.亲密反应模式.快感外露方式 }}</p>
          </div>
          <div v-if="sexFeature?.亲密反应模式?.语言与事后余韵" class="cw-axis-card">
            <span class="cw-axis-tag">语言与事后余韵</span>
            <p class="cw-priv-v">{{ sexFeature.亲密反应模式.语言与事后余韵 }}</p>
          </div>
        </div>
      </div>

      <!-- 性经历记录 -->
      <div class="cw-private-card">
        <h4 class="cw-section-title">
          <SvgIcon name="heart" :size="16" />
          <span>既往亲密经历档案</span>
        </h4>
        <div class="cw-private-grid">
          <div class="cw-priv-cell">
            <span class="cw-priv-k">经验确数</span>
            <span class="cw-priv-v">
              {{
                sexExp?.性次数?.确数 !== null && sexExp?.性次数?.确数 !== undefined
                  ? `${sexExp.性次数.确数} 次`
                  : '未知 / 未确认'
              }}
            </span>
          </div>
          <div class="cw-priv-cell">
            <span class="cw-priv-k">概数说明</span>
            <span class="cw-priv-v">
              {{ sexExp?.性次数?.概数说明 || '未知 / 未确认' }}
            </span>
          </div>
          <div class="cw-priv-cell cw-cell-full">
            <span class="cw-priv-k">亲密交往人群</span>
            <span class="cw-priv-v">
              {{ sexExp?.性人群 || '未知 / 未确认' }}
            </span>
          </div>
          <div v-if="sexExp?.性次数?.已知新增说明" class="cw-priv-cell cw-cell-full">
            <span class="cw-priv-k">近期新增说明</span>
            <span class="cw-priv-v">{{ sexExp.性次数.已知新增说明 }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 不适用提示 -->
    <div v-else class="cw-not-applicable-box">
      <SvgIcon name="info" :size="32" class="cw-na-icon" />
      <span class="cw-na-title">本组资料不适用</span>
      <p class="cw-na-desc">该角色为男性、次要人物或当前未达到适用知情条件，依照设定规则省略整组私密字段。</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import SvgIcon from '../../icons/SvgIcon.vue';

const props = defineProps<{
  char: any;
}>();

const sexFeature = computed(() => props.char?.性特征 ?? props.char?.静态性特征 ?? null);
const sexExp = computed(() => props.char?.性特征?.性经验 ?? props.char?.性经验 ?? null);

const isApplicable = computed(() => {
  const gender = props.char?.性别;
  if (gender === '男' || gender === '男性' || props.char?.性特征适用 === false) return false;
  return Boolean(sexFeature.value || sexExp.value);
});

const hasIntimacyReaction = computed(() => {
  const m = sexFeature.value?.亲密反应模式;
  return Boolean(m && (m.主导权与姿态 || m.快感外露方式 || m.语言与事后余韵));
});
</script>

<style scoped lang="scss">
.cw-char-tab-private {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-private-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-private-card {
  padding: 16px 20px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-private-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;

  .cw-priv-cell {
    padding: 10px 14px;
    border-radius: var(--cw-radius-sm);
    background: var(--cw-bg-card-subtle);
    border: 1px solid var(--cw-border);
    display: flex;
    flex-direction: column;
    gap: 4px;

    .cw-priv-k {
      font-size: 11px;
      font-weight: 600;
      color: var(--cw-text-secondary);
    }
    .cw-priv-v {
      margin: 0;
      font-size: 13.5px;
      font-weight: 500;
      color: var(--cw-text-primary);
      line-height: 1.72;
      white-space: pre-wrap;
      word-break: break-word;
    }

    &.cw-cell-full {
      grid-column: span 2;
    }
  }
}

.cw-reaction-card {
  border-left: 3px solid var(--cw-accent);
}

.cw-reaction-axes {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-axis-card {
  padding: 11px 14px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 6px;

  .cw-axis-tag {
    align-self: flex-start;
    font-size: 11.5px;
    font-weight: 600;
    color: var(--cw-tag-accent-text, var(--cw-accent));
    background: var(--cw-tag-accent-bg, var(--cw-accent-bg));
    border: 1px solid var(--cw-tag-accent-border, var(--cw-accent-border));
    padding: 2px 9px;
    border-radius: 5px;
  }

  .cw-priv-v {
    margin: 0;
    font-size: 13.5px;
    line-height: 1.72;
    color: var(--cw-text-primary);
    white-space: pre-wrap;
    word-break: break-word;
  }
}

.cw-not-applicable-box {
  padding: 48px 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card-subtle);
  border: 1px dashed var(--cw-border);
  gap: 10px;

  .cw-na-icon {
    color: var(--cw-text-muted);
  }
  .cw-na-title {
    font-size: 15px;
    font-weight: 600;
    color: var(--cw-text-primary);
  }
  .cw-na-desc {
    margin: 0;
    font-size: 13px;
    color: var(--cw-text-secondary);
    max-width: 440px;
    line-height: 1.6;
  }
}
</style>
