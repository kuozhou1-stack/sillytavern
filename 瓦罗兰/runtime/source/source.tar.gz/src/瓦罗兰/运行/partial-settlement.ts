import { patchGroup, relatedPatchGroups } from './patch-group';
import { InformationNotLoadedError } from './knowledge-context';

type Patch = { op?: string; path?: string; from?: string; to?: string; value?: unknown };

export function assertPatchOperations(commands: readonly unknown[]) {
  for (const [index, item] of commands.entries()) {
    const patch = item as Patch | null;
    const path = patch?.op === 'move' ? patch.to ?? patch.path : patch?.path;
    if (!patch || typeof path !== 'string' || (path !== '' && !path.startsWith('/')) ||
        !['add', 'insert', 'replace', 'remove', 'delta', 'move'].includes(patch.op ?? '') ||
        (patch.op === 'move' && (typeof patch.from !== 'string' || !patch.from.startsWith('/'))) ||
        (['replace', 'insert', 'add', 'delta'].includes(patch.op!) && !Object.hasOwn(patch, 'value')) ||
        (patch.op === 'delta' && typeof patch.value !== 'number'))
      throw Error('第 ' + (index + 1) + ' 条补丁的操作、路径或值无效：' + (path ?? '未知路径'));
  }
}

/** Re-evaluate retained groups from the original state, in the model's original order. */
export async function settlePatchGroups<T>(
  commands: readonly unknown[],
  apply: (commands: readonly unknown[]) => Promise<T>,
  hasChange: (candidate: T) => boolean,
  retryMissingInformation = false,
  classify: typeof patchGroup = patchGroup,
): Promise<{ value: T; warnings: string[] }> {
  try {
    return { value: await apply(commands), warnings: [] };
  } catch (error) {
    // A failing precondition or cross-path operation might guard the whole reply.
    if (commands.some(item => {
      const patch = item as Patch | null;
      return patch?.path === '' || ['test', 'move', 'copy'].includes(patch?.op ?? '');
    })) throw error;
    if (retryMissingInformation && error instanceof InformationNotLoadedError) throw error;
    const paths = commands.map((item, index) => classify(item as Patch | null, index));
    const ancestors = [...new Set(paths)].sort((a, b) => a.length - b.length);
    const labels = paths.map(path => ancestors.find(parent => relatedPatchGroups(path, parent))!);
    const groups = [...new Set(labels)];
    if (groups.length < 2) throw error;
    const describe = (group: string, reason: unknown) => group + '未写入：' + String(reason);
    const failures = new Map<string, unknown>([[JSON.stringify(groups), error]]);
    const applyGroups = async (keep: Set<string>) => {
      const key = JSON.stringify(groups.filter(group => keep.has(group)));
      if (failures.has(key)) throw failures.get(key);
      try {
        return await apply(commands.filter((_, index) => keep.has(labels[index])));
      } catch (reason) {
        failures.set(key, reason);
        throw reason;
      }
    };

    // A single failure is common. Preserve dependencies between every other group first.
    const hint = String(error);
    const likely = groups.filter(group => group.split('/').every(part => hint.includes(part)));
    for (const group of [...likely, ...groups.filter(group => !likely.includes(group))].slice(0, 8)) {
      try {
        const keep = new Set(groups.filter(other => other !== group));
        const value = await applyGroups(keep);
        if (hasChange(value)) return { value, warnings: [describe(group, error)] };
      } catch {
        // Multiple failures or a dependent group require narrower validation.
      }
    }

    const keep = new Set<string>();
    const rejected = new Map<string, unknown>();
    let value: { candidate: T } | undefined;
    // The second pass lets an earlier group refer to a valid group appearing later.
    for (let pass = 0; pass < 2; pass++) {
      for (const group of groups) {
        if (keep.has(group)) continue;
        keep.add(group);
        try {
          value = { candidate: await applyGroups(keep) };
          rejected.delete(group);
        } catch (reason) {
          keep.delete(group);
          rejected.set(group, reason);
        }
      }
    }
    if (!value || !hasChange(value.candidate)) throw error;
    return { value: value.candidate, warnings: [...rejected].map(([group, reason]) => describe(group, reason)) };
  }
}
