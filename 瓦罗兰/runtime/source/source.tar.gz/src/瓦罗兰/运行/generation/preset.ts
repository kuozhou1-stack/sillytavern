import { assemblePreset } from './preset-native.js';
import {
  callSubstituteParams,
  DEFAULT_CHAT_COMPLETION_SOURCES,
  DEFAULT_TOOL_REASONING_MODES,
  type SubstituteParamsOptions,
} from './compat';

/** Native parent-realm modules. Their APIs are provided by the installed Tavern version. */
export type PresetNative = Record<string, any>;
export type PresetChatMessage = { role: string; content?: unknown; [key: string]: unknown };
export type PresetExtensionPrompt = {
  value: string;
  position: number;
  depth?: number;
  role?: number;
  filter?: () => boolean | Promise<boolean>;
  [key: string]: unknown;
};
export type PresetRequestData = {
  messages: PresetChatMessage[];
  messageExamples: unknown[][];
  extensionPrompts: Record<string, PresetExtensionPrompt>;
  scenario: string;
  charDescription?: string;
  charPersonality?: string;
  name1?: string;
  name2?: string;
  type?: string;
  settings?: Record<string, any>;
  presetPreferences?: { persona_description_position: number; pin_examples: boolean };
  dynamicMacros?: Record<string, unknown>;
  [key: string]: any;
};

export async function preparePreset(
  native: PresetNative,
  requestData: PresetRequestData,
): Promise<PresetChatMessage[]> {
  const { script, openai, promptManager: promptModule, powerUser, extensions, groupChats } = native;
  const settings = structuredClone(requestData.settings ?? openai.promptManager.serviceSettings);
  const preferences = requestData.presetPreferences ?? powerUser.power_user;
  const power = {
    persona_description: requestData.personaDescription ?? powerUser.power_user.persona_description,
    persona_description_position: preferences.persona_description_position,
    pin_examples: preferences.pin_examples,
  };
  const name1 = requestData.name1 ?? script.name1;
  const name2 = requestData.name2 ?? script.name2;
  const mediaSupport = {
    image: typeof openai.isImageInliningSupported === 'function' ? openai.isImageInliningSupported() : false,
    video: typeof openai.isVideoInliningSupported === 'function' ? openai.isVideoInliningSupported() : false,
    audio: typeof openai.isAudioInliningSupported === 'function' ? openai.isAudioInliningSupported() : false,
  };
  const tools = extensions?.getContext?.()?.ToolManager;
  const toolReasoningModes = {
    ...DEFAULT_TOOL_REASONING_MODES,
    ...(openai.tool_reasoning_modes && typeof openai.tool_reasoning_modes === 'object' ? openai.tool_reasoning_modes : {}),
  };
  const chatCompletionSources = {
    ...DEFAULT_CHAT_COMPLETION_SOURCES,
    ...(openai.chat_completion_sources && typeof openai.chat_completion_sources === 'object'
      ? openai.chat_completion_sources
      : {}),
  };
  const request = {
    ...requestData,
    messages: structuredClone(requestData.messages),
    messageExamples: structuredClone(requestData.messageExamples),
  };
  const dynamicMacros = {
    ...requestData.dynamicMacros,
    scenario: request.scenario,
    description: request.charDescription ?? '',
    personality: request.charPersonality ?? '',
    persona: power.persona_description ?? '',
  };
  const substitute = (text: string, options: SubstituteParamsOptions = {}) =>
    callSubstituteParams(script, requestData.expandPrompt && typeof text === 'string' ? requestData.expandPrompt(text) : text, {
      ...options,
      name1Override: name1,
      name2Override: name2,
      dynamicMacros: { ...dynamicMacros, ...(options.dynamicMacros as object) },
    });

  // The prototype supplies ordering/name helpers, while mutable settings and macro expansion belong to this request.
  const promptMgr = openai.promptManager;
  const manager = Object.assign(Object.create(Object.getPrototypeOf(promptMgr)), promptMgr, {
    serviceSettings: settings,
    activeCharacter: promptMgr.activeCharacter !== undefined ? structuredClone(promptMgr.activeCharacter) : null,
    configuration: promptMgr.configuration !== undefined ? structuredClone(promptMgr.configuration) : {},
    overriddenPrompts: [],
    ...(typeof promptMgr.isValidName === 'function'
      ? {}
      : { isValidName: (name: string) => typeof name === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(name) }),
    ...(typeof promptMgr.sanitizeName === 'function'
      ? {}
      : { sanitizeName: (name: string) => String(name ?? '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64) }),
    ...(typeof promptMgr.isPromptDisabledForActiveCharacter === 'function'
      ? {}
      : { isPromptDisabledForActiveCharacter: () => false }),
    ...(typeof promptMgr.log === 'function' ? {} : { log: () => {} }),
    preparePrompt(this: any, prompt: any, original: string | null = null) {
      const result = new promptModule.Prompt(prompt);
      const members = typeof this.getActiveGroupCharacters === 'function' ? this.getActiveGroupCharacters() : [];
      result.content = substitute(prompt.content, {
        ...(typeof original === 'string' ? { original } : {}),
        ...(members.length ? { groupOverride: members.join(', ') } : {}),
      });
      return result;
    },
  });
  const tokenHandler = new openai.TokenHandler(native.tokenizers.countTokensOpenAIAsync);
  manager.tokenHandler = tokenHandler;

  const getExtensionPromptMaxDepth = () => {
    let max = 0;
    for (const item of Object.values(request.extensionPrompts ?? {})) {
      const depth = Number((item as PresetExtensionPrompt | undefined)?.depth);
      if (Number.isFinite(depth) && depth > max) max = Math.floor(depth);
    }
    for (const item of Array.isArray(settings.prompts) ? settings.prompts : []) {
      const depth = Number(item?.injection_depth);
      if (Number.isFinite(depth) && depth > max) max = Math.floor(depth);
    }
    return Math.min(max, 1000);
  };

  async function getExtensionPrompt(position: number, depth?: number, separator = '\n', role?: number, wrap = true) {
    const values: string[] = [];
    for (const key of Object.keys(request.extensionPrompts).sort()) {
      const prompt = request.extensionPrompts[key];
      if (prompt.position !== position || !prompt.value) continue;
      if (depth !== undefined && (prompt.depth ?? 0) !== depth) continue;
      if (role !== undefined && (prompt.role ?? 0) !== role) continue;
      if (typeof prompt.filter === 'function' && !(await prompt.filter())) continue;
      values.push(prompt.value.trim());
    }
    let result = values.join(separator);
    if (wrap && result && !result.startsWith(separator)) result = separator + result;
    if (wrap && result && !result.endsWith(separator)) result += separator;
    return result ? substitute(result) : result;
  }

  const chat = await assemblePreset(
    {
      ...openai,
      ...promptModule,
      extension_prompt_types: script.extension_prompt_types,
      extension_prompt_roles: script.extension_prompt_roles,
      selected_group: groupChats.selected_group,
      oai_settings: settings,
      power_user: power,
      persona_description_positions: powerUser.persona_description_positions,
      promptManager: manager,
      tokenHandler,
      ToolManager: {
        isToolCallingSupported: () =>
          typeof tools?.isToolCallingSupported === 'function' ? tools.isToolCallingSupported(settings) : false,
        canPerformToolCalls: (type: string) =>
          typeof tools?.canPerformToolCalls === 'function' ? tools.canPerformToolCalls(type, settings) : false,
        registerFunctionToolsOpenAI: (data: object) =>
          typeof tools?.registerFunctionToolsOpenAI === 'function' ? tools.registerFunctionToolsOpenAI(data) : undefined,
      },
      isImageInliningSupported: () => mediaSupport.image,
      isVideoInliningSupported: () => mediaSupport.video,
      isAudioInliningSupported: () => mediaSupport.audio,
      substituteParams: substitute,
      substituteParamsExtended: (
        text: string,
        additionalMacro: Record<string, unknown> = {},
        postProcessFn?: (text: string) => string,
      ) => substitute(text, { dynamicMacros: additionalMacro, postProcessFn }),
      getExtensionPrompt,
      getExtensionPromptMaxDepth,
      formatWorldInfo: (text: string) =>
        typeof openai.formatWorldInfo === 'function'
          ? openai.formatWorldInfo(text, { wiFormat: settings.wi_format })
          : text
            ? settings.wi_format
              ? String(settings.wi_format).replace('{0}', () => text)
              : text
            : '',
      isReasoningSignatureSupported: () =>
        typeof openai.isReasoningSignatureSupported === 'function'
          ? openai.isReasoningSignatureSupported(settings)
          : false,
      tool_reasoning_modes: toolReasoningModes,
      chat_completion_sources: chatCompletionSources,
      INJECTION_POSITION: promptModule.INJECTION_POSITION ?? { RELATIVE: 0, ABSOLUTE: 1 },
      getEffectiveToolReasoningMode: () =>
        settings.show_thoughts
          ? Object.values(toolReasoningModes).includes(settings.tool_reasoning_mode)
            ? settings.tool_reasoning_mode
            : toolReasoningModes.DISABLED
          : toolReasoningModes.DISABLED,
      interleaved_reasoning_providers: openai.interleaved_reasoning_providers ?? [
        chatCompletionSources.OPENROUTER,
        chatCompletionSources.CUSTOM,
      ],
      character_names_behavior: openai.character_names_behavior ?? { NONE: -1, DEFAULT: 0, COMPLETION: 1, CONTENT: 2 },
      MEDIA_TYPE: openai.MEDIA_TYPE ?? { IMAGE: 'image', VIDEO: 'video', AUDIO: 'audio' },
      MEDIA_DISPLAY: openai.MEDIA_DISPLAY ?? { LIST: 'list', GALLERY: 'gallery' },
    },
    request,
  );
  if (script.event_types?.CHAT_COMPLETION_PROMPT_READY && typeof script.eventSource?.emit === 'function') {
    const eventData = { chat, dryRun: false };
    await script.eventSource.emit(script.event_types.CHAT_COMPLETION_PROMPT_READY, eventData);
    return eventData.chat;
  }
  return chat;
}
