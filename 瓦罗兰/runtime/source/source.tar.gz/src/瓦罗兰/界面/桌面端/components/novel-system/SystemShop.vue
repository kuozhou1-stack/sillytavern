<template>
  <div class="cw-system-shop-panel">
    <!-- 顶部公告与物品栏快捷入口 -->
    <div class="cw-shop-banner">
      <div class="cw-banner-left">
        <div class="cw-banner-badge">
          <SvgIcon name="sparkles" :size="15" />
          <span>瓦罗兰奇遇商店 · 四阶装备体系</span>
        </div>
        <div class="cw-banner-text">
          <p class="cw-banner-title">商品全部按世界观动态刷新，兑换后直接发放至「随身物品栏」</p>
          <p class="cw-banner-desc">
            按英雄联盟装备品质分为基础、史诗、传说、神话四阶；兑换不推进剧情，在正文中自主决定使用时机并按品质、代价与描述结算。
          </p>
        </div>
      </div>
      <div class="cw-banner-right">
        <slot name="refresh" />
        <button
          type="button"
          class="cw-btn cw-btn-secondary cw-inventory-btn"
          title="打开个人档案的物品栏界面，查看与使用已获得的道具"
          @click="emit('openInventory')"
        >
          <SvgIcon name="backpack" :size="16" />
          <span>查看随身物品栏</span>
        </button>
      </div>
    </div>

    <!-- 品质筛选导航 Tab -->
    <div class="cw-shop-tabs-row">
      <div class="cw-shop-tabs-left">
        <button
          type="button"
          class="cw-filter-tab"
          :class="{ active: currentQuality === 'all' }"
          @click="currentQuality = 'all'"
        >
          <span>全部商品 ({{ allGoods.length }})</span>
        </button>
        <button
          v-for="quality in GOOD_QUALITIES"
          :key="quality"
          type="button"
          class="cw-filter-tab"
          :class="[`cw-tab-tier-${tierSlug(quality)}`, { active: currentQuality === quality }]"
          @click="currentQuality = quality"
        >
          <span class="cw-tier-dot" :class="`cw-dot-${tierSlug(quality)}`"></span>
          <span>{{ quality }} ({{ goodsByQuality(quality).length }})</span>
          <span v-if="!isTierUnlocked(quality)" class="cw-tab-lock-badge">
            <SvgIcon name="lock" :size="11" />
            <span>{{ completedCount }}/{{ goodUnlockCount(quality) }}</span>
          </span>
        </button>
      </div>

      <div class="cw-shop-status-hint">
        <span>已领任务：</span>
        <strong class="cw-text-accent">{{ completedCount }}</strong>
        <span class="cw-hint-tail">（史诗2 · 传说5 · 神话9）</span>
      </div>
    </div>

    <!-- 商品滚动展示区 -->
    <div class="cw-goods-scroll-area">
      <!-- 全局空态（尚未刷新商店） -->
      <div v-if="allGoods.length === 0" class="cw-shop-empty">
        <SvgIcon name="sparkles" :size="40" class="cw-empty-icon" />
        <h4 class="cw-empty-title">商店货架尚未刷新</h4>
        <p class="cw-empty-desc">
          系统商店不再保留固定杂货，全部商品按当前片区、季节与英雄联盟四阶品质（基础 / 史诗 / 传说 / 神话）动态生成。点击右上角「刷新商店」即可进货。
        </p>
      </div>

      <!-- 选定单品质为空 -->
      <div v-else-if="visibleSections.every(sec => sec.goods.length === 0)" class="cw-shop-empty">
        <SvgIcon name="backpack" :size="36" class="cw-empty-icon" />
        <h4 class="cw-empty-title">当前「{{ currentQuality }}」品阶暂无上架商品</h4>
        <p class="cw-empty-desc">可切换查看其他品质，或点击右上角「刷新商店」补充本品阶新品。</p>
      </div>

      <!-- 分品质货架区 -->
      <template v-else>
        <section
          v-for="section in visibleSections"
          :key="section.quality"
          v-show="section.goods.length > 0 || currentQuality === section.quality"
          class="cw-goods-section"
          :class="`cw-section-tier-${tierSlug(section.quality)}`"
        >
          <div class="cw-section-title-line">
            <div class="cw-section-title" :class="`cw-title-tier-${tierSlug(section.quality)}`">
              <span class="cw-tier-pill" :class="`cw-pill-${tierSlug(section.quality)}`">{{ section.quality }}</span>
              <span>{{ section.quality }}品阶</span>
              <span v-if="section.unlockCount > 0" class="cw-unlock-tag" :class="{ unlocked: section.unlocked }">
                {{ section.unlocked ? '已解锁' : `完成 ${section.unlockCount} 项任务解锁` }}
              </span>
            </div>
            <span class="cw-section-sub">{{ section.subtitle }}</span>
          </div>

          <div v-if="!section.unlocked" class="cw-tier-locked-alert" :class="`cw-alert-tier-${tierSlug(section.quality)}`">
            <SvgIcon name="lock" :size="15" />
            <span>
              {{ section.quality }}品阶暂未解锁：需完成并领取 {{ section.unlockCount }} 项奇遇任务以激活兑换权限（当前
              {{ completedCount }} / {{ section.unlockCount }} 项）
            </span>
          </div>

          <div class="cw-goods-grid">
            <div
              v-for="good in section.goods"
              :key="good.id"
              class="cw-good-card"
              :class="[
                `cw-card-tier-${tierSlug(good.quality)}`,
                {
                  'cw-good-locked': !section.unlocked,
                  'cw-good-disabled': isGoodDisabled(good),
                },
              ]"
            >
              <!-- 未解锁遮罩 -->
              <div v-if="!section.unlocked" class="cw-tier-overlay-mask">
                <div class="cw-mask-content">
                  <SvgIcon name="lock" :size="22" />
                  <span class="cw-mask-title">需完成 {{ section.unlockCount }} 项任务解锁</span>
                  <span class="cw-mask-progress">当前进度：{{ completedCount }} / {{ section.unlockCount }}</span>
                </div>
              </div>

              <!-- 卡片头部：品质、类别、名称、价格 -->
              <div class="cw-good-header">
                <div class="cw-good-title-box">
                  <div class="cw-tags-row">
                    <span class="cw-tier-pill" :class="`cw-pill-${tierSlug(good.quality)}`">{{ good.quality }}</span>
                    <span class="cw-good-category">{{ good.category }}</span>
                  </div>
                  <h4 class="cw-good-name" :class="`cw-name-tier-${tierSlug(good.quality)}`">{{ good.name }}</h4>
                </div>
                <div class="cw-good-price-tag" :class="`cw-price-tier-${tierSlug(good.quality)}`">
                  <span class="cw-price-number">{{ good.price }}</span>
                  <span class="cw-price-unit">蓝色精粹</span>
                </div>
              </div>

              <!-- 卡片中间：完整描述、用途与代价 -->
              <div class="cw-good-body">
                <p class="cw-good-description">{{ good.description }}</p>
              </div>

              <!-- 卡片底部：限购说明与兑换按钮 -->
              <div class="cw-good-footer">
                <div class="cw-limit-status">
                  <template v-if="good.limit !== undefined">
                    <span class="cw-limit-label">限购：</span>
                    <span
                      class="cw-limit-count"
                      :class="{ 'cw-limit-reached': (novelState._商店已购[good.id] ?? 0) >= good.limit }"
                    >
                      已购 {{ novelState._商店已购[good.id] ?? 0 }} / {{ good.limit }} {{ good.unit || '件' }}
                    </span>
                  </template>
                  <template v-else>
                    <span class="cw-limit-unlimited">常规供给 · 不设限购</span>
                  </template>
                </div>

                <div class="cw-good-action-box">
                  <button
                    type="button"
                    class="cw-btn cw-btn-primary cw-buy-btn"
                    :class="`cw-buy-tier-${tierSlug(good.quality)}`"
                    :disabled="props.disabled || !!getIssue(good) || pendingId === good.id"
                    :title="getIssue(good) || undefined"
                    @click="handleBuy(good)"
                  >
                    <SvgIcon v-if="pendingId === good.id" name="refreshCw" :size="14" class="cw-spin" />
                    <SvgIcon v-else-if="!section.unlocked" name="lock" :size="14" />
                    <SvgIcon v-else-if="good.quality === '神话' || good.quality === '传说'" name="sparkles" :size="14" />
                    <SvgIcon v-else name="coins" :size="14" />
                    <span>{{ getButtonText(good) }}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import type { State } from '../../../../运行/core';
import {
  GOOD_QUALITIES,
  GOOD_QUALITY_META,
  goodUnlockCount,
  systemGoods,
  shopIssue,
  completedQuests,
  type GoodQuality,
  type SystemGood,
} from '../../../../运行/novel-system';
import SvgIcon from '../icons/SvgIcon.vue';

const props = defineProps<{
  state: State;
  novelState: State['奇遇系统'];
  disabled?: boolean;
  pendingId?: string | null;
}>();

const emit = defineEmits<{
  (e: 'buy', goodId: string): void;
  (e: 'openInventory'): void;
}>();

const currentQuality = ref<'all' | GoodQuality>('all');

const allGoods = computed(() => systemGoods(props.state));
const completedCount = computed(() => completedQuests(props.state));

function tierSlug(quality: GoodQuality): string {
  switch (quality) {
    case '史诗':
      return 'epic';
    case '传说':
      return 'legendary';
    case '神话':
      return 'mythic';
    default:
      return 'basic';
  }
}

function isTierUnlocked(quality: GoodQuality): boolean {
  return completedCount.value >= goodUnlockCount(quality);
}

function goodsByQuality(quality: GoodQuality): SystemGood[] {
  return allGoods.value.filter(g => g.quality === quality);
}

const visibleSections = computed(() => {
  const tiers = currentQuality.value === 'all' ? [...GOOD_QUALITIES] : [currentQuality.value];
  return tiers.map(quality => ({
    quality,
    subtitle: GOOD_QUALITY_META[quality].subtitle,
    unlockCount: goodUnlockCount(quality),
    unlocked: isTierUnlocked(quality),
    goods: goodsByQuality(quality),
  }));
});

function getIssue(good: SystemGood): string {
  return shopIssue(props.state, good);
}

function isGoodDisabled(good: SystemGood): boolean {
  return !!getIssue(good);
}

function getButtonText(good: SystemGood): string {
  if (props.pendingId === good.id) return '兑换中...';
  const issue = getIssue(good);
  if (!issue) return `兑换 (${good.price} 蓝色精粹)`;
  if (issue.includes('解锁')) return '未达解锁条件';
  if (issue.includes('上限')) return '已达限购上限';
  if (issue.includes('不足')) return '蓝色精粹不足';
  return '暂不可兑换';
}

function handleBuy(good: SystemGood) {
  if (props.disabled || getIssue(good) || props.pendingId) return;
  emit('buy', good.id);
}
</script>

<style scoped>
.cw-system-shop-panel {
  display: flex;
  flex-direction: column;
  gap: 14px;
  flex: 1;
  min-height: 0;
  overflow: hidden;
  color: var(--cw-text-primary);
}

.cw-shop-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  background: var(--cw-accent-bg);
  border: 1px solid var(--cw-accent-border);
  border-radius: var(--cw-radius, 10px);
  gap: 16px;
  flex-shrink: 0;
}

.cw-banner-left {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cw-banner-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  font-weight: 600;
  color: var(--cw-accent);
  letter-spacing: 0.4px;
}

.cw-banner-title {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
}

.cw-banner-desc {
  margin: 0;
  font-size: 12px;
  color: var(--cw-text-secondary);
  line-height: 1.45;
}

.cw-banner-right {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  flex-shrink: 0;
}

.cw-inventory-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 34px;
  padding: 0 14px;
  white-space: nowrap;
  font-size: 13px;
  font-weight: 500;
  border: 1px solid var(--cw-border);
  background: var(--cw-bg-card);
  color: var(--cw-text-primary);
  border-radius: var(--cw-radius-sm, 6px);
  cursor: pointer;
  transition: all 0.2s ease;
}

.cw-inventory-btn:hover:not(:disabled) {
  border-color: var(--cw-accent);
  color: var(--cw-accent);
  background: var(--cw-bg-card-hover);
}

.cw-shop-tabs-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  border-bottom: 1px solid var(--cw-border);
  padding-bottom: 8px;
  flex-shrink: 0;
  gap: 8px 12px;
}

.cw-shop-tabs-left {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
}

.cw-filter-tab {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px 11px;
  border-radius: var(--cw-radius-sm, 6px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--cw-text-secondary);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.15s ease;
}

.cw-filter-tab:hover {
  background: var(--cw-bg-card-subtle);
  color: var(--cw-text-primary);
}

.cw-filter-tab.active {
  background: var(--cw-accent-bg);
  color: var(--cw-accent);
  border-color: var(--cw-accent-border);
  font-weight: 600;
}

.cw-tier-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}

.cw-dot-basic {
  background: #94a3b8;
}

.cw-dot-epic {
  background: #38bdf8;
}

.cw-dot-legendary {
  background: #a855f7;
}

.cw-dot-mythic {
  background: #f59e0b;
  box-shadow: 0 0 6px rgba(245, 158, 11, 0.7);
}

.cw-tab-lock-badge {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  font-size: 11px;
  opacity: 0.8;
}

.cw-shop-status-hint {
  font-size: 12px;
  color: var(--cw-text-secondary);
}

.cw-text-accent {
  color: var(--cw-accent);
}

.cw-hint-tail {
  color: var(--cw-text-muted);
}

.cw-goods-scroll-area {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 22px;
  padding-right: 4px;
}

.cw-shop-empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 44px 24px;
  gap: 8px;
  color: var(--cw-text-muted);
}

.cw-empty-icon {
  opacity: 0.45;
  margin-bottom: 4px;
}

.cw-empty-title {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: var(--cw-text-primary);
}

.cw-empty-desc {
  margin: 0;
  max-width: 440px;
  font-size: 12.5px;
  line-height: 1.6;
  color: var(--cw-text-secondary);
}

.cw-goods-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.cw-section-title-line {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 6px 12px;
}

.cw-section-title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 700;
}

.cw-section-sub {
  font-size: 12px;
  color: var(--cw-text-muted);
}

.cw-tier-pill {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.3px;
}

.cw-pill-basic {
  background: rgba(148, 163, 184, 0.18);
  color: #64748b;
  border: 1px solid rgba(148, 163, 184, 0.45);
}

.cw-pill-epic {
  background: rgba(56, 189, 248, 0.16);
  color: #0284c7;
  border: 1px solid rgba(56, 189, 248, 0.5);
}

.cw-pill-legendary {
  background: rgba(168, 85, 247, 0.16);
  color: #9333ea;
  border: 1px solid rgba(168, 85, 247, 0.5);
}

.cw-pill-mythic {
  background: linear-gradient(135deg, rgba(245, 158, 11, 0.24), rgba(234, 88, 12, 0.2));
  color: #b45309;
  border: 1px solid rgba(245, 158, 11, 0.7);
}

.cw-unlock-tag {
  font-size: 11px;
  font-weight: 500;
  padding: 1px 7px;
  border-radius: 999px;
  background: var(--cw-bg-card-subtle);
  color: var(--cw-text-muted);
  border: 1px solid var(--cw-border);
}

.cw-unlock-tag.unlocked {
  color: #15803d;
  background: rgba(34, 197, 94, 0.12);
  border-color: rgba(34, 197, 94, 0.35);
}

.cw-tier-locked-alert {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 9px 12px;
  border-radius: var(--cw-radius-sm, 6px);
  font-size: 12px;
  background: var(--cw-bg-card-subtle);
  border: 1px dashed var(--cw-border);
  color: var(--cw-text-secondary);
}

.cw-goods-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 12px;
}

.cw-good-card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px 16px;
  border-radius: var(--cw-radius, 10px);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
  transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
  overflow: hidden;
}

.cw-card-tier-basic {
  border-left: 3px solid #94a3b8;
}

.cw-card-tier-epic {
  border-left: 3px solid #38bdf8;
  border-color: rgba(56, 189, 248, 0.35);
}

.cw-card-tier-legendary {
  border-left: 3px solid #a855f7;
  border-color: rgba(168, 85, 247, 0.42);
  box-shadow: 0 2px 10px rgba(168, 85, 247, 0.08);
}

.cw-card-tier-mythic {
  border-left: 3px solid #f59e0b;
  border-color: rgba(245, 158, 11, 0.6);
  box-shadow: 0 3px 14px rgba(245, 158, 11, 0.14);
}

.cw-tier-overlay-mask {
  position: absolute;
  inset: 0;
  z-index: 2;
  background: rgba(15, 23, 42, 0.56);
  backdrop-filter: blur(1.5px);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
}

.cw-mask-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  color: #f8fafc;
  text-align: center;
}

.cw-mask-title {
  font-size: 13px;
  font-weight: 700;
}

.cw-mask-progress {
  font-size: 11.5px;
  opacity: 0.85;
}

.cw-good-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
}

.cw-good-title-box {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.cw-tags-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
}

.cw-good-category {
  font-size: 11px;
  padding: 1px 6px;
  border-radius: 4px;
  background: var(--cw-bg-card-subtle);
  color: var(--cw-text-muted);
  border: 1px solid var(--cw-border);
}

.cw-good-name {
  margin: 0;
  font-size: 14.5px;
  font-weight: 700;
  color: var(--cw-text-primary);
  word-break: break-word;
}

.cw-name-tier-epic {
  color: #0284c7;
}

.cw-name-tier-legendary {
  color: #9333ea;
}

.cw-name-tier-mythic {
  color: #b45309;
}

.cw-good-price-tag {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  flex-shrink: 0;
  padding: 4px 9px;
  border-radius: 8px;
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
}

.cw-price-number {
  font-size: 15px;
  font-weight: 800;
  line-height: 1.1;
  color: var(--cw-accent);
}

.cw-price-tier-mythic .cw-price-number {
  color: #d97706;
}

.cw-price-unit {
  font-size: 10px;
  color: var(--cw-text-muted);
}

.cw-good-body {
  flex: 1;
}

.cw-good-description {
  margin: 0;
  font-size: 12.5px;
  line-height: 1.55;
  color: var(--cw-text-secondary);
  white-space: pre-wrap;
  word-break: break-word;
}

.cw-good-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding-top: 8px;
  border-top: 1px dashed var(--cw-border);
  flex-wrap: wrap;
}

.cw-limit-status {
  font-size: 11.5px;
  color: var(--cw-text-muted);
}

.cw-limit-reached {
  color: var(--cw-danger, #dc2626);
  font-weight: 600;
}

.cw-buy-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  padding: 5px 11px;
}

@media (max-width: 640px) {
  .cw-shop-banner {
    flex-direction: column;
    align-items: stretch;
  }

  .cw-goods-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
