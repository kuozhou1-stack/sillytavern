import { Schema } from '../schema';
import { uid, copy, equal, type State } from './core';
import { byNewest, postActivity, storyMinute } from './phone';
import { storyDateKey } from './novel-system';
function archiveInteractions(state: State) {
  const raw = state.手机.原文;
  return [
    ...Object.entries(raw.评论).map(([id, row]) => ({ id, post: row.帖子id })),
    ...Object.entries(raw.点赞).map(([id, row]) => ({ id, post: row.内容id })),
    ...Object.entries(raw.转发).map(([id, row]) => ({ id, post: row.原帖id })),
  ];
}

function sameCoverage(actual: string[], expected: string[]) {
  return new Set(actual).size === actual.length && actual.length === expected.length &&
    expected.every(id => actual.includes(id));
}

export function planArchives(state: State): State {
  const s: any = copy(state);
  const pending = new Set(
    Object.values(state._系统.任务)
      .filter(t => t.类别 === '摘要' && !['已提交', '取消', '失效'].includes(t.状态))
      .map(t => t.触发来源),
  );
  const add = (key: string, ids: string[], targets: string[]) => {
    if (!ids.length || pending.has(key)) return;
    pending.add(key);
    s._系统.任务[uid('archive')] = {
      类别: '摘要',
      触发来源: key,
      目标id: targets,
      覆盖记录id: ids,
      截止时间: s.世界.当前时间,
      状态: '排队',
      提交id: uid('archive_commit'),
    };
  };
  for (const [id, p] of Object.entries(s.角色) as any) {
    if (s._系统.角色停用标识[id]) continue;
    if (p.层级 === '主要') {
      const recent = Object.keys(p.经历.最近经历);
      const current = s.世界.当前时间;
      // A life update may already have advanced its anchor; date the records themselves before archiving.
      const previousDayRecords = recent.filter(recordId => {
        const record = p.经历.最近经历[recordId];
        const date = record.日期精度 === '日' && record.日期说明?.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日$/);
        return (
          current &&
          date &&
          Number(date[1]) * 10000 + Number(date[2]) * 100 + Number(date[3]) <
            current.年 * 10000 + current.月 * 100 + current.日
        );
      });
      const crossed = Boolean(
        s.世界.当前时间 &&
        p._更新循环.上次更新变量时间 &&
        storyDateKey(p._更新循环.上次更新变量时间) !== storyDateKey(s.世界.当前时间),
      );
      if (previousDayRecords.length) add('人物:' + id, previousDayRecords.slice(0, 10), [id]);
      else if (recent.length >= 10 || crossed) add('人物:' + id, recent.slice(0, 10), [id]);
      const fine = Object.keys(p.经历.生活摘要),
        stages = Object.keys(p.经历.阶段概述);
      if (fine.length > 7) add('人物细摘要:' + id, fine.slice(0, 2), [id]);
      if (stages.length > 4) add('人物阶段:' + id, stages.slice(0, 2), [id]);
    }
  }
  const streams = [
    ...Object.entries(s.手机.会话).map(([id, c]: any) => ({
      key: '会话:' + id,
      window: c._窗口,
      limit: c.类型 === '群聊' ? 30 : 20,
      batch: 10,
    })),
    ...Object.entries(s.手机._动态流).map(([id, w]: any) => ({
      key: '动态:' + id,
      window: w,
      limit: id === '朋友圈' ? 20 : 30,
      batch: id === '朋友圈' ? 5 : 10,
    })),
  ];
  const interactions = archiveInteractions(state);
  for (const x of streams) {
    const dynamic = x.key.startsWith('动态:');
    x.window._近期id = x.window._近期id.filter((id: string) => (dynamic ? s.手机.原文.帖子[id] : s.手机.原文.消息[id]));
    x.window._近期id.sort((a: string, b: string) =>
      dynamic
        ? byNewest(postActivity(s, a), postActivity(s, b))
        : byNewest({ id: a, ...s.手机.原文.消息[a] }, { id: b, ...s.手机.原文.消息[b] }),
    );
    const covered = new Set<string>(x.window._已归档覆盖id);
    for (const summary of Object.values(state.手机.摘要)) {
      if (summary.内容?.trim() && summary.来源类型 + ':' + summary.来源id === x.key)
        summary.覆盖记录id.forEach(id => covered.add(id));
    }
    const current = x.window._近期id.filter((id: string) => !covered.has(id));
    const uncatalogued = dynamic ? interactions.filter(({ id }) => !covered.has(id)) : [];
    if (dynamic) {
      const platform = x.key.slice(3);
      const followups = uncatalogued.filter(({ post }) => post && covered.has(post) && s.手机.原文.帖子[post]?.平台 === platform);
      add(x.key, followups.slice(0, x.batch).map(row => row.id), []);
    }
    if (current.length > x.limit) {
      const oldest = current.slice(-x.batch);
      const attached = uncatalogued.filter(({ post }) => post && oldest.includes(post)).map(row => row.id);
      add(x.key, [...oldest, ...attached], []);
    }
    if (x.window._细摘要id.length > 5) add('细摘要:' + x.key, x.window._细摘要id.slice(0, 2), []);
    if (x.window._阶段概述id.length > 3) add('阶段:' + x.key, x.window._阶段概述id.slice(0, 2), []);
  }
  return Schema.parse(s);
}
export function archiveSourceRecords(state: State, taskId: string) {
  const task = state._系统.任务[taskId], key = task.触发来源!;
  if (key.startsWith('人物')) {
    const id = task.目标id[0];
    const root = key.startsWith('人物细摘要:') ? '生活摘要' : key.startsWith('人物阶段:') ? '阶段概述' : '最近经历';
    return task.覆盖记录id.map(recordId => ({
      path: ['角色', id, '经历', root, recordId], value: (state.角色[id] as any).经历[root][recordId],
    }));
  }
  const root = key.startsWith('细摘要:') || key.startsWith('阶段:') ? '摘要' : key.startsWith('会话:') ? '消息' : '帖子';
  return task.覆盖记录id.map(id => {
    if (root === '摘要') return { path: ['手机', '摘要', id], value: state.手机.摘要[id] };
    const raw = state.手机.原文;
    const recordType = ([root, '评论', '点赞', '转发'] as const).find(type => Object.hasOwn(raw[type], id)) ?? root;
    return { path: ['手机', '原文', recordType, id], value: raw[recordType][id] };
  });
}

export function archivePrompt(state: State, taskId: string) {
  const task = state._系统.任务[taskId],
    key = task.触发来源!;
  const person = key.startsWith('人物');
  let path: string, layer: string;
  if (person) {
    const id = task.目标id[0];
    const root = key.startsWith('人物细摘要:') ? '生活摘要' : key.startsWith('人物阶段:') ? '阶段概述' : '最近经历';
    layer = root === '最近经历' ? '生活摘要' : '阶段概述';
    path = '/角色/' + id + '/经历/' + layer;
  } else {
    const root =
      key.startsWith('细摘要:') || key.startsWith('阶段:') ? '摘要' : key.startsWith('会话:') ? '消息' : '帖子';
    layer = root === '摘要' ? '阶段概述' : '细摘要';
    path = '/手机/摘要';
  }
  const references = archiveSourceRecords(state, taskId).map(({ path }) => '/' + path.map(part => part.replaceAll('~', '~0').replaceAll('/', '~1')).join('/'));
  const scopeNote = person
    ? `人物${layer}目标${layer === '生活摘要' ? '150–300字' : '600字内'}，保留重要经历与关系变化，不截断。`
    : '原帖已覆盖的事实仅作上下文，旧帖新互动仅总结新增互动，不重复结算事件。会话细摘要目标150–300字，动态细摘要200–400字，阶段概述目标600字内，保护重要事实，不截断。';
  return `归档任务。只在 ${path} 新增一条 ${layer}；使用原日期区间与覆盖记录id ${JSON.stringify(task.覆盖记录id)}。${scopeNote}原文和旧摘要由脚本迁移，不得删除原文或修改下划线字段。源记录路径（从本次状态资料或共享补充读取全文）：${JSON.stringify(references)}`;
}
export function finalizeArchive(before: State, candidate: State, taskId: string, withInteraction = false, onAccepted?: (path: string[]) => void): State {
  const task = before._系统.任务[taskId],
    key = task.触发来源!;
  const s: any = candidate;
  const unchanged = withInteraction ? null : copy(candidate);
  let summaryPath: string[];
  if (key.startsWith('人物')) {
    const id = task.目标id[0],
      old: any = before.角色[id],
      p = s.角色[id];
    if (!old || !p || old._管理.版本 !== p._管理.版本) throw Error('归档目标版本变化');
    const source = key.startsWith('人物细摘要:') ? '生活摘要' : key.startsWith('人物阶段:') ? '阶段概述' : '最近经历';
    const target = source === '最近经历' ? '生活摘要' : '阶段概述';
    const added = Object.keys(p.经历[target]).filter(
      k => !old.经历[target][k] && sameCoverage(p.经历[target][k].覆盖记录id, task.覆盖记录id),
    );
    if (added.length !== 1 || !p.经历[target][added[0]].经历?.trim()) throw Error('归档候选没有完整摘要');
    summaryPath = ['角色', id, '经历', target, added[0]];
    if (unchanged) {
      delete (unchanged.角色[id] as any).经历[target][added[0]];
      if (!equal(unchanged, before)) throw Error('摘要任务修改了归档范围之外的数据');
    }
    for (const recordId of task.覆盖记录id)
      if (!equal(p.经历[source][recordId], old.经历[source][recordId]))
        throw Error('待归档经历已变化，保留原文等待下次归档');
    for (const recordId of task.覆盖记录id) {
      if (source === '最近经历') p.经历._待归档经历[recordId] = old.经历[source][recordId];
      delete p.经历[source][recordId];
    }
  } else {
    const ids = Object.keys(s.手机.摘要).filter(
      id => !before.手机.摘要[id] && sameCoverage(s.手机.摘要[id].覆盖记录id, task.覆盖记录id),
    );
    if (ids.length !== 1 || !s.手机.摘要[ids[0]].内容?.trim())
      throw Error('手机摘要覆盖不完整');
    for (const { path, value } of archiveSourceRecords(before, taskId)) {
      if (value === undefined || !equal(value, _.get(candidate, path))) throw Error('待归档手机原文已变化，请按当前记录重新归档');
    }
    summaryPath = ['手机', '摘要', ids[0]];
    if (unchanged) {
      delete unchanged.手机.摘要[ids[0]];
      if (!equal(unchanged, before)) throw Error('摘要任务修改了原文或其他数据');
    }
    const target = key.replace(/^(细摘要|阶段):/, '');
    const window = target.startsWith('会话:') ? s.手机.会话[target.slice(3)]._窗口 : s.手机._动态流[target.slice(3)];
    const source = key.startsWith('细摘要:') ? '_细摘要id' : key.startsWith('阶段:') ? '_阶段概述id' : '_近期id';
    window[source] = window[source].filter((id: string) => !task.覆盖记录id.includes(id));
    window[source === '_近期id' ? '_细摘要id' : '_阶段概述id'].push(ids[0]);
    window._已归档覆盖id = [...new Set([...window._已归档覆盖id, ...task.覆盖记录id])];
    const coveredMessages = target.startsWith('会话:') && source === '_近期id'
      ? task.覆盖记录id.filter(id => Boolean(s.手机.原文.消息[id]))
      : [];
    const coveredPosts = target.startsWith('动态:') && source === '_近期id'
      ? task.覆盖记录id.filter(id => Boolean(s.手机.原文.帖子[id]))
      : [];
    const coveredInteractions = target.startsWith('动态:') && source === '_近期id'
      ? task.覆盖记录id.filter(id => Boolean(s.手机.原文.评论[id] || s.手机.原文.点赞[id] || s.手机.原文.转发[id]))
      : [];
    const recordTimes: NonNullable<State['世界']['当前时间']>[] = [];
    if (source === '_近期id') {
      for (const id of coveredMessages) {
        const t = s.手机.原文.消息[id]?.故事时间;
        if (t) recordTimes.push(t);
      }
      for (const id of coveredPosts) {
        const t = s.手机.原文.帖子[id]?.故事时间;
        if (t) recordTimes.push(t);
      }
      for (const id of coveredInteractions) {
        const t = s.手机.原文.评论[id]?.故事时间 ?? s.手机.原文.点赞[id]?.时间 ?? s.手机.原文.转发[id]?.时间;
        if (t) recordTimes.push(t);
      }
    } else {
      for (const id of task.覆盖记录id) {
        const prev = s.手机.摘要[id];
        if (prev?.起始时间) recordTimes.push(prev.起始时间);
        if (prev?.结束时间) recordTimes.push(prev.结束时间);
      }
    }
    recordTimes.sort((a, b) => storyMinute(a) - storyMinute(b));
    const summary = s.手机.摘要[ids[0]];
    const batchStart = recordTimes.length ? copy(recordTimes[0]) : null;
    const batchEnd = recordTimes.length ? copy(recordTimes[recordTimes.length - 1]) : null;
    summary.来源类型 = target.split(':')[0];
    summary.来源id = target.slice(3);
    summary.层级 = source === '_近期id' ? '细摘要' : '阶段概述';
    summary.起始时间 = batchStart;
    summary.结束时间 = batchEnd;
    if (target.startsWith('动态:') && source === '_近期id') {
      const waitingPosts = new Set(archiveInteractions(s)
        .filter(({ id }) => !window._已归档覆盖id.includes(id)).map(({ post }) => post));
      window._近期id = window._近期id.filter((post: string) =>
        !window._已归档覆盖id.includes(post) || waitingPosts.has(post));
    }
    s.手机._归档批次[taskId] = {
      来源类型: target.split(':')[0],
      来源id: target.slice(3),
      覆盖消息id: coveredMessages,
      覆盖帖子id: coveredPosts,
      覆盖互动id: coveredInteractions,
      摘要id: ids[0],
      起始时间: batchStart,
      结束时间: batchEnd,
      提交id: task.提交id,
    };
  }
  s._系统.任务[taskId].状态 = '已提交';
  const settled = Schema.parse(s);
  onAccepted?.(summaryPath);
  return settled;
}
