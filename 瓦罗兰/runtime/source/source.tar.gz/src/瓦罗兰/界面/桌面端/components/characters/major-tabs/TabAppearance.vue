<template>
  <div class="cw-tab-pane cw-char-tab-appearance">
    <!-- 1. 外貌与身形 -->
    <div class="cw-char-section-card cw-section-appearance">
      <h4 class="cw-section-title">
        <SvgIcon name="eye" :size="15" />
        <span>身形与外貌特征</span>
      </h4>

      <div v-if="hasAppearanceMetrics" class="cw-scalar-grid">
        <div v-if="char?.外貌?.身高" class="cw-scalar-cell">
          <span class="cw-scalar-k">身高</span>
          <span class="cw-scalar-v">{{ char.外貌.身高 }} cm</span>
        </div>
        <div v-if="char?.外貌?.体重" class="cw-scalar-cell">
          <span class="cw-scalar-k">体重</span>
          <span class="cw-scalar-v">{{ char.外貌.体重 }} kg</span>
        </div>
        <div v-if="femaleMeasurements" class="cw-scalar-cell cw-scalar-wide">
          <span class="cw-scalar-k">三围 / 罩杯</span>
          <span class="cw-scalar-v">{{ femaleMeasurements }}</span>
        </div>
      </div>

      <div class="cw-stack-list">
        <div v-if="char?.外貌?.整体体型" class="cw-stack-field">
          <span class="cw-stack-k">体态轮廓</span>
          <p class="cw-stack-v">{{ char.外貌.整体体型 }}</p>
        </div>

        <div v-if="char?.外貌?.主色调与高光焦点" class="cw-stack-field cw-callout-accent">
          <span class="cw-stack-k">主色调与高光焦点</span>
          <p class="cw-stack-v">{{ char.外貌.主色调与高光焦点 }}</p>
        </div>

        <div class="cw-stack-field">
          <span class="cw-stack-k">外貌细节描述</span>
          <div class="cw-long-text-block">
            <p class="cw-prose-paragraph" :class="{ 'is-clamped': !appearanceExpanded && isAppearanceLong }">
              {{ char?.外貌?.详细外表 || '尚未登记详细外貌描述' }}
            </p>
            <button
              v-if="isAppearanceLong"
              type="button"
              class="cw-expand-toggle-btn"
              @click="emit('toggleExpand', 'appearance:detail')"
            >
              <span>{{ appearanceExpanded ? '收起描述' : '展开全文' }}</span>
              <SvgIcon :name="appearanceExpanded ? 'chevronUp' : 'chevronDown'" :size="12" />
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 2. 多形态与形象衣橱 -->
    <div v-if="wardrobeEntries.length" class="cw-char-section-card cw-section-wardrobe">
      <div class="cw-section-head-row">
        <h4 class="cw-section-title cw-title-inline">
          <SvgIcon name="layers" :size="15" />
          <span>多形态与形象衣橱</span>
        </h4>
        <span class="cw-count-meta">共 {{ wardrobeEntries.length }} 套形态 · 点击切换预览，点击大图可替换本地头像</span>
      </div>

      <div class="cw-form-switcher" role="tablist" aria-label="切换预览形态">
        <button
          v-for="[formName] in wardrobeEntries"
          :key="formName"
          type="button"
          role="tab"
          class="cw-form-tab"
          :class="{
            'is-selected': formName === activeWardrobeForm,
            'is-live': formName === char?.当前形态,
          }"
          :aria-selected="formName === activeWardrobeForm"
          @click="selectedWardrobeForm = formName"
        >
          <CharacterAvatar :name="char?.姓名" :form="formName" :size="32" shape="rounded" />
          <div class="cw-form-tab-text">
            <span class="cw-form-tab-name">{{ formName }}</span>
            <span v-if="formName === char?.当前形态" class="cw-form-live-tag">当前</span>
            <span v-else-if="formName === char?.默认形态" class="cw-form-default-tag">默认</span>
          </div>
        </button>
      </div>

      <div v-if="activeWardrobeEntry" class="cw-wardrobe-stage">
        <div class="cw-wardrobe-stage-head">
          <CharacterAvatar
            :name="char?.姓名"
            :form="activeWardrobeEntry.name"
            :size="72"
            shape="rounded"
            editable
            class="cw-wardrobe-portrait"
          />
          <div class="cw-wardrobe-stage-meta">
            <div class="cw-wardrobe-stage-title">
              <h5>{{ activeWardrobeEntry.name }}</h5>
              <span v-if="activeWardrobeEntry.name === char?.当前形态" class="cw-badge cw-badge-accent">当前穿着</span>
              <span v-if="activeWardrobeEntry.name === char?.默认形态" class="cw-badge">默认形态</span>
            </div>
            <p v-if="activeWardrobeEntry.data.对应身份" class="cw-wardrobe-stage-role">
              对应身份：{{ activeWardrobeEntry.data.对应身份 }}
            </p>
          </div>
        </div>

        <div class="cw-wardrobe-fields">
          <div v-if="activeWardrobeEntry.data.形象描述" class="cw-stack-field">
            <span class="cw-stack-k">形象与单品构成</span>
            <p class="cw-stack-v">{{ activeWardrobeEntry.data.形象描述 }}</p>
          </div>

          <div
            v-if="activeWardrobeEntry.data.暴露度策略 || activeWardrobeEntry.data.核心视觉焦点"
            class="cw-wardrobe-two-col"
          >
            <div v-if="activeWardrobeEntry.data.暴露度策略" class="cw-stack-field cw-sub-box">
              <span class="cw-stack-k">暴露度与剪裁策略</span>
              <p class="cw-stack-v">{{ activeWardrobeEntry.data.暴露度策略 }}</p>
            </div>
            <div v-if="activeWardrobeEntry.data.核心视觉焦点" class="cw-stack-field cw-sub-box">
              <span class="cw-stack-k">核心视觉焦点</span>
              <p class="cw-stack-v">{{ activeWardrobeEntry.data.核心视觉焦点 }}</p>
            </div>
          </div>

          <div v-if="activeWardrobeEntry.data.着装失序动态" class="cw-stack-field cw-sub-box cw-dishevel-box">
            <span class="cw-stack-k">着装失序动态</span>
            <p class="cw-stack-v">{{ activeWardrobeEntry.data.着装失序动态 }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- 3. 外观与感官标识（身体印记、随身信物、感官特征） -->
    <div v-if="hasPhysicalSignatures" class="cw-char-section-card cw-signature-card">
      <h4 class="cw-section-title">
        <SvgIcon name="bookmark" :size="15" />
        <span>外观与感官标识</span>
      </h4>
      <div class="cw-stack-list">
        <div v-if="char?.专属标识?.身体印记?.length" class="cw-stack-field cw-sub-box">
          <span class="cw-stack-k">身体印记</span>
          <div class="cw-chip-wrap">
            <span v-for="(mark, idx) in char.专属标识.身体印记" :key="idx" class="cw-tag-signature">
              {{ mark }}
            </span>
          </div>
        </div>
        <div v-if="char?.专属标识?.随身信物?.length" class="cw-stack-field cw-sub-box">
          <span class="cw-stack-k">随身信物</span>
          <div class="cw-chip-wrap">
            <span v-for="(item, idx) in char.专属标识.随身信物" :key="idx" class="cw-tag-keepsake">
              {{ item }}
            </span>
          </div>
        </div>
        <div v-if="char?.专属标识?.感官特征" class="cw-stack-field cw-sub-box">
          <span class="cw-stack-k">感官特征</span>
          <p class="cw-stack-v">{{ char.专属标识.感官特征 }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import SvgIcon from '../../icons/SvgIcon.vue';
import CharacterAvatar from '../../shared/CharacterAvatar.vue';

const props = defineProps<{
  char: any;
  expandedFields: Record<string, boolean>;
}>();

const emit = defineEmits<{
  (e: 'toggleExpand', field: string): void;
}>();

const appearanceExpanded = computed(() => !!props.expandedFields['appearance:detail']);

const isAppearanceLong = computed(() => {
  const text = props.char?.外貌?.详细外表;
  if (!text || typeof text !== 'string') return false;
  return text.length > 180 || (text.match(/\n/g) || []).length >= 4;
});

const isMale = computed(() => {
  const g = props.char?.性别;
  return g === '男' || g === '男性';
});

const femaleMeasurements = computed(() => {
  if (isMale.value) return null;
  const m = props.char?.外貌?.三围信息;
  const cup = props.char?.外貌?.罩杯;
  if (!m && !cup) return null;
  const parts: string[] = [];
  if (cup) parts.push(`${cup} 罩杯`);
  if (m && (m.胸围 != null || m.腰围 != null || m.臀围 != null)) {
    const bwh = [
      m.胸围 != null ? `${m.胸围}` : '?',
      m.腰围 != null ? `${m.腰围}` : '?',
      m.臀围 != null ? `${m.臀围}` : '?',
    ].join(' / ');
    parts.push(`B·W·H ${bwh} cm`);
  }
  return parts.length > 0 ? parts.join(' · ') : null;
});

const hasAppearanceMetrics = computed(() => {
  const a = props.char?.外貌;
  return Boolean(a?.身高 || a?.体重 || femaleMeasurements.value);
});

const wardrobeEntries = computed(() => {
  const w = props.char?.形态衣橱;
  if (!w || typeof w !== 'object') return [] as [string, any][];
  return Object.entries(w).filter(([, v]) => v && typeof v === 'object');
});

const selectedWardrobeForm = ref<string>('');

function pickDefaultWardrobeForm(): string {
  const entries = wardrobeEntries.value;
  if (!entries.length) return '';
  const current = props.char?.当前形态;
  if (current && entries.some(([k]) => k === current)) return current;
  const def = props.char?.默认形态;
  if (def && entries.some(([k]) => k === def)) return def;
  return entries[0][0];
}

watch(
  () => [props.char?.id, props.char?.姓名, props.char?.当前形态, wardrobeEntries.value.length],
  () => {
    selectedWardrobeForm.value = pickDefaultWardrobeForm();
  },
  { immediate: true },
);

const activeWardrobeForm = computed(() => {
  const entries = wardrobeEntries.value;
  if (!entries.length) return '';
  if (entries.some(([k]) => k === selectedWardrobeForm.value)) return selectedWardrobeForm.value;
  return pickDefaultWardrobeForm();
});

const activeWardrobeEntry = computed(() => {
  const found = wardrobeEntries.value.find(([k]) => k === activeWardrobeForm.value);
  return found ? { name: found[0], data: found[1] } : null;
});

const hasPhysicalSignatures = computed(() => {
  const s = props.char?.专属标识;
  return Boolean(
    s && ((s.身体印记 && s.身体印记.length > 0) || (s.随身信物 && s.随身信物.length > 0) || s.感官特征),
  );
});
</script>

<style scoped lang="scss">
.cw-char-tab-appearance {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-char-section-card {
  padding: 16px 18px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-signature-card {
  border-left: 3px solid var(--cw-accent);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-section-head-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);

  .cw-title-inline {
    margin: 0;
    padding: 0;
    border: 0;
  }
}

.cw-count-meta {
  font-size: 11px;
  color: var(--cw-text-secondary);
}

.cw-scalar-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
  margin-bottom: 12px;
}

.cw-scalar-cell {
  display: flex;
  flex-direction: column;
  gap: 3px;
  padding: 8px 10px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  min-width: 0;

  &.cw-scalar-wide {
    grid-column: span 2;
  }

  .cw-scalar-k {
    font-size: 11px;
    color: var(--cw-text-muted);
  }

  .cw-scalar-v {
    font-size: 13px;
    font-weight: 600;
    color: var(--cw-text-primary);
    overflow-wrap: anywhere;
  }
}

.cw-stack-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-stack-field {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 0;

  .cw-stack-k {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
    color: var(--cw-text-secondary);
  }

  .cw-stack-v {
    margin: 0;
    font-size: 13.5px;
    line-height: 1.72;
    color: var(--cw-text-primary);
    white-space: pre-wrap;
    word-break: break-word;
    overflow-wrap: anywhere;
  }
}

.cw-sub-box {
  padding: 10px 12px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
}

.cw-callout-accent {
  padding: 10px 12px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-tag-accent-bg, var(--cw-accent-bg));
  border: 1px solid var(--cw-tag-accent-border, var(--cw-accent-border));
  border-left: 3px solid var(--cw-accent);

  .cw-stack-k {
    color: var(--cw-tag-accent-text, var(--cw-accent));
  }
}

.cw-form-switcher {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 14px;
}

.cw-form-tab {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 11px 6px 6px;
  border-radius: var(--cw-radius-sm);
  border: 1px solid var(--cw-border);
  background: var(--cw-bg-card-subtle);
  color: var(--cw-text-secondary);
  cursor: pointer;
  transition: border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease;

  &:hover {
    border-color: var(--cw-border-hover);
    color: var(--cw-text-primary);
  }

  &.is-selected {
    border-color: var(--cw-tag-accent-border, var(--cw-accent));
    background: var(--cw-tag-accent-bg, var(--cw-accent-bg));
    color: var(--cw-tag-accent-text, var(--cw-text-primary));
    box-shadow: var(--cw-shadow-sm);
  }
}

.cw-form-tab-text {
  display: flex;
  align-items: center;
  gap: 5px;
}

.cw-form-tab-name {
  font-size: 12.5px;
  font-weight: 600;
}

.cw-form-live-tag {
  font-size: 10px;
  font-weight: 600;
  padding: 1px 6px;
  border-radius: var(--cw-radius-full);
  background: var(--cw-accent);
  color: var(--cw-text-inverse);
  flex-shrink: 0;
  white-space: nowrap;
}

.cw-form-default-tag {
  font-size: 10px;
  font-weight: 500;
  padding: 1px 6px;
  border-radius: var(--cw-radius-full);
  background: var(--cw-tag-neutral-bg, var(--cw-bg-card));
  border: 1px solid var(--cw-tag-neutral-border, var(--cw-border));
  color: var(--cw-tag-neutral-text, var(--cw-text-secondary));
  flex-shrink: 0;
  white-space: nowrap;
}

.cw-wardrobe-stage {
  padding: 14px 16px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-surface);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.cw-wardrobe-stage-head {
  display: flex;
  align-items: center;
  gap: 14px;
  padding-bottom: 12px;
  border-bottom: 1px dashed var(--cw-border);
}

.cw-wardrobe-portrait {
  box-shadow: var(--cw-shadow-sm);
}

.cw-wardrobe-stage-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.cw-wardrobe-stage-title {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;

  h5 {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    color: var(--cw-text-primary);
  }
}

.cw-wardrobe-stage-role {
  margin: 0;
  font-size: 12.5px;
  color: var(--cw-text-secondary);
  line-height: 1.5;
}

.cw-wardrobe-fields {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-wardrobe-two-col {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.cw-dishevel-box {
  border-style: dashed;
}

.cw-chip-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.cw-tag-signature {
  display: inline-flex;
  align-items: center;
  background: var(--cw-tag-accent-bg, var(--cw-accent-bg));
  color: var(--cw-tag-accent-text, var(--cw-accent));
  border: 1px solid var(--cw-tag-accent-border, var(--cw-accent-border));
  font-size: 12px;
  font-weight: 500;
  line-height: 1.45;
  padding: 3px 9px;
  border-radius: var(--cw-radius-sm);
  overflow-wrap: anywhere;
}

.cw-tag-keepsake {
  display: inline-flex;
  align-items: center;
  background: var(--cw-tag-info-bg, var(--cw-info-bg));
  color: var(--cw-tag-info-text, var(--cw-info));
  border: 1px solid var(--cw-tag-info-border, var(--cw-info));
  font-size: 12px;
  font-weight: 500;
  line-height: 1.45;
  padding: 3px 9px;
  border-radius: var(--cw-radius-sm);
  overflow-wrap: anywhere;
}

.cw-long-text-block {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 100%;
}

.cw-prose-paragraph {
  margin: 0;
  font-size: 13.5px;
  line-height: 1.78;
  color: var(--cw-text-primary);
  white-space: pre-wrap;
  word-break: break-word;
  overflow-wrap: anywhere;

  &.is-clamped {
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

.cw-expand-toggle-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-top: 6px;
  padding: 3px 10px;
  border-radius: var(--cw-radius-sm);
  border: 1px solid var(--cw-tag-accent-border, var(--cw-border));
  background: var(--cw-tag-accent-bg, var(--cw-bg-card-subtle));
  color: var(--cw-tag-accent-text, var(--cw-accent));
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s ease;

  &:hover {
    filter: brightness(0.96);
  }
}

@media (max-width: 640px) {
  .cw-scalar-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .cw-wardrobe-two-col {
    grid-template-columns: 1fr;
  }

  .cw-wardrobe-stage-head {
    align-items: flex-start;
  }
}
</style>
