import type { State } from './core';
import { hydrateStateFromExternalSettings } from './external-settings';

/** 从外置设定目录同步区域、地点/建筑与组织资料，不在源码内硬编码具体世界资料。 */
export function normalizeWorldInformation(state: State): State {
  return hydrateStateFromExternalSettings(state);
}
