<template>
  <div class="cw-tab-pane cw-char-tab-network">
    <div class="cw-network-card">
      <div class="cw-section-head-row">
        <h4 class="cw-section-title cw-title-inline">
          <SvgIcon name="phone" :size="16" />
          <span>已知平台账号</span>
        </h4>
        <span v-if="hasAccounts" class="cw-badge cw-badge-success">
          {{ accountEntries.length }} 个
        </span>
      </div>

      <div class="cw-identity-stack">
        <div v-if="hasAccounts" class="cw-account-cards-list">
          <div v-for="[accId, acc] in accountEntries" :key="accId" class="cw-acc-detail-card">
            <div class="cw-acc-header">
              <div class="cw-acc-plat">
                <SvgIcon
                  :name="acc.平台?.includes('星讯') || acc.平台?.includes('微信') ? 'messageSquare' : 'globe'"
                  :size="15"
                />
                <span class="cw-plat-name">{{ acc.平台 || '社交平台' }}</span>
              </div>
              <span class="cw-badge cw-badge-accent">{{ acc.账号名 || accId }}</span>
            </div>
            <div v-if="acc.昵称 || accountBio(acc)" class="cw-acc-info">
              <div v-if="acc.昵称" class="cw-acc-row">
                <span class="cw-k">昵称：</span>
                <span class="cw-v">{{ acc.昵称 }}</span>
              </div>
              <div v-if="accountBio(acc)" class="cw-acc-row">
                <span class="cw-k">简介：</span>
                <span class="cw-v">{{ accountBio(acc) }}</span>
              </div>
            </div>
          </div>
        </div>

        <div v-else class="cw-empty-compact">
          <SvgIcon name="globe" :size="15" class="cw-empty-icon" />
          <span>暂未获知对方的平台账号。</span>
        </div>

      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, toRaw } from 'vue';
import type { State } from '../../../../../运行/core';
import { useWorldState } from '../../../utils/context';
import SvgIcon from '../../icons/SvgIcon.vue';

const state = useWorldState<State>();

const props = defineProps<{
  char: any;
}>();

function accountBio(acc: any): string | null {
  return acc?.简介 || acc?.公开资料?.简介 || acc?.公开资料?.签名 || acc?.公开资料?.个性签名 || null;
}

const accountEntries = computed(() => {
  const rawChar = toRaw(props.char);
  const id = props.char?.id || Object.keys(state.value.角色).find(k => toRaw(state.value.角色[k]) === rawChar);
  if (!id) return [];
  const accounts = state.value.手机.账号;
  return Object.keys(state.value.玩家.已知信息.已知账号)
    .filter(accountId => accounts[accountId]?.人物id === id)
    .map(accountId => [accountId, accounts[accountId]] as const);
});

const hasAccounts = computed(() => accountEntries.value.length > 0);
</script>

<style scoped lang="scss">
.cw-char-tab-network {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-network-card {
  padding: 16px 20px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-section-head-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 14px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);

  .cw-title-inline {
    margin: 0;
    padding: 0;
    border: 0;
  }
}

.cw-identity-stack {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-account-cards-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cw-acc-detail-card {
  padding: 11px 14px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-surface);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 8px;

  .cw-acc-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;

    .cw-acc-plat {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      font-weight: 600;
      color: var(--cw-text-primary);
      min-width: 0;
    }
  }

  .cw-acc-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-size: 12px;

    .cw-acc-row {
      display: flex;
      gap: 6px;

      .cw-k {
        color: var(--cw-text-secondary);
        width: 48px;
        flex-shrink: 0;
      }
      .cw-v {
        color: var(--cw-text-primary);
        min-width: 0;
        word-break: break-word;
      }
    }
  }
}

.cw-empty-compact {
  padding: 12px 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px dashed var(--cw-border);
  color: var(--cw-text-secondary);
  font-size: 12px;

  .cw-empty-icon {
    opacity: 0.65;
    flex-shrink: 0;
  }
}

@media (max-width: 600px) {
  .cw-pref-grid {
    grid-template-columns: 1fr;
  }
}
</style>
