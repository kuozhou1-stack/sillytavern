export type CharacterIdentity = {
  公开: string[];
  隐秘: string[];
  保密底线: string | null;
  已明确?: true;
};

/** 纯函数身份标准化（零 Zod 依赖，可直接供前端轻量组件与纯 UI 测试使用）。 */
export function normalizeIdentityInput(raw: unknown): CharacterIdentity {
  if (typeof raw === 'string') {
    const tags = raw
      .split(/[、,，/]/)
      .map(item => item.trim())
      .filter(Boolean);
    return { 公开: tags, 隐秘: [], 保密底线: null };
  }
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    const obj = raw as Record<string, unknown>;
    const toList = (val: unknown) =>
      Array.isArray(val)
        ? val.map(v => String(v ?? '').trim()).filter(Boolean)
        : typeof val === 'string'
          ? val
              .split(/[、,，/]/)
              .map(s => s.trim())
              .filter(Boolean)
          : [];
    return {
      ...(obj.已明确 === true ? { 已明确: true as const } : {}),
      公开: toList(obj.公开),
      隐秘: toList(obj.隐秘),
      保密底线: typeof obj.保密底线 === 'string' && obj.保密底线.trim() ? obj.保密底线.trim() : null,
    };
  }
  return { 公开: [], 隐秘: [], 保密底线: null };
}

/** 判断身份结构是否含非空当局内容（公开、隐秘或保密底线任一非空）。 */
export function hasIdentityContent(identity: CharacterIdentity): boolean {
  return identity.公开.length > 0 || identity.隐秘.length > 0 || Boolean(identity.保密底线);
}

/** 合并当局动态身份与静态原始身份：当局身份非空时以当局为准，空壳或缺失时回退原始档案。 */
export function resolveEffectiveCharacterIdentity(
  dynamicIdentity: unknown,
  staticIdentity?: unknown,
): CharacterIdentity {
  const dynamic = normalizeIdentityInput(dynamicIdentity);
  if (dynamic.已明确 || hasIdentityContent(dynamic)) return dynamic;
  if (staticIdentity !== undefined) {
    const fallback = normalizeIdentityInput(staticIdentity);
    if (hasIdentityContent(fallback)) return fallback;
  }
  return dynamic;
}

/** 提取公开身份标签（目录与表世界卡片默认只显示公开身份，防剧透隐秘身份）。 */
export function publicIdentityTags(identity: unknown): string[] {
  return normalizeIdentityInput(identity).公开;
}

export function hiddenIdentityTags(identity: unknown): string[] {
  return normalizeIdentityInput(identity).隐秘;
}

export function formatPublicIdentity(identity: unknown): string {
  const tags = publicIdentityTags(identity);
  return tags.length ? tags.join('、') : '';
}

/** 中文可紧邻目录 ID，连续的拉丁字母、数字、下划线与连字符属于同一个 ID。 */
export function mentionsRecordId(text: string, id: string) {
  if (!id || !text.includes(id)) return false;
  const word = /[A-Za-z0-9_-]/;
  for (let start = text.indexOf(id); start >= 0; start = text.indexOf(id, start + 1)) {
    if (!word.test(text[start - 1] ?? '') && !word.test(text[start + id.length] ?? '')) return true;
  }
  return false;
}
