// Presets using "execute the latest advice" must see this task as that advice,
// rather than treating the player's previous story action as another turn.
export const workerTask = `<advice>
本次执行变量更新（后台结算），不是新的正文回合。仅依据交接的已完成正文、手机操作及本次列明的后台待办，按世界书的变量更新规则与下方“变量输出格式”直接返回补丁，不续写未发生的行为或推进未来安排。
</advice>`;
