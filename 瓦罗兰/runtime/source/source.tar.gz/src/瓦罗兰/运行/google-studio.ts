import type { ApiProfile } from './settings';
import { lowestSupportedThinkingLevel, mergeCustomIncludeBody, modelFamily, vertexThinkingLevels } from './vertex';

export const DEFAULT_GOOGLE_STUDIO_API_URL = 'https://generativelanguage.googleapis.com';

export type GoogleStudioThinkingLevel = ApiProfile['googleThinkingLevel'];
export type GoogleStudioProfile = {
  apiurl: string;
  key: string;
  model: string;
  thinkingLevel?: GoogleStudioThinkingLevel;
};

/** 规范化 Google AI Studio 根地址（留空默认官方地址）。 */
export function normalizeGoogleStudioBaseUrl(apiurl?: string): string {
  const raw = (apiurl ?? '').trim();
  if (!raw) return DEFAULT_GOOGLE_STUDIO_API_URL;
  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    throw Error('Google AI Studio API 地址无效');
  }
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw Error('Google AI Studio API 地址无效，密钥请填在密钥栏');
  }
  let pathname = parsed.pathname.replace(/\/+$/, '');
  pathname = pathname.replace(/\/(?:v1beta|v1alpha|v1)\/(?:openai|models)$/i, '');
  pathname = pathname.replace(/\/(?:v1beta|v1alpha|v1|models)$/i, '');
  return `${parsed.origin}${pathname}`;
}

/**
 * 推导供酒馆后端（ChatCompletionService / getModelList）转发使用的 Google AI Studio 端点。
 * 官方地址或未带 OpenAI 兼容后缀的地址统一映射至 /v1beta/openai；若用户明确填写了 /v1 反代地址则予以保留。
 */
export function googleStudioOpenAiEndpoint(apiurl?: string): string {
  const raw = (apiurl ?? '').trim();
  if (!raw) return `${DEFAULT_GOOGLE_STUDIO_API_URL}/v1beta/openai`;
  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    throw Error('Google AI Studio API 地址无效');
  }
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw Error('Google AI Studio API 地址无效，密钥请填在密钥栏');
  }
  const pathname = parsed.pathname.replace(/\/+$/, '');
  if (/\/(?:v1beta|v1alpha|v1)\/openai$/i.test(pathname)) {
    return `${parsed.origin}${pathname}`;
  }
  if (/\/(?:v1beta|v1alpha)$/i.test(pathname)) {
    return `${parsed.origin}${pathname}/openai`;
  }
  if (parsed.origin !== DEFAULT_GOOGLE_STUDIO_API_URL && /\/v1$/i.test(pathname)) {
    return `${parsed.origin}${pathname}`;
  }
  const base = normalizeGoogleStudioBaseUrl(raw);
  return `${base}/v1beta/openai`;
}

export function normalizeGoogleStudioModelId(model: string): string {
  return model.trim().replace(/^(?:models\/|publishers\/google\/models\/|google\/)/i, '');
}

export function googleStudioThinkingLevels(model: string): readonly GoogleStudioThinkingLevel[] {
  return vertexThinkingLevels(normalizeGoogleStudioModelId(model));
}

export function lowestGoogleStudioThinkingLevel(model: string): GoogleStudioThinkingLevel {
  return lowestSupportedThinkingLevel(normalizeGoogleStudioModelId(model));
}

export function googleStudioConnection(profile: ApiProfile): CustomApiConfig & { googleStudio: GoogleStudioProfile } {
  const apiurl = googleStudioOpenAiEndpoint(profile.apiurl);
  const model = normalizeGoogleStudioModelId(profile.model);
  return {
    source: 'custom',
    apiurl,
    key: profile.key.trim(),
    model,
    googleStudio: {
      apiurl,
      key: profile.key.trim(),
      model,
      thinkingLevel: profile.googleThinkingLevel ?? 'default',
    },
  };
}

/** 清理 Google AI Studio 模型列表：去除 models/ 前缀，过滤非文本对话模型并按版本降序排列。 */
export function filterGoogleStudioModelIds(rawModels: readonly string[]): string[] {
  const models = new Set<string>();
  for (const item of rawModels) {
    const id = normalizeGoogleStudioModelId(String(item || ''));
    if (!id) continue;
    if (/(?:embedding|aqa|imagen|veo|tts|live|audio-preview)/i.test(id)) continue;
    models.add(id);
  }
  return [...models].sort((a, b) => b.localeCompare(a, 'en', { numeric: true }));
}

/**
 * 将思考强度等 Google AI Studio 参数写入酒馆后端 custom 通道的 payload，
 * 由酒馆 Node.js 后端转发至 generativelanguage.googleapis.com/v1beta/openai。
 */
export function applyGoogleStudioGenerationOptions(
  payload: Record<string, any>,
  model: string,
  level: GoogleStudioThinkingLevel = 'default',
) {
  const cleanModel = normalizeGoogleStudioModelId(model);
  if (!googleStudioThinkingLevels(cleanModel).includes(level)) {
    throw Error(`当前 Google AI Studio 模型不支持 ${level} 思考强度，请重新选择`);
  }
  delete payload.reasoning_effort;
  delete payload.top_k;
  const family = modelFamily(cleanModel);
  if (/^gemini-(?:4-|3\.[5-8]-flash)/.test(family)) {
    for (const key of ['temperature', 'top_p', 'presence_penalty', 'frequency_penalty', 'n']) delete payload[key];
  }
  if (level === 'default') return;
  const options: Record<string, any> = family.startsWith('gemini-2.5-')
    ? { reasoning_effort: level }
    : { extra_body: { google: { thinking_config: { thinking_level: level.toUpperCase() } } } };
  mergeCustomIncludeBody(payload, options);
}

export function googleStudioTransport(profile: GoogleStudioProfile) {
  const key = profile.key.trim();
  if (!key) throw Error('请先填写 Google AI Studio API Key');
  const model = normalizeGoogleStudioModelId(profile.model);
  if (!model) throw Error('请先填写 Google AI Studio 模型名称');
  return {
    url: googleStudioOpenAiEndpoint(profile.apiurl),
    model,
    key,
  };
}
