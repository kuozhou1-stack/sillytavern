import type { OrganizationProfile, OrganizationRelation } from './organization-profile';
import type { State } from './core';
import settingsPaths from './设定路径.json' with { type: 'json' };

const copy = <T>(value: T): T => JSON.parse(JSON.stringify(value));

declare const __CHENGWAN_EXTERNAL_SETTINGS_URL__: string | undefined;
declare const __CHENGWAN_AVATAR_BASE_URL__: string | undefined;

export type ExternalDistrict = {
  id: string;
  name: string;
  shortName: string;
  role: string;
  desc: string;
  scope: string;
  layer: '表世界' | '口袋维度' | '里世界';
  trafficTier: '繁荣快线' | '长途跋涉' | '特殊通道';
  azimuth: string;
  travelSummary: string;
  locationIds: string[];
  x: number;
  y: number;
  labelY: number;
  map: {
    bounds: { x: number; y: number; w: number; h: number };
    theme: string;
    zones: { id?: string; name: string; kind: string; x: number; y: number; w: number; h: number }[];
  };
};

export type ExternalGeographyBundle = {
  format?: string;
  版本: string;
  片区: Record<string, State['世界']['片区'][string]>;
  districts: ExternalDistrict[];
  positions: Record<string, [number, number]>;
  calibratedLandmarks?: Record<string, { previous: [number, number]; note: string }>;
  locationNames: Record<string, string>;
  publicLandmarks: string[];
};

export type AvatarHeroEntry = {
  默认形态: string;
  形态: Record<string, string>;
};

export type AvatarManifest = {
  format?: string;
  basePath?: string;
  totalHeroes?: number;
  totalImages?: number;
  heroes: Record<string, AvatarHeroEntry>;
};

export type ExternalOrganization = State['组织'][string] & Partial<OrganizationProfileFields>;
type OrganizationProfileFields = Omit<OrganizationProfile, '公开性质' | '象限' | '名称' | '编号'>;

export type ExternalSettingsBundle = {
  版本: string;
  geography: ExternalGeographyBundle;
  locations: Record<string, State['地点'][string]>;
  organizations: Record<string, ExternalOrganization>;
  legacyOrganizations?: Record<string, ExternalOrganization>;
  organizationRelations?: OrganizationRelation[];
  avatars: AvatarManifest;
};

export type ResolvedAvatar = {
  url: string;
  fallbacks: string[];
  heroName: string;
  matchedForm: string;
  availableForms: string[];
  relativePath: string;
};

export const defaultExternalSettingsUrl =
  typeof __CHENGWAN_EXTERNAL_SETTINGS_URL__ === 'string' && __CHENGWAN_EXTERNAL_SETTINGS_URL__ !== ''
    ? __CHENGWAN_EXTERNAL_SETTINGS_URL__.trim().replace(/\/+$/, '')
    : (settingsPaths.运行资料网址 || `http://localhost:5500/src/瓦罗兰/${settingsPaths.运行资料目录}`).replace(/\/+$/, '');

export const defaultAvatarBaseUrl =
  typeof __CHENGWAN_AVATAR_BASE_URL__ === 'string' && __CHENGWAN_AVATAR_BASE_URL__.trim()
    ? __CHENGWAN_AVATAR_BASE_URL__.trim().replace(/\/+$/, '')
    : new URL('../' + (settingsPaths.头像目录 ?? ''), defaultExternalSettingsUrl + '/').href.replace(/\/$/, '');

type SharedExternalSettingsStore = {
  bundle: ExternalSettingsBundle;
  externalBaseUrl: string;
  avatarBaseUrl: string;
  loaded: boolean;
  manifestSignature?: string;
  loadingBaseUrl: string | null;
  loadingPromise: Promise<ExternalSettingsBundle> | null;
  listeners: Set<() => void>;
};

function createEmptyExternalStore(): SharedExternalSettingsStore {
  return {
    bundle: {
      版本: '',
      geography: {
        版本: '',
        片区: {},
        districts: [],
        positions: {},
        locationNames: {},
        publicLandmarks: [],
      },
      locations: {},
      organizations: {},
      avatars: { heroes: {} },
    },
    externalBaseUrl: defaultExternalSettingsUrl,
    avatarBaseUrl: defaultAvatarBaseUrl,
    loaded: false,
    loadingBaseUrl: null,
    loadingPromise: null,
    listeners: new Set<() => void>(),
  };
}

const LOCAL_EXTERNAL_STORE = createEmptyExternalStore();

function getExternalStore(): SharedExternalSettingsStore {
  try {
    if (typeof window !== 'undefined') {
      const host = (window.parent && window.parent !== window ? window.parent : window) as any;
      if (host && typeof host === 'object') {
        if (!host.__valoranExternalSettingsStore) {
          host.__valoranExternalSettingsStore = LOCAL_EXTERNAL_STORE.loaded
            ? LOCAL_EXTERNAL_STORE
            : createEmptyExternalStore();
        }
        return host.__valoranExternalSettingsStore as SharedExternalSettingsStore;
      }
    }
  } catch {
    // 跨域或受限宿主回退到本地内存
  }
  return LOCAL_EXTERNAL_STORE;
}

function notify() {
  for (const fn of getExternalStore().listeners) {
    try {
      fn();
    } catch (error) {
      console.warn('[瓦罗兰外置设定] 监听通知异常', error);
    }
  }
}

export function subscribeExternalSettings(listener: () => void): () => void {
  const { listeners } = getExternalStore();
  listeners.add(listener);
  let active = true;
  const unsub = () => {
    if (!active) return;
    active = false;
    listeners.delete(listener);
    if (typeof window !== 'undefined') window.removeEventListener?.('pagehide', unsub);
  };
  if (typeof window !== 'undefined') window.addEventListener?.('pagehide', unsub, { once: true });
  return unsub;
}

export function isExternalSettingsLoaded() {
  return getExternalStore().loaded;
}

export function getExternalGeography(): ExternalGeographyBundle {
  return getExternalStore().bundle.geography;
}

export function getOrganizationSettings() {
  return getExternalStore().bundle;
}

export function getExternalOrganizations(): Record<string, ExternalOrganization> {
  return getExternalStore().bundle.organizations;
}

export function setExternalSettingsBundle(bundle: ExternalSettingsBundle) {
  const store = getExternalStore();
  store.bundle = {
    版本: bundle.版本 || bundle.geography?.版本 || '',
    geography: bundle.geography ?? store.bundle.geography,
    locations: bundle.locations ?? {},
    organizations: bundle.organizations ?? {},
    legacyOrganizations: bundle.legacyOrganizations,
    organizationRelations: bundle.organizationRelations,
    avatars: bundle.avatars ?? { heroes: {} },
  };
  store.loaded = true;
  notify();
}

/** 为 jsDelivr / GitHub Raw 派生多节点回退地址；本地开发直连单源。 */
export function buildExternalAssetFallbacks(url: string): string[] {
  const candidates: string[] = [];
  const push = (value?: string) => {
    if (value && !candidates.includes(value)) candidates.push(value);
  };
  push(url);
  const jsdelivr = /^https?:\/\/[^/]+\.jsdelivr\.net\/gh\/([^/]+)\/([^/@]+)@([^/]+)\/(.+)$/.exec(url);
  if (jsdelivr) {
    const [, owner, repo, ref, filePath] = jsdelivr;
    push(`https://testingcf.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
    push(`https://fastly.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
    push(`https://raw.githubusercontent.com/${owner}/${repo}/${ref}/${filePath}`);
  } else {
    const raw = /^https?:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/.exec(url);
    if (raw) {
      const [, owner, repo, ref, filePath] = raw;
      push(`https://cdn.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
      push(`https://testingcf.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
      push(`https://fastly.jsdelivr.net/gh/${owner}/${repo}@${ref}/${filePath}`);
    }
  }
  return candidates;
}

function encodePathSegments(relPath: string): string {
  return relPath
    .replaceAll('\\', '/')
    .split('/')
    .filter(Boolean)
    .map(segment => encodeURIComponent(segment))
    .join('/');
}

async function fetchJsonWithFallback(url: string, fetcher: typeof fetch) {
  const candidates = buildExternalAssetFallbacks(url);
  let lastError: unknown;
  for (const candidate of candidates) {
    try {
      const response = await fetcher(candidate, { cache: 'no-store' });
      if (!response.ok) throw Error(`HTTP ${response.status}: ${candidate}`);
      return await response.json();
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError ?? Error('外置设定读取失败：' + url);
}

/** A branch or development URL may publish new settings under the same name. */
export function refreshExternalSettingsOnMount() {
  const pinned = /(?:raw\.githubusercontent\.com\/[^/]+\/[^/]+\/|\.jsdelivr\.net\/gh\/[^/]+\/[^/@]+@)[0-9a-f]{40}\//i.test(defaultExternalSettingsUrl);
  return loadExternalSettings(defaultExternalSettingsUrl, fetch, pinned ? false : 'manifest');
}

/** 运行期从外置设定文件夹按 manifest 加载区域/地点/建筑/组织/头像清单，不硬编码进代码。 */
export async function loadExternalSettings(
  baseUrl?: string,
  fetcher: typeof fetch = fetch,
  force: boolean | 'manifest' = false,
): Promise<ExternalSettingsBundle> {
  const store = getExternalStore();
  const normalizedBase = (baseUrl ?? store.externalBaseUrl).trim().replace(/\/+$/, '');
  if (!force && store.loaded && normalizedBase === store.externalBaseUrl) return store.bundle;
  if (store.loadingPromise && normalizedBase === store.loadingBaseUrl) return store.loadingPromise;

  let run: Promise<ExternalSettingsBundle> | null = null;
  run = (async () => {
    const manifestUrl = `${normalizedBase}/manifest.json`;
    const manifest = await fetchJsonWithFallback(manifestUrl, fetcher);
    const files = manifest?.files ?? {};
    const signature = JSON.stringify([manifest?.版本, files]);
    if (force === 'manifest' && store.loaded && store.externalBaseUrl === normalizedBase && store.manifestSignature === signature)
      return store.bundle;
    const resolveRel = (rel: string) => `${normalizedBase}/${encodePathSegments(rel)}`;

    const [geoDoc, locDoc, orgDoc, avatarDoc] = await Promise.all([
      fetchJsonWithFallback(resolveRel(files.geography.path), fetcher),
      fetchJsonWithFallback(resolveRel(files.locations.path), fetcher),
      fetchJsonWithFallback(resolveRel(files.organizations.path), fetcher),
      files.avatars ? fetchJsonWithFallback(resolveRel(files.avatars.path), fetcher) : null,
    ]);

    const bundle: ExternalSettingsBundle = {
      版本: manifest?.版本 ?? geoDoc?.版本 ?? '',
      geography: geoDoc,
      locations: locDoc?.地点 ?? {},
      organizations: orgDoc?.组织 ?? {},
      legacyOrganizations: orgDoc?.旧版组织,
      organizationRelations: orgDoc?.组织关系,
      avatars: avatarDoc ?? { heroes: {} },
    };
    if (store.loadingPromise === run) {
      store.externalBaseUrl = normalizedBase;
      // 若构建期未显式注入非空头像根路径，则从外置设定路径推导同源头像目录。
      store.manifestSignature = signature;
      if (typeof __CHENGWAN_AVATAR_BASE_URL__ !== 'string' || !__CHENGWAN_AVATAR_BASE_URL__.trim()) {
        const directory = avatarDoc?.basePath ?? settingsPaths.头像目录 ?? '';
        store.avatarBaseUrl = new URL('../' + encodePathSegments(directory), normalizedBase + '/').href.replace(/\/$/, '');
      }
      setExternalSettingsBundle(bundle);
    }
    return bundle;
  })();

  store.loadingBaseUrl = normalizedBase;
  store.loadingPromise = run;
  try {
    return await run;
  } finally {
    if (store.loadingPromise === run) {
      store.loadingPromise = null;
      store.loadingBaseUrl = null;
    }
  }
}

/**
 * 解析角色多形态头像 URL：
 * - 依据 外置设定/头像/头像清单.json 中的真实文件名拼装，自动兼容 .jpg/.png/.webp 等任意后缀；
 * - 未匹配到指定形态时自动回退至该角色的公共默认形态（防剧透隐秘身份）。
 */
export function resolveCharacterAvatar(
  heroName: string | null | undefined,
  formName?: string | null,
  avatarBaseUrl?: string,
): ResolvedAvatar | null {
  const store = getExternalStore();
  const rawName = heroName?.trim();
  if (!rawName) return null;
  const heroes = store.bundle.avatars?.heroes ?? {};
  const cleanName = rawName.replace(/[（(][^）)]+[）)]/g, '').trim();
  const matchedHeroKey =
    (Object.hasOwn(heroes, rawName) && rawName) ||
    (cleanName.length > 0 && Object.hasOwn(heroes, cleanName) && cleanName) ||
    (cleanName.length > 0
      ? Object.keys(heroes).find(key => cleanName.includes(key) || key.includes(cleanName))
      : undefined);
  if (!matchedHeroKey) return null;

  const entry = heroes[matchedHeroKey];
  const forms = entry?.形态 ?? {};
  const availableForms = Object.keys(forms);
  if (!availableForms.length) return null;

  const requested = formName?.trim();
  let matchedForm: string | undefined;
  if (requested) {
    matchedForm =
      availableForms.find(name => name === requested) ??
      availableForms.find(name => name.toLowerCase() === requested.toLowerCase()) ??
      availableForms.find(name => requested.includes(name) || name.includes(requested));
  }
  matchedForm ??= forms[entry.默认形态] ? entry.默认形态 : availableForms[0];

  const relativePath = forms[matchedForm];
  if (!relativePath) return null;

  const base = (avatarBaseUrl ?? store.avatarBaseUrl).trim().replace(/\/+$/, '');
  const url = `${base}/${encodePathSegments(relativePath)}`;
  return {
    url,
    fallbacks: buildExternalAssetFallbacks(url),
    heroName: matchedHeroKey,
    matchedForm,
    availableForms,
    relativePath,
  };
}

const legacyFields = ['编号', '名称', '象限', '类型', '公开性质', '简介', '规则'] as const;
export function legacyAliases(state: State, bundle: ExternalSettingsBundle) {
  const aliases = new Map<string, string>();
  for (const [id, profile] of Object.entries(bundle.organizations)) {
    const old = profile.旧版id;
    if (!old || !bundle.legacyOrganizations?.[old]) continue;
    const local = state.组织[old], target = state.组织[id];
    // 有同名编号的玩家自建实体、或新旧两边都已有剧情时，保留各自记录。
    const oldProfile = bundle.legacyOrganizations[old];
    if ((target?.名称 && target.名称 !== profile.名称) || (local?.名称 && local.名称 !== oldProfile.名称) ||
        (local && target && !_.isEqual(local, oldProfile))) continue;
    aliases.set(old, id);
  }
  return aliases;
}

function migrateOrganizationState(state: State, bundle: ExternalSettingsBundle): State {
  const aliases = legacyAliases(state, bundle);
  const rows: State['组织'] = {};
  for (const [id, row] of Object.entries(state.组织)) {
    const base = bundle.legacyOrganizations?.[id] ?? bundle.organizations[id];
    const target = aliases.get(id) ?? id;
    if (!base || row.名称 && row.名称 !== base.名称) {
      rows[id] = row;
      continue;
    }
    const delta = { ...row };
    for (const key of legacyFields) if (row[key] === base[key]) delete delta[key];
    if (row.已知成员) {
      const changes = { ...row.成员变更 };
      for (const [person, value] of Object.entries(row.已知成员)) {
        if (!_.isEqual(base.已知成员?.[person], value) && !changes[person])
          changes[person] = { 关系: '正式成员', ...(value.职务 ? { 职务: value.职务 } : {}) };
      }
      for (const person of Object.keys(base.已知成员 ?? {}))
        if (!row.已知成员[person]) changes[person] ??= { 关系: '退出' };
      if (Object.keys(changes).length) delta.成员变更 = changes;
      delete delta.已知成员;
    }
    if (row.场所id) {
      const changes = { ...row.据点变更 };
      for (const place of row.场所id) if (!base.场所id?.includes(place)) changes[place] ??= '启用';
      for (const place of base.场所id ?? []) if (!row.场所id.includes(place)) changes[place] ??= '停用';
      if (Object.keys(changes).length) delta.据点变更 = changes;
      delete delta.场所id;
    }
    if (!delta.活动日程id?.length && !base.活动日程id?.length) delete delta.活动日程id;
    for (const key of ['成员变更', '据点变更'] as const) if (_.isEmpty(delta[key])) delete delta[key];
    if (Object.keys(delta).length) rows[target] = delta;
  }
  let result = _.isEqual(rows, state.组织) ? state : { ...state, 组织: rows };
  if (!aliases.size) return result;
  const ids = (list: string[]) => [...new Set(list.map(id => aliases.get(id) ?? id))];
  const control = state._系统.资料加载;
  const overrides = { ...control.组织覆盖 };
  for (const [old, id] of aliases) if (old in overrides) {
    overrides[id] ??= overrides[old];
    delete overrides[old];
  }
  const next = { ...control, 组织: ids(control.组织), 组织覆盖: overrides,
    轮候: { ...control.轮候, 组织: ids(control.轮候.组织) } };
  if (!_.isEqual(next, control)) result = { ...result, _系统: { ...result._系统, 资料加载: next } };
  const identity = state.玩家.身份;
  const playerIds = ids(identity.组织id);
  if (!_.isEqual(playerIds, identity.组织id))
    result = { ...result, 玩家: { ...state.玩家, 身份: { ...identity, 组织id: playerIds } } };
  for (const [id, person] of Object.entries(state.角色)) {
    const mapped = ids(person.组织id);
    if (!_.isEqual(mapped, person.组织id)) result = { ...result, 角色: { ...result.角色, [id]: { ...person, 组织id: mapped } } };
  }
  return result;
}

/** 区域和地点按版本补齐；旧组织记录与原始外置表比对，只保存本局差异。 */
export function hydrateStateFromExternalSettings(state: State, bundle: ExternalSettingsBundle = getExternalStore().bundle): State {
  const hasBundleData =
    Object.keys(bundle.geography.片区 ?? {}).length > 0 ||
    Object.keys(bundle.locations ?? {}).length > 0 ||
    Object.keys(bundle.organizations ?? {}).length > 0;
  if (!hasBundleData) return state;

  const needAreas = Object.keys(state.世界.片区).length === 0;
  const needLocations = Object.keys(state.地点).length === 0;
  const migrated = migrateOrganizationState(state, bundle);
  const versionChanged = Boolean(bundle.版本 && state._系统.资料加载.资料版本 !== bundle.版本);
  if (!needAreas && !needLocations && !versionChanged) return migrated;

  const areas = { ...state.世界.片区 };
  for (const [id, area] of Object.entries(bundle.geography.片区 ?? {})) {
    if (!areas[id]) areas[id] = copy(area);
  }

  const locations = { ...state.地点 };
  for (const [id, loc] of Object.entries(bundle.locations ?? {})) {
    if (!locations[id]) {
      locations[id] = copy(loc);
    } else if (versionChanged && locations[id].名称 === loc.名称) {
      const saved = locations[id];
      const previous = bundle.geography.calibratedLandmarks?.[id]?.previous;
      const useMapAnchor = previous && saved.片区id === loc.片区id && saved.上级地点id === loc.上级地点id &&
        saved.地图位置?.精度 === '地点' && saved.地图位置.x === previous[0] && saved.地图位置.y === previous[1];
      locations[id] = {
        ...locations[id],
        ...(useMapAnchor && { 地图位置: copy(loc.地图位置) }),
        层级: locations[id].层级 ?? loc.层级,
        简介: locations[id].简介 || loc.简介,
        进入条件: locations[id].进入条件 || loc.进入条件,
      };
    }
  }

  return {
    ...migrated,
    世界: { ...state.世界, 片区: areas },
    地点: locations,
    _系统: {
      ...migrated._系统,
      资料加载: {
        ...migrated._系统.资料加载,
        资料版本: bundle.版本 || state._系统.资料加载.资料版本,
      },
    },
  };
}
