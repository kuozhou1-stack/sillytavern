import { inject, type Ref } from 'vue';
import { resolveLocationName } from './entity';
export const StateKey = Symbol('瓦洛兰正式只读状态');
export function useWorldState<T = any>() {
  return inject<Ref<T>>(StateKey)!;
}
export function locationName(state: any, id: unknown) {
  return typeof id === 'string' && id ? resolveLocationName(state, id) : '未知';
}
export function show(value: any) {
  return value === null || value === undefined || value === '' ? '未知' : String(value);
}
