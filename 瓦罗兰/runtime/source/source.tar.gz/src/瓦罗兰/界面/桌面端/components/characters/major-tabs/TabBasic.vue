<template>
  <div class="cw-tab-pane cw-char-tab-basic">
    <!-- 1. 好感度与信任度双进度条卡片 -->
    <div class="cw-relation-bars-card">
      <div class="cw-rel-bar-group">
        <div
          class="cw-rel-bar-row"
          :class="{ 'is-unknown': favorValue === null }"
          tabindex="0"
          role="meter"
          aria-label="对玩家的好感度"
          :aria-valuemin="-100"
          :aria-valuemax="100"
          :aria-valuenow="favorValue ?? undefined"
          :aria-valuetext="favorTooltip"
          :data-cw-tooltip="favorTooltip"
          data-cw-tooltip-touch
        >
          <span class="cw-bar-label">好感</span>
          <div class="cw-bipolar-track">
            <div class="cw-track-half cw-track-neg">
              <div
                v-if="favorValue !== null && favorValue < 0"
                class="cw-fill-neg"
                :style="{ width: `${Math.min(100, Math.abs(favorValue))}%` }"
              ></div>
            </div>
            <div class="cw-bipolar-center"></div>
            <div class="cw-track-half cw-track-pos">
              <div
                v-if="favorValue !== null && favorValue > 0"
                class="cw-fill-pos"
                :style="{ width: `${Math.min(100, favorValue)}%` }"
              ></div>
            </div>
          </div>
        </div>

        <div
          class="cw-rel-bar-row"
          :class="{ 'is-unknown': trustValue === null }"
          tabindex="0"
          role="meter"
          aria-label="对玩家的信任度"
          :aria-valuemin="-100"
          :aria-valuemax="100"
          :aria-valuenow="trustValue ?? undefined"
          :aria-valuetext="trustTooltip"
          :data-cw-tooltip="trustTooltip"
          data-cw-tooltip-touch
        >
          <span class="cw-bar-label">信任</span>
          <div class="cw-bipolar-track cw-trust-track">
            <div class="cw-track-half cw-track-neg">
              <div
                v-if="trustValue !== null && trustValue < 0"
                class="cw-fill-neg"
                :style="{ width: `${Math.min(100, Math.abs(trustValue))}%` }"
              ></div>
            </div>
            <div class="cw-bipolar-center"></div>
            <div class="cw-track-half cw-track-pos">
              <div
                v-if="trustValue !== null && trustValue > 0"
                class="cw-fill-pos"
                :style="{ width: `${Math.min(100, trustValue)}%` }"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 2. 表里身份与所属组织 -->
    <div class="cw-char-section-card cw-section-archive">
      <h4 class="cw-section-title">
        <SvgIcon name="user" :size="15" />
        <span>公开身份与组织</span>
      </h4>

      <div class="cw-stack-list">
        <div class="cw-stack-field">
          <span class="cw-stack-k">身份</span>
          <OccupationTags :value="char?.身份" />
        </div>

        <div v-if="organizationNames.length" class="cw-stack-field">
          <span class="cw-stack-k">所属组织</span>
          <div class="cw-chip-row">
            <span v-for="org in organizationNames" :key="org.id" class="cw-org-chip">
              {{ org.name }}
            </span>
          </div>
        </div>

      </div>
    </div>

    <!-- 3. 人物简介 -->
    <div class="cw-char-section-card cw-section-bio">
      <h4 class="cw-section-title">
        <SvgIcon name="bookmark" :size="15" />
        <span>人物简介</span>
      </h4>
      <div class="cw-long-text-block">
        <p class="cw-prose-paragraph" :class="{ 'is-clamped': !bioExpanded && isBioLong }">
          {{ char?.简介 || '尚未登记人物简介' }}
        </p>
        <button
          v-if="isBioLong"
          type="button"
          class="cw-expand-toggle-btn"
          @click="emit('toggleExpand', 'basic:bio')"
        >
          <span>{{ bioExpanded ? '收起简介' : '展开全文' }}</span>
          <SvgIcon :name="bioExpanded ? 'chevronUp' : 'chevronDown'" :size="12" />
        </button>
      </div>
    </div>

    <!-- 超凡能力 -->
    <div v-if="hasMagicAbility" class="cw-char-section-card cw-section-magic">
      <div class="cw-section-head-row">
        <h4 class="cw-section-title cw-title-inline">
          <SvgIcon name="star" :size="15" />
          <span>超凡能力</span>
        </h4>
        <span v-if="char?.超凡能力?.力量体系" class="cw-magic-system-pill">
          {{ char.超凡能力.力量体系 }}
        </span>
      </div>
      <div class="cw-stack-list">
        <div v-if="char?.超凡能力?.核心能力与媒介" class="cw-stack-field">
          <span class="cw-stack-k">核心能力与施法媒介</span>
          <p class="cw-stack-v">{{ char.超凡能力.核心能力与媒介 }}</p>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue';
import { useWorldState } from '../../../utils/context';
import { resolveOrganizationName } from '../../../utils/entity';
import { favorDescription, trustDescription } from '../../../utils/relationship-labels';
import { subscribeExternalSettings } from '../../../../../运行/external-settings';
import SvgIcon from '../../icons/SvgIcon.vue';
import OccupationTags from '../../shared/OccupationTags.vue';

const worldState = useWorldState();
const externalRevision = ref(0);
const stopExternalWatch = subscribeExternalSettings(() => {
  externalRevision.value++;
});
onBeforeUnmount(stopExternalWatch);

const props = defineProps<{
  char: any;
  expandedFields: Record<string, boolean>;
}>();

const emit = defineEmits<{
  (e: 'toggleExpand', field: string): void;
}>();

const bioExpanded = computed(() => !!props.expandedFields['basic:bio']);

const isBioLong = computed(() => {
  const text = props.char?.简介;
  if (!text || typeof text !== 'string') return false;
  return text.length > 180 || (text.match(/\n/g) || []).length >= 4;
});

const organizationNames = computed(() => {
  void externalRevision.value;
  const ids = props.char?.组织id;
  if (!Array.isArray(ids)) return [];
  return ids.filter(Boolean).map((id: string) => ({
    id,
    name: resolveOrganizationName(worldState.value, id),
  }));
});

const hasMagicAbility = computed(() => {
  const m = props.char?.超凡能力;
  return Boolean(m && (m.力量体系 || m.核心能力与媒介));
});

const relationWithPlayer = computed(() => {
  const net = props.char?.关系网;
  if (!net) return null;
  return net[worldState?.value?.玩家?.id] ?? null;
});

const favorValue = computed(() => relationWithPlayer.value?.好感度 ?? null);
const trustValue = computed(() => relationWithPlayer.value?.信任度 ?? null);
const favorTooltip = computed(() => favorDescription(favorValue.value));
const trustTooltip = computed(() => trustDescription(trustValue.value));
</script>

<style scoped lang="scss">
.cw-char-tab-basic {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-relation-bars-card,
.cw-char-section-card {
  padding: 16px 18px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-section-magic {
  border-left: 3px solid var(--cw-info);
}

.cw-section-companion {
  border-left: 3px solid var(--cw-accent);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-section-head-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);

  .cw-title-inline {
    margin: 0;
    padding: 0;
    border: 0;
  }
}

.cw-magic-system-pill {
  font-size: 11.5px;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: var(--cw-radius-full);
  background: var(--cw-tag-info-bg, var(--cw-info-bg));
  color: var(--cw-tag-info-text, var(--cw-info));
  border: 1px solid var(--cw-tag-info-border, var(--cw-info));
  line-height: 1.4;
}

/* 关系轨卡片 */
.cw-relation-bars-card {
  padding: 12px 16px;
}

.cw-rel-bar-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cw-rel-bar-row {
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr);
  align-items: center;
  gap: 10px;
  min-height: 18px;
  cursor: help;
  border-radius: 3px;
}

.cw-rel-bar-row:focus-visible {
  outline: 2px solid var(--cw-accent);
  outline-offset: 3px;
}

.cw-bar-label {
  font-size: 11px;
  font-weight: 500;
  color: var(--cw-text-secondary);
}

.is-unknown :is(.cw-bipolar-track, .cw-trust-track) {
  background: repeating-linear-gradient(120deg, var(--cw-bg-card-subtle) 0 5px, var(--cw-border) 5px 7px);
}

.cw-bipolar-track {
  width: 100%;
  height: 11px;
  background: var(--cw-bg-card-subtle);
  border-radius: var(--cw-radius-full);
  border: 1px solid var(--cw-border);
  display: flex;
  position: relative;
  overflow: hidden;

  .cw-track-half {
    flex: 1;
    height: 100%;
    position: relative;
  }

  .cw-track-neg {
    display: flex;
    justify-content: flex-end;
  }

  .cw-fill-neg {
    height: 100%;
    background: linear-gradient(90deg, #dc3545, #e67e22);
    border-radius: var(--cw-radius-full) 0 0 var(--cw-radius-full);
    transition: width 0.3s;
  }

  .cw-fill-pos {
    height: 100%;
    background: linear-gradient(90deg, #c4783c, #e6a23c);
    border-radius: 0 var(--cw-radius-full) var(--cw-radius-full) 0;
    transition: width 0.3s;
  }

  .cw-bipolar-center {
    width: 2px;
    height: 100%;
    background: var(--cw-text-muted);
    z-index: 2;
  }
}

.cw-stack-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-stack-field {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 0;

  .cw-stack-k {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
    color: var(--cw-text-secondary);
  }

  .cw-stack-v {
    margin: 0;
    font-size: 13.5px;
    line-height: 1.72;
    color: var(--cw-text-primary);
    white-space: pre-wrap;
    word-break: break-word;
    overflow-wrap: anywhere;
  }
}

.cw-callout-caution {
  padding: 10px 12px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-tag-warning-bg, var(--cw-warning-bg));
  border: 1px solid var(--cw-tag-warning-border, var(--cw-border));
  border-left: 3px solid var(--cw-warning);

  .cw-stack-k {
    color: var(--cw-tag-warning-text, var(--cw-warning));
  }
}

.cw-chip-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.cw-org-chip {
  padding: 3px 10px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-tag-neutral-bg, var(--cw-bg-card-subtle));
  border: 1px solid var(--cw-tag-neutral-border, var(--cw-border));
  font-size: 12px;
  font-weight: 500;
  color: var(--cw-tag-neutral-text, var(--cw-text-primary));
  line-height: 1.45;
}

.cw-long-text-block {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 100%;
}

.cw-prose-paragraph {
  margin: 0;
  font-size: 13.5px;
  line-height: 1.78;
  color: var(--cw-text-primary);
  white-space: pre-wrap;
  word-break: break-word;
  overflow-wrap: anywhere;

  &.is-clamped {
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

.cw-expand-toggle-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-top: 6px;
  padding: 3px 10px;
  border-radius: var(--cw-radius-sm);
  border: 1px solid var(--cw-tag-accent-border, var(--cw-border));
  background: var(--cw-tag-accent-bg, var(--cw-bg-card-subtle));
  color: var(--cw-tag-accent-text, var(--cw-accent));
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s ease;

  &:hover {
    filter: brightness(0.96);
  }
}
</style>
