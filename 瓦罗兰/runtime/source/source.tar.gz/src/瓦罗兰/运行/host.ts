import { validateSettlement, validateUse, type UseIntent } from './settlement';
import { phoneBudget } from './phone-budget';
import { normalizePhoneRecordPatches } from './model-phone-patch';
import { phoneRequestIdentity, type PhoneRequestIdentity, type PhoneRequestState, type PhoneRequestStatus, type PhoneActionResult } from './phone-request';
import { finalizeWorld, normalizeWorldAnchorPatches, restoreWorldAnchors } from './world';
import { reactive, toRaw } from 'vue';
import { sha256 } from './browser-crypto';
import { requestBrowserLock, type BrowserLock } from './browser-lock';
import { livePromptConfig, nativePromptConfig, variableRulePrompts } from './prompts';
import { normalizeGeographicNames } from './地理名称';
import { normalizeWorldInformation } from './世界资料';
import { normalizeMapLandmarks } from './地图地标';
import {
  prepareInformationCommand, informationSelectionPrompt, recentInformationFloors,
  hasAutomaticInformation, hasActiveMultiFormCharacters, ensureFreeOpeningInformation,
  assertInformationPatch, type InformationKind, type InformationMode,
  ensureInformationContext, expandInformationForRetry, InformationNotLoadedError,
  parseInformationSelection, applyInformationSelectionValues,
} from './knowledge-context';
import { mergeOpeningTasks, planOpeningCharacters, openingMessage } from './opening';
import { taskReceipt, type UpdateReceipt } from './update-receipt';
import { planTasks } from './tasks';
import { pendingUpdateTasks, withUpdateTasks, finalizeUpdateTasks, MissingRosterProgressError } from './update-tasks';
import { phoneTimePrompt } from './phone';
import { applyPhoneAction, assertPhoneActionNotRepeated, blockText, finalizePhone, type PhoneAction } from './phone';
import { Schema } from '../schema';
import { messageSource, reconcileMessageSource, assertMessageSource, sourceDifference, MessageSourceError, MessageSourceSchema, sameAssistantFloorText, assistantFloorTextVariants, type MessageSource } from './request-source';
import { RequestScheduler } from './scheduler';
import {
  CommitService,
  assertContext,
  copy,
  countRound,
  equal,
  uid,
  validateModel,
  assertModelPrivatePatches,
  type Context,
  type State,
} from './core';
import { committedChanges } from './commit-replay';

import { SettingsSchema, createSettingsController, validateApi, isApiConfigured, apiConnection, informationApi, type ApiSettings, type SettingsChannel, type SettingsScope } from './settings';
import { ApiProviderError } from './generation/provider-error';
import { atmospherePrompt } from './atmosphere';
import { stripProtocol, storedNarrative, updateBlock, protocolJson } from './message-protocol';
import { createPromptRequestContext, preparePromptWorldbook, type PromptRequestContext } from './prompt-context';
import { PatchArraySyntaxError, variableResponseBlock, variableResponseSchema, type VariableReplyFormat } from './variable-response';
import {
  extractEditableVariableOutput,
  assembleEditedVariableOutput,
  type StoredVariableOutput,
  type VariableOutputChannel,
  type VariableOutputIndexEntry,
  type VariableOutputRecord,
} from './variable-inspector';
import {
  VARIABLE_OUTPUTS_KEY,
  appendStoredVariableOutput,
  buildActivePendingVariableRecord,
  buildVariableOutputIndex,
  listVariableOutputEntries,
  parseStoredVariableOutputs,
  selectVariableOutputRecord,
  toVariableOutputRecord,
  type VariableOutputTarget,
} from './variable-output-store';
import { withPromptInstructions, promptProjections } from './model-history';
import { savedChanges, storyChangeStatus, type StorySettlement } from './variable-changes';
import { applyCommitReplay, replayAfterStory, MissingCommitReplay, type CommitReplay } from './commit-replay';
import { legacyStoryReplay } from './story-backup';
import { CandidateIdentityError, isCommittedCandidate } from './committed-candidate';
import { assertMvuCommandResult, MVU_SETTLEMENT_PROBE } from './mvu-schema';
import { assertPatchOperations, settlePatchGroups } from './partial-settlement';
import { patchGroup } from './patch-group';
import { persistChat } from './chat-persistence';
import { LIBRARY_KEY, LibrarySchema, libraryRevision, libraryView, prepareLibraryCommand, exportManagedCharacter, type CharacterLibrary, type LibraryCommand, type LibraryView } from './character-library';
import {
  STATIC_PROFILE_KEY,
  applyCharacterFormSelections,
  stageCharacterProfiles,
  getLegalCharacterForms,
  exportStaticProfilesObject,
  loadStaticProfilesFromObject,
} from './character-static';
import { isExternalSettingsLoaded, loadExternalSettings, subscribeExternalSettings } from './external-settings';
import { prepareCharacterRoster, prepareOpeningCharacterRoster, restoreOpeningCharacterSources, characterSelectionContext } from './character-roster';
import { createProfile, createProfileWithRoster, initialConnectionIds } from './creation';
import { assertDisabledUnchanged, taskHasActiveTargets } from './character-activity';
import { applyNovelAction, refreshNovelSystem, type NovelAction } from './novel-system';
import { applyNovelRefresh, novelRefreshPrompt, type NovelRefreshTarget } from './novel-refresh';
const normalizeRuntimeWorld = (state: State): State =>
  normalizeWorldInformation(normalizeMapLandmarks(normalizeGeographicNames(state)));

export { stripProtocol } from './message-protocol';
export { SettingsSchema } from './settings';
export type { PhoneRequestIdentity, PhoneRequestState, PhoneRequestStatus, PhoneActionResult } from './phone-request';
export type { VariableOutputChannel, VariableOutputIndexEntry, VariableOutputRecord, VariableOutputState } from './variable-inspector';
// Tavern logs event-listener exceptions without rejecting parseMessage. Keep the
// rejection on that exact candidate so a rolled-back update cannot look successful.
const rejectedMvuCandidates = new WeakMap<Mvu.MvuData, unknown>();
type CandidateCheck = (before: State, candidate: Mvu.MvuData) => State;
async function parseCandidate(
  text: string, envelope: Mvu.MvuData, fromStory: boolean, check: CandidateCheck, warnings?: string[], retryMissingInformation = false, useItem = false, blocked = new Set<string>(),
) {
  let { commands } = updateBlock(text, fromStory, warnings, blocked);
  const useGroup = (group: string) => group === '玩家' || group === '玩家/资金与物品栏' || group.startsWith('玩家/当前状态') || group === '事件' || group.startsWith('事件/');
  if (useItem && [...blocked].some(useGroup)) {
    commands = commands.filter((patch, index) => !useGroup(patchGroup(patch as { path?: string } | null, index)));
    warnings?.push('本次物品使用的扣量、效果与事件一并跳过');
    if (!commands.length) throw Error(warnings?.join('\n'));
  }
  const base = copy(envelope);
  // 旧存档只在候选快照内补新分组，不改活动楼层，也不放宽只读字段校验。
  if (!Object.hasOwn(base.stat_data, '奇遇系统')) base.stat_data.奇遇系统 = Schema.parse({}).奇遇系统;
  base.stat_data.委托 ??= {};
  if (!Object.hasOwn(base.stat_data._系统 ?? {}, '资料加载'))
    _.set(base.stat_data, '_系统.资料加载', Schema.parse({})._系统.资料加载);
  const before = Schema.parse(base.stat_data);
  const apply = async (group: readonly unknown[]) => {
    assertPatchOperations(group);
    const normalized = normalizePhoneRecordPatches(before, normalizeWorldAnchorPatches(before, group));
    assertInformationPatch(before, normalized);
    assertModelPrivatePatches(before, normalized);
    // Give MVU only the extracted commands, without preset markup or explanation examples.
    const safeBlock = `<UpdateVariable><JSONPatch>${protocolJson(normalized)}</JSONPatch></UpdateVariable>`;
    const parsed = normalized.length || group.length === 0
      ? await Mvu.parseMessage(safeBlock, { ...copy(base), [MVU_SETTLEMENT_PROBE]: true })
      : undefined;
    if (parsed && rejectedMvuCandidates.has(parsed)) {
      const error = rejectedMvuCandidates.get(parsed);
      rejectedMvuCandidates.delete(parsed);
      throw error;
    }
    if (parsed) {
      assertMvuCommandResult(parsed);
      delete parsed[MVU_SETTLEMENT_PROBE];
    }
    if (!parsed && normalized.length) throw Error('MVU 未返回更新候选');
    const result = parsed ?? base;
    const candidate = { ...result, stat_data: restoreWorldAnchors(before, result.stat_data) };
    return { envelope: candidate, state: check(before, candidate) };
  };
  if (!warnings) return { value: await apply(commands), warnings: [] };
  const result = await settlePatchGroups(commands, apply, candidate => !equal(candidate.envelope.stat_data, base.stat_data),
    retryMissingInformation, (patch, index) => {
      const group = patchGroup(patch, index);
      if (useItem && useGroup(group))
        return '物品使用';
      const path = patch?.path?.split('/');
      if (path?.[1] === '角色' && path[2] && path[3] && Object.hasOwn(before.角色, path[2].replaceAll('~1', '/').replaceAll('~0', '~')))
        return group + '/' + path[3];
      return group;
    });
  if (warnings.length && equal(result.value.envelope.stat_data, base.stat_data)) throw Error(warnings.join('\n'));
  return { value: result.value, warnings: [...warnings, ...result.warnings] };
}
function messageExtra(message: { extra?: Record<string, any> } | undefined): Record<string, any> {
  const outer = message?.extra ?? {};
  const nested = outer.extra && typeof outer.extra === 'object' ? outer.extra : {};
  const plain = { ...outer };
  delete plain.extra;
  return { ...nested, ...plain };
}
export function activeContext(lastFloor = getLastMessageId()): Context {
  const chat = SillyTavern.getCurrentChatId();
  if (!chat) throw Error('请先打开瓦洛兰聊天');
  const active = (() => {
    for (let end = lastFloor; end >= 0; end -= 10) {
      const floors = getChatMessages(`${Math.max(0, end - 9)}-${end}`, { role: 'assistant', include_swipes: true });
      for (const f of floors.reverse()) {
        const data = f.swipes_data[f.swipe_id]?.stat_data;
        const extra = messageExtra({ extra: f.swipes_info[f.swipe_id] });
        if (extra.cw_incomplete || extra.cw_update_pending) continue;
        // MVU can copy the previous floor's data into an unfinished reply. Its floor id
        // still points at the previous committed floor, so it must not become the base.
        const committedFloor = data?._系统?.楼层id;
        const committed = isCommittedCandidate(data, f.message_id, f.swipe_id);
        if (committedFloor === f.message_id && !committed)
          throw new CandidateIdentityError('所选候选的变量属于其他候选，请返回已结算候选或重新生成');
        if (committed) return f;
      }
    }
    return undefined;
  })();
  if (!active) throw Error('尚未找到已初始化的助手状态楼层');
  const raw = Mvu.getMvuData({ type: 'message', message_id: active.message_id }).stat_data;
  const branch = `${chat}:${active.message_id}:${active.swipe_id}`;
  return {
    chat,
    floor: active.message_id,
    swipe: active.swipe_id,
    branch,
    version: raw._系统?.数据版本 ?? 0,
    fingerprint: JSON.stringify(raw),
  };
}
/** A source mismatch whose recovery records and player notice were already handled by send(). */
class StaleStoryRequestError extends MessageSourceError {}

function storySource(source: MessageSource, id?: string, continuation = false): MessageSource {
  // Old failed sends also saved a continuation flag. Landed replies retain the continue_ action ID.
  const start = source?.at(-1);
  if (!start || start.continuationStart || !(continuation || id?.startsWith('continue_'))) return source;
  return [...source.slice(0, -1), { ...start, continuationStart: true }];
}

type VariableUpdateRequest = {
  id: string;
  warnings?: string[];
  retryIssue?: { kind: 'patch-syntax'; line?: number; column?: number } | { kind: 'missing-progress'; targets: number };
};

function variableRetryPrompt(issue: VariableUpdateRequest['retryIssue']) {
  if (issue?.kind === 'patch-syntax') {
    const location = Number.isSafeInteger(issue.line) && Number.isSafeInteger(issue.column)
      ? `（第 ${issue.line} 行，第 ${issue.column} 列）` : '';
    return `本次待办曾返回语法无效的 JSONPatch 字符串，内层数组无法解析${location}。请按当前格式把本轮完整补丁数组写入 JSONPatch 字符串，检查字段名、引号和逗号。`;
  }
  if (issue?.kind === 'missing-progress' && Number.isSafeInteger(issue.targets))
    return `本次待办的一份回包未产生业务变化，要求更新的 ${issue.targets} 位人物实际覆盖 0 位。请按本轮生活检查及当前资料补全各目标的进展，输出完整结算。`;
  return '';
}

export function createRuntime(generateRequest: (config: GenerateConfig, context?: PromptRequestContext) => Promise<unknown> = generate,
  stopRequest: (id: string) => unknown = id => stopGenerationById(id)) {
  // Keep the original callback: Helper's returned stop handle loses this mapping.
  function listen<T extends EventType>(event: T, listener: ListenerType[T]): EventOnReturn {
    eventOn(event, listener);
    return { stop: () => eventRemoveListener(event, listener) };
  }
  const boundChat = SillyTavern.getCurrentChatId();
  const view = reactive({
    data: null as State | null,
    characterLibrary: null as LibraryView | null,
    managementPending: false,
    messages: [] as any[],
    hasEarlierMessages: false,
    totalMessages: 0,
    visibleMessageCount: 10,
    busy: false,
    updating: false,
    generationId: null as string | null,
    error: '',
    canResend: false,
    canAutoRead: false,
    loadError: '',
    loading: false,
    loadPhase: '' as '' | 'read' | 'worldbook' | 'recovery',
    settingsWarning: '',
    settlementWarning: '' as string,
    settlementWarningId: '',
    streaming: '',
    readOnly: false,
    operation: '',
    phase: '',
    updates: [] as UpdateReceipt[],
    activeNovelTarget: null as NovelRefreshTarget | null,
    queued: [] as { id: string; label: string; kind: string; target?: NovelRefreshTarget }[],
    recoverable: [] as { id: string; label: string; kind: string; preview: string; target?: NovelRefreshTarget }[],
    phoneRequest: null as PhoneRequestState | null,
    variableOutput: null as VariableOutputRecord | null,
    variableOutputIndex: {} as Record<string, VariableOutputIndexEntry>,
  });
  let errorSource: 'candidate' | 'operation' | 'source' = 'operation';
  function setError(error: unknown) {
    errorSource = error instanceof CandidateIdentityError ? 'candidate' : 'operation';
    view.canResend = false;
    view.error = String(error);
  }
  function setSourceChangeError(message: string) {
    setError(message);
    errorSource = 'source';
    updateResendState();
  }
  function updateResendState() {
    if (errorSource !== 'source') return;
    view.canResend = !view.readOnly && !view.loadError && !disposed &&
      SillyTavern.getCurrentChatId() === boundChat && !pending && !failedSend && !pendingPhone &&
      !intents.length && !getVariables({ type: 'chat' }).澄湾待确认提交 && !firstUnsettledNarrative();
  }
  function setLoadError(error: unknown, phase: 'read' | 'worldbook' | 'recovery' = 'read') {
    view.loadPhase = phase;
    view.loadError = error instanceof z.ZodError
      ? `存档字段“${error.issues[0]?.path.join('.') || '存档内容'}”格式不正确。`
      : String(error);
    setError(error instanceof CandidateIdentityError ? error : view.loadError);
    console.error('[瓦洛兰存档] 读取或恢复失败', error);
  }
  const settings = reactive(SettingsSchema.parse(getVariables({ type: 'character' }).澄湾设置));
  const settingsController = createSettingsController(requireWriter);
  let disposed = false;
  let receivedStory = '';
  let cancelled = false;
  let epoch = 0;
  const retryWakeups = new Set<() => void>();
  function waitRetryDelay(ms: number, startedEpoch: number) {
    return new Promise<void>(resolve => {
      if (cancelled || disposed || startedEpoch !== epoch) {
        resolve();
        return;
      }
      const done = () => {
        clearTimeout(timer);
        retryWakeups.delete(done);
        resolve();
      };
      const timer = setTimeout(done, ms);
      retryWakeups.add(done);
    });
  }
  let requestSource: MessageSource | undefined;
  let sourceChange: MessageSourceError | undefined;
  let releaseWriter: (() => void) | undefined;
  let writerLock: BrowserLock | undefined;
  let writerTask: Promise<void> | undefined;
  let chatWrites: Promise<unknown> = Promise.resolve();
  type OpeningPrewarmEntry = {
    signature: string;
    generationId: string;
    promise: Promise<string>;
    reply?: string;
    invalidated?: boolean;
  };
  let openingPrewarm: OpeningPrewarmEntry | null = null;
  function invalidateOpeningPrewarm() {
    if (!openingPrewarm) return;
    const current = openingPrewarm;
    openingPrewarm = null;
    current.invalidated = true;
    if (current.reply === undefined) {
      try {
        stopRequest(current.generationId);
      } catch {
        // 忽略已完成的预热中断
      }
    }
  }
  const IntentSchema = z.object({
    id: z.string(),
    chat: z.string(),
    label: z.string(),
    kind: z.enum(['story', 'phone', 'novel']),
    target: z.enum(['tasks', 'shop', 'initial']).optional(),
    text: z.string().optional(),
    append: z.boolean().optional(),
    inputSaved: z.boolean().optional(),
    opening: z.boolean().optional(),
    intent: z.object({ itemId: z.string(), amount: z.number() }).optional(),
    action: z
      .custom<PhoneAction>(
        v =>
          !!v &&
          typeof v === 'object' &&
          ['send', 'post', 'comment', 'like', 'repost', 'refresh', 'invite'].includes((v as PhoneAction).kind),
      )
      .optional(),
    source: MessageSourceSchema,
  });
  type Intent = z.infer<typeof IntentSchema>;
  let intents: Intent[] = [];
  function restoreIntents() {
    const restored = z.array(IntentSchema).safeParse(getVariables({ type: 'chat' }).澄湾排队操作 ?? []);
    if (!restored.success) {
      // The last parsed queue is no longer authoritative after a failed manual reread.
      // Invalidate only that memory view; leave the saved value available for repair.
      intents = [];
      updateQueueView();
      throw Error('待发送操作记录损坏，原记录已保留；请修复聊天备份后重新读取', { cause: restored.error });
    }
    intents = restored.data;
    updateQueueView();
  }
  const scheduled = new Set<string>();
  const submittedPhoneIdentities = new WeakMap<Intent, PhoneRequestIdentity>();
  const updateQueueView = () => {
    view.recoverable = intents
      .filter(i => !scheduled.has(i.id))
      .map(i => ({
        id: i.id,
        label: i.label,
        kind: i.kind,
        ...(i.kind === 'novel' && { target: i.target }),
        preview: i.text ?? i.action?.text ?? blockText(i.action?.blocks ?? []),
      }));
  };
  let phaseOwner = '';
  const scheduler = new RequestScheduler((active, waiting) => {
    if ((active?.key ?? '') !== phaseOwner) {
      phaseOwner = active?.key ?? '';
      if (active) view.phase = 'preparing';
      else if (!view.error) view.phase = '';
    }
    view.operation = active?.kind ?? '';
    view.activeNovelTarget = active?.kind === 'novel' ? intents.find(item => item.id === active.key)?.target ?? null : null;
    view.queued = waiting.filter(i => !i.background).map(i => ({
      id: i.key, label: i.label, kind: i.kind,
      ...(i.kind === 'novel' && { target: intents.find(item => item.id === i.key)?.target }),
    }));
    updateQueueView();
    updateReadAvailability();
  });
  updateQueueView();
  function requireWriter() {
    writerLock?.assertHeld();
    if (disposed || view.readOnly || SillyTavern.getCurrentChatId() !== boundChat)
      throw Error('当前页面已失效或不是活动写入界面，请重新打开');
  }
  function requireLoaded() {
    if (view.loading) throw Error('请先完成存档读取和恢复，再进行操作');
    if (view.loadError) {
      if (errorSource === 'candidate') throw new CandidateIdentityError(view.loadError);
      throw Error(view.loadError);
    }
    if (!view.data) throw Error('尚未读取到有效的存档状态');
  }
  // Recheck at the mutation itself, including error recovery after an awaited request.
  const createMessages = (...args: Parameters<typeof createChatMessages>) => {
    requireWriter();
    return createChatMessages(...args);
  };
  const setMessages = (...args: Parameters<typeof setChatMessages>) => {
    requireWriter();
    return setChatMessages(...args);
  };
  function writeStoryCandidate(floor: number, swipe: number, text: string, extra: Record<string, any>, data?: Mvu.MvuData) {
    const row = getChatMessages(floor, { include_swipes: true })[0];
    if (row?.message_id !== floor || row.swipe_id !== swipe) throw Error('正文候选已切换，请返回原候选后重试');
    const { swipes, swipes_data, swipes_info } = row;
    swipes[swipe] = text;
    if (data) swipes_data[swipe] = data;
    // 助手的候选数组写法保留其他 swipe_info；旧酒馆候选可把业务字段放在嵌套 extra 中。
    const info = _.isPlainObject(swipes_info[swipe]) ? swipes_info[swipe] : (swipes_info[swipe] = {});
    const cardFields = _.pickBy(extra, (_value, key) => key.startsWith('cw_'));
    for (const target of [info, info?.extra].filter(_.isPlainObject)) {
      for (const key of Object.keys(target)) if (key.startsWith('cw_')) delete target[key];
      Object.assign(target, cardFields);
    }
    return setMessages([{ message_id: floor, swipe_id: swipe, swipes, swipes_data, swipes_info }], { refresh: 'affected' });
  }
  const deleteMessages = (...args: Parameters<typeof deleteChatMessages>) => {
    requireWriter();
    return deleteChatMessages(...args);
  };
  const saveChat = () => {
    requireWriter();
    return persistChat();
  };
  // 保存等待期间仍可入队。只对本次待确认的出队项暂时隐藏，失败时按原顺序恢复。
  let confirmingRemovals: string[] = [];
  const queueForSave = () => intents.filter(item => !confirmingRemovals.includes(item.id));
  function patchChat(patch: Record<string, unknown>, removeIntents: string[] = []) {
    const saved = copy(patch);
    const operation = chatWrites.then(async () => {
      requireWriter();
      const previous = getVariables({ type: 'chat' });
      confirmingRemovals = removeIntents.filter(id => intents.some(item => item.id === id));
      if (confirmingRemovals.length || Object.hasOwn(saved, '澄湾排队操作')) saved.澄湾排队操作 = copy(queueForSave());
      if (!Object.keys(saved).length) return;
      try {
        await replaceVariables({ ...previous, ...saved }, { type: 'chat' });
        requireWriter();
        const readback = getVariables({ type: 'chat' });
        for (const key of Object.keys(saved)) {
          const expected = saved[key];
          if (!equal(readback[key], expected)) throw Error('聊天恢复记录保存不一致：' + key);
        }
        await saveChat();
        if (confirmingRemovals.length) {
          intents = queueForSave();
          updateQueueView();
        }
      } catch (error) {
        // Failed acknowledgement must not remove the only local recovery record.
        // 清除日志与原请求基线交接同属一次保存，失败时一起保留原恢复依据。
        if (!disposed && SillyTavern.getCurrentChatId() === boundChat) {
          try {
            requireWriter();
            const current = getVariables({ type: 'chat' });
            const restore = Object.fromEntries(Object.keys(saved)
              .filter(key => previous[key] != null && ((saved[key] === null && current[key] === null) ||
                (key === '澄湾失败请求' && saved.澄湾待确认提交 === null && equal(current[key], saved[key]))))
              .map(key => [key, previous[key]]));
            if (confirmingRemovals.length) restore.澄湾排队操作 = copy(intents);
            if (Object.keys(restore).length) await replaceVariables({ ...current, ...restore }, { type: 'chat' });
          } catch (restoreError) {
            console.warn('[瓦洛兰恢复记录] 保存失败后回退本地变量失败', restoreError);
          }
        }
        throw error;
      } finally {
        confirmingRemovals = [];
      }
    });
    chatWrites = operation.catch(() => {});
    return operation;
  }
  const persistIntents = (remove: string[]) => patchChat({}, remove);
  const saveIntents = (durable = false) => {
    requireWriter();
    if (durable) {
      updateQueueView();
      return patchChat({ 澄湾排队操作: [] });
    }
    const current = getVariables({ type: 'chat' });
    const saved = replaceVariables({ ...current, 澄湾排队操作: copy(queueForSave()) }, { type: 'chat' });
    updateQueueView();
    return Promise.resolve(saved);
  };
  type PendingStory = VariableUpdateRequest & {
    context: Context;
    text: string;
    reply?: string;
    replyFormat?: VariableReplyFormat;
    failedReply?: string;
    failedReplyFormat?: VariableReplyFormat;
    useEditedReply?: boolean;
    envelope: Mvu.MvuData;
    replyFloor?: number;
    replySwipe?: number;
    intent?: UseIntent;
    source: MessageSource;
    mode: 'main' | 'extra';
    variableApiOverride?: 'main';
    openingTaskId?: string;
    prepared?: {
      envelope: Mvu.MvuData;
      settlement: StorySettlement;
      variableOutput?: { rawText: string; replyFormat?: VariableReplyFormat; edited?: boolean; error?: string };
    };
    replay?: CommitReplay;
    revisionVersion?: number;
    editingOriginal?: { text: string; commitId: string };
  };
  let pending: PendingStory | null = getVariables({ type: 'chat' }).澄湾待更新正文 ?? null;
  let failedSend: {
    context: Context;
    text: string;
    intent?: UseIntent;
    source: MessageSource;
    id?: string;
    opening?: boolean;
    continuation?: boolean;
    append?: boolean;
  } | null = getVariables({ type: 'chat' }).澄湾失败请求 ?? null;
  if (pending) pending = { ...pending, source: storySource(pending.source, pending.id) };
  if (failedSend) failedSend = { ...failedSend, source: storySource(failedSend.source, failedSend.id, failedSend.continuation) };
  let pendingPhone: (VariableUpdateRequest & {
    context: Context;
    envelope: Mvu.MvuData;
    draft: State;
    action: PhoneAction;
    reply?: string;
    replyFormat?: VariableReplyFormat;
    failedReply?: string;
    failedReplyFormat?: VariableReplyFormat;
    editedReply?: boolean;
    candidate?: State;
    source?: MessageSource;
  }) | null = getVariables({ type: 'chat' }).澄湾待更新手机 ?? null;
  function setPhoneRequest(p: { id: string; action: PhoneAction; context: Context }, status: PhoneRequestStatus) {
    view.phoneRequest = { ...phoneRequestIdentity(p.id, p.action, p.context), status };
  }
  if (pendingPhone) setPhoneRequest(pendingPhone, 'failed');
  async function savePhone() {
    requireWriter();
    await patchChat({ 澄湾待更新手机: pendingPhone });
  }
  async function saveFailed() {
    requireWriter();
    const records = getVariables({ type: 'chat' });
    const journal = records.澄湾待确认提交;
    const committedJournal = failedSend && equal(failedSend.context, activeContext()) &&
      committedPreparation(journal, failedSend.context, service.host.read(failedSend.context.floor).stat_data as State, failedSend.id);
    await patchChat({
      澄湾失败请求: failedSend,
      ...(committedJournal ? { 澄湾待确认提交: null } : {}),
    });
  }
  async function savePending() {
    requireWriter();
    await patchChat({ 澄湾待更新正文: pending });
  }
  function readStoredVariableOutputs(): StoredVariableOutput[] {
    return parseStoredVariableOutputs(getVariables({ type: 'chat' })[VARIABLE_OUTPUTS_KEY]);
  }
  function nextStoredVariableOutputs(entry: StoredVariableOutput): StoredVariableOutput[] {
    return appendStoredVariableOutput(readStoredVariableOutputs(), entry);
  }
  function isLatestEditableSettledFloor(floor?: number, swipe?: number): boolean {
    if (
      disposed ||
      view.readOnly ||
      view.busy ||
      view.updating ||
      pending ||
      pendingPhone ||
      failedSend ||
      view.managementPending ||
      floor === undefined ||
      floor <= 0
    )
      return false;
    if (SillyTavern.getCurrentChatId() !== boundChat) return false;
    if (getVariables({ type: 'chat' }).澄湾待确认提交) return false;
    if (floor !== getLastMessageId()) return false;
    try {
      const current = activeContext();
      return current.floor === floor && current.swipe === (swipe ?? 0);
    } catch {
      return false;
    }
  }
  function currentActivePendingVariableRecord(storedList = readStoredVariableOutputs()): VariableOutputRecord | null {
    return buildActivePendingVariableRecord({
      storedList,
      pending,
      pendingPhone,
      failedLog: getVariables({ type: 'chat' }).澄湾最近解析失败,
      viewState: view,
    });
  }
  function refreshVariableOutputs() {
    if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return;
    const storedList = readStoredVariableOutputs();
    const active = currentActivePendingVariableRecord(storedList);
    const index = buildVariableOutputIndex(storedList, active);
    const latestStored = storedList.at(-1);
    const current: VariableOutputRecord | null =
      active ??
      (latestStored
        ? toVariableOutputRecord(latestStored, {
            editable: false,
            canResummarize:
              latestStored.channel !== 'phone' && isLatestEditableSettledFloor(latestStored.floor, latestStored.swipe),
          })
        : null);
    if (!equal(toRaw(view.variableOutput), current)) view.variableOutput = current;
    if (!equal(toRaw(view.variableOutputIndex), index)) view.variableOutputIndex = index;
  }
  function getVariableOutput(target?: VariableOutputTarget): VariableOutputRecord | null {
    if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return null;
    const storedList = readStoredVariableOutputs();
    return selectVariableOutputRecord({
      storedList,
      active: currentActivePendingVariableRecord(storedList),
      target,
      canResummarizeFloor: isLatestEditableSettledFloor,
    });
  }
  function listVariableOutputs(): VariableOutputIndexEntry[] {
    if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return [];
    const storedList = readStoredVariableOutputs();
    return listVariableOutputEntries(storedList, currentActivePendingVariableRecord(storedList));
  }
  async function narrativeRequest(p: NonNullable<typeof pending>) {
    return { id: p.id, context: p.context, source: p.source, intent: p.intent, openingTaskId: p.openingTaskId,
      mode: p.mode, reply: p.reply,
      replay: p.replay, revisionVersion: p.revisionVersion, editingOriginal: p.editingOriginal,
      narrativeHash: await sha256(new TextEncoder().encode(stripProtocol(p.text))) };
  }
  async function matchesNarrativeHash(hash: string, narrative: string, floor: number) {
    const matches = async (text: string) => hash === await sha256(new TextEncoder().encode(text));
    if (await matches(narrative)) return true;
    // 旧回执只有原文哈希，按与来源比较相同的编号规则还原待核对的文本。
    for (const text of assistantFloorTextVariants(narrative, floor)) {
      if (await matches(text)) return true;
    }
    return false;
  }
  function sameReplyNarrative(expected: string, current: string, floor: number) {
    return sameAssistantFloorText(stripProtocol(expected), stripProtocol(current), floor);
  }
  async function captureSavedNarrative(p: NonNullable<typeof pending>) {
    const saved = getChatMessages(p.replyFloor!)[0];
    // The completed create operation includes native/plugin receive processing.
    // Seal its readback once; retries must never adopt later edits this way.
    const generated = p.text;
    p.text = saved.message;
    if (sameReplyNarrative(generated, p.text, p.replyFloor!)) return;
    const extra = messageExtra(saved);
    extra.cw_story_request = await narrativeRequest(p);
    assertContext(p.context, activeContext());
    assertMessageSource(p.source, p.replyFloor);
    const current = getChatMessages(p.replyFloor!)[0];
    if (!current || !sameReplyNarrative(p.text, current.message, p.replyFloor!))
      throw Error('正文保存读回期间已被编辑，保留原请求供检查');
    await writeStoryCandidate(p.replyFloor!, p.replySwipe ?? 0, current.message, extra);
  }
  async function parseUpdate(text: string, envelope: Mvu.MvuData, channel: string, operation: VariableUpdateRequest, check: CandidateCheck, format?: VariableReplyFormat, retryMissingInformation = false) {
    try {
      const opening = operation === pending && !!pending.openingTaskId;
      const warnings = opening ? undefined : [] as string[];
      const blocked = new Set<string>();
      const result = await parseCandidate(format === undefined ? text : variableResponseBlock(text, format, warnings, blocked), envelope,
        operation === pending && pending.mode === 'main', check, warnings, retryMissingInformation, operation === pending && !!pending.intent, blocked);
      operation.warnings = result.warnings;
      return result.value;
    } catch (error) {
      // Keep the actual response and stack in the chat, outside stat_data/prompts.
      // A retry may request a new response, but must not erase the failed evidence.
      const { id } = operation;
      if (error instanceof PatchArraySyntaxError) operation.retryIssue = { kind: 'patch-syntax', ...error.location };
      await patchChat({
        ...(error instanceof PatchArraySyntaxError && operation === pending ? { 澄湾待更新正文: pending } : {}),
        澄湾最近解析失败: {
          channel, id, at: new Date().toISOString(),
          error: String(error), stack: error instanceof Error ? error.stack : undefined,
          ...(error instanceof Error && error.cause instanceof SyntaxError ? { cause: String(error.cause) } : {}),
          response: text,
        },
      });
      console.error('[瓦洛兰变量解析] 已保存原始回复与堆栈', { channel, id }, error);
      if (operation === pending && pending.mode === 'main' && error instanceof SyntaxError) {
        const recovery = pending.replyFloor === undefined
          ? '本次回复已保留，变量更新格式错误，正文楼层尚未建立。请取消本次待办后重新生成。'
          : '正文已保存，变量更新格式错误，尚未完成结算。请编辑本楼修正变量块，保存后点击“立即重试”。';
        throw new SyntaxError(recovery + error.message, { cause: error });
      }
      throw error;
    }
  }
  const service = new CommitService({
    context: () => {
      requireWriter();
      return activeContext();
    },
    read: floor => Mvu.getMvuData({ type: 'message', message_id: floor }),
    write: (data, floor) => {
      requireWriter();
      return Mvu.replaceMvuData(data, { type: 'message', message_id: floor });
    },
    persist: () => {
      requireWriter();
      return saveChat();
    },
    journal: async (value, alongside) => {
      requireWriter();
      const previous = getVariables({ type: 'chat' }).澄湾待确认提交;
      if (value === null && previous == null) return;
      if (value === null && recoverablePreparationJournal(previous)) {
        const resumed = { ...failedSend!, context: activeContext() };
        // 原请求的新基线与清除调度日志同次保存，避免二者之间失败后丢失衔接依据。
        await patchChat({ 澄湾待确认提交: null, 澄湾失败请求: resumed });
        failedSend = resumed;
      } else {
        const journal = value && previous?.requestId && previous.commitId === value.commitId
          ? { ...value, requestId: previous.requestId } : value;
        await patchChat({ ...alongside, 澄湾待确认提交: journal });
      }
    },
  });
  const settledTexts = new Map<string, { commitId?: string; text: string }>();
  function updateReadAvailability() {
    view.canAutoRead = !disposed && !!writerLock && !view.readOnly &&
      SillyTavern.getCurrentChatId() === boundChat && !!view.data && !view.loading && !view.loadError &&
      !view.busy && !view.updating && !pending && !pendingPhone && !failedSend &&
      !scheduler.active && !scheduler.waiting && !intents.length &&
      !getVariables({ type: 'chat' }).澄湾待确认提交;
    if (view.canAutoRead) {
      try { view.canAutoRead = !firstUnsettledNarrative(); }
      catch (error) {
        view.canAutoRead = false;
        setLoadError(error);
      }
    }
  }
  let visibleMessageCount = 10;
  let lastMessagesFingerprint: string | null = null;
  const messageObservers = new Set<() => void>();
  let stopMessageReconciliation: (() => void) | undefined;
  let lastParsedStateFingerprint: string | null = null;
  let lastStaticProfilesJson: string | null = null;
  function computeMessagesFastFingerprint(last: number, firstVisible: number): string | null {
    const archived = SillyTavern.chat as any[] | undefined;
    if (!Array.isArray(archived) || archived.length <= last) return null;
    const parts: unknown[] = [
      last,
      String(firstVisible),
      String(visibleMessageCount),
      pending?.id ?? '',
      String(pending?.replyFloor ?? ''),
      String(pending?.replySwipe ?? ''),
      String(pending?.mode ?? ''),
      pending?.reply ?? '',
      pendingPhone?.id ?? '',
      view.updating ? '1' : '0',
      view.busy ? '1' : '0',
      view.error,
    ];
    for (let i = firstVisible; i <= last; i++) {
      const row: Record<string, any> | undefined = archived[i];
      if (!row || typeof row !== 'object') return null;
      const swipe = typeof row.swipe_id === 'number' ? row.swipe_id : 0;
      const swipesInfo = row.swipe_info == null ? (swipe === 0 ? row.extra : undefined) : row.swipe_info[swipe];
      const extra = messageExtra({ extra: swipesInfo });
      // Helper reads candidate slots by index, including old object slots and messages with no variables.
      const system = row.variables?.[swipe]?.stat_data?._系统;
      const settlement = extra.cw_story_settlements?.[String(swipe)];
      const mes = typeof row.mes === 'string' ? row.mes : '';
      let mesHash = 2166136261;
      for (let c = 0; c < mes.length; c++) {
        mesHash ^= mes.charCodeAt(c);
        mesHash = Math.imul(mesHash, 16777619);
      }
      parts.push(
        [i, swipe, mes.length, mesHash >>> 0, row.is_user, row.extra?.type, row.is_system,
          !!extra.cw_incomplete, !!extra.cw_update_pending, settlement,
          system?.楼层id, system?.候选回复id, system?.数据版本, system?.提交记录?.[settlement?.commitId]?.数据版本],
      );
    }
    const storedVars = SillyTavern.chatMetadata?.variables ?? getVariables({ type: 'chat' });
    const failedLog = storedVars.澄湾最近解析失败;
    parts.push(storedVars[VARIABLE_OUTPUTS_KEY] ?? null, [failedLog?.id, failedLog?.at, failedLog?.error, failedLog?.response]);
    return JSON.stringify(parts);
  }
  function observeMessages(onReconciled: () => void) {
    if (disposed) return () => {};
    messageObservers.add(onReconciled);
    if (!stopMessageReconciliation) {
      const doc = window.parent?.document ?? (typeof document === 'undefined' ? undefined : document);
      const reconcile = () => {
        if (doc?.hidden) return;
        refreshMessages();
        for (const notify of messageObservers) {
          try { notify(); }
          catch (error) { console.warn('[瓦罗兰消息对账] 更新前端失败', error); }
        }
      };
      const timer = setInterval(reconcile, 2500);
      doc?.addEventListener?.('visibilitychange', reconcile);
      stopMessageReconciliation = () => {
        clearInterval(timer);
        doc?.removeEventListener?.('visibilitychange', reconcile);
        stopMessageReconciliation = undefined;
      };
    }
    return () => {
      if (messageObservers.delete(onReconciled) && !messageObservers.size) stopMessageReconciliation?.();
    };
  }
  function loadEarlierMessages(step = 10) {
    if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return;
    const last = getLastMessageId();
    const delta = Number.isFinite(step) && step > 0 ? Math.floor(step) : 10;
    visibleMessageCount = Math.min(Math.max(10, last), visibleMessageCount + delta);
    view.visibleMessageCount = visibleMessageCount;
    refreshMessages(true);
  }
  function refreshMessages(force = false) {
    if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return;
    const last = getLastMessageId();
    view.totalMessages = Math.max(0, last);
    if (last < 1) {
      lastMessagesFingerprint = null;
      view.hasEarlierMessages = false;
      if (view.messages.length) view.messages = [];
      refreshVariableOutputs();
      return;
    }
    const windowSize = Math.max(10, visibleMessageCount);
    const firstVisible = Math.max(1, last - windowSize + 1);
    view.hasEarlierMessages = firstVisible > 1;
    view.visibleMessageCount = windowSize;
    const fastFingerprint = computeMessagesFastFingerprint(last, firstVisible);
    if (!force && fastFingerprint !== null && fastFingerprint === lastMessagesFingerprint) return;
    const selected = getChatMessages(`${firstVisible}-${last}`, { include_swipes: true });
    // The helper's plain read clones the same variables again. Reuse selected
    // candidate data/metadata, but display the saved message, which may differ
    // from a stale swipe string after a preset or direct native edit.
    const archived = SillyTavern.chat;
    let previous: { floor: number; swipe: number; data: Record<string, unknown> } | undefined;
    for (let end = firstVisible - 1; end > 0 && !previous; end -= 10) {
      const prior = getChatMessages(`${Math.max(1, end - 9)}-${end}`, { role: 'assistant', include_swipes: true });
      for (const message of prior.reverse()) {
        const data = message.swipes_data[message.swipe_id]?.stat_data;
        if (!isCommittedCandidate(data, message.message_id, message.swipe_id)) continue;
        const extra = messageExtra({ extra: message.swipes_info[message.swipe_id] });
        const pendingSelected = pending?.replyFloor === message.message_id && pending?.replySwipe === message.swipe_id;
        if (extra.cw_incomplete || (extra.cw_update_pending && pendingSelected)) continue;
        previous = { floor: message.message_id, swipe: message.swipe_id, data };
        break;
      }
    }
    if (!previous) {
      const first = getChatMessages(0, { include_swipes: true })[0];
      const firstData = first?.swipes_data[first.swipe_id]?.stat_data;
      if (firstData) previous = { floor: 0, swipe: first.swipe_id, data: firstData };
    }
    const messages = selected
      .filter(m => m.message_id > 0 && m.role !== 'system')
      .map(m => {
        const swipe = m.swipe_id;
        const extra = messageExtra({ extra: m.swipes_info[swipe] });
        const data = m.swipes_data[swipe]?.stat_data;
        const history = extra.cw_story_settlements;
        const settlement = history && typeof history === 'object' ? history[String(swipe)] as StorySettlement : undefined;
        const committedSelected = isCommittedCandidate(data, m.message_id, swipe);
        const textKey = `${m.message_id}:${swipe}`;
        const remembered = settledTexts.get(textKey);
        if (m.role === 'assistant' && committedSelected && !extra.cw_update_pending &&
            (!remembered || remembered.commitId !== settlement?.commitId))
          settledTexts.set(textKey, { commitId: settlement?.commitId, text: archived[m.message_id]?.mes ?? m.swipes[swipe] });
        const pendingSelected = pending?.replyFloor === m.message_id && pending?.replySwipe === swipe;
        const isUpdatePending = !!extra.cw_update_pending && (pendingSelected || !committedSelected);
        const variableUpdate = m.role === 'assistant' ? storyChangeStatus({
          floor: m.message_id,
          swipe,
          data,
          previous,
          settlement,
          pending: isUpdatePending,
          failed: pendingSelected && !view.updating && !!view.error,
          receiving: !!extra.cw_incomplete,
        }) : undefined;
        if (m.role === 'assistant' && !extra.cw_incomplete && !isUpdatePending && committedSelected)
          previous = { floor: m.message_id, swipe, data };
        return {
          id: m.message_id,
          swipe,
          role: m.role,
          content: archived[m.message_id]?.mes ?? '',
          editContent: pendingSelected && pending?.mode === 'main' ? pending.reply : undefined,
          isIncomplete: !!extra.cw_incomplete,
          isUpdatePending,
          variableUpdate,
        };
      });
    if (
      messages.length !== view.messages.length ||
      messages.some((message, index) =>
        Object.entries(message).some(([key, value]) =>
          key === 'variableUpdate' ? JSON.stringify(value) !== JSON.stringify(view.messages[index]?.[key]) :
            value !== view.messages[index]?.[key]),
      )
    )
      view.messages = messages;
    refreshVariableOutputs();
    lastMessagesFingerprint = fastFingerprint;
  }
  function committedPreparation(journal: any, context: Context, state: State, requestId?: string) {
    return String(journal?.commitId ?? '').startsWith('information_selection_') &&
      (!requestId || !journal.requestId || journal.requestId === requestId) &&
      journal.context?.chat === context.chat && journal.context?.floor === context.floor &&
      journal.context?.swipe === context.swipe && journal.context?.branch === context.branch &&
      isCommittedCandidate(state, context.floor, context.swipe) &&
      !!state._系统.提交记录[journal.commitId];
  }
  function refresh() {
    if (disposed) return false;
    if (!pendingPhone && !view.busy) view.phoneRequest = null;
    try {
      const c = activeContext();
      const chatVariables = getVariables({ type: 'chat' });
      const savedStatic = chatVariables && Object.hasOwn(chatVariables, STATIC_PROFILE_KEY)
        ? chatVariables[STATIC_PROFILE_KEY]
        : undefined;
      {
        const staticJson = JSON.stringify(savedStatic ?? {});
        if (staticJson !== lastStaticProfilesJson) {
          lastStaticProfilesJson = staticJson;
          loadStaticProfilesFromObject(savedStatic);
        }
      }
      let data: State;
      if (view.data && lastParsedStateFingerprint === c.fingerprint) {
        data = toRaw(view.data);
      } else {
        data = normalizeRuntimeWorld(Schema.parse(service.host.read(c.floor).stat_data));
        if (lastParsedStateFingerprint === null || !equal(toRaw(view.data), data)) view.data = data;
        lastParsedStateFingerprint = c.fingerprint;
      }
      const characterLibrary = libraryView(data, chatVariables[LIBRARY_KEY]);
      if (!equal(toRaw(view.characterLibrary), characterLibrary)) view.characterLibrary = characterLibrary;
      const pendingJournal = chatVariables.澄湾待确认提交;
      const isCommittedPrepJournal = committedPreparation(pendingJournal, c, data);
      view.managementPending = Boolean(pendingJournal?.rollbackOnFailure && !isCommittedPrepJournal);
      const updates = chatVariables.澄湾更新回执;
      view.updates = Array.isArray(updates)
        ? updates.filter(
            r => r && Array.isArray(r.changed) && Array.isArray(r.targets) && view.data?._系统.提交记录[r.commitId],
          )
        : [];
      refreshMessages(true);
      if (errorSource === 'candidate') {
        view.loadError = '';
        view.loadPhase = '';
        setError('');
      }
      updateResendState();
      updateReadAvailability();
      return true;
    } catch (e) {
      lastParsedStateFingerprint = null;
      setLoadError(e);
      return false;
    }
  }
  let promptWorldbookPending = true;
  let variableSettingsWork: Promise<unknown> = Promise.resolve();
  // Keep the saved mode and its two worldbook entries in order. Generation runs after this short setup.
  function inVariableSettingsOrder<T>(run: () => Promise<T>): Promise<T> {
    const next = variableSettingsWork.then(run, run);
    variableSettingsWork = next.catch(() => {});
    return next;
  }
  async function syncPromptWorldbook() {
    promptWorldbookPending = true;
    await preparePromptWorldbook(!settings.variable.independent, requireWriter);
    promptWorldbookPending = false;
  }
  async function saveSettings(input: unknown, channel?: SettingsScope) {
    requireWriter();
    const appearance = ['theme', 'font', 'fontSize', 'scale', 'lineHeight', 'letterSpacing', 'paragraphSpacing'];
    const appearanceOnly = channel === 'general' && !!input && typeof input === 'object' &&
      Object.keys(input).every(key => appearance.includes(key));
    if ((view.busy || view.updating) && channel !== 'atmosphere' && !appearanceOnly)
      throw Error('请等待当前请求完成或停止后保存设置');
    let result: Awaited<ReturnType<typeof settingsController.save>>;
    try {
      result = await settingsController.save(input, channel);
    } catch (error) {
      if (channel === 'general' && input && typeof input === 'object') {
        try {
          requireWriter();
          const actual = SettingsSchema.parse(getVariables({ type: 'character' }).澄湾设置);
          for (const key of Object.keys(input) as (keyof typeof settings)[]) {
            if (key in actual) Object.assign(settings, { [key]: actual[key] });
          }
        } catch (readError) {
          console.error('[瓦洛兰设置] 保存失败后读取当前设置失败', readError);
          throw Object.assign(Error('设置保存未确认，读取当前设置失败：' + String(readError), { cause: error }),
            { settingsUnconfirmed: true });
        }
      }
      throw error;
    }
    const { value, warning } = result;
    requireWriter();
    invalidateOpeningPrewarm();
    // Independent forms may finish in either order; only adopt the saved channel.
    Object.assign(settings, value);
    view.settingsWarning = warning;
    if (!channel || channel === 'variable')
      await syncPromptWorldbook();
    return warning;
  }
  async function reloadSettings(channel?: SettingsChannel) {
    requireWriter();
    if ((view.busy || view.updating) && channel !== 'atmosphere') throw Error('请等待当前请求完成或停止后同步设置');
    const { value, warning } = await settingsController.load(channel, copy(settings));
    requireWriter();
    invalidateOpeningPrewarm();
    if (channel === 'atmosphere') settings.atmosphere = value.atmosphere;
    else if (channel === 'information') settings.information = value.information;
    else if (channel === 'variable') settings.variable = value.variable;
    else if (channel) settings[channel] = value[channel];
    else Object.assign(settings, value);
    view.settingsWarning = warning;
    if (!channel || channel === 'variable')
      await syncPromptWorldbook();
    return warning;
  }
  function readAlertMemory(): Record<string, boolean> {
    return getVariables({ type: 'chat' }).澄湾告警 ?? {};
  }
  async function saveAlertMemory(value: Record<string, boolean>) {
    if (equal(readAlertMemory(), value)) return;
    await patchChat({ 澄湾告警: copy(value) });
  }
  async function commit(mutate: (s: State) => void | State, id = uid('commit'), skipUnchanged = false) {
    requireWriter();
    if (view.busy || view.updating || pending || pendingPhone || failedSend ||
        getVariables({ type: 'chat' }).澄湾待确认提交 || firstUnsettledNarrative())
      throw Error('请等待当前任务完成或恢复未确认提交后重试');
    view.updating = true;
    try {
      await service.commit(activeContext(), id, s => planTasks(refreshNovelSystem(mutate(s) || s)), false, undefined, skipUnchanged);
      const staticProfiles = exportStaticProfilesObject();
      if (!equal(getVariables({ type: 'chat' })[STATIC_PROFILE_KEY] ?? {}, staticProfiles)) {
        await patchChat({ [STATIC_PROFILE_KEY]: staticProfiles });
      }
      setError('');
      refresh();
    } catch (e) {
      setError(e);
      throw e;
    } finally {
      view.updating = false;
    }
  }
  function requireManagementIdle(operation = '管理角色') {
    requireWriter();
    if (view.busy || view.updating || pending || pendingPhone || failedSend || scheduler.active || scheduler.waiting ||
        intents.length || firstUnsettledNarrative() || getVariables({ type: 'chat' }).澄湾待确认提交)
      throw Error('当前正在生成、结算或有待恢复操作；请完成或取消后再' + operation);
  }
  function novelAction(input: NovelAction) {
    requireManagementIdle('操作奇遇系统');
    const action = copy(input), expected = activeContext();
    return foreground('local', async () => {
      assertContext(expected, activeContext());
      await commit(s => applyNovelAction(s, action), `novel:${action.operationId}`);
    }, `novel:${action.operationId}`);
  }
  function manageInformation(kind: InformationKind, id: string, mode: InformationMode) {
    requireManagementIdle('管理地点与组织资料');
    invalidateOpeningPrewarm();
    const expected = activeContext();
    return foreground('local', async () => {
      assertContext(expected, activeContext());
      await commit(state => prepareInformationCommand(normalizeRuntimeWorld(state), kind, id, mode), uid('information_management'));
    }, uid('information_management'));
  }
  function manageCharacters(input: LibraryCommand) {
    // Check before scheduling so a click during generation does not silently execute later.
    requireManagementIdle();
    invalidateOpeningPrewarm();
    const command = copy(input), expected = activeContext();
    return foreground('local', async () => {
      assertContext(expected, activeContext());
      view.updating = true;
      try {
        const before = Schema.parse(service.host.read(expected.floor).stat_data);
        const prepared = prepareLibraryCommand(before, getVariables({ type: 'chat' })[LIBRARY_KEY], command);
        // Snapshot and revision persistence must be acknowledged before removing any active record.
        await patchChat({ [LIBRARY_KEY]: prepared.library, [STATIC_PROFILE_KEY]: exportStaticProfilesObject() });
        assertContext(expected, activeContext());
        await service.commit(expected, uid('character_management'), () => prepared.state, true);
        epoch++;
        setError('');
        refresh();
        return { created: prepared.created, results: prepared.results };
      } catch (error) {
        setError(error);
        refresh();
        throw error;
      } finally { view.updating = false; }
    });
  }
  async function saveCreatedProfile(payload: Parameters<typeof createProfile>[1] & { submissionId?: string }) {
    requireWriter();
    if (view.busy || view.updating || pending || pendingPhone || view.managementPending)
      throw Error('请等待当前任务完成后建档');
    invalidateOpeningPrewarm();
    view.updating = true;
    try {
      const expected = activeContext(), before = Schema.parse(service.host.read(expected.floor).stat_data);
      const submissionId = payload.submissionId ?? uid('creation');
      if (!before._系统.提交记录[submissionId]) {
        const selectionPending = settings.characterAuto && settings.informationAuto;
        const currentLibrary = getVariables({ type: 'chat' })[LIBRARY_KEY];
        const staged = createProfileWithRoster(
          before,
          payload,
          currentLibrary,
          settings.characterRoster,
          selectionPending,
          settings.characterAuto,
        );
        if (staged.library) {
          await patchChat({ [LIBRARY_KEY]: staged.library, [STATIC_PROFILE_KEY]: exportStaticProfilesObject() });
          assertContext(expected, activeContext());
          await service.commit(expected, submissionId, () => planTasks(refreshNovelSystem(staged.state)), true);
        } else {
          const created = staged.state;
          const prepared = prepareOpeningCharacterRoster(
            created,
            currentLibrary,
            settings.characterRoster,
            initialConnectionIds(payload),
            selectionPending ? [] : undefined,
          );
          if (prepared) {
            prepared.revision.automatic!.opening!.selectionPending = selectionPending;
            await patchChat({ [LIBRARY_KEY]: prepared.library, [STATIC_PROFILE_KEY]: exportStaticProfilesObject() });
          } else {
            await patchChat({ [STATIC_PROFILE_KEY]: exportStaticProfilesObject() });
          }
          assertContext(expected, activeContext());
          await service.commit(expected, submissionId, () => planTasks(refreshNovelSystem(prepared?.state ?? created)), true);
        }
      }
      refresh();
      const opening = libraryRevision(view.data!, LibrarySchema.parse(getVariables({ type: 'chat' })[LIBRARY_KEY])).automatic?.opening;
      return {
        active: Object.keys(view.data!.角色).length,
        waiting: Object.values(view.characterLibrary!.meta).filter(person => !person.enabled).length,
        selectionPending: opening?.selectionPending === true,
      };
    } catch (error) {
      setError(error);
      refresh();
      throw error;
    } finally { view.updating = false; }
  }
  function prepareLocalStoryRoster(before: State, input: string, opening: boolean) {
    const library = getVariables({ type: 'chat' })[LIBRARY_KEY];
    const prepared = opening
      ? prepareOpeningCharacterRoster(before, library, settings.characterRoster)
      : !settings.characterAuto ? null : prepareCharacterRoster(before, library, input, undefined, settings.characterRoster);
    const state = prepared ? planTasks(prepared.state) : before;
    return {
      state: opening ? ensureFreeOpeningInformation(state, { 地点: settings.locationRoster, 组织: settings.organizationRoster }) : state,
      library: prepared?.library ?? null,
      rollbackOnFailure: Boolean(prepared),
    };
  }
  async function prepareWorldInformation() {
    if (!isExternalSettingsLoaded()) await loadExternalSettings();
    const expected = activeContext(), before = Schema.parse(service.host.read(expected.floor).stat_data);
    const normalized = normalizeRuntimeWorld(before);
    if (equal(before, normalized)) return;
    await service.commit(expected, uid('world_information_migration'), () => normalized);
    refresh();
  }
  function informationRetryHint(id: string) {
    const failed = getVariables({ type: 'chat' }).澄湾最近解析失败;
    const prefix = 'Error: 请先展开资料再更新：';
    return failed?.id === id && typeof failed.error === 'string' && failed.error.startsWith(prefix)
      ? '\n上一份结算请求需要先展开已有资料：' + failed.error.slice(prefix.length) : '';
  }
  function computeOpeningPrewarmSignature(state: State, source: MessageSource, config: GenerateConfig, inputFloor?: number): string | null {
    if (
      disposed ||
      view.readOnly ||
      SillyTavern.getCurrentChatId() !== boundChat ||
      !state._系统.建档完成 ||
      Object.keys(state._系统.已计轮事件).length > 0 ||
      !settings.informationAuto
    ) {
      return null;
    }
    const api = informationApi(settings);
    if (!isApiConfigured(api)) return null;
    return JSON.stringify({
      chat: boundChat,
      branch: activeContext().branch,
      history: recentInformationFloors(source, inputFloor).map(({ id, swipe, text, candidate }) => [id, swipe, text, candidate]),
      prompt: config.user_input,
      preset: getPreset('in_use'),
      saveId: state._系统.存档id,
      version: state._系统.数据版本,
      libraryRev: state._系统.角色库版本,
      informationAuto: settings.informationAuto,
      characterAuto: settings.characterAuto,
      characterRoster: settings.characterRoster,
      locationRoster: settings.locationRoster,
      organizationRoster: settings.organizationRoster,
      api,
    });
  }
  async function prewarmOpening(): Promise<boolean> {
    try {
      requireWriter();
    } catch {
      return false;
    }
    if (view.busy || view.updating || pending || pendingPhone || failedSend || view.managementPending) return false;
    if (!isExternalSettingsLoaded()) return false;
    let before: State;
    try {
      before = normalizeRuntimeWorld(Schema.parse(service.host.read(activeContext().floor).stat_data));
    } catch {
      return false;
    }
    const library = getVariables({ type: 'chat' })[LIBRARY_KEY];
    const characters = settings.characterAuto
      ? characterSelectionContext(before, library, settings.characterRoster, openingMessage)
      : undefined;
    const chooseCharacters = Boolean(characters && Object.keys(characters.目录).length > 0);
    const chooseForms = characters?.存在多形态候选 ?? hasActiveMultiFormCharacters(before);
    if (!hasAutomaticInformation(before) && !chooseCharacters && !chooseForms) return false;

    const quotas = { 地点: settings.locationRoster, 组织: settings.organizationRoster };
    const source = messageSource();
    const config = informationSelectionPrompt(
      before,
      openingMessage,
      source,
      { quotas, characters: chooseCharacters ? characters : undefined, chooseForms },
    );
    const signature = computeOpeningPrewarmSignature(before, source, config);
    if (!signature) return false;
    if (openingPrewarm?.signature === signature) {
      if (openingPrewarm.reply !== undefined) return true;
      return openingPrewarm.promise.then(() => true, () => false);
    }
    invalidateOpeningPrewarm();

    const api = informationApi(settings);
    const profile = api.mode === 'main' ? undefined : api;
    const native = nativePromptConfig({
      ...config,
      custom_api: profile ? apiConnection(profile) : undefined,
    });
    const generationId = uid('prewarm_generation');
    const entry: OpeningPrewarmEntry = {
      signature,
      generationId,
      promise: Promise.resolve(''),
    };
    openingPrewarm = entry;
    entry.promise = (async () => {
      const raw = await generateRequest(
        { ...native, generation_id: generationId, should_stream: false },
        createPromptRequestContext({
          purpose: 'knowledge',
          state: before,
          input: typeof native.user_input === 'string' ? native.user_input : undefined,
          phoneActive: false,
        }),
      );
      if (entry.invalidated || disposed || typeof raw !== 'string' || !raw.trim()) {
        throw Error('开局预热已取消或未返回有效内容');
      }
      parseInformationSelection(raw, chooseCharacters, chooseForms);
      entry.reply = raw;
      console.info('[瓦洛兰开局预热] 已静默完成开局资料与人物形态预选');
      return raw;
    })();
    try {
      await entry.promise;
      return openingPrewarm === entry && entry.reply !== undefined;
    } catch (error) {
      if (openingPrewarm === entry) openingPrewarm = null;
      console.info('[瓦洛兰开局预热] 后台预热未采用，正式开场时将实时选择', error);
      return false;
    }
  }
  async function selectInformationInMemory(
    before: State,
    input: string,
    key: string,
    retain = false,
    action?: PhoneAction,
    origin?: MessageSource,
    inputFloor?: number,
  ): Promise<{ state: State; library: CharacterLibrary | null; rollbackOnFailure: boolean }> {
    if (!settings.informationAuto) return { state: before, library: null, rollbackOnFailure: false };
    const library = getVariables({ type: 'chat' })[LIBRARY_KEY];
    const characters = settings.characterAuto ? characterSelectionContext(before, library, settings.characterRoster, input, action) : undefined;
    const chooseCharacters = Boolean(characters && Object.keys(characters.目录).length > 0);
    const chooseForms = characters?.存在多形态候选 ?? hasActiveMultiFormCharacters(before);
    if (before._系统.资料加载.选择依据 === key || (!hasAutomaticInformation(before) && !chooseCharacters && !chooseForms)) {
      return { state: ensureInformationContext(before, input), library: null, rollbackOnFailure: false };
    }
    const api = informationApi(settings);
    validateApi(api, '资料选择');
    const expected = activeContext(), source = origin ?? messageSource();
    const quotas = { 地点: settings.locationRoster, 组织: settings.organizationRoster };

    const config = informationSelectionPrompt(before, input, source,
      { quotas, characters: chooseCharacters ? characters : undefined, chooseForms, inputFloor });
    const recent = recentInformationFloors(source, inputFloor);
    let reply: string | undefined;
    const isOpeningTurn = !action && input === openingMessage && !Object.keys(before._系统.已计轮事件).length;
    const prewarmSig = isOpeningTurn ? computeOpeningPrewarmSignature(before, source, config, inputFloor) : null;
    if (openingPrewarm && openingPrewarm.signature !== prewarmSig) invalidateOpeningPrewarm();
    if (prewarmSig && openingPrewarm?.signature === prewarmSig && !openingPrewarm.invalidated) {
      const matchedPrewarm = openingPrewarm;
      if (matchedPrewarm.reply !== undefined) {
        reply = matchedPrewarm.reply;
        openingPrewarm = null;
      } else {
        view.phase = 'information';
        view.generationId = matchedPrewarm.generationId;
        try {
          reply = await matchedPrewarm.promise;
          if (openingPrewarm === matchedPrewarm) openingPrewarm = null;
        } catch (prewarmError) {
          if (cancelled || disposed) throw Error('生成已取消或上下文已变化', { cause: prewarmError });
          reply = undefined;
        } finally {
          if (view.generationId === matchedPrewarm.generationId) view.generationId = null;
        }
      }
    }

    if (reply === undefined) {
      reply = await requestExtra(config, before, api, 'knowledge');
    }

    assertContext(expected, activeContext());
    assertMessageSource(source);
    const latest = recentInformationFloors(reconcileMessageSource(source, messageSource()), inputFloor);
    if (recent.length !== latest.length || recent.some((floor, i) => sourceDifference({ ...floor, continuationStart: true }, latest[i])))
      throw Error('资料选择期间最近正文已变化，请重新选择资料');
    if (prewarmSig && computeOpeningPrewarmSignature(before, source, config, inputFloor) !== prewarmSig)
      throw Error('开局资料选择期间预设或候选已变化，请重试开场');
    const selection = parseInformationSelection(reply, chooseCharacters, chooseForms);
    return stageCharacterProfiles(() => {
      let selected = applyInformationSelectionValues(before, selection, key, retain, quotas, input, characters?.候选组织id);
      if (isOpeningTurn) selected = ensureFreeOpeningInformation(selected, quotas);
      const prepared = chooseCharacters
        ? characters!.开局
          ? prepareOpeningCharacterRoster(selected, library, settings.characterRoster, undefined, selection.人物!, characters!.保留人物id)
          : prepareCharacterRoster(selected, library, input, action, settings.characterRoster, selection.人物!)
        : null;
      if (prepared) {
        selected = planTasks(prepared.state);
      }
      const forms = Object.fromEntries(Object.entries(selection.角色形态 ?? {}).filter(([id]) => {
        if (!Object.hasOwn(selected.角色, id)) {
          if (selection.人物?.includes(id)) return false;
          throw Error('角色形态不属于本轮开启人物：' + id);
        }
        if (!chooseForms || getLegalCharacterForms(selected, id).forms.length <= 1)
          throw Error('角色形态只接受多形态人物：' + id);
        return true;
      }));
      selected = applyCharacterFormSelections(selected, forms);
      return {
        state: ensureInformationContext(selected, input),
        library: prepared ? prepared.library : null,
        rollbackOnFailure: Boolean(prepared),
      };
    });
  }
  async function selectInformation(before: State, input: string, key: string, retain = false, action?: PhoneAction, origin?: MessageSource) {
    const expected = activeContext(), source = origin ?? messageSource();
    const res = await selectInformationInMemory(before, input, key, retain, action, origin);
    if (res.library) {
      assertContext(expected, activeContext());
      assertMessageSource(source);
      await patchChat({ [LIBRARY_KEY]: res.library, [STATIC_PROFILE_KEY]: exportStaticProfilesObject() });
    }
    return res.state;
  }
  /**
   * 正文前准备态单次原子落盘：将角色库、静态档案库、恢复日志与准备后的楼层 `stat_data` 在同一次 `saveChat()` 中写入磁盘；
   * 正常路径仅触发 1 次 `saveChat()`（加玩家楼共 2 次），若该次落盘失败则回滚内存楼层并保留 `澄湾待确认提交` 供冷启动恢复。
   */
  async function commitPreStoryPreparation(
    expected: Context,
    commitId: string,
    nextState: State,
    nextLibrary: CharacterLibrary | null,
    rollbackOnFailure: boolean,
    requestId: string,
  ): Promise<State> {
    return service.run(async () => {
      assertContext(expected, activeContext());
      requireWriter();
      const envelope = copy(service.host.read(expected.floor));
      const before = Schema.parse(envelope.stat_data);
      const candidate = copy(nextState);
      candidate._系统.数据版本 = before._系统.数据版本 + 1;
      candidate._系统.存档id ??= uid('save');
      candidate._系统.分支id = expected.branch;
      candidate._系统.楼层id = expected.floor;
      candidate._系统.候选回复id = String(expected.swipe);
      candidate._系统.提交记录[commitId] = {
        任务id: null,
        事件id: [],
        数据版本: candidate._系统.数据版本,
        状态: '已写入',
        恢复候选JSON: null,
        变更JSON: JSON.stringify(committedChanges(before, candidate)),
      };
      const validated = Schema.parse(candidate);
      const recovery = { context: expected, commitId, requestId, candidate: validated, rollbackOnFailure };
      const staticProfiles = exportStaticProfilesObject();
      const previousVars = getVariables({ type: 'chat' });
      const staticChanged = !equal(previousVars[STATIC_PROFILE_KEY] ?? {}, staticProfiles);
      const chatPatch: Record<string, unknown> = {
        澄湾待确认提交: recovery,
        ...(nextLibrary ? { [LIBRARY_KEY]: copy(nextLibrary) } : {}),
        ...(staticChanged ? { [STATIC_PROFILE_KEY]: staticProfiles } : {}),
      };

      const writeOp = chatWrites.then(async () => {
        requireWriter();
        assertContext(expected, activeContext());
        assertMessageSource(requestSource);
        if (disposed || cancelled) throw Error('正文准备已取消');
        const latestVars = getVariables({ type: 'chat' });
        await replaceVariables({ ...latestVars, ...chatPatch }, { type: 'chat' });
        const readbackVars = getVariables({ type: 'chat' });
        for (const key of Object.keys(chatPatch)) {
          if (!equal(readbackVars[key], chatPatch[key])) throw Error('聊天恢复记录保存不一致：' + key);
        }
        assertContext(expected, activeContext());
        await service.host.write({ ...envelope, stat_data: validated }, expected.floor);
        const readbackState = Schema.parse(service.host.read(expected.floor).stat_data);
        if (!equal(readbackState, validated)) throw Error('写回后的完整数据不一致，保留恢复记录');
        await saveChat();
        const after = activeContext();
        if (
          after.chat !== expected.chat ||
          after.floor !== expected.floor ||
          after.swipe !== expected.swipe ||
          after.branch !== expected.branch
        ) {
          throw Error('保存期间上下文已变化，未清除恢复记录');
        }
        return readbackState;
      });
      chatWrites = writeOp.catch(() => {});

      try {
        return await writeOp;
      } catch (error) {
        if (!rollbackOnFailure) throw error;
        // 角色调度候选须可撤回，同时保留恢复日志和独立快照。
        try {
          const now = activeContext();
          if (
            now.chat === expected.chat &&
            now.floor === expected.floor &&
            now.swipe === expected.swipe &&
            now.branch === expected.branch &&
            equal(service.host.read(expected.floor).stat_data, validated)
          ) {
            await service.host.write(envelope, expected.floor);
          }
        } catch (rollbackError) {
          throw Error(`准备提交未确认，回滚失败：${String(rollbackError)}`, { cause: error });
        }
        throw error;
      }
    });
  }
  async function requestOnce(config: GenerateConfig, state: State, extra = false, purpose: 'variables' | 'novel' | 'knowledge' = 'variables', inlineVariables = false, storyText?: string) {
    const id = uid('generation');
    view.generationId = id;
    const startedEpoch = epoch;
    try {
      requireWriter();
      view.phase = purpose === 'knowledge' ? 'information' : purpose === 'novel' ? 'novel' : extra ? 'variables' : 'story';
      const native = extra || inlineVariables ? nativePromptConfig(config) : { user_input: config.user_input ?? '' };
      const ruleInput = storyText ?? (typeof config.user_input === 'string' ? config.user_input : undefined);
      const recentText = purpose === 'variables' ? messageSource(Math.max(0, SillyTavern.chat.length - 5)).slice(-4).map(row => row.role === 'assistant' ? stripProtocol(row.text) : row.text).join('\n').slice(-4000) : undefined;
      const injects = extra && purpose === 'variables'
        ? await variableRulePrompts({ state, input: ruleInput, recentText, phoneActive: Boolean(pendingPhone) })
        : [];
      const atmosphere = purpose === 'knowledge' ? null : atmospherePrompt(settings.atmosphere);
      if (atmosphere) injects.push(atmosphere);
      if (cancelled || disposed || startedEpoch !== epoch) throw Error('生成已取消或上下文已变化');
      const result = await generateRequest({
          ...native, ...(injects.length ? { injects } : {}), generation_id: id,
          should_stream: extra ? false : getPreset('in_use').settings.should_stream,
        }, createPromptRequestContext({
          purpose: inlineVariables ? 'inline' : extra ? purpose : 'story',
          state,
          projection: extra || inlineVariables ? promptProjections.get(config) : undefined,
          input: storyText ?? (typeof config.user_input === 'string' ? config.user_input : undefined),
          phoneActive: Boolean(pendingPhone),
          recentText,
        }));
      if (cancelled || disposed || startedEpoch !== epoch) throw Error('生成已取消或上下文已变化');
      requireWriter();
      view.phase = 'validating';
      if (typeof result !== 'string' || !result.trim()) throw Error('生成未返回有效正文');
      if (!extra && !stripProtocol(result)) throw Error('主模型没有返回剧情正文；请重试正文生成');
      if (cancelled || disposed || startedEpoch !== epoch) throw Error('生成已取消或上下文已变化');
      return result;
    } finally {
      view.generationId = null;
    }
  }
  async function requestExtra(config: GenerateConfig, state: State, api: ApiSettings, purpose: 'variables' | 'novel' | 'knowledge') {
    const profiles = api.mode === 'main' ? [undefined] : [api, ...(api.autoFailover ? api.backups : [])];
    const canSwitch = profiles.length > 1;
    const source = canSwitch || api.retries ? messageSource() : undefined;
    const context = source ? activeContext() : undefined;
    const startedEpoch = epoch;
    for (let round = 0; ; round++) {
      for (const [index, profile] of profiles.entries()) {
        if (cancelled || disposed || startedEpoch !== epoch) throw Error('生成已取消或上下文已变化');
        if (source && context && (round || index)) {
          requireWriter();
          assertContext(context, activeContext());
          assertMessageSource(source, undefined, purpose === 'novel');
        }
        config.custom_api = profile ? apiConnection(profile) : undefined;
        try {
          return await requestOnce(config, state, true, purpose);
        } catch (error) {
          if (cancelled || disposed || startedEpoch !== epoch || (error as Error)?.name === 'AbortError') throw error;
          if (canSwitch && !(error instanceof ApiProviderError)) throw error;
          if (index === profiles.length - 1 && round === api.retries) {
            if (!canSwitch) throw error;
            throw Error(`已尝试全部 ${profiles.length} 个 API，最后一个连接「${profile!.name || profile!.model}」失败：${(error as Error).message}`, { cause: error });
          }
        }
      }
      await waitRetryDelay(2000, startedEpoch);
    }
  }
  async function requestUpdate(config: GenerateConfig, api: ApiSettings, name: string, state: State) {
    validateApi(api, name);
    console.info('[瓦洛兰变量更新] 开始请求', name);
    config.json_schema = variableResponseSchema;
    return requestExtra(config, state, api, 'variables');
  }
  async function requestScopedUpdate(
    before: State, envelope: Mvu.MvuData, makeConfig: (state: State) => Promise<GenerateConfig>,
    api: ApiSettings, name: string, operation: VariableUpdateRequest, saveContext: (state: State) => Promise<void>, check: CandidateCheck,
    cachedReply?: string,
    receiveReply?: (text: string, format: VariableReplyFormat) => Promise<void>, rejectReply?: () => void,
    cachedFormat?: VariableReplyFormat,
  ) {
    // Retry the variable handoff once with the missing records. Never regenerate the story or apply the rejected patch.
    for (let attempt = 0; attempt < 2; attempt++) {
      const cached = attempt === 0 && cachedReply !== undefined;
      let text: string;
      if (cached) text = cachedReply;
      else {
        let config = await makeConfig(before);
        const feedback = attempt === 0 && variableRetryPrompt(operation.retryIssue);
        if (feedback) config = withPromptInstructions(config, [{ role: 'system', position: 'in_chat', depth: 0, content: feedback }]);
        text = await requestUpdate(config, api, name, before);
      }
      // Unmarked phone replies predate structured output and use the original MVU reader.
      const format = cached ? cachedFormat : 'structured';
      if (!cached) await receiveReply?.(text, 'structured');
      try {
        const parsed = await parseUpdate(text, { ...envelope, stat_data: before }, name, operation, check, format, settings.informationAuto && attempt === 0);
        return { before, text, parsed };
      } catch (error) {
        rejectReply?.();
        if (!(error instanceof InformationNotLoadedError) || !settings.informationAuto || attempt !== 0) throw error;
        const expanded = expandInformationForRetry(before, updateBlock(format === undefined ? text : variableResponseBlock(text, format, []), false, []).commands);
        if (expanded === before) throw error;
        before = expanded;
        await saveContext(before);
        console.info('[瓦洛兰资料加载] 已补齐结算所需资料，重新请求变量更新');
      }
    }
    throw Error('变量结算未完成，请重试');
  }
  function pendingAlreadyCommitted(p: NonNullable<typeof pending>, current = activeContext()) {
    if (p.replyFloor === undefined || current.chat !== p.context.chat ||
        current.floor !== p.replyFloor || current.swipe !== (p.replySwipe ?? 0)) return false;
    const data = service.host.read(p.replyFloor)?.stat_data;
    return isCommittedCandidate(data, p.replyFloor, current.swipe) && !!data._系统?.提交记录?.[p.id];
  }
  function noteTaskWarnings(operation: VariableUpdateRequest, candidate: State, taskIds: string[]) {
    for (const id of taskIds) {
      const task = candidate._系统.任务[id];
      if (task?.状态 === '失败' && task.错误) (operation.warnings ??= []).push(task.错误);
    }
  }
  function reportSettlementWarning(operation: VariableUpdateRequest) {
    const warning = operation.warnings?.join('\n') ?? '';
    view.settlementWarning = warning;
    view.settlementWarningId = operation.id;
    if (warning) console.warn('[瓦罗兰变量更新] 部分结算', warning);
  }
  async function storeStoryProgress(p: NonNullable<typeof pending>, complete = false) {
    const records = getVariables({ type: 'chat' });
    const matchingFailure = records.澄湾失败请求?.id === p.id;
    const receipt = complete && p.openingTaskId
      ? taskReceipt(Schema.parse(p.envelope.stat_data), Schema.parse(service.host.read(p.replyFloor!).stat_data), p.openingTaskId, p.replyFloor!)
      : undefined;
    const settledOutput = complete
      ? p.prepared?.variableOutput ??
        (p.mode === 'main' && (p.reply ?? p.text)
          ? { rawText: p.reply ?? p.text, replyFormat: undefined, edited: undefined }
          : p.failedReply
            ? { rawText: p.failedReply, replyFormat: p.failedReplyFormat, edited: p.useEditedReply }
            : undefined)
      : undefined;
    await patchChat({
      澄湾待更新正文: complete ? null : p,
      ...(settledOutput
        ? {
            [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
              id: p.id,
              channel: p.mode === 'main' ? 'story-main' : 'story-extra',
              state: 'saved',
              floor: p.replyFloor,
              swipe: p.replySwipe ?? 0,
              updatedAt: new Date().toISOString(),
              rawText: settledOutput.rawText,
              replyFormat: settledOutput.replyFormat,
              edited: settledOutput.edited,
              error: p.warnings?.join('\n') || undefined,
            }),
          }
        : {}),
      ...(receipt ? { 澄湾更新回执: [...(Array.isArray(records.澄湾更新回执) ? records.澄湾更新回执 : []).filter(r =>
        r.commitId !== receipt.commitId &&
        (r.floor !== p.replyFloor || p.envelope.stat_data._系统.任务[r.taskId]?.类别 !== '建档')), receipt] } : {}),
      ...((complete && records.澄湾待确认提交?.commitId === p.id) ||
        committedPreparation(records.澄湾待确认提交, p.context, p.envelope.stat_data as State, p.id)
        ? { 澄湾待确认提交: null } : {}),
      ...(matchingFailure ? { 澄湾失败请求: null } : {}),
      ...(complete && p.replay ? { 澄湾正文重放: {
        ...records.澄湾正文重放,
        [p.id]: { saveId: service.host.read(p.replyFloor!).stat_data._系统.存档id, floor: p.replyFloor, swipe: p.replySwipe ?? 0,
          branch: `${p.context.chat}:${p.replyFloor}:${p.replySwipe ?? 0}`, plan: p.replay },
      } } : {}),
    }, complete ? [p.id] : []);
    if (matchingFailure && failedSend?.id === p.id) failedSend = null;
    if (complete) reportSettlementWarning(p);
    if (complete && pending === p) pending = null;
  }
  async function finishPending() {
    requireWriter();
    if (!pending) throw Error('没有待重试结果');
    const p = pending;
    assertMessageSource(p.source, p.replyFloor);
    const replySwipe = p.replyFloor === undefined ? 0 : (p.replySwipe ?? 0);
    if (
      p.replyFloor !== undefined &&
      getChatMessages(p.replyFloor, { include_swipes: true })[0]?.swipe_id !== replySwipe
    )
      throw Error('待结算正文已切换候选，请返回原候选后重试');
    if (
      p.replyFloor !== undefined &&
      !sameReplyNarrative(p.text, getChatMessages(p.replyFloor)[0]?.message ?? '', p.replyFloor)
    )
      throw Error('待更新正文已被编辑，请取消后重新生成');
    if (pendingAlreadyCommitted(p)) {
      view.phase = 'saving';
      await saveChat();
      requireWriter();
      assertMessageSource(p.source, p.replyFloor);
      if (!pendingAlreadyCommitted(p)) throw Error('保存期间候选变化，保留待恢复记录');
      await storeStoryProgress(p, true);
      setError('');
      refresh();
      return;
    }
    assertContext(p.context, activeContext());
    if (cancelled || disposed) throw Error('更新已取消');
    view.updating = true;
    try {
      const startedEpoch = epoch;
      if (!p.prepared && !isExternalSettingsLoaded()) await loadExternalSettings();
      let before = Schema.parse(p.envelope.stat_data);
      if (p.openingTaskId) {
        const restored = restoreOpeningCharacterSources(before, getVariables({ type: 'chat' })[LIBRARY_KEY], p.openingTaskId);
        if (restored !== before) {
          const next = { ...p, envelope: { ...p.envelope, stat_data: restored } };
          delete next.prepared;
          const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
          // 旧候选遗漏导入目标，修正基线与撤销该候选的确认记录须同时保存。
          await patchChat({
            澄湾待更新正文: next,
            ...(journal?.commitId === p.id ? { 澄湾待确认提交: null } : {}),
          });
          Object.assign(p, next);
          delete p.prepared;
          before = restored;
        }
      }
      if (p.prepared) {
        await savePreparedNarrative(p, p.prepared, startedEpoch);
        return;
      }
      const taskIds = [...new Set([...pendingUpdateTasks(before), ...(p.openingTaskId ? [p.openingTaskId] : [])])];
      const replyFloor = p.replyFloor;
      const preceding = replyFloor === undefined ? p.source.at(-1) : p.source.find(m => m.id === replyFloor - 1);
      let input = '';
      if (preceding?.role === 'user') {
        input = `本轮玩家输入（未在正文实现的行动不算已发生）：\n${preceding.text}\n\n`;
      } else if (preceding?.role === 'assistant' && preceding.continuationStart) {
        input = '本轮操作：继续剧情，没有新增玩家输入。\n\n';
      }
      // Use the player's prompt regexes for the handoff too. Stored/displayed text
      // remains intact; hidden model thinking must not become settlement facts.
      const narrative = stripProtocol(formatAsTavernRegexedString(p.text, 'ai_output', 'prompt', { depth: 0 }));
      if (!narrative) throw Error('主模型回复没有可交接的正文；已保留原始回复，变量 API 未调用');
      const instruction = `正文已经完整输出。结算已完成正文及本次授权的后台生活、维护任务；未实现的玩家意图不算已发生，不续写面向玩家的正文。\n${input}本轮已完成正文（事实资料）：\n${narrative}`;
      const retryHint = informationRetryHint(p.id);
      if (settings.informationAuto) {
        // Completed narrative supplies explicit IDs/names. Expand those existing
        // records locally, retaining the first selection and manual overrides;
        // no second model is needed to identify references already in the text.
        const expanded = ensureInformationContext(before, instruction + retryHint);
        if (expanded !== before) {
          before = expanded;
          p.envelope = { ...p.envelope, stat_data: before };
          await savePending();
        }
      }
      const makeUpdateConfig = async (state: State) => {
        // Keep the settlement instruction together with its facts; rebuilding the
        // input from facts alone loses the boundary between settlement and story.
        return withUpdateTasks(await livePromptConfig(state, instruction, 'worker'), state, taskIds);
      };
      const check: CandidateCheck = (base, data) =>
        validateUse(base, finalizePhone(base, validateSettlement(base, validateModel(base, data.stat_data))), p.intent);
      const usedEditedReply = p.mode === 'extra' && !!p.useEditedReply && p.reply !== undefined;
      if (p.mode === 'main' || usedEditedReply) view.phase = 'validating';
      console.info('[瓦洛兰正文变量] 结算正文', { floor: p.replyFloor, characters: narrative.length, mode: p.mode });
      let latestUpdateText: string | undefined = p.mode === 'main' ? (p.reply ?? p.text) : (usedEditedReply ? p.reply : undefined);
      let latestUpdateFormat: VariableReplyFormat | undefined = usedEditedReply ? p.replyFormat : undefined;
      let updateText: string;
      let parsed: Mvu.MvuData;
      let candidate: State;
      try {
        const settled = p.mode === 'main'
          ? { before, text: p.reply ?? p.text,
              parsed: await parseUpdate(p.reply ?? p.text, { ...p.envelope, stat_data: before }, '正文同次变量', p, check) }
          : await requestScopedUpdate(
              before,
              p.envelope,
              makeUpdateConfig,
              p.variableApiOverride === 'main' ? { ...settings.variable, mode: 'main' } : settings.variable,
              '正文变量',
              p,
              async state => { p.envelope = { ...p.envelope, stat_data: state }; await savePending(); },
              check,
              usedEditedReply ? p.reply : undefined,
              async (text, format) => {
                latestUpdateText = text;
                latestUpdateFormat = format;
              },
              undefined,
              usedEditedReply ? p.replyFormat : undefined,
            );
        before = settled.before;
        updateText = settled.text;
        parsed = settled.parsed.envelope;
        candidate = settled.parsed.state;
        try {
          candidate = finalizeUpdateTasks(before, candidate, taskIds, updateText, p.warnings ??= []);
          noteTaskWarnings(p, candidate, taskIds);
        } catch (error) {
          if (error instanceof MissingRosterProgressError && p === pending) {
            p.retryIssue = { kind: 'missing-progress', targets: error.targetCount };
            await savePending();
          }
          throw error;
        }
        candidate = finalizeWorld(before, candidate);
        candidate = refreshNovelSystem(candidate);
      } catch (error) {
        if (!cancelled && !disposed && SillyTavern.getCurrentChatId() === boundChat && (p.mode === 'main' || latestUpdateText !== undefined)) {
          try {
            if (p.mode === 'extra' && p === pending && latestUpdateText !== undefined) {
              p.failedReply = latestUpdateText;
              p.failedReplyFormat = latestUpdateFormat;
              delete p.reply;
              delete p.replyFormat;
              delete p.useEditedReply;
            }
            await patchChat({
              ...(p.mode === 'extra' && p === pending ? { 澄湾待更新正文: p } : {}),
              [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
                id: p.id,
                channel: p.mode === 'main' ? 'story-main' : 'story-extra',
                state: 'failed',
                floor: p.replyFloor,
                swipe: p.replySwipe ?? 0,
                updatedAt: new Date().toISOString(),
                rawText: latestUpdateText ?? '',
                replyFormat: latestUpdateFormat,
                error: String(error),
                edited: usedEditedReply || undefined,
              }),
            });
          } catch (recordError) {
            console.warn('[瓦洛兰变量检查器] 保存失败变量快照未完成', recordError);
          }
        }
        throw error;
      }
      assertContext(p.context, activeContext());
      assertMessageSource(p.source, p.replyFloor);
      if (cancelled || disposed) throw Error('更新已停止，结果保留待重试');
      countRound(candidate, p.id);
      candidate = planTasks(candidate);
      // 本次正文的展示差异先结算；随后恢复的独立操作不能被归因为正文造成的变化。
      const storyChanges = savedChanges(before, candidate);
      candidate = applyCommitReplay(candidate, p.replay);
      // The completed text is stored before update; retry replaces this same floor, never appends twice.
      const floor = p.replyFloor ?? getLastMessageId() + 1;
      candidate._系统.楼层id = floor;
      candidate._系统.数据版本 = Math.max(p.context.version, p.revisionVersion ?? 0,
        ...Object.values(p.replay?.records ?? {}).map(receipt => receipt.数据版本)) + 1;
      candidate._系统.候选回复id = String(replySwipe);
      candidate._系统.分支id = `${p.context.chat}:${floor}:${replySwipe}`;
      candidate._系统.提交记录[p.id] = {
        任务id: p.openingTaskId ?? null,
        事件id: [],
        数据版本: candidate._系统.数据版本,
        状态: '已写入',
        恢复候选JSON: null,
      };
      const openingCommitId = p.openingTaskId ? before._系统.任务[p.openingTaskId]?.提交id : null;
      if (openingCommitId)
        candidate._系统.提交记录[openingCommitId] = copy(candidate._系统.提交记录[p.id]);
      const validatedCandidate = Schema.parse(candidate);
      const envelope = { ...parsed, stat_data: validatedCandidate };
      const settlement: StorySettlement = {
        floor,
        swipe: replySwipe,
        commitId: p.id,
        version: validatedCandidate._系统.数据版本,
        baseFloor: p.context.floor,
        baseSwipe: p.context.swipe,
        baseVersion: p.context.version,
        changes: storyChanges,
        ...(p.replay ? { replayId: p.id } : {}),
      };
      // The MVU result is already parsed and written as floor data. Keeping the command in
      // the message would let MVU or another script apply the same patch again on a rerender.
      p.prepared = {
        envelope,
        settlement,
        variableOutput: {
          rawText: updateText,
          replyFormat: latestUpdateFormat,
          edited: usedEditedReply || undefined,
        },
      };
      await savePreparedNarrative(p, p.prepared, startedEpoch);
    } finally {
      view.updating = false;
    }
  }
  async function savePreparedNarrative(
    p: NonNullable<typeof pending>, prepared: NonNullable<NonNullable<typeof pending>['prepared']>, startedEpoch: number,
  ) {
    view.phase = 'saving';
    const { envelope, settlement } = prepared;
    const floor = settlement.floor, replySwipe = settlement.swipe;
    let message = storedNarrative(p.text);
    assertContext(p.context, activeContext());
    assertMessageSource(p.source, p.replyFloor);
    if (cancelled || disposed || epoch !== startedEpoch) throw Error('更新已停止，结果保留待重试');
    try {
      // The prepared reply and its write-ahead journal describe the same candidate.
      // Confirm both in one save before changing the reply floor.
      await service.host.journal({
        context: p.context,
        commitId: p.id,
        candidate: envelope.stat_data,
        replyFloor: floor,
      }, { 澄湾待更新正文: p });
    } catch (error) {
      if (pending === p && !disposed && !cancelled && epoch === startedEpoch && SillyTavern.getCurrentChatId() === boundChat) {
        try { await savePending(); }
        catch (recoveryError) { console.warn('[瓦洛兰正文] 候选恢复记录保存失败', recoveryError); }
      }
      throw error;
    }
    assertContext(p.context, activeContext());
    assertMessageSource(p.source, p.replyFloor);
    if (cancelled || disposed || epoch !== startedEpoch) throw Error('更新已停止，结果保留待重试');
    if (p.replyFloor === undefined) {
      await createMessages([{ role: 'assistant', message, data: envelope,
        extra: { cw_story_settlements: { [String(replySwipe)]: settlement } } }], {
        refresh: 'affected',
      });
      p.replyFloor = floor;
      p.replySwipe = 0;
    } else {
      const saved = getChatMessages(floor)[0];
      if (!saved || saved.role !== 'assistant' || !sameReplyNarrative(p.text, saved.message, floor))
        throw Error(`第 ${floor} 楼待结算正文已被编辑，未写入旧结算结果`);
      // 变量请求和保存回执都可能等待。保留这期间写入楼层的编号和展示标记。
      message = storedNarrative(saved.message);
      const extra = messageExtra(saved);
      delete extra.cw_update_pending;
      delete extra.cw_story_request;
      delete extra.cw_incomplete;
      extra.cw_story_settlements = {
        ...(extra.cw_story_settlements && typeof extra.cw_story_settlements === 'object' ? extra.cw_story_settlements : {}),
        [String(replySwipe)]: settlement,
      };
      await writeStoryCandidate(floor, replySwipe, message, extra, envelope);
    }
    if (
      !sameAssistantFloorText(message, getChatMessages(floor)[0]?.message ?? '', floor) ||
      !equal(Schema.parse(service.host.read(floor).stat_data), envelope.stat_data)
    )
      throw Error('回复楼层状态读回不一致');
    await saveChat();
    requireWriter();
    if (activeContext().floor !== floor || activeContext().swipe !== replySwipe)
      throw Error('保存期间候选变化，保留待恢复记录');
    await storeStoryProgress(p, true);
    setError('');
    refresh();
  }
  async function send(
    text: string,
    append = true,
    intent?: UseIntent,
    submissionId = uid('round'),
    opening = false,
    onSent?: () => void,
    { continuation = false, originalSource, newInput = false }: {
      continuation?: boolean; originalSource?: MessageSource; newInput?: boolean;
    } = {},
  ) {
    requireWriter();
    const expectedEpoch = epoch;
    const savedSource = continuation ? storySource(originalSource ?? messageSource(), submissionId, true) : originalSource;
    if (!view.busy && !view.updating) await restoreOrphanedNarrative();
    if (!pending && firstUnsettledNarrative()) throw Error(view.error || '待结算正文尚未恢复，请先处理该楼层');
    if (!text.trim() || view.busy || view.updating || pending || pendingPhone || view.managementPending) throw Error('输入为空或仍有待处理更新');
    const mode = await inVariableSettingsOrder(async () => {
      requireWriter();
      try {
        if (promptWorldbookPending) await syncPromptWorldbook();
        if (!opening && settings.variable.independent) validateApi(settings.variable, '正文变量');
      } catch (error) {
        // A new unsent input still belongs to the composer. A restored or already-saved input keeps its ID.
        if (newInput && expectedEpoch === epoch && !disposed && SillyTavern.getCurrentChatId() === boundChat) {
          try {
            await persistIntents([submissionId]);
          } catch (cleanupError) {
            throw Error(`${error}。正文待办移除未确认：${cleanupError}。请在正文待办中恢复或移除该项。`, { cause: cleanupError });
          }
        }
        throw error;
      }
      requireWriter();
      if (expectedEpoch !== epoch) throw Error('正文准备期间操作已停止或上下文已变化');
      view.busy = true;
      cancelled = false;
      return settings.variable.independent ? 'extra' : 'main';
    });
    view.streaming = '';
    receivedStory = '';
    setError('');
    sourceChange = undefined;
    requestSource = undefined;
    let context = activeContext();
    let envelope = copy(service.host.read(context.floor));
    let openingTaskId: string | undefined;
    let inputSaved = !append;
    let replyFloor: number | undefined;
    try {
      assertContext(context, activeContext());
      requestSource = savedSource ?? messageSource();
      if (append) {
        const inputFloor = getLastMessageId() + 1;
        await createMessages([{ role: 'user', message: text, extra: intent ? { cw_use_intent: intent } : {} }], {
          refresh: 'affected',
        });
        requestSource = [...requestSource, { id: inputFloor, role: 'user', swipe: 0,
          text, archive: text, candidate: text }];
        inputSaved = true;
        // 玩家楼已创建。即使失效出队或后续生成的保存失败，恢复也只能沿该楼继续。
        const queued = intents.find(item => item.id === submissionId && item.kind === 'story');
        if (queued) {
          queued.source = requestSource;
          queued.inputSaved = true;
          await saveIntents();
        }
        assertMessageSource(requestSource);
        // Publish the saved floor before acknowledging input; disk/model work may take longer.
        refreshMessages();
        onSent?.();
        await saveChat();
      }
      // The player's saved floor must appear before worldbook I/O and roster commits.
      // Preparation still finishes before constructing prompts or calling the model.
      {
        if (!isExternalSettingsLoaded()) await loadExternalSettings();
        context = activeContext();
        envelope = copy(service.host.read(context.floor));
        const baseState = Schema.parse(envelope.stat_data);
        let workingState = normalizeRuntimeWorld(baseState);
        assertMessageSource(requestSource);
        const inputFloor = !continuation && requestSource.at(-1)?.role === 'user' ? requestSource.at(-1)?.id : undefined;
        const preparationId = 'information_selection_' + submissionId;
        const selectionRes = baseState._系统.提交记录[preparationId]
          ? { state: workingState, library: null, rollbackOnFailure: false }
          : settings.informationAuto
          ? await selectInformationInMemory(workingState, text, 'story:' + submissionId, false, undefined, requestSource, inputFloor)
          : prepareLocalStoryRoster(workingState, text, opening);
        workingState = selectionRes.state;
        if (opening) {
          openingTaskId = Object.keys(workingState._系统.任务).find(
            id => workingState._系统.任务[id].类别 === '建档' && ['排队', '失败'].includes(workingState._系统.任务[id].状态),
          );
          if (!openingTaskId) {
            workingState = planOpeningCharacters(workingState, [], true);
            openingTaskId = Object.keys(workingState._系统.任务).find(
              id => workingState._系统.任务[id].类别 === '建档' && ['排队', '失败'].includes(workingState._系统.任务[id].状态),
            );
          }
          if (openingTaskId) {
            const retries = new Set(
              Object.keys(workingState._系统.任务).filter(
                id => workingState._系统.任务[id].类别 === '建档' && workingState._系统.任务[id].状态 === '失败',
              ),
            );
            const merged = mergeOpeningTasks(workingState, openingTaskId, retries);
            if (!equal(workingState, merged)) workingState = merged;
          }
        }
        assertContext(context, activeContext());
        assertMessageSource(requestSource);
        if (!equal(baseState, workingState) || selectionRes.library) {
          await commitPreStoryPreparation(
            context,
            preparationId,
            workingState,
            selectionRes.library,
            selectionRes.rollbackOnFailure,
            submissionId,
          );
          context = activeContext();
          envelope = copy(service.host.read(context.floor));
          if (opening) {
            const committedState = Schema.parse(envelope.stat_data);
            openingTaskId = Object.keys(committedState._系统.任务).find(
              id => committedState._系统.任务[id].类别 === '建档' && ['排队', '失败'].includes(committedState._系统.任务[id].状态),
            );
          }
        }
      }
      if (cancelled || disposed) throw Error('生成已停止');
      assertMessageSource(requestSource);
      refresh();
      const storyState = Schema.parse(envelope.stat_data);
      const storyInput = continuation ? text : '';
      const config = mode === 'main'
        ? withUpdateTasks(await livePromptConfig(storyState, storyInput, 'inline', undefined, undefined, text), storyState,
            [...new Set([...pendingUpdateTasks(storyState), ...(openingTaskId ? [openingTaskId] : [])])], true)
        : { user_input: storyInput };
      const reply = await requestOnce(config, storyState, false, 'variables', mode === 'main', text);
      assertContext(context, activeContext());
      assertMessageSource(requestSource);
      pending = {
        context,
        envelope,
        text: mode === 'main' ? storedNarrative(reply, true) : reply,
        ...(mode === 'main' ? { reply } : {}),
        id: submissionId,
        intent,
        source: requestSource,
        mode,
        openingTaskId,
      };
      await storeStoryProgress(pending);
      const origin = await narrativeRequest(pending);
      assertContext(context, activeContext());
      assertMessageSource(requestSource);
      if (cancelled || disposed) throw Error('生成已停止');
      // Publish completed narrative before the independent variable request; retry updates this same floor.
      view.phase = 'story-save';
      const floor = getLastMessageId() + 1;
      await createMessages(
        [{ role: 'assistant', message: storedNarrative(pending.text), extra: { cw_update_pending: true, cw_story_request: origin } }],
        { refresh: 'affected' },
      );
      replyFloor = floor;
      pending.replyFloor = floor;
      pending.replySwipe = 0;
      await captureSavedNarrative(pending);
      await savePending();
      view.streaming = '';
      refresh();
      view.busy = false;
      await finishPending();
    } catch (e) {
      if (e instanceof MessageSourceError) sourceChange ??= e;
      if (!sourceChange && requestSource && !disposed && SillyTavern.getCurrentChatId() === context.chat) {
        try {
          assertMessageSource(requestSource, pending?.replyFloor);
        } catch (error) {
          if (!(error instanceof MessageSourceError)) throw error;
          sourceChange = error;
        }
      }
      if (sourceChange) {
        const reason = sourceChange.message;
        const savedReply = replyFloor === undefined || disposed || SillyTavern.getCurrentChatId() !== context.chat
          ? undefined : messageExtra(getChatMessages(replyFloor)[0]);
        const replyStillSelected = savedReply?.cw_story_request?.id === submissionId;
        if (!disposed && SillyTavern.getCurrentChatId() === context.chat) {
          const records = getVariables({ type: 'chat' });
          const matchingFailure = records.澄湾失败请求?.id === submissionId;
          const committedPrepJournal =
            committedPreparation(records.澄湾待确认提交, context, service.host.read(context.floor).stat_data as State, submissionId);
          try {
            await patchChat({
              澄湾待更新正文: null,
              ...(matchingFailure ? { 澄湾失败请求: null } : {}),
              ...(records.澄湾待确认提交?.commitId === submissionId || committedPrepJournal ? { 澄湾待确认提交: null } : {}),
            }, [submissionId]);
          } catch (error) {
            setError(`${reason}。旧请求清理未确认：${error instanceof Error ? error.message : error}。请恢复该排队操作。`);
            throw Error(view.error, { cause: error });
          }
          pending = null;
          if (matchingFailure && failedSend?.id === submissionId) failedSend = null;
        }
        setSourceChangeError(reason + (replyFloor === undefined ? '。本轮没有新增正文，可从当前玩家楼续接，或发送新输入。'
          : replyStillSelected ? `。正文保留在第 ${replyFloor} 楼，原结算请求已失效。请从该楼的消息菜单重新生成回复。`
          : `。本轮正文曾写入第 ${replyFloor} 楼，请检查当前楼层和候选。`));
        throw new StaleStoryRequestError(view.error, { cause: sourceChange });
      }
      if (mode === 'main' && !pending && storedNarrative(receivedStory, true).trim() && !disposed &&
          SillyTavern.getCurrentChatId() === context.chat) {
        pending = { context, envelope, text: storedNarrative(receivedStory, true), reply: receivedStory,
          id: submissionId, intent, source: requestSource ?? savedSource ?? messageSource(), mode, openingTaskId };
        await storeStoryProgress(pending);
      }
      setError(cancelled
        ? pending
          ? mode === 'main' ? '已保留收到的正文和变量回包，请检查本楼并补齐变量块后重试，或重新生成本楼' : '正文已保存，变量尚未结算；请点击重试'
          : '生成已停止；已发送的玩家消息可用“重试”继续'
        : e);
      if (!pending && SillyTavern.getCurrentChatId() === context.chat) {
        failedSend = {
          context,
          text,
          intent,
          source: requestSource ?? savedSource ?? messageSource(),
          id: submissionId,
          opening,
          continuation,
          append: append && !inputSaved,
        };
        await saveFailed();
      }
      if (pending && pending.replyFloor === undefined && SillyTavern.getCurrentChatId() === context.chat) {
        const floor = getLastMessageId() + 1;
        const origin = await narrativeRequest(pending);
        assertContext(pending.context, activeContext());
        assertMessageSource(pending.source);
        await createMessages(
          [{ role: 'assistant', message: storedNarrative(pending.text), extra: { cw_update_pending: true, cw_story_request: origin } }],
          { refresh: 'affected' },
        );
        pending.replyFloor = floor;
        pending.replySwipe = 0;
        await captureSavedNarrative(pending);
        await savePending();
      }
      throw cancelled ? Error('生成已停止；请检查已保存消息后继续。') : e;
    } finally {
      requestSource = undefined;
      view.streaming = '';
      view.busy = false;
      view.updating = false;
      refresh();
    }
  }
  async function retry(): Promise<PhoneActionResult | void> {
    requireWriter();
    if (view.busy || view.updating) throw Error('当前操作仍在执行，请等待或停止');
    cancelled = false;
    try {
      const rosterJournal = getVariables({ type: 'chat' }).澄湾待确认提交;
      if (rosterJournal?.rollbackOnFailure && ['character_roster_', 'opening_roster_'].some(prefix =>
        String(rosterJournal.commitId).startsWith(prefix))) {
        const resumeStory = failedSend && recoverablePreparationJournal(rosterJournal);
        if (failedSend && !resumeStory) throw Error('自动名单恢复与原请求上下文不一致，请检查当前候选');
        if (resumeStory) assertMessageSource(failedSend!.source);
        libraryView(Schema.parse(rosterJournal.candidate), getVariables({ type: 'chat' })[LIBRARY_KEY]);
        await service.commit(rosterJournal.context, rosterJournal.commitId, () => Schema.parse(rosterJournal.candidate), true);
        refresh();
      }
      const informationJournal = getVariables({ type: 'chat' }).澄湾待确认提交;
      if (informationJournal?.commitId && String(informationJournal.commitId).startsWith('information_selection_')) {
        if (failedSend?.id && (informationJournal.requestId === failedSend.id || informationJournal.candidate?._系统?.资料加载?.选择依据 === 'story:' + failedSend.id)) {
          if (!recoverablePreparationJournal(informationJournal))
            throw Error('资料调度恢复与原请求上下文不一致，请检查当前候选');
          assertMessageSource(failedSend.source);
          if (informationJournal.rollbackOnFailure)
            libraryView(Schema.parse(informationJournal.candidate), getVariables({ type: 'chat' })[LIBRARY_KEY]);
          await service.commit(informationJournal.context, informationJournal.commitId,
            () => Schema.parse(informationJournal.candidate), !!informationJournal.rollbackOnFailure);
          refresh();
        }
      }
      if (pending?.replyFloor !== undefined) await discardStaleRecovery();
      await restoreOrphanedNarrative();
      if (!pending && firstUnsettledNarrative()) throw Error(view.error || '待结算正文尚未恢复，请先处理该楼层');
      if (pending) {
        setError('');
        // Old chats may contain several saved replies with no settlement. Each
        // reply receives its own previous-floor baseline and one atomic commit.
        do {
          await finishPending();
          await restoreOrphanedNarrative();
        } while (pending && !cancelled && !disposed);
      }
      else if (pendingPhone) return await phoneAction(pendingPhone.action);
      else if (failedSend) {
        assertContext(failedSend.context, activeContext());
        assertMessageSource(failedSend.source);
        if (!failedSend.id) {
          // 旧版本的失败请求可能没有 ID；先保存身份，后续交接和重试共用同一提交。
          failedSend = { ...failedSend, id: uid('round') };
          await saveFailed();
        }
        await send(
          failedSend.text,
          failedSend.append ?? false,
          failedSend.intent,
          failedSend.id,
          failedSend.opening,
          undefined,
          { continuation: failedSend.continuation ?? failedSend.id?.startsWith('continue_'), originalSource: failedSend.source },
        );
      } else {
        const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
        if (journal) {
          if (journal.replyFloor !== undefined) {
            // 正文结算属于回复候选。普通提交会把 candidate 写进 journal.context 指向的上一楼。
            const floor = journal.replyFloor;
            const swipe = Number(journal.candidate?._系统?.候选回复id);
            // 酒馆助手会把越界的楼号截到最后一楼。
            const row = floor <= getLastMessageId() ? getChatMessages(floor, { include_swipes: true })[0] : undefined;
            const written = row?.swipes_data[swipe]?.stat_data;
            if (isCommittedCandidate(written, floor, swipe) && written?._系统?.提交记录?.[journal.commitId]) {
              await patchChat({ 澄湾待确认提交: null }, [journal.commitId]);
              setError('');
            } else if (!row) {
              await patchChat({ 澄湾待确认提交: null }, [journal.commitId]);
              setSourceChangeError(`第 ${floor} 楼已删除，旧结算记录已清理。`);
            } else {
              throw Error(`第 ${floor} 楼缺少这次结算的确认记录，请检查原候选。如需重新生成，请先取消这条待确认记录。`);
            }
            return;
          }
          const novel = intents.find(item => item.kind === 'novel' && item.id === journal.commitId);
          if (novel?.target) {
            await refreshNovelContent(novel.target, novel.id);
            return;
          }
          if (journal.rollbackOnFailure) libraryView(Schema.parse(journal.candidate), getVariables({ type: 'chat' })[LIBRARY_KEY]);
          await service.commit(journal.context, journal.commitId, () => Schema.parse(journal.candidate), !!journal.rollbackOnFailure);
          setError('');
        } else {
          const item = intents.find(intent => intent.kind === 'novel' || intent.kind === 'phone');
          if (!item) throw Error('没有待恢复提交，请重新执行原操作');
          assertMessageSource(item.source, undefined, true);
          // 名单快照保存可能早于 phone pending/journal，原排队操作仍保留身份。
          if (item.kind === 'phone' && item.action) return await phoneAction(item.action, item.id);
          if (!item.target) throw Error('待恢复操作缺少请求内容');
          await refreshNovelContent(item.target, item.id);
        }
      }
    } catch (error) {
      if (failedSend && error instanceof MessageSourceError && !(error instanceof StaleStoryRequestError) &&
          !getVariables({ type: 'chat' }).澄湾待确认提交) {
        await discardStaleRecovery();
        if (!failedSend) throw new StaleStoryRequestError(view.error, { cause: error });
      }
      if (!(error instanceof StaleStoryRequestError)) setError(error);
      console.error('[瓦洛兰重试] 未完成', error);
      throw error;
    } finally {
      view.updating = false;
      refresh();
    }
  }
  function cancelCurrentGeneration() {
    invalidateOpeningPrewarm();
    if (cancelled) return;
    cancelled = true;
    epoch++;
    for (const wake of [...retryWakeups]) wake();
    view.streaming = '';
    if (view.phoneRequest && view.busy) view.phoneRequest = { ...view.phoneRequest, status: 'stopping' };
    scheduler.cancelWaiting('已停止；尚未发送的操作保留供手动恢复');
  }
  function stop() {
    cancelCurrentGeneration();
    if (view.generationId) stopRequest(view.generationId);
  }
  async function closeRecovery(ids: string[], clearFailure = false) {
    const records = getVariables({ type: 'chat' });
    const patch: Record<string, unknown> = {};
    for (const key of ['澄湾待更新正文', '澄湾待更新手机', '澄湾失败请求']) {
      if (ids.includes(records[key]?.id)) patch[key] = null;
    }
    if (clearFailure) patch.澄湾失败请求 = null;
    const journal = records.澄湾待确认提交;
    if (journal && ids.includes(journal.commitId)) {
      if (journal.replyFloor === undefined && journal.rollbackOnFailure) {
        const { floor, swipe } = journal.context;
        const row = floor <= getLastMessageId() ? getChatMessages(floor, { include_swipes: true })[0] : undefined;
        const envelope = row?.swipes_data[swipe];
        // 进程可能在候选保存后、失败回滚前关闭。只撤回仍完整匹配本次候选的原分支。
        if (envelope && equal(envelope.stat_data, journal.candidate)) {
          const restored = { ...envelope, stat_data: JSON.parse(journal.context.fingerprint) };
          const swipes_data = row!.swipes_data;
          swipes_data[swipe] = restored;
          await setMessages([{ message_id: floor, swipes_data }], { refresh: 'affected' });
          if (!equal(getChatMessages(floor, { include_swipes: true })[0]?.swipes_data[swipe], restored))
            throw Error('放弃请求时原候选回滚读回失败，保留恢复记录');
        }
      }
      patch.澄湾待确认提交 = null;
    }
    await patchChat(patch, ids);
    if (pending && ids.includes(pending.id)) pending = null;
    if (pendingPhone && ids.includes(pendingPhone.id)) pendingPhone = null;
    if (clearFailure || failedSend?.id && ids.includes(failedSend.id)) failedSend = null;
  }
  async function cancelEditedStory(p: NonNullable<typeof pending>) {
    const floor = p.replyFloor!, swipe = p.replySwipe ?? 0;
    const row = getChatMessages(floor)[0], extra = messageExtra(row);
    const oldCommit = extra.cw_story_settlements?.[String(swipe)]?.commitId;
    const cached = settledTexts.get(`${floor}:${swipe}`);
    const original = p.editingOriginal ?? (cached && cached.commitId === oldCommit && oldCommit
      ? { text: cached.text, commitId: oldCommit } : undefined);
    if (!original || original.commitId !== oldCommit ||
        !isCommittedCandidate(row?.data?.stat_data, floor, swipe) ||
        !row.data.stat_data._系统.提交记录[original.commitId]) return false;
    if (!sameReplyNarrative(p.text, row.message, floor) && !sameReplyNarrative(original.text, row.message, floor))
      throw Error('待撤回正文已变化，请先保存最新编辑');
    const restoredExtra = { ...extra };
    delete restoredExtra.cw_story_request;
    delete restoredExtra.cw_update_pending;
    try {
      await writeStoryCandidate(floor, swipe, original.text, restoredExtra);
      await closeRecovery([p.id]);
    } catch (error) {
      // 保留可再次撤回的编辑及原文依据，避免确认失败后只能删除正文。
      await writeStoryCandidate(floor, swipe, p.text, extra);
      setError(error);
      refresh();
      throw error;
    }
    setError('');
    refresh();
    return true;
  }
  async function discardPending() {
    requireWriter();
    requireLoaded();
    if (view.busy || view.updating) {
      stop();
      return;
    }
    await restoreOrphanedNarrative();
    if (pending && pendingAlreadyCommitted(pending)) {
      await finishPending();
      return;
    }
    if (pendingPhone && phoneAlreadyCommitted(pendingPhone)) {
      await phoneAction(pendingPhone.action);
      return;
    }
    if (pending?.replyFloor !== undefined) {
      if (await cancelEditedStory(pending)) return;
      setError('这段正文缺少可撤回的已结算原文。请继续编辑或重试变量结算，也可从消息菜单重新生成或删除。');
      refresh();
      return;
    }
    const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
    const ids = [
      pending?.id,
      pendingPhone?.id,
      failedSend?.id,
      journal?.commitId,
      ...intents.filter(item => item.kind === 'novel').map(item => item.id),
    ].filter((id): id is string => !!id);
    if (ids.length) await closeRecovery([...new Set(ids)], true);
    if (pending || pendingPhone || failedSend || getVariables({ type: 'chat' }).澄湾待确认提交) {
      await patchChat({
        澄湾待更新正文: null, 澄湾待更新手机: null, 澄湾失败请求: null, 澄湾待确认提交: null,
      });
      pending = null;
      pendingPhone = null;
      failedSend = null;
    }
    setError('');
    refresh();
  }
  async function computeEditedStoryReplay(
    id: number,
    swipe: number,
    edited: any,
    extra: Record<string, any>,
    context: Context,
    previous?: PendingStory,
  ) {
    let replay: CommitReplay | undefined;
    const oldStory = extra.cw_story_settlements?.[String(swipe)] as StorySettlement | undefined;
    const current = oldStory ? Schema.parse(edited.data.stat_data) : undefined;
    const savedReplay = oldStory?.replayId ? getVariables({ type: 'chat' }).澄湾正文重放?.[oldStory.replayId] : undefined;
    if (oldStory?.replayId && (!savedReplay || oldStory.replayId !== oldStory.commitId ||
        savedReplay.saveId !== current?._系统.存档id || savedReplay.floor !== id || savedReplay.swipe !== swipe ||
        savedReplay.branch !== current?._系统.分支id)) throw Error('正文重放依据与当前候选不一致，请恢复完整聊天记录');
    const replayStory = oldStory ? { ...oldStory, replay: savedReplay?.plan as CommitReplay | undefined } : undefined;
    const library = current ? LibrarySchema.parse(getVariables({ type: 'chat' })[LIBRARY_KEY]) : undefined;
    const archived = (commitId: string, version: number) => {
      return Object.values(library?.snapshots ?? {}).find(snapshot => snapshot.saveId === current?._系统.存档id &&
        snapshot.replays?.[commitId]?.version === version)?.replays?.[commitId]?.changes;
    };
    try { replay = previous ? previous.replay : current ? replayAfterStory(current, replayStory, archived) : undefined; }
    catch (error) {
      if (!(error instanceof MissingCommitReplay) || !oldStory) throw error;
      const originalEpoch = epoch;
      replay = await legacyStoryReplay(current!, Schema.parse(service.host.read(context.floor).stat_data), replayStory!, () => {
        requireWriter();
        assertContext(context, activeContext(id - 1));
        if (epoch !== originalEpoch || getChatMessages(id)[0]?.message !== edited.message ||
            !equal(getChatMessages(id)[0]?.data?.stat_data, edited.data.stat_data))
          throw Error('读取备份期间候选或变量已变化，未采用旧结果');
      });
    }
    if (replay && library && current) replay.archived = [...new Set(Object.values(library.snapshots)
      .filter(snapshot => snapshot.saveId === current._系统.存档id)
      .flatMap(snapshot => Object.entries(snapshot.replays ?? {}).filter(([commitId, value]) =>
        current._系统.提交记录[commitId]?.数据版本 === value.version && !current._系统.提交记录[commitId].变更JSON)
        .map(([commitId]) => commitId)))];
    return replay;
  }
  async function recordEditedStory(id: number, replacement?: string) {
    if (id === 0 || id !== getLastMessageId()) return false;
    const edited = getChatMessages(id)[0];
    if (edited?.role !== 'assistant') return false;
    const swipe = getChatMessages(id, { include_swipes: true })[0].swipe_id;
    const previous = pending?.replyFloor === id && (pending.replySwipe ?? 0) === swipe ? pending : undefined;
    if (!previous && edited.data?.stat_data?._系统?.楼层id !== id) return false;
    const extra = messageExtra(edited);
    const mode = previous?.mode ?? extra.cw_story_request?.mode ?? (settings.variable.independent ? 'extra' : 'main');
    let reply = replacement ?? edited.message;
    // 同轮模式纯正文编辑（弹窗不混入协议块）时，保留既有待结算回复里的 <UpdateVariable> 块，避免误删变量。
    if (mode === 'main' && replacement !== undefined && !/<UpdateVariable\b/i.test(replacement) && previous?.reply) {
      const preserved = extractEditableVariableOutput(previous.reply, 'story-main');
      if (!preserved.missingUpdateBlock && preserved.rawText.trim()) {
        reply = `${replacement.trimEnd()}\n${preserved.rawText.trim()}`;
      }
    }
    const text = storedNarrative(reply, mode === 'main');
    const oldCommit = extra.cw_story_settlements?.[String(swipe)]?.commitId;
    const cached = settledTexts.get(`${id}:${swipe}`);
    // 原生事件在存档已被改写后触发，原文取自同一候选的待办或已结算版本。
    const before = previous?.text ?? (cached?.commitId === oldCommit ? cached?.text : undefined);
    // 旧版可能已把原文登记成待结算编辑，重复保存也应结束这次可撤回的编辑。
    if (previous?.editingOriginal && previous.editingOriginal.commitId === oldCommit &&
        (mode !== 'main' || reply === text) &&
        sameAssistantFloorText(previous.editingOriginal.text, text, id)) {
      if (view.busy || view.updating) stop();
      if (await cancelEditedStory(previous)) return true;
    }
    // 原生编辑已经写入。桌面显式恢复到已结算原文时，调用方仍需保存替换文本。
    if (before !== undefined && sameAssistantFloorText(before, text, id) &&
        (mode !== 'main' || reply === previous?.reply || reply === text)) return replacement === undefined;
    if (view.busy || view.updating) stop();
    const context = activeContext(id - 1);
    let replay: CommitReplay | undefined;
    try {
      replay = await computeEditedStoryReplay(id, swipe, edited, extra, context, previous);
    } catch (error) {
      // 原生完成编辑事件发生在正文已被宿主改写之后。只用事先缓存的同候选原文恢复。
      if (replacement === undefined) {
        if (cached && cached.commitId === oldCommit && getChatMessages(id)[0]?.message === edited.message) {
          await writeStoryCandidate(id, swipe, cached.text, extra);
          await saveChat();
        }
      }
      throw error;
    }
    const priorMessage = getChatMessages(id - 1)[0];
    const idToSettle = previous && !edited.data?.stat_data?._系统?.提交记录?.[previous.id]
      ? previous.id : uid('edited_round');
    const next: NonNullable<typeof pending> = {
      context, envelope: copy(service.host.read(context.floor)), text, id: idToSettle,
      source: storySource(messageSource().filter(m => m.id !== id), idToSettle), replyFloor: id, replySwipe: swipe, mode,
      ...(mode === 'main' ? { reply } : {}),
      openingTaskId: previous?.openingTaskId ?? edited.data?.stat_data?._系统?.提交记录?.[oldCommit]?.任务id ?? undefined,
      intent: previous?.intent ?? (priorMessage?.role === 'user' ? messageExtra(priorMessage).cw_use_intent : undefined),
      replay,
      revisionVersion: previous?.revisionVersion ?? edited.data?.stat_data?._系统?.数据版本,
      editingOriginal: previous?.editingOriginal ?? (oldCommit && cached && cached.commitId === oldCommit
        ? { text: cached.text, commitId: oldCommit }
        : !previous && replacement !== undefined && oldCommit && !extra.cw_update_pending
          ? { text: edited.message, commitId: oldCommit } : undefined),
    };
    extra.cw_story_request = await narrativeRequest(next);
    extra.cw_update_pending = true;
    assertContext(context, activeContext(id - 1));
    assertMessageSource(next.source, id);
    if (getChatMessages(id)[0]?.message !== edited.message) throw Error('正文在记录编辑时再次变更，请检查最新内容');
    await writeStoryCandidate(id, swipe, text, extra);
    pending = next;
    await savePending();
    setError('正文已编辑，点击输入区“立即重试”重新结算变量');
    refresh();
    return true;
  }
  async function saveEditedVariableOutputImpl(input: {
    text: string;
    target?: { floor?: number; swipe?: number; id?: string; channel?: VariableOutputChannel };
    retryNow?: boolean;
  }): Promise<PhoneActionResult | void> {
    requireWriter();
    requireLoaded();
    if (view.busy || view.updating) throw Error('当前操作仍在执行，请等待或停止');
    const { text, target, retryNow = false } = input;
    const matchesPending =
      !!pending &&
      (!target ||
        target.id === pending.id ||
        (target.channel !== 'phone' &&
          target.floor !== undefined &&
          target.floor === pending.replyFloor &&
          (target.swipe === undefined || target.swipe === (pending.replySwipe ?? 0))));
    const matchesPhone =
      !!pendingPhone &&
      (!target ||
        target.id === pendingPhone.id ||
        target.channel === 'phone');

    if (matchesPending && pending) {
      const p = pending;
      assertMessageSource(p.source, p.replyFloor);
      const channel: VariableOutputChannel = p.mode === 'main' ? 'story-main' : 'story-extra';
      const assembled = assembleEditedVariableOutput(text, channel, p.failedReplyFormat ?? p.replyFormat);
      const nextPending: PendingStory = { ...p };
      delete nextPending.prepared;
      delete nextPending.retryIssue;
      if (nextPending.mode === 'main') {
        nextPending.reply = `${nextPending.text}\n\n${assembled.transportText}`;
        if (nextPending.replyFloor !== undefined) {
          const swipe = nextPending.replySwipe ?? 0;
          const savedSwiped = getChatMessages(nextPending.replyFloor, { include_swipes: true })[0];
          const savedPlain = getChatMessages(nextPending.replyFloor)[0];
          if (!savedSwiped || !savedPlain || savedSwiped.swipe_id !== swipe)
            throw Error('待结算正文已切换候选，请返回原候选后重试');
          if (!sameReplyNarrative(nextPending.text, savedPlain.message, nextPending.replyFloor))
            throw Error('待更新正文已被编辑，请取消后重新生成');
          const extra = messageExtra({ extra: savedSwiped.swipes_info[swipe] });
          extra.cw_story_request = await narrativeRequest(nextPending);
          await writeStoryCandidate(nextPending.replyFloor, swipe, savedPlain.message, extra);
        }
      } else {
        nextPending.reply = assembled.transportText;
        nextPending.replyFormat = assembled.replyFormat;
        nextPending.failedReply = assembled.transportText;
        nextPending.failedReplyFormat = assembled.replyFormat;
        nextPending.useEditedReply = true;
      }
      await patchChat({
        澄湾待更新正文: nextPending,
        [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
          id: nextPending.id,
          channel,
          state: 'pending',
          floor: nextPending.replyFloor,
          swipe: nextPending.replySwipe ?? 0,
          updatedAt: new Date().toISOString(),
          rawText: assembled.rawRecordText,
          replyFormat: assembled.replyFormat,
          edited: true,
        }),
      });
      pending = nextPending;
      if (!retryNow) {
        setError('变量块已修改保存，点击“立即重试”完成结算');
        refresh();
        return;
      }
      refresh();
      return await retry();
    }

    if (matchesPhone && pendingPhone) {
      const p = pendingPhone;
      assertMessageSource(p.source);
      const assembled = assembleEditedVariableOutput(text, 'phone', p.failedReplyFormat ?? p.replyFormat);
      const nextPhone = {
        ...p,
        reply: assembled.transportText,
        replyFormat: assembled.replyFormat,
        failedReply: assembled.transportText,
        failedReplyFormat: assembled.replyFormat,
        editedReply: true,
      };
      delete nextPhone.candidate;
      delete nextPhone.retryIssue;
      await patchChat({
        澄湾待更新手机: nextPhone,
        [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
          id: nextPhone.id,
          channel: 'phone',
          state: 'pending',
          floor: nextPhone.context.floor,
          swipe: nextPhone.context.swipe,
          updatedAt: new Date().toISOString(),
          rawText: assembled.rawRecordText,
          replyFormat: assembled.replyFormat,
          edited: true,
        }),
      });
      pendingPhone = nextPhone;
      if (!retryNow) {
        setError('手机变量块已修改保存，点击“重试”完成结算');
        refresh();
        return;
      }
      refresh();
      return await retry();
    }

    // 允许修订并重新结算最新已结算助手楼层的变量输出。
    if (pending || pendingPhone || failedSend || view.managementPending || getVariables({ type: 'chat' }).澄湾待确认提交)
      throw Error('当前存在其他待处理或未确认操作，请先处理后再修改变量');
    const floor = target?.floor;
    if (floor === undefined || !isLatestEditableSettledFloor(floor, target?.swipe))
      throw Error('仅支持修改当前待结算的变量，或最新已结算楼层的变量输出');
    const row = getChatMessages(floor, { include_swipes: true })[0];
    if (!row || row.role !== 'assistant') throw Error('未找到对应的助手楼层');
    const swipe = row.swipe_id;
    const edited = getChatMessages(floor)[0];
    const extra = messageExtra(edited);
    const oldCommit = extra.cw_story_settlements?.[String(swipe)]?.commitId;
    const context = activeContext(floor - 1);
    const replay = await computeEditedStoryReplay(floor, swipe, edited, extra, context);
    const mode: 'main' | 'extra' = settings.variable.independent ? 'extra' : 'main';
    const channel: VariableOutputChannel = mode === 'main' ? 'story-main' : 'story-extra';
    const assembled = assembleEditedVariableOutput(text, channel);
    const storyText = storedNarrative(edited.message, mode === 'main');
    const priorMessage = getChatMessages(floor - 1)[0];
    const idToSettle = uid('edited_var');
    const next: PendingStory = {
      context,
      envelope: copy(service.host.read(context.floor)),
      text: storyText,
      id: idToSettle,
      source: storySource(messageSource().filter(m => m.id !== floor), idToSettle),
      replyFloor: floor,
      replySwipe: swipe,
      mode,
      ...(mode === 'main'
        ? { reply: `${storyText}\n\n${assembled.transportText}` }
        : {
            reply: assembled.transportText,
            replyFormat: assembled.replyFormat,
            failedReply: assembled.transportText,
            failedReplyFormat: assembled.replyFormat,
            useEditedReply: true,
          }),
      openingTaskId: edited.data?.stat_data?._系统?.提交记录?.[oldCommit]?.任务id ?? undefined,
      intent: priorMessage?.role === 'user' ? messageExtra(priorMessage).cw_use_intent : undefined,
      replay,
      revisionVersion: edited.data?.stat_data?._系统?.数据版本,
      editingOriginal: oldCommit ? { text: edited.message, commitId: oldCommit } : undefined,
    };
    extra.cw_story_request = await narrativeRequest(next);
    extra.cw_update_pending = true;
    assertContext(context, activeContext(floor - 1));
    assertMessageSource(next.source, floor);
    if (getChatMessages(floor)[0]?.message !== edited.message) throw Error('正文在保存变量修改期间发生变化，请重试');
    await writeStoryCandidate(floor, swipe, storyText, extra);
    pending = next;
    await patchChat({
      澄湾待更新正文: next,
      [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
        id: next.id,
        channel,
        state: 'pending',
        floor,
        swipe,
        updatedAt: new Date().toISOString(),
        rawText: assembled.rawRecordText,
        replyFormat: assembled.replyFormat,
        edited: true,
      }),
    });
    if (!retryNow) {
      setError('变量块已修改保存，点击输入区“立即重试”完成重新结算');
      refresh();
      return;
    }
    refresh();
    return await retry();
  }
  async function reRequestPendingVariablesImpl(): Promise<PhoneActionResult | void> {
    requireWriter();
    requireLoaded();
    if (view.busy || view.updating) throw Error('当前操作仍在执行，请等待或停止');
    if (pending && pending.mode === 'extra') {
      const nextPending: PendingStory = { ...pending };
      delete nextPending.reply;
      delete nextPending.replyFormat;
      delete nextPending.useEditedReply;
      delete nextPending.prepared;
      await patchChat({ 澄湾待更新正文: nextPending });
      pending = nextPending;
      return await retry();
    }
    if (pending && pending.mode === 'main' && pending.replyFloor !== undefined) {
      // 同轮模式遇到未展开资料或格式错误时，允许用户显式保留正文、展开缺失资料并单次重算变量（不重写正文、不采用旧猜测补丁）。
      let before = Schema.parse(pending.envelope.stat_data);
      const nextPending: PendingStory = { ...pending };
      if (settings.informationAuto) {
        const rawReply = nextPending.reply ?? nextPending.text;
        try {
          const expandedFromPatch = expandInformationForRetry(before, updateBlock(rawReply, true).commands);
          if (expandedFromPatch !== before) before = expandedFromPatch;
        } catch {
          // 原始变量块可能语法损坏，继续依据正文文本补齐资料。
        }
        const expandedFromStory = ensureInformationContext(before, nextPending.text + informationRetryHint(nextPending.id));
        if (expandedFromStory !== before) before = expandedFromStory;
        nextPending.envelope = { ...nextPending.envelope, stat_data: before };
      }
      nextPending.mode = 'extra';
      nextPending.variableApiOverride = settings.variable.independent ? undefined : 'main';
      delete nextPending.reply;
      delete nextPending.replyFormat;
      delete nextPending.useEditedReply;
      delete nextPending.prepared;
      await patchChat({ 澄湾待更新正文: nextPending });
      pending = nextPending;
      console.info('[瓦洛兰正文变量] 同轮模式转为单次变量补算（保留已生成正文）', { floor: nextPending.replyFloor });
      return await retry();
    }
    if (pendingPhone) {
      const nextPhone = { ...pendingPhone };
      delete nextPhone.reply;
      delete nextPhone.replyFormat;
      delete nextPhone.editedReply;
      delete nextPhone.candidate;
      await patchChat({ 澄湾待更新手机: nextPhone });
      pendingPhone = nextPhone;
      return await retry();
    }
    throw Error('当前待处理操作不支持重新请求变量补算');
  }
  let changingMessages = false;
  async function closeChangedRecovery(start?: number, replacedInput?: number) {
    const changedSource = (source: MessageSource | undefined) => {
      if (replacedInput !== undefined && source?.at(-1)?.id === replacedInput) return true;
      try { assertMessageSource(source, undefined, true); return false; }
      catch (error) {
        if (!(error instanceof MessageSourceError)) throw error;
        return true;
      }
    };
    const changedReply = (floor: number, swipe: number) => {
      if (start !== undefined) return floor >= start;
      if (floor > getLastMessageId()) return true;
      return getChatMessages(floor, { include_swipes: true })[0]?.swipe_id !== swipe;
    };
    const ids: string[] = [];
    const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
    if (pending && (pending.replyFloor !== undefined && changedReply(pending.replyFloor, pending.replySwipe ?? 0) ||
        changedSource(pending.source))) ids.push(pending.id);
    const changedFailed = !!failedSend && changedSource(failedSend.source);
    if (changedFailed && failedSend?.id) ids.push(failedSend.id);
    if (pendingPhone && (changedReply(pendingPhone.context.floor, pendingPhone.context.swipe) ||
        changedSource(pendingPhone.source))) ids.push(pendingPhone.id);
    for (const intent of intents) if (changedSource(intent.source)) ids.push(intent.id);
    if (journal && (ids.includes(journal.commitId) || (journal.replyFloor !== undefined
      ? changedReply(journal.replyFloor, Number(journal.candidate?._系统?.候选回复id))
      : changedReply(journal.context.floor, journal.context.swipe) ||
        changedFailed && preparationJournalMatchesFailure(journal)))) ids.push(journal.commitId);
    for (const id of ids) scheduler.cancel(id, '原楼层或候选已变更');
    await closeRecovery([...new Set(ids)], changedFailed);
    return ids.length > 0 || changedFailed;
  }
  async function messageAction(action: string, id: number, text?: string) {
    requireWriter();
    if (view.busy || view.updating) throw Error('请先停止当前生成');
    if (action === 'swipe') {
      const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
      if (pendingPhone || journal && journal.replyFloor === undefined)
        throw Error('请先重试或取消当前手机与管理操作，再切换候选');
      const target = Number(text), row = getChatMessages(id, { include_swipes: true })[0];
      if (!Number.isSafeInteger(target) || !isCommittedCandidate(row?.swipes_data[target]?.stat_data, id, target))
        throw Error('此旧候选没有已结算变量，不能作为当前分支');
      if (pending && pending.replyFloor === id && pendingAlreadyCommitted(pending)) await finishPending();
      else if (pending?.replyFloor === id && pending.editingOriginal) await cancelEditedStory(pending);
      changingMessages = true;
      try {
        await setMessages([{ message_id: id, swipe_id: target }], { refresh: 'affected' });
        await closeChangedRecovery();
        await saveChat();
      } finally { changingMessages = false; }
      setError('');
      refresh();
      return;
    }
    if (action === 'continue') {
      if (pending || pendingPhone || failedSend) throw Error('请先重试或取消待处理请求');
      if (getChatMessages(-1)[0]?.message_id !== id || activeContext().floor !== id)
        throw Error('只能从当前已结算的最新助手楼层继续');
      await send('接续上一段剧情，不重复已写内容。', false, undefined, uid('continue'), false, undefined, { continuation: true });
      return;
    }
    if (!['edit', 'delete'].includes(action) && settings.variable.independent) validateApi(settings.variable, '正文变量');
    const old = action === 'edit' ? getChatMessages(id)[0] : undefined;
    if (old?.role === 'assistant' && text !== undefined && text !== old.message &&
        await recordEditedStory(id, text)) return;
    const message = old?.role === 'assistant' ? storedNarrative(text ?? '') : text ?? '';
    if (old && (text === undefined || old.message === message || old.message === text)) {
      if (text !== undefined && old.role === 'assistant' && pending?.editingOriginal &&
          await recordEditedStory(id, message)) return;
      await saveChat();
      return;
    }
    if (old?.role === 'assistant' && sameAssistantFloorText(old.message, message, id)) {
      if (pending?.editingOriginal && await recordEditedStory(id, message)) return;
      await setMessages([{ message_id: id, message }], { refresh: 'affected' });
      refresh();
      await saveChat();
      return;
    }
    if (action === 'edit') {
      const recorded = old?.role === 'assistant' && await recordEditedStory(id, message);
      if (!recorded) await setMessages([{ message_id: id, message }], { refresh: 'affected' });
      // 旧操作的排队快照可能截止于玩家输入前；按完整失败快照移除失效重试和同 ID 排队项。
      if (failedSend) await discardStaleRecovery();
      if (recorded) return;
    } else {
      if (id === 0) throw Error('第 0 层为界面容器，请在新聊天中重新建档');
      epoch++;
      const start = action === 'player_send' ? id + 1 : id;
      if (pending?.replyFloor !== undefined && pending.replyFloor >= start && pendingAlreadyCommitted(pending))
        await finishPending();
      const remove = Array.from({ length: Math.max(0, getLastMessageId() - start + 1) }, (_, offset) => start + offset);
      changingMessages = true;
      try {
        await deleteMessages(remove, { refresh: 'affected' });
        await closeChangedRecovery(start, action === 'player_send' ? id : undefined);
      } finally { changingMessages = false; }
      setError('');
      if (action !== 'delete') {
        refresh();
        await saveChat();
        const latest = getChatMessages(-1)[0];
        if (latest?.role === 'assistant')
          await send('接续上一段剧情，不重复已写内容。', false, undefined, uid('continue'), false, undefined, { continuation: true });
        else {
          const state = view.data!;
          const opening = !Object.keys(state._系统.已计轮事件).length &&
            Object.values(state._系统.任务).some(task => task.类别 === '建档' && ['排队', '失败'].includes(task.状态));
          await send(latest?.message ?? '', false, messageExtra(latest).cw_use_intent, uid('round'), opening);
        }
        return;
      }
    }
    refresh();
    await saveChat();
  }
  function phoneAlreadyCommitted(p: NonNullable<typeof pendingPhone>) {
    const current = activeContext();
    return current.chat === p.context.chat && current.floor === p.context.floor &&
      current.swipe === p.context.swipe && current.branch === p.context.branch &&
      !!service.host.read(p.context.floor).stat_data._系统.提交记录[p.id];
  }
  function assertPhoneResultCurrent(result: PhoneActionResult, startedEpoch: number) {
    requireWriter();
    if (cancelled || epoch !== startedEpoch) throw Error('手机结果已取消或上下文已变化');
    const context = activeContext();
    if (context.chat !== result.chatId || context.floor !== result.floor || context.swipe !== result.swipe ||
        !service.host.read(context.floor).stat_data._系统.提交记录[result.id])
      throw Error('手机结果不属于当前聊天、楼层或候选');
  }
  function confirmedPhoneResult(p: { id: string; action: PhoneAction; context: Context }, startedEpoch: number): PhoneActionResult {
    const result: PhoneActionResult = { ...phoneRequestIdentity(p.id, p.action, p.context), type: 'phone', status: 'confirmed' };
    assertPhoneResultCurrent(result, startedEpoch);
    return result;
  }
  function isPhoneResult(result: unknown): result is PhoneActionResult {
    return !!result && typeof result === 'object' && 'type' in result && result.type === 'phone' &&
      'status' in result && result.status === 'confirmed';
  }
  async function clearSavedPhone(p: NonNullable<typeof pendingPhone>, complete: boolean) {
    const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
    const savedReply = complete ? (p.reply ?? p.failedReply) : undefined;
    await patchChat({
      澄湾待更新手机: null,
      ...(journal?.commitId === p.id ? { 澄湾待确认提交: null } : {}),
      ...(savedReply
        ? {
            [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
              id: p.id,
              channel: 'phone',
              state: 'saved',
              floor: p.context.floor,
              swipe: p.context.swipe,
              updatedAt: new Date().toISOString(),
              rawText: savedReply,
              replyFormat: p.replyFormat ?? p.failedReplyFormat,
              edited: p.editedReply || undefined,
              error: p.warnings?.join('\n') || undefined,
            }),
          }
        : {}),
    }, complete ? [p.id] : []);
    if (complete) reportSettlementWarning(p);
    if (pendingPhone === p) pendingPhone = null;
    view.phoneRequest = null;
  }
  async function phoneAction(action: PhoneAction, submissionId = uid('phone_round')): Promise<PhoneActionResult> {
    requireWriter();
    if (view.busy || view.updating || pending || view.managementPending) throw Error('请等待当前任务完成或恢复未确认角色管理操作');
    if (pendingPhone && !equal(pendingPhone.action, action)) throw Error('有待重试手机操作，请先重试或取消');
    view.busy = true;
    cancelled = false;
    const startedEpoch = epoch;
    const assertPhoneWritable = () => {
      requireWriter();
      if (cancelled || epoch !== startedEpoch) throw Error('手机任务已取消或上下文已变化');
    };
    setError('');
    let rejectedReply = false;
    let rosterAttempted = false;
    let operation: NonNullable<typeof pendingPhone> | undefined;
    try {
      setPhoneRequest(pendingPhone ?? { id: submissionId, action, context: activeContext() },
        pendingPhone?.candidate ? 'saving' : pendingPhone?.reply ? 'settling' : 'sending');
      if (!pendingPhone) {
        const alreadyCommitted = !!service.host.read(activeContext().floor).stat_data?._系统?.提交记录?.[submissionId];
        if (!alreadyCommitted) {
          validateApi(settings.phone, '手机');
          await prepareWorldInformation();
        }
        assertPhoneWritable();
        const context = activeContext(),
          envelope = copy(service.host.read(context.floor));
        const before = Schema.parse(envelope.stat_data), source = messageSource();
        const roster = !alreadyCommitted && settings.characterAuto
          ? prepareCharacterRoster(before, getVariables({ type: 'chat' })[LIBRARY_KEY], '', action, settings.characterRoster)
          : null;
        // 在草稿里先调度私信对象，再检查投递资格。当前楼的活动名单随手机结果一起提交。
        const draft = alreadyCommitted ? before : applyPhoneAction(roster ? planTasks(roster.state) : before, action);
        if (roster) {
          rosterAttempted = true;
          // 草稿和后续资料选择都要能从角色库读取这一版；原楼仍指向原版本。
          await patchChat({ [LIBRARY_KEY]: roster.library });
          assertPhoneWritable();
          assertContext(context, activeContext());
          assertMessageSource(source);
        }
        pendingPhone = operation = {
          context,
          id: submissionId,
          envelope,
          draft,
          action: copy(action),
          source,
        };
        await savePhone();
      }
      const p = operation = pendingPhone;
      const { context, id, envelope } = p;
      assertPhoneWritable();
      assertMessageSource(p.source);
      setPhoneRequest(p, p.candidate ? 'saving' : p.reply ? 'settling' : 'sending');
      if (phoneAlreadyCommitted(p)) {
        view.phase = 'saving';
        setPhoneRequest(p, 'saving');
        await service.host.persist();
        assertPhoneWritable();
        assertMessageSource(p.source);
        if (!phoneAlreadyCommitted(p)) throw Error('保存期间候选变化，保留手机恢复记录');
        await clearSavedPhone(p, true);
        setError('');
        refresh();
        return confirmedPhoneResult(p, startedEpoch);
      }
      assertContext(context, activeContext());
      if (!p.candidate && !p.reply) {
        const selected = await selectInformation(p.draft,
          '玩家手机操作与待结算状态：' + JSON.stringify(action) + informationRetryHint(p.id),
          'phone:' + p.id + informationRetryHint(p.id), !!informationRetryHint(p.id), action);
        assertPhoneWritable();
        if (selected !== p.draft) {
          p.draft = selected;
          await savePhone();
        }
      }
      if (!p.candidate) {
        let draft = p.draft;
        const config = settings.phone;
        const taskIds = pendingUpdateTasks(draft);
        const actionBase = Schema.parse(envelope.stat_data);
        const budget = phoneBudget(draft, action, draft._系统.生成密度);
        const instruction =
          '玩家本次手机操作已写入候选状态，不重复执行。按已有交流、人物知情和实际活动生成手机新内容，允许没有回应。数量参考仅用于手机新内容。其他实际变化按本轮变量规则一并结算。\n' +
          phoneTimePrompt(draft);
        const settled = await requestScopedUpdate(
          draft,
          envelope,
          async state => {
            let config = withUpdateTasks(
              await livePromptConfig(state, '', 'worker', undefined, {
                session: action.kind === 'send' ? action.id : undefined,
                post: ['comment', 'like', 'repost'].includes(action.kind) ? action.id : undefined,
                platform: action.platform,
              }),
              state,
              taskIds,
            );
            config = withPromptInstructions(config, [{ role: 'system', position: 'in_chat', depth: 0, content: instruction }]);
            config.user_input = JSON.stringify({ 玩家手机操作: action, 手机新内容数量参考: budget });
            return config;
          },
          config,
          '手机',
          p,
          async state => {
            assertPhoneWritable();
            p.draft = state;
            delete p.reply;
            delete p.replyFormat;
            await savePhone();
          },
          (base, data) => {
            const candidate = validateSettlement(base, validateModel(base, data.stat_data));
            assertPhoneActionNotRepeated(actionBase, base, candidate);
            return finalizePhone(base, candidate);
          },
          p.reply,
          async (text, format) => {
            assertPhoneWritable();
            rejectedReply = false;
            p.reply = text;
            p.replyFormat = format;
            p.failedReply = text;
            p.failedReplyFormat = format;
            delete p.editedReply;
            setPhoneRequest(p, 'settling');
            await savePhone();
          },
          () => {
            rejectedReply = true;
          },
          p.replyFormat,
        );
        assertPhoneWritable();
        draft = settled.before;
        const { text: reply, parsed } = settled;
        try {
          let candidate = finalizeUpdateTasks(draft, parsed.state, taskIds, reply, p.warnings ??= []);
          noteTaskWarnings(p, candidate, taskIds);
          candidate = finalizeWorld(draft, candidate);
          candidate = refreshNovelSystem(candidate);
          assertPhoneWritable();
          assertMessageSource(p.source);
          if (action.kind !== 'refresh' || !equal(draft.手机.原文, candidate.手机.原文)) countRound(candidate, id);
          p.candidate = planTasks(candidate);
        } catch (error) {
          if (error instanceof MissingRosterProgressError) p.retryIssue = { kind: 'missing-progress', targets: error.targetCount };
          rejectedReply = true;
          throw error;
        }
        // Persist the exact derived result before journal/write I/O; retries do not regenerate or assign new delivery IDs.
        await savePhone();
      }
      assertPhoneWritable();
      setPhoneRequest(p, 'saving');
      view.phase = 'saving';
      view.updating = true;
      await service.commit(context, id, () => copy(p.candidate!), false, () => {
        assertPhoneWritable();
        assertMessageSource(p.source);
      });
      assertPhoneWritable();
      await clearSavedPhone(p, true);
      setError('');
      refresh();
      return confirmedPhoneResult(p, startedEpoch);
    } catch (e) {
      const invalidated = cancelled || startedEpoch !== epoch;
      const hadEditedPhoneReply = !!pendingPhone?.editedReply;
      if (pendingPhone && rejectedReply && !pendingPhone.candidate) {
        delete pendingPhone.reply;
        delete pendingPhone.replyFormat;
        delete pendingPhone.editedReply;
      }
      if (invalidated) view.phoneRequest = null;
      else if (pendingPhone) setPhoneRequest(pendingPhone, 'failed');
      setError(invalidated ? '' : e);
      try {
        if (!disposed && SillyTavern.getCurrentChatId() === boundChat) {
          if (invalidated && operation && pendingPhone === operation) {
            if (phoneAlreadyCommitted(operation)) {
              // Stop cannot undo an issued write. Keep its identity so retry only confirms that same submission.
              setPhoneRequest(operation, 'failed');
              setError('手机提交已写入，保存确认尚未完成，请重试确认');
              await savePhone();
            } else await clearSavedPhone(operation, false);
          } else {
            const failedRaw = pendingPhone?.failedReply ?? pendingPhone?.reply;
            if (!invalidated && pendingPhone && failedRaw) {
              await patchChat({
                澄湾待更新手机: pendingPhone,
                [VARIABLE_OUTPUTS_KEY]: nextStoredVariableOutputs({
                  id: pendingPhone.id,
                  channel: 'phone',
                  state: 'failed',
                  floor: pendingPhone.context.floor,
                  swipe: pendingPhone.context.swipe,
                  updatedAt: new Date().toISOString(),
                  rawText: failedRaw,
                  replyFormat: pendingPhone.failedReplyFormat ?? pendingPhone.replyFormat,
                  error: String(e),
                  edited: hadEditedPhoneReply || undefined,
                }),
              });
            } else if (pendingPhone) {
              await savePhone();
            } else if (rosterAttempted) {
              try {
                await saveChat();
              } catch (saveError) {
                console.warn('[瓦洛兰手机] 持久化排队操作未完成', saveError);
              }
            }
          }
        }
      } catch (saveError) {
        if (pendingPhone) setPhoneRequest(pendingPhone, 'failed');
        setError('手机恢复记录保存未确认：' + String(saveError));
        throw Error(view.error, { cause: e });
      }
      throw e;
    } finally {
      view.busy = false;
      view.updating = false;
      refresh();
    }
  }
  async function refreshNovelContent(target: NovelRefreshTarget, id: string) {
    requireWriter();
    const context = activeContext(), journal = getVariables({ type: 'chat' }).澄湾待确认提交;
    const startedEpoch = epoch, source = intents.find(intent => intent.id === id)?.source;
    const assertNovelWritable = () => {
      requireWriter();
      if (cancelled || disposed || epoch !== startedEpoch) throw Error('奇遇刷新已取消或上下文已变化');
      if (source) assertMessageSource(source, undefined, true);
    };
    view.busy = true;
    try {
      assertNovelWritable();
      if (service.host.read(context.floor).stat_data?._系统?.提交记录?.[id]) {
        view.phase = 'saving';
        await service.host.persist();
        if (journal?.commitId === id) await service.host.journal(null);
      } else if (journal?.commitId === id) {
        view.phase = 'saving';
        await service.commit(journal.context, id, () => Schema.parse(journal.candidate), false, assertNovelWritable);
      } else {
        validateApi(settings.phone, '手机与奇遇');
        const state = Schema.parse(service.host.read(context.floor).stat_data);
        const config = novelRefreshPrompt(state, target);
        console.info('[瓦洛兰奇遇] 开始刷新', target);
        const text = await requestExtra(config, state, settings.phone, 'novel');
        assertNovelWritable();
        view.updating = true;
        view.phase = 'saving';
        await service.commit(context, id, candidate => applyNovelRefresh(candidate, target, text, id), false, assertNovelWritable);
      }
      setError('');
      console.info('[瓦洛兰奇遇] 刷新已保存', target);
    } catch (error) {
      if (cancelled && !disposed && SillyTavern.getCurrentChatId() === boundChat) {
        try {
          const savedJournal = getVariables({ type: 'chat' }).澄湾待确认提交;
          const written = service.host.read(context.floor).stat_data?._系统?.提交记录?.[id];
          if (!written && savedJournal?.commitId === id) await service.host.journal(null);
          await persistIntents([id]);
        } catch (saveError) {
          setError('奇遇停止记录保存未确认：' + String(saveError));
          throw Error(view.error, { cause: saveError });
        }
      }
      setError(cancelled ? '' : error);
      throw error;
    } finally {
      view.busy = false;
      view.updating = false;
      refresh();
    }
  }
  function novelRefresh(target: NovelRefreshTarget) {
    requireManagementIdle('刷新奇遇内容');
    if (!['tasks', 'shop', 'initial'].includes(target)) throw Error('未知的奇遇刷新目标');
    if (!view.data?.奇遇系统._启用) throw Error('请先开启奇遇系统');
    validateApi(settings.phone, '手机与奇遇');
    novelRefreshPrompt(view.data, target);
    cancelled = false;
    return submit('novel', { target });
  }
  // Manual maintenance only queues work for the next authorized interaction.
  function runBackground(retryFailed = false): Promise<void> {
    if (!retryFailed) return Promise.resolve();
    requireLoaded();
    return commit(s => {
      for (const task of Object.values(s._系统.任务))
        if (task.状态 === '失败' && taskHasActiveTargets(s, task)) {
          task.状态 = '排队';
          task.错误 = null;
          task.重试次数 += 1;
        }
    });
  }
  function foreground<T>(kind: string, action: () => Promise<T>, key = uid('operation')): Promise<T> {
    requireWriter();
    try { if (kind !== 'recovery') requireLoaded(); }
    catch (error) { return Promise.reject(error); }
    const expectedEpoch = epoch;
    return scheduler.run(
      { key, label: kind === 'recovery' ? '恢复未完成操作' : '保存操作', kind, background: false },
      async () => {
        requireWriter();
        if (kind !== 'recovery') requireLoaded();
        if (epoch !== expectedEpoch) throw Error('排队期间上下文已变化，请重新执行');
        const result = await action();
        const committed = view.data?._系统.提交记录 ?? {};
        const completed = intents.filter(i => committed[i.id]).map(i => i.id);
        if (completed.length) await persistIntents(completed);
        if (isPhoneResult(result)) assertPhoneResultCurrent(result, expectedEpoch);
        return result;
      },
    );
  }
  function enqueueIntent(item: Intent, onSent?: () => void): Promise<PhoneActionResult | void> {
    const existing = scheduler.get(item.id);
    if (existing) return existing;
    scheduled.add(item.id);
    const isNew = !intents.some(i => i.id === item.id);
    if (isNew) intents.push(item);
    const persisted = saveIntents(item.kind !== 'story');
    // Catch immediately; execution still awaits and propagates the persistence failure.
    void persisted.catch(() => {});
    const expectedEpoch = epoch;
    const result = scheduler.run({ key: item.id, label: item.label, kind: item.kind, background: false }, async () => {
      await persisted;
      requireWriter();
      if (item.chat !== boundChat || expectedEpoch !== epoch) throw Error('排队期间聊天或分支已变化，请重新执行');
      refresh();
      // 已落玩家楼只允许恢复这次输入；普通待发项仍可排在前一轮回复之后。
      const savedInput = item.kind === 'story' && item.inputSaved === true;
      const hasRecovery = pending?.id === item.id || pendingPhone?.id === item.id || failedSend?.id === item.id;
      if (!savedInput || (!hasRecovery && !view.data?._系统.提交记录[item.id])) {
        try {
          assertMessageSource(item.source, undefined, !savedInput);
        } catch (error) {
          if (!savedInput || !(error instanceof MessageSourceError)) throw error;
          await persistIntents([item.id]);
          setSourceChangeError(error.message + '。旧请求已清理，可按当前内容重新发送。');
          throw new StaleStoryRequestError(view.error, { cause: error });
        }
      }
      let phoneResult: PhoneActionResult | void = undefined;
      if (item.kind === 'novel' && item.target) {
        if (pending || pendingPhone || failedSend) throw Error('有尚未完成的操作，请先重试或取消');
        await refreshNovelContent(item.target, item.id);
      } else if (!view.data?._系统.提交记录[item.id]) {
        if (hasRecovery) phoneResult = await retry();
        else {
          if (pending || pendingPhone || failedSend) throw Error('有尚未完成的操作，请先重试或取消');
          if (item.kind === 'story')
            await send(item.text ?? '', !savedInput && item.append !== false, item.intent, item.id, item.opening, onSent,
              { newInput: isNew && !savedInput && item.append !== false });
          else if (item.action) phoneResult = await phoneAction(copy(item.action), item.id);
          else throw Error('手机操作记录缺少内容');
        }
      } else if (item.kind === 'phone' && item.action) {
        if (pending || failedSend || (pendingPhone && pendingPhone.id !== item.id))
          throw Error('有尚未完成的操作，请先重试或取消');
        // A commit ID proves the atomic write, not durable acknowledgement. Use the
        // same recovery path as retry(), including persistence, cleanup and stop checks.
        phoneResult = await phoneAction(copy(item.action), item.id);
      }
      if (item.kind === 'phone' && !phoneResult) throw Error('手机操作尚未返回确认结果，请检查待恢复记录');
      await persistIntents([item.id]);
      if (phoneResult) assertPhoneResultCurrent(phoneResult, expectedEpoch);
      return phoneResult;
    });
    return result.finally(() => {
      scheduled.delete(item.id);
      updateQueueView();
    });
  }
  function submit(
    kind: 'phone', payload: Pick<Intent, 'action'>, onSent?: () => void,
    onRequest?: (identity: PhoneRequestIdentity) => void,
  ): Promise<PhoneActionResult>;
  function submit(
    kind: 'story' | 'novel',
    payload: Pick<Intent, 'text' | 'action' | 'append' | 'intent' | 'opening' | 'target'>,
    onSent?: () => void,
  ): Promise<void>;
  function submit(
    kind: 'story' | 'phone' | 'novel',
    payload: Pick<Intent, 'text' | 'action' | 'append' | 'intent' | 'opening' | 'target'>,
    onSent?: () => void,
    onRequest?: (identity: PhoneRequestIdentity) => void,
  ): Promise<PhoneActionResult | void> {
    requireWriter();
    try { requireLoaded(); }
    catch (error) { return Promise.reject(error); }
    payload = copy(payload);
    const duplicate = intents.find(
      i => scheduled.has(i.id) && i.kind === kind && equal(_.pick(i, Object.keys(payload)), payload),
    );
    const existingDuplicate = duplicate ? scheduler.get(duplicate.id) : undefined;
    if (duplicate && existingDuplicate) {
      if (kind === 'phone' && duplicate.action) {
        const identity = submittedPhoneIdentities.get(duplicate) ?? phoneRequestIdentity(
          duplicate.id, duplicate.action, pendingPhone?.id === duplicate.id ? pendingPhone.context : activeContext(),
        );
        onRequest?.({ ...identity });
      }
      return existingDuplicate;
    }
    if ((pending || pendingPhone || failedSend) && !['story', 'phone'].includes(scheduler.active?.kind ?? ''))
      return Promise.reject(Error('有尚未完成的操作，请先重试或取消'));
    if (kind === 'story' && (view.busy || view.updating))
      return Promise.reject(Error('请等待本轮正文与变量更新完成'));
    const phoneLabels = {
      send: '发送消息',
      post: '发布动态',
      comment: '评论',
      like: '切换点赞',
      repost: '转发',
      refresh: '刷新',
      invite: '群聊邀约',
    };
    const label = kind === 'novel' ? (payload.target === 'initial' ? '奇遇：生成初始任务与商品' :
      payload.target === 'tasks' ? '奇遇：刷新任务' : '奇遇：刷新商店') :
      kind === 'story'
        ? '正文：' + (payload.text ?? '').slice(0, 32)
        : '手机' +
          phoneLabels[payload.action!.kind] +
          '：' +
          (payload.action?.text ?? blockText(payload.action?.blocks ?? [])).slice(0, 32);
    const item: Intent = {
      id: uid('action'),
      kind,
      label,
      chat: boundChat,
      source: messageSource(),
      ...payload,
    };
    if (kind === 'phone' && item.action) {
      const identity = phoneRequestIdentity(item.id, item.action, activeContext());
      submittedPhoneIdentities.set(item, identity);
      // Notify this caller synchronously, before scheduling. Frontend mirrors may
      // never observe a short-lived phoneRequest status, so they cannot bind IDs by polling it.
      onRequest?.({ ...identity });
    }
    return enqueueIntent(item, onSent);
  }
  function resumeQueued(id: string) {
    requireWriter();
    const item = intents.find(i => i.id === id);
    if (!item) throw Error('待发送操作不存在');
    requireLoaded();
    if (item.kind === 'novel') cancelled = false;
    return enqueueIntent(item);
  }
  async function cancelQueued(id: string) {
    requireWriter();
    if (scheduler.active?.key === id) throw Error('操作正在执行，请使用停止按钮');
    const novel = intents.find(item => item.id === id && item.kind === 'novel');
    if (novel?.target && view.data?._系统.提交记录[id]) {
      cancelled = false;
      await foreground('recovery', () => refreshNovelContent(novel.target!, id), 'confirm:' + id);
      await persistIntents([id]);
      return;
    }
    if ([pending?.id, pendingPhone?.id, failedSend?.id].includes(id) ||
        intents.some(item => item.id === id && item.kind === 'novel')) {
      await foreground('recovery', discardPending, 'discard');
      return;
    }
    scheduler.cancel(id);
    await persistIntents([id]);
    updateResendState();
  }
  const listeners: EventOnReturn[] = [];
  function preparationJournalMatchesFailure(journal: any) {
    if (!failedSend?.id || !journal?.context) return false;
    const roster = journal.rollbackOnFailure && ['character_roster_', 'opening_roster_'].some(prefix =>
      String(journal.commitId).startsWith(prefix));
    const information = String(journal.commitId).startsWith('information_selection_') &&
      (journal.requestId === failedSend.id || journal.candidate?._系统?.资料加载?.选择依据 === 'story:' + failedSend.id);
    return (roster || information) &&
      ['chat', 'floor', 'swipe', 'branch'].every(key => failedSend!.context[key as keyof Context] === journal.context[key]) &&
      (equal(failedSend.context, journal.context) || equal(JSON.parse(failedSend.context.fingerprint), journal.candidate));
  }
  function recoverablePreparationJournal(journal: any, current?: Context) {
    if (!preparationJournalMatchesFailure(journal)) return false;
    const actual = current ?? activeContext();
    const original = equal(failedSend!.context, journal.context);
    if (original && equal(actual, journal.context)) return true;
    return (original || equal(failedSend!.context, actual)) &&
      ['chat', 'floor', 'swipe', 'branch'].every(key => actual[key as keyof Context] === journal.context[key]) &&
      equal(service.host.read(actual.floor).stat_data, journal.candidate);
  }
  async function discardStaleRecovery() {
    const previous = pending;
    const current = activeContext();
    let reason = '';
    const sourceMatches = (source: MessageSource | undefined, replyFloor?: number) => {
      try {
        assertMessageSource(source, replyFloor);
        return true;
      } catch (error) {
        if (!(error instanceof MessageSourceError)) throw error;
        reason ||= error.message;
        return false;
      }
    };
    const valid = (context: Context, source: MessageSource | undefined, replyFloor?: number) =>
      equal(context, current) && sourceMatches(source, replyFloor);
    const pendingCommitted = pending && pendingAlreadyCommitted(pending, current);
    const stalePending =
      pending &&
      ((!pendingCommitted && (firstUnsettledNarrative()?.message_id ?? pending.replyFloor) !== pending.replyFloor) ||
        !(pendingCommitted ? sourceMatches(pending.source, pending.replyFloor) : valid(pending.context, pending.source, pending.replyFloor)) ||
        (pending.replyFloor !== undefined &&
          pending.replySwipe !== undefined &&
          getChatMessages(pending.replyFloor, { include_swipes: true })[0]?.swipe_id !== pending.replySwipe) ||
        (pending.replyFloor !== undefined &&
          !sameReplyNarrative(pending.text, getChatMessages(pending.replyFloor)[0]?.message ?? '', pending.replyFloor)));
    const phoneCommitted = pendingPhone && phoneAlreadyCommitted(pendingPhone);
    const stalePhone = pendingPhone && !(phoneCommitted
      ? sourceMatches(pendingPhone.source)
      : valid(pendingPhone.context, pendingPhone.source));
    const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
    // 调度可能已写入而保存未确认。原日志证明这次版本变化，retry 会先确认它。
    // A committed preparation still needs its original story identity even if the player
    // temporarily edits its input. retry validates the source again before confirming it.
    const prepared = recoverablePreparationJournal(journal, current);
    const staleFailed = failedSend && !valid(failedSend.context, failedSend.source) && !prepared;
    if (!stalePending && !stalePhone && !staleFailed) return;
    const obsolete = [stalePending && pending?.id, stalePhone && pendingPhone?.id, staleFailed && failedSend?.id]
      .filter((id): id is string => typeof id === 'string');
    await patchChat({
      澄湾待更新正文: stalePending ? null : pending,
      澄湾待更新手机: stalePhone ? null : pendingPhone,
      澄湾失败请求: staleFailed ? null : failedSend,
      ...(stalePending && pending && journal?.replyFloor !== undefined && journal.replyFloor === pending.replyFloor &&
        journal.commitId === pending.id ? { 澄湾待确认提交: null } : {}),
    }, obsolete);
    if (stalePending) pending = null;
    if (stalePhone) pendingPhone = null;
    if (staleFailed) failedSend = null;
    setSourceChangeError((reason || '存档楼层、候选或请求基线已变化') + '。旧请求已清理，可按当前内容重新发送。');
    if (stalePending && previous) await restoreOrphanedNarrative(previous);
  }
  function firstUnsettledNarrative() {
    const base = activeContext().floor;
    const last = getLastMessageId();
    if (last <= base) return undefined;
    return getChatMessages(`${base + 1}-${last}`).find(message => {
      const extra = messageExtra(message);
      return message.role === 'assistant' &&
        extra.cw_update_pending && !extra.cw_incomplete;
    });
  }
  async function restoreOrphanedNarrative(previous?: NonNullable<typeof pending>) {
    if (pending || pendingPhone || failedSend) return;
    const last = firstUnsettledNarrative();
    if (!last) return;
    const extra = messageExtra(last);
    const replySwipe = getChatMessages(last.message_id, { include_swipes: true })[0]?.swipe_id ?? 0;
    if (isCommittedCandidate(last.data?.stat_data, last.message_id, replySwipe) &&
        (!extra.cw_story_request?.id || last.data.stat_data._系统.提交记录[extra.cw_story_request.id])) {
      delete extra.cw_update_pending;
      delete extra.cw_story_request;
      await writeStoryCandidate(last.message_id, replySwipe, last.message, extra);
      await saveChat();
      return;
    }
    const context = activeContext();
    const narrative = stripProtocol(last.message);
    if (!narrative) {
      setError('待更新楼层没有正文，请删除该楼层后重新发送');
      return;
    }
    const original = previous?.replyFloor === last.message_id && (previous.replySwipe ?? 0) === replySwipe
      ? previous : extra.cw_story_request as Awaited<ReturnType<typeof narrativeRequest>> | undefined;
    if (!original?.id || !original.source) {
      setError('待结算正文缺少原请求归属，不能绑定当前输入；请删除该正文后重新发送');
      return;
    }
    const source = storySource(original.source, original.id);
    try {
      assertContext(original.context, context);
      assertMessageSource(source, last.message_id);
      if ('text' in original && !sameReplyNarrative(original.text, last.message, last.message_id)) throw Error('正文已编辑');
      if ('narrativeHash' in original && !await matchesNarrativeHash(original.narrativeHash, narrative, last.message_id))
        throw Error('正文已编辑');
    } catch (error) {
      setError(`第 ${last.message_id} 楼正文的原请求已失效。${error instanceof Error ? error.message : String(error)}。请从该楼的消息菜单重新生成回复。`);
      return;
    }
    pending = {
      context,
      envelope: copy(service.host.read(context.floor)),
      text: last.message,
      reply: original.reply,
      id: original.id,
      intent: IntentSchema.shape.intent.parse(original.intent),
      source,
      replyFloor: last.message_id,
      replySwipe,
      mode: original.mode ?? 'extra',
      openingTaskId: original.openingTaskId,
      replay: original.replay,
      revisionVersion: original.revisionVersion,
      editingOriginal: original.editingOriginal,
    };
    await savePending();
    setError('已找回待结算正文，请点击重试完成变量更新');
  }
  function startOpening() {
    requireWriter();
    if (!view.data?._系统.建档完成) return Promise.reject(Error('请先保存建档资料'));
    if (pending || failedSend) return foreground('recovery', retry, 'retry');
    const queued = intents.find(i => i.opening);
    if (queued) return enqueueIntent(queued);
    if (Object.keys(view.data._系统.已计轮事件).length) return runBackground(true);
    return submit('story', {
      opening: true,
      text: openingMessage,
    });
  }
  async function reload() {
    view.loading = true;
    const previousError = view.loadError;
    view.loadError = '';
    view.loadPhase = '';
    if (previousError && view.error === previousError) setError('');
    let phase: 'read' | 'worldbook' | 'recovery' = 'read';
    try {
      restoreIntents();
      if (!refresh()) return;
      if (view.managementPending) setError('角色管理保存尚未确认，请点击重试；恢复快照已独立保留');
      phase = 'worldbook';
      if (!view.readOnly) {
        await settingsController.recoverLegacyRules();
        requireWriter();
        await inVariableSettingsOrder(syncPromptWorldbook);
      }
      if (!view.readOnly) await settingsController.removeLegacyAtmosphere();
      if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return;
      phase = 'recovery';
      if (!view.readOnly) {
        try {
          // 未完成请求拥有原版本；中断任务整理不能先提交新版本，使原正文失去恢复依据。
          if (!pending && !pendingPhone && !failedSend && !getVariables({ type: 'chat' }).澄湾待确认提交 &&
              Object.values(view.data?._系统.任务 ?? {}).some(t => ['生成中', '待校验', '待提交'].includes(t.状态)) &&
              !firstUnsettledNarrative()) {
            await service.commit(activeContext(), uid('task_recovery'), s => {
              for (const t of Object.values(s._系统.任务))
                if (['生成中', '待校验', '待提交'].includes(t.状态)) {
                  t.状态 = '失败';
                  t.错误 = '上次任务已中断，等待手动重试';
                }
            });
            refresh();
          }
          await discardStaleRecovery();
          await restoreOrphanedNarrative();
          const journal = getVariables({ type: 'chat' }).澄湾待确认提交;
          if (
            journal &&
            journal.replyFloor === undefined &&
            !failedSend &&
            !pending &&
            !pendingPhone &&
            view.data && committedPreparation(journal, activeContext(), view.data)
          ) {
            await patchChat({ 澄湾待确认提交: null });
          }
          const activeJournal = getVariables({ type: 'chat' }).澄湾待确认提交;
          const inProgress = [pending?.id, pendingPhone?.id, failedSend?.id, activeJournal?.commitId];
          const completed = intents.filter(item => !inProgress.includes(item.id) && view.data?._系统.提交记录[item.id]);
          if (completed.length) await persistIntents(completed.map(item => item.id));
        } catch (error) {
          // Keep the service available so the player can switch back to a valid candidate.
          if (!(error instanceof CandidateIdentityError)) throw error;
          setError(error);
          refreshMessages();
        }
      }
      if (pending || failedSend || pendingPhone) setError('上次请求尚未完成，请点击重试');
      else if (!view.error && !view.readOnly && getVariables({ type: 'chat' }).澄湾待确认提交?.replyFloor !== undefined)
        setError('上次回复的结算尚未确认，请点击重试核对原楼层。');
    } catch (error) {
      if (!disposed && SillyTavern.getCurrentChatId() === boundChat) setLoadError(error, phase);
    } finally {
      view.loading = false;
      refreshVariableOutputs();
      updateReadAvailability();
    }
  }
  async function start() {
    view.readOnly = true;
    await new Promise<void>((ready, reject) => {
      writerTask = requestBrowserLock('澄湾写入:' + boundChat, {
        ifAvailable: true,
        onLost: error => {
          view.readOnly = true;
          epoch++;
          stop();
          setError(error);
          releaseWriter?.();
        },
      }, async lock => {
          if (!lock) {
            setError('此聊天已有活动写入窗口，本窗口只读');
            ready();
            return;
          }
          if (disposed) {
            ready();
            return;
          }
          view.readOnly = false;
          writerLock = lock;
          const held = new Promise<void>(resolve => {
            releaseWriter = resolve;
          });
          ready();
          await held;
        })
        .catch(reject);
    });
    if (disposed || SillyTavern.getCurrentChatId() !== boundChat) {
      releaseWriter?.();
      return;
    }
    try {
      const loadedSettings = await settingsController.load();
      if (disposed || SillyTavern.getCurrentChatId() !== boundChat) {
        releaseWriter?.();
        return;
      }
      Object.assign(settings, loadedSettings.value);
      view.settingsWarning = loadedSettings.warning;
      listeners.push({
        stop: subscribeExternalSettings(() => {
          if (disposed || SillyTavern.getCurrentChatId() !== boundChat) return;
          lastParsedStateFingerprint = null;
          refresh();
        }),
      });
      if (!isExternalSettingsLoaded()) {
        void loadExternalSettings().catch(err => console.warn('[瓦罗兰外置设定] 异步载入失败，继续使用当前存档资料', err));
      }
      await reload();
      if (disposed || SillyTavern.getCurrentChatId() !== boundChat) {
        releaseWriter?.();
        return;
      }
    } catch (error) {
      releaseWriter?.();
      throw error;
    }
    listeners.push(
      listen(iframe_events.STREAM_TOKEN_RECEIVED_FULLY, (text, id) => {
        // 重试与楼层菜单也会发起正文请求，队列操作类型不能决定分片属于哪个通道。
        if (!cancelled && !disposed && view.generationId && id === view.generationId && view.phase === 'story') {
          receivedStory = text;
          view.streaming = text;
        }
      }),
    );
    listeners.push(listen(tavern_events.GENERATION_STOPPED, (id?: string) => {
      // Helper includes its generation id; native Tavern's global stop has none.
      if (view.generationId && (id === undefined || id === view.generationId)) cancelCurrentGeneration();
    }));
    const mvuBaselines = new WeakMap<Mvu.MvuData, Mvu.MvuData>();
    listeners.push(listen(Mvu.events.BEFORE_MESSAGE_UPDATE, context => {
      if (SillyTavern.getCurrentChatId() !== boundChat) return;
      // This event belongs to MVU's automatic message save. Public parseMessage calls
      // only prepare candidates and must retain their own results.
      const baseline = mvuBaselines.get(context.variables);
      mvuBaselines.delete(context.variables);
      const baseVersion = baseline?.stat_data?._系统?.数据版本;
      if (baseVersion === undefined) return;
      let managedStory: any;
      for (let end = getLastMessageId(); end >= 0 && !managedStory; end -= 10) {
        const floors = getChatMessages(`${Math.max(0, end - 9)}-${end}`, { role: 'assistant', include_swipes: true });
        for (const message of floors.reverse()) {
          const extra = messageExtra({ extra: message.swipes_info[message.swipe_id] });
          const version = extra.cw_story_settlements?.[String(message.swipe_id)]?.baseVersion
            ?? extra.cw_story_request?.context?.version;
          if (message.swipes[message.swipe_id] === context.message_content && version === baseVersion) {
            managedStory = message;
            break;
          }
        }
      }
      if (!managedStory) return;
      const saved = managedStory.swipes_data[managedStory.swipe_id];
      const data = saved?.stat_data ? saved : baseline;
      // The Runtime owns settlement for these floors. Restore its saved envelope,
      // including pending baselines, before MVU writes its automatic candidate.
      for (const key of Object.keys(context.variables)) delete context.variables[key];
      Object.assign(context.variables, copy(data));
    }));
    listeners.push(listen(Mvu.events.VARIABLE_UPDATE_ENDED, (next, old) => {
      // Explicit settlement validates the returned candidate before it can be written.
      if (next?.[MVU_SETTLEMENT_PROBE] || old?.[MVU_SETTLEMENT_PROBE]) return;
      mvuBaselines.set(next, old);
      if (!old?.stat_data || !next?.stat_data) return;
      try { assertDisabledUnchanged(Schema.parse(old.stat_data), Schema.parse(next.stat_data)); }
      catch (error) {
        rejectedMvuCandidates.set(next, error);
        next.stat_data = copy(old.stat_data);
        console.warn('[瓦洛兰角色启停] 已拒绝停用人物活动', error);
        throw error;
      }
    }));
    const chat = boundChat;
    listeners.push(
      listen(tavern_events.CHAT_CHANGED, () => {
        if (!disposed && SillyTavern.getCurrentChatId() !== chat) {
          epoch++;
          stop();
          window.location.reload();
        }
      }),
    );
    listeners.push(
      listen(tavern_events.MESSAGE_EDITED, async id => {
        try {
          if (!view.readOnly) await recordEditedStory(id);
        } catch (error) {
          setError('编辑后的变量尚未重新结算：' + String(error));
          console.error('[瓦洛兰原生编辑] 记录待更新失败', error);
        }
      }),
    );
    for (const event of [
      tavern_events.MESSAGE_SWIPED,
      tavern_events.MESSAGE_DELETED,
      tavern_events.MESSAGE_UPDATED,
      tavern_events.USER_MESSAGE_RENDERED,
      tavern_events.CHARACTER_MESSAGE_RENDERED,
      Mvu.events.VARIABLE_UPDATE_ENDED,
    ])
      listeners.push(
        listen(event as any, async (next?: Mvu.MvuData, old?: Mvu.MvuData) => {
          if (event === Mvu.events.VARIABLE_UPDATE_ENDED && (next?.[MVU_SETTLEMENT_PROBE] || old?.[MVU_SETTLEMENT_PROBE])) return;
          if (event === tavern_events.MESSAGE_UPDATED && requestSource) {
            try {
              assertMessageSource(requestSource, undefined, true);
            } catch (error) {
              if (!(error instanceof MessageSourceError)) throw error;
              sourceChange ??= error;
              stop();
            }
          }
          if (event === tavern_events.MESSAGE_SWIPED || event === tavern_events.MESSAGE_DELETED) {
            if (changingMessages) return;
            epoch++;
            stop();
            if (!view.readOnly) {
              try {
                const closed = await closeChangedRecovery();
                if (closed && !pending && !pendingPhone && !failedSend && !getVariables({ type: 'chat' }).澄湾待确认提交)
                  setError('');
              }
              catch (error) { setError(error); }
            }
          }
          refresh();
        }),
      );
  }
  function dispose() {
    if (disposed) return writerTask ?? Promise.resolve();
    disposed = true;
    stopMessageReconciliation?.();
    messageObservers.clear();
    invalidateOpeningPrewarm();
    for (const wake of [...retryWakeups]) wake();
    scheduler.close();
    epoch++;
    stop();
    listeners.forEach(l => l.stop());
    releaseWriter?.();
    return writerTask ?? Promise.resolve();
  }
  return {
    view,
    settings,
    service,
    start,
    dispose,
    refresh,
    refreshMessages,
    observeMessages,
    loadEarlierMessages,
    reload: () => foreground('recovery', async () => {
      await reload();
      if (view.loadError) throw Error(view.loadError);
    }, 'reload'),
    manageCharacters,
    manageInformation,
    novelAction,
    novelRefresh,
    exportManagedCharacter: (id: string) => {
      requireWriter();
      return exportManagedCharacter(Schema.parse(service.host.read(activeContext().floor).stat_data), getVariables({ type: 'chat' })[LIBRARY_KEY], id);
    },
    commit: (mutate: (s: State) => void | State, id = uid('commit'), options?: { skipUnchanged?: boolean }) =>
      foreground('local', () => commit(mutate, id, options?.skipUnchanged ?? false), id),
    createProfile: (payload: Parameters<typeof saveCreatedProfile>[0]) =>
      foreground('local', () => saveCreatedProfile(payload), payload.submissionId),
    prewarmOpening,
    send: (text: string, append = true, intent?: UseIntent, onSent?: () => void) =>
      submit('story', { text, append, intent }, onSent),
    startOpening,
    stop,
    retry: (): Promise<PhoneActionResult | void> => {
      const existing = scheduler.get('retry');
      if (existing) return existing;
      if (view.busy || view.updating) return Promise.reject(Error('当前操作仍在执行，请等待或停止'));
      return foreground('recovery', retry, 'retry');
    },
    discardPending: () => foreground('recovery', discardPending, 'discard'),
    messageAction: (action: string, id: number, text?: string) =>
      foreground('local', () => messageAction(action, id, text), `message:${action}:${id}`),
    saveSettings: (input: unknown = copy(settings), channel?: SettingsScope) =>
      !channel || channel === 'variable' ? inVariableSettingsOrder(() => saveSettings(input, channel)) : saveSettings(input, channel),
    reloadSettings: (channel?: SettingsChannel) =>
      !channel || channel === 'variable' ? inVariableSettingsOrder(() => reloadSettings(channel)) : reloadSettings(channel),
    phoneAction: (action: PhoneAction, onRequest?: (identity: PhoneRequestIdentity) => void): Promise<PhoneActionResult> => {
      try {
        return submit('phone', { action }, undefined, onRequest);
      } catch (error) {
        return Promise.reject(error);
      }
    },
    runBackground,
    readAlertMemory,
    saveAlertMemory,
    getVariableOutput,
    listVariableOutputs,
    saveEditedVariableOutput: (input: {
      text: string;
      target?: { floor?: number; swipe?: number; id?: string; channel?: VariableOutputChannel };
      retryNow?: boolean;
    }): Promise<PhoneActionResult | void> => {
      if (view.busy || view.updating) return Promise.reject(Error('当前操作仍在执行，请等待或停止'));
      return foreground('recovery', () => saveEditedVariableOutputImpl(input), 'variable_edit');
    },
    reRequestPendingVariables: (): Promise<PhoneActionResult | void> => {
      if (view.busy || view.updating) return Promise.reject(Error('当前操作仍在执行，请等待或停止'));
      return foreground('recovery', reRequestPendingVariablesImpl, 'variable_rerequest');
    },
    resumeQueued,
    cancelQueued,
    revision: () => [...Object.values(view), ...Object.values(settings)],
    snapshot: () => JSON.stringify({ view, settings }),
  };
}
export type Runtime = ReturnType<typeof createRuntime>;
export const RuntimeKey = Symbol('澄湾运行服务');
