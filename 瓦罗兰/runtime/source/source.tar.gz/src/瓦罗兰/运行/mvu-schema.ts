/*! Adapted from StageDog/tavern_resource util/mvu_zod.ts. Local changes: schema-aware private _-path blocking, error symbol collection, no new Function eval, disposer return. License: PolyForm Noncommercial 1.0.0 https://polyformproject.org/licenses/noncommercial/1.0.0/ */
import { prettifyErrorWithInput } from '../../../util/common';
import { isPrivateModelPath, publicModelFields } from './model-fields';
import type { ZodType } from 'zod';

// Schema and settlement run in separate card iframes. Keep the error on the exact
// candidate, outside enumerable/save data, rather than relying on UI notifications.
const commandErrors = Symbol.for('valoran.mvu.commandErrors');
// MVU clones the input envelope before emitting events. Remove this enumerable flag before handing the candidate to persistence.
export const MVU_SETTLEMENT_PROBE = '__valoranSettlementProbe';
export function assertMvuCommandResult(candidate: Mvu.MvuData) {
  const errors: string[] | undefined = (candidate as any)[commandErrors];
  if (!errors?.length) return;
  delete (candidate as any)[commandErrors];
  throw Error(errors.join('\n'));
}

// 整项回填省略地图字段时，取同批上一条命令后的标点，避免 Schema 将其补为空坐标。
function retainMapPositions(previous: Record<string, any>, next: Record<string, any>, path: string[]) {
  for (const [collection, field] of [[['地点'], '地图位置'], [['世界', '片区'], '地图中心']] as const) {
    if (path.length > collection.length + 1 || !collection.every((key, i) => i >= path.length || key === path[i])) continue;
    const records = _.get(next, collection);
    const prior = _.get(previous, collection);
    const ids = path.length > collection.length ? [path[collection.length]] : Object.keys(records ?? {});
    for (const id of ids) {
      const row = records?.[id];
      if (_.isPlainObject(row) && !Object.hasOwn(row, field) && prior?.[id]?.[field] !== undefined)
        row[field] = prior[id][field];
    }
  }
}

export function registerMvuSchema(input: ZodType<Record<string, any>> | (() => ZodType<Record<string, any>>)) {
  const unwrapSchema = () => {
    const original_schema = typeof input === 'function' ? input() : input;
    const schema = original_schema instanceof z.ZodObject ? z.looseObject(original_schema.shape) : original_schema;
    if (typeof registerVariableSchema === 'function') {
      registerVariableSchema(z.object({ stat_data: schema }), { type: 'message' });
    }
    return schema;
  };

  unwrapSchema();

  const on_variable_initialized = (variables: Mvu.MvuData, swipe_id: number) => {
    const schema = unwrapSchema();
    try {
      const result = schema.safeParse(_.get(variables, 'stat_data', {}), { reportInput: true });
      if (result.success) {
        variables.stat_data = { ...variables.stat_data, ...result.data };
        return;
      }
      reportError('error', z.prettifyError(result.error), `开局 '${swipe_id + 1}' 变量初始化失败`);
    } catch (e) {
      const error = e as Error;
      reportError(
        'error',
        error.stack ? error.stack : error.name + ': ' + error.message,
        `第 ${swipe_id + 1} 条开场白的变量初始化失败`,
      );
    }
  };
  eventOn('mag_variable_initialized', on_variable_initialized);

  // on_error 是 MVU 收集模式追加的第四个参数；旧版调用方不传时继续使用原有错误通知。
  const on_command_parsed = (
    variables: Mvu.MvuData,
    commands: Mvu.CommandInfo[],
    _message_content?: string,
    on_error?: (error_info: string) => void,
  ) => {
    const schema = unwrapSchema();
    const notification_enabled = Boolean($('#mvu_notification_error').prop('checked'));

    /** 收集模式不受通知开关影响，并由调用方负责展示；未提供回调时保留原有通知。 */
    const report_command_error = (content: string, command: Mvu.CommandInfo) => {
      const title = `发生变量更新错误, 可能需要重Roll: ${command.full_match}`;
      if (!Object.hasOwn(variables, commandErrors))
        Object.defineProperty(variables, commandErrors, { value: [], configurable: true });
      (variables as any)[commandErrors].push(`${title}\n${content}`);
      if (on_error) {
        on_error(`${title}\n${content}`);
      } else if (notification_enabled && !variables[MVU_SETTLEMENT_PROBE]) {
        reportError('warn', content, title);
      }
    };

    const checkSchema = (data: any, command: Mvu.CommandInfo, should_report: boolean) => {
      let error_message = '';
      try {
        if (command.type === 'set' || command.type === 'insert')
          retainMapPositions(variables.stat_data, data, _.toPath(parsePath(command.args[0])));
        const result = schema.safeParse(data, { reportInput: true });
        if (result.success) {
          return result.data;
        }
        error_message = prettifyErrorWithInput(result.error);
      } catch (e) {
        const error = e as Error;
        error_message = error.stack ? error.stack : error.name + ': ' + error.message;
      }

      // 插入时可能先尝试对象再尝试数组，仅报告最终失败，避免收集到已恢复的探测错误。
      if (should_report) {
        report_command_error(error_message, command);
      }
      return null;
    };

    const isReadonlyPath = (path: string | string[]) => {
      const parts = typeof path === 'string' ? (path ? _.toPath(path) : []) : path;
      return parts.length > 0 && isPrivateModelPath(parts);
    };

    const deletePathParts = (args: string[]) => {
      if (args.length <= 1) return _.toPath(parsePath(args[0] ?? ''));
      return [..._.toPath(parsePath(args[0])), ...args.slice(1).map(parsePath)];
    };

    const hasForbiddenPrivatePayload = (currentData: any, basePath: string[], nextValue: unknown): boolean => {
      if (!nextValue || typeof nextValue !== 'object') return false;
      const privateEntries: { path: string[]; value: unknown }[] = [];
      const collect = (node: unknown, route: string[]) => {
        if (!node || typeof node !== 'object') return;
        if (Array.isArray(node)) {
          node.forEach((item, i) => collect(item, [...route, String(i)]));
          return;
        }
        for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
          const child = [...route, k];
          if (isPrivateModelPath(child)) privateEntries.push({ path: child, value: v });
          else collect(v, child);
        }
      };
      collect(nextValue, basePath);
      if (!privateEntries.length) return false;
      let defaults: any;
      for (const { path: child, value } of privateEntries) {
        if (_.has(currentData, child)) {
          if (!_.isEqual(_.get(currentData, child), value)) return true;
        } else {
          if (defaults === undefined) {
            const probe = klona(currentData);
            const stripped = publicModelFields(nextValue, basePath);
            const raw = basePath.length ? _.set(probe, basePath, stripped) : stripped;
            const parsed = schema.safeParse(raw);
            defaults = parsed.success ? parsed.data : null;
          }
          if (!defaults || !_.isEqual(_.get(defaults, child), value)) return true;
        }
      }
      return false;
    };

    const applyCommand = (data: any, command: Mvu.CommandInfo): Record<string, any> | null => {
      switch (command.type) {
        case 'set': {
          if (command.args.length === 3) {
            command.args.splice(1, 1);
          }
          const path = parsePath(command.args[0]);
          const pathParts = path ? _.toPath(path) : [];
          if (isReadonlyPath(pathParts)) {
            return null;
          }
          const value = parseCommandValue(command.args[1]);
          if (hasForbiddenPrivatePayload(data, pathParts, value)) {
            return null;
          }
          if (path) {
            _.set(data, pathParts, value);
          } else {
            data = value;
          }
          return checkSchema(data, command, true);
        }
        case 'add': {
          const path = parsePath(command.args[0]);
          if (!path || isReadonlyPath(path)) {
            return null;
          }
          const old_value = _.get(data, path);
          const old_value_type = typeof old_value;
          if (old_value_type !== 'number') {
            report_command_error(
              [
                `✖ 不能对非数字类型 '${old_value_type}' 进行加减运算`,
                `  → 路径: ${path}`,
                `  → 原值: ${JSON.stringify(old_value)}`,
              ].join('\n'),
              command,
            );
            return null;
          }
          const delta_value = parseCommandValue(command.args[1]);
          _.update(data, path, value => value + Number(delta_value));
          return checkSchema(data, command, true);
        }
        case 'insert': {
          const path = parsePath(command.args[0]);
          const pathParts = path ? _.toPath(path) : [];
          if (isReadonlyPath(pathParts)) {
            return null;
          }
          const key_or_index = parseCommandValue(command.args[1]);
          const value = parseCommandValue(command.args.at(-1)!);

          const insert = (data: any, should_report: boolean) => {
            const collection = path === '' ? data : _.get(data, pathParts);
            const is_array = _.isArray(collection);
            if (command.args.length === 2) {
              if (is_array) {
                if (hasForbiddenPrivatePayload(data, [...pathParts, String(collection.length)], value)) return null;
                collection.push(value);
              } else {
                if (_.isPlainObject(value)) {
                  for (const [k, v] of Object.entries(value)) {
                    const targetParts = [...pathParts, k];
                    if (isReadonlyPath(targetParts) || hasForbiddenPrivatePayload(data, targetParts, v)) return null;
                  }
                }
                _.assign(collection, value);
              }
            } else if (is_array) {
              const targetIndex = key_or_index === '-' ? collection.length : key_or_index;
              if (hasForbiddenPrivatePayload(data, [...pathParts, String(targetIndex)], value)) return null;
              collection.splice(targetIndex, 0, value);
            } else {
              const targetParts = [...pathParts, String(key_or_index)];
              if (isReadonlyPath(targetParts) || hasForbiddenPrivatePayload(data, targetParts, value)) return null;
              collection[String(key_or_index)] = value;
            }
            return checkSchema(data, command, should_report);
          };

          const collection = path === '' ? data : _.get(data, pathParts);
          const is_nil = _.isNil(collection);
          if (!is_nil && !_.isArray(collection) && !_.isPlainObject(collection)) {
            return null;
          }
          if (!is_nil) {
            return insert(data, true);
          }
          const filled = _(klona(data));
          const result_as_object = insert(filled.set(pathParts, {}).value(), false);
          if (result_as_object) {
            return result_as_object;
          }
          return insert(filled.set(pathParts, []).value(), true);
        }
        case 'delete': {
          const path_array = deletePathParts(command.args);
          if (isReadonlyPath(path_array)) {
            return null;
          }
          // 保留路径分段，避免 `inventory.v2` 这类带点号的键被重新解释成多层路径。
          const parent_path = _.dropRight(path_array);
          const parent = parent_path.length ? _.get(data, parent_path) : data;
          if (_.isArray(parent)) {
            _.pullAt(parent, Number(_(path_array).last()));
          } else {
            _.unset(data, path_array);
          }
          return checkSchema(data, command, true);
        }
      }
      return null;
    };

    const consumed_indices: number[] = [];
    commands.forEach((command, index) => {
      let data: Record<string, any> | null = klona(variables.stat_data);
      if (command.type === 'move') {
        const from_path = parsePath(command.args[0]);
        const from_parts = _.toPath(from_path);
        const to_path = parsePath(command.args[1]);
        const to_parts = _.toPath(to_path);
        if (isReadonlyPath(from_parts) || isReadonlyPath(to_parts)) {
          return;
        }
        if (!_.has(data, from_parts)) {
          report_command_error(`移动源路径不存在: ${from_path}`, command);
          return;
        }
        const value = klona(_.get(data, from_parts));
        if (hasForbiddenPrivatePayload(data, to_parts, value)) {
          return;
        }
        const from_parent_path = _.dropRight(from_parts);
        const from_parent = from_parent_path.length ? _.get(data, from_parent_path) : data;
        if (_.isArray(from_parent)) {
          _.pullAt(from_parent, Number(_.last(from_parts)));
        } else {
          _.unset(data, from_parts);
        }
        if (to_parts.length) {
          _.set(data, to_parts, value);
        } else {
          data = value;
        }
        data = checkSchema(data, command, true);
      } else {
        data = applyCommand(data, command);
      }

      // 顶层 delete/move 会让 data 少一个键，仅按 data 现有键比较会误判为没有变化；
      // 对象展开也不会删除旧键，因此合并前需要显式清理被移除的源路径。
      const removed_paths =
        command.type === 'delete'
          ? [deletePathParts(command.args)]
          : command.type === 'move'
            ? [_.toPath(parsePath(command.args[0]))]
            : [];
      const has_removed_value =
        data !== null && removed_paths.some(path => _.has(variables.stat_data, path) && !_.has(data, path));

      if (data !== null && (has_removed_value || !_.isEqual(data, _.pick(variables.stat_data, Object.keys(data))))) {
        removed_paths.forEach(path => {
          if (!_.has(data, path)) {
            _.unset(variables.stat_data, path);
          }
        });
        variables.stat_data = { ...variables.stat_data, ...data };
        consumed_indices.push(index);
      }
    });

    _.pullAt(commands, consumed_indices);
  };
  eventOn('mag_command_parsed_for_zod', on_command_parsed);

  const on_command_parsed_ended = (_variables: Mvu.MvuData, commands: Mvu.CommandInfo[]) => {
    commands.length = 0;
  };
  eventOn('mag_command_parsed_ended_for_zod', on_command_parsed_ended);

  const on_variable_update_ended = (variables: Mvu.MvuData) => {
    _.set(variables, 'schema', '没有用别管这个');
    _.unset(variables, 'display_data');
    _.unset(variables, 'delta_data');
  };
  eventOn('mag_variable_update_ended_for_zod', on_variable_update_ended);

  console.info('变量结构注册成功');
  return () => {
    eventRemoveListener('mag_variable_initialized', on_variable_initialized);
    eventRemoveListener('mag_command_parsed_for_zod', on_command_parsed);
    eventRemoveListener('mag_command_parsed_ended_for_zod', on_command_parsed_ended);
    eventRemoveListener('mag_variable_update_ended_for_zod', on_variable_update_ended);
  };
}

function escapeHtml(text: string): string {
  return text
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function reportError(level: 'error' | 'warn', content: string, title: string) {
  toastr[level === 'warn' ? 'warning' : 'error'](
    escapeHtml(content).replaceAll('\n', '<br>'),
    '[MVU zod]' + escapeHtml(title),
    { escapeHtml: false },
  );
  console[level](`${title}\n${content}`);
}

function trimQuotesAndBackslashes(string: string): string {
  return string.replace(/^[\\"'` ]*(.*?)[\\"'` ]*$/, '$1');
}

function parsePath(string: string): string {
  return (
    trimQuotesAndBackslashes(string)
      // 一些错误提示词写法会导致 AI 在更新变量时带上 `stat_data.` 或 `status_current_variables.` 前缀, 这里将它去掉
      .replace(/^(?:stat_data|status_current_variables)\./, '')
  );
}

function parseCommandValue(string: any): any {
  if (typeof string !== 'string') {
    return string;
  }

  const value = parseCommandValueImpl(string);
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (Array.isArray(value)) {
    return value.map(item => (item instanceof Date ? item.toISOString() : item));
  }
  return value;
}

function parseCommandValueImpl(string: string): any {
  const trimmed = string.trim();

  if (trimmed === 'true') {
    return true;
  }
  if (trimmed === 'false') {
    return false;
  }
  if (trimmed === 'null') {
    return null;
  }
  if (trimmed === 'undefined') {
    return undefined;
  }

  try {
    return JSON.parse(trimmed);
  } catch {
    // 非标准 JSON 交由下方 YAML.parse 安全解析。
  }

  try {
    return YAML.parse(trimmed);
  } catch {
    // 无法按 YAML 解析时退回去除包裹引号的纯字符串。
  }

  return trimQuotesAndBackslashes(string);
}
