import type { State } from '../../../运行/core';
import { dragonRiftLinkId, iceWellPassageId, stillwaterPassageId, witnessedMapLink } from '../../../运行/map';

type Reflection = {
  sheetId: string;
  dreamId: string;
  label: string;
  returnLabel: string;
  center: { x: number; y: number };
  eventLink?: string;
  passageFact?: string;
};

// 坐标采用目标图幅的 1000 × 700 视图。主路与支路共用同一幅内景。
const icePrison = { sheetId: '15-4', dreamId: '15-4-01', label: '查看冰封监视者视界', center: { x: 266, y: 167 } };
const undergroundMaze = { sheetId: '15-4', dreamId: '15-4-02', label: '查看地下紫菌迷宫', center: { x: 251, y: 514 } };

export const reflections: Record<string, Reflection> = {
  '01-2-03': { sheetId: '15-1', dreamId: '15-1-02', label: '查看校舍倒影', returnLabel: '回看瓦洛兰高中', center: { x: 605, y: 386 } },
  '01-5-02': { sheetId: '15-1', dreamId: '15-1-01', label: '查看商场倒影', returnLabel: '回看星梦复古未来商业广场', center: { x: 245, y: 170 } },
  '08-1-02': { sheetId: '15-2', dreamId: '15-2-01', label: '查看樱河渡口', returnLabel: '回看神柳圣林祭坛', center: { x: 235, y: 176 } },
  '01-5-05': { sheetId: '15-2', dreamId: '15-2-02', label: '查看潜梦回廊', returnLabel: '回看星夜花园公寓群', center: { x: 224, y: 517 } },
  '03-3-01': { sheetId: '15-2', dreamId: '15-2-03', label: '查看血玫瑰荒林', returnLabel: '回看龙脊凹谷', center: { x: 840, y: 394 }, eventLink: dragonRiftLinkId },
  '01-5-03': { sheetId: '15-3', dreamId: '15-3-01', label: '查看四幕星辰悬空剧场', returnLabel: '回看四拍先锋歌剧院', center: { x: 252, y: 147 } },
  '05-1-01': { sheetId: '15-3', dreamId: '15-3-02', label: '查看死者铁城', returnLabel: '回看不朽堡垒主殿', center: { x: 250, y: 446 } },
  '13-1-02': { sheetId: '15-3', dreamId: '15-3-03', label: '查看奇点引力坟场', returnLabel: '回看魂锁黑狱灯塔', center: { x: 807, y: 293 } },
  '06-1-02': { ...icePrison, returnLabel: '回看嚎哭深渊大桥' },
  '10-2-01': { ...undergroundMaze, returnLabel: '回看艾卡西亚焦土防线' },
  '10-2-02': { sheetId: '15-4', dreamId: '15-4-03', label: '查看紫海新生摇篮核心', returnLabel: '回看窃星伪神殿', center: { x: 822, y: 279 } },
  '06-1-03': { ...icePrison, returnLabel: '回看极北瓷冰秘殿', passageFact: iceWellPassageId },
  '03-3-03': { ...undergroundMaze, returnLabel: '回看深渊死水潭', passageFact: stillwaterPassageId },
};

export const reflectionSheets = new Set(Object.values(reflections).map(link => link.sheetId));

export function knownReflectionSources(state: Pick<State, '玩家' | '事件'>, spots: Record<string, unknown>) {
  return Object.keys(reflections).filter(id => {
    const link = reflections[id];
    if (!spots[id] || !spots[link.dreamId]) return false;
    if (link.eventLink) return witnessedMapLink(state, link.eventLink);
    if (!link.passageFact) return true;
    const fact = state.玩家.已知信息.获知事项?.[link.passageFact];
    return fact?.性质 === '事实' && fact.对象id === id && Boolean(fact.内容?.trim());
  });
}
