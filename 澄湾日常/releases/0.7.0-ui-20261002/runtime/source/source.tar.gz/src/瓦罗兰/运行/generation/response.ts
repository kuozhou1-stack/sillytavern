/**
 * Request-local transport using SillyTavern's public ChatCompletionService.
 * Parameter/response behavior follows SillyTavern openai.js (AGPL-3.0) and
 * Tavern Helper responseGenerator.ts (PolyForm Noncommercial 1.0.0).
 * Sources: SillyTavern commit 51ad27fb86d39a3daca3adaa970375c9670c12df,
 * JS-Slash-Runner commit b1566767a111348aaa007e0044e786835330f884.
 */
import YAML from 'yaml';

import type { NativeModules } from './native';
import { withApiProviderError } from './provider-error';
import {
  callSubstituteParams,
  createGenerationParametersCompat,
  resolveChatCompletionModel,
  sendChatCompletionCompat,
} from './compat';
import { applyVertexGenerationOptions, vertexTransport, type VertexRequestProfile } from '../vertex';
import {
  applyGoogleStudioGenerationOptions,
  googleStudioTransport,
  type GoogleStudioProfile,
} from '../google-studio';

export type ResponseOptions = {
  settings?: Record<string, any>; tokenizerModel?: string; scenario?: string; stoppingStrings?: string[];
};

const proxySources = ['claude', 'openai', 'mistralai', 'makersuite', 'vertexai', 'deepseek', 'xai', 'zai', 'moonshot'];
const biasSources = ['openai', 'azure_openai', 'openrouter', 'electronhub', 'chutes', 'custom'];

/** 识别要求使用 max_completion_tokens 而非 max_tokens 的 OpenAI 新一代模型（gpt-5+ / o1 / o3 / o4+ 系列，兼容带空格或版本后缀的名称如 gpt-6.2 sol）。 */
export function usesMaxCompletionTokens(model: string): boolean {
  const id = (model || '').trim().replace(/^(?:openai\/|azure\/|chatgpt\/)/i, '').toLowerCase();
  return /^(?:gpt-(?:[5-9]|[1-9]\d)|o[1-9]\d*)(?:$|[\s\-./:])/.test(id);
}

function collectErrorText(error: unknown, depth = 0): string {
  if (depth > 3 || error == null) return '';
  if (typeof error === 'string') return error;
  if (error instanceof Error) {
    const extra = error as unknown as Record<string, unknown>;
    return [
      error.message,
      collectErrorText(extra.cause, depth + 1),
      collectErrorText(extra.data, depth + 1),
      collectErrorText(extra.responseJSON, depth + 1),
    ]
      .filter(Boolean)
      .join('\n');
  }
  if (typeof error === 'object') {
    try {
      return JSON.stringify(error);
    } catch {
      return String(error);
    }
  }
  return String(error);
}

export function isMaxTokensUnsupportedError(error: unknown): boolean {
  const text = collectErrorText(error);
  return /max_tokens/i.test(text) && /max_completion_tokens/i.test(text);
}

function isBadRequestError(error: unknown): boolean {
  const text = collectErrorText(error);
  return /\b400\b|bad request|unsupported_parameter/i.test(text);
}

function parseBodyObject(raw: unknown): Record<string, any> {
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) return { ...raw };
  if (typeof raw !== 'string' || !raw.trim()) return {};
  try {
    const parsed = YAML.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...parsed } : {};
  } catch {
    return {};
  }
}

function parseBodyKeyList(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.filter((item): item is string => typeof item === 'string' && !!item.trim());
  if (typeof raw !== 'string' || !raw.trim()) return [];
  try {
    const parsed = YAML.parse(raw);
    if (Array.isArray(parsed)) return parsed.filter((item): item is string => typeof item === 'string' && !!item.trim());
  } catch {
    // 兼容换行或逗号分隔的旧配置格式。
  }
  return raw
    .split(/[\r\n,]+/)
    .map(item => item.trim())
    .filter(Boolean);
}

function ensureCustomOpenAiTransport(payload: Record<string, any>, url: string, key?: string) {
  const normalizedUrl = url.trim().replace(/\/+$/, '');
  payload.chat_completion_source = 'custom';
  payload.custom_url = normalizedUrl;
  delete payload.reverse_proxy;
  delete payload.proxy_password;
  if (key) {
    const headers = parseBodyObject(payload.custom_include_headers);
    for (const k of Object.keys(headers)) {
      if (k.toLowerCase() === 'authorization') delete headers[k];
    }
    headers.Authorization = `Bearer ${key}`;
    payload.custom_include_headers = YAML.stringify(headers);
  }
}

/** 将 custom OpenAI 兼容通道中的 max_tokens 改写为 max_completion_tokens（同时删去 payload.max_tokens 与写 custom_exclude/include_body 双保险）。 */
export function rewritePayloadMaxCompletionTokens(payload: Record<string, any>, maxTokens?: number) {
  const tokens =
    typeof maxTokens === 'number' && Number.isFinite(maxTokens) && maxTokens > 0
      ? Math.floor(maxTokens)
      : typeof payload.max_tokens === 'number' && Number.isFinite(payload.max_tokens) && payload.max_tokens > 0
        ? Math.floor(payload.max_tokens)
        : undefined;
  delete payload.max_tokens;
  const exclude = parseBodyKeyList(payload.custom_exclude_body);
  if (!exclude.includes('max_tokens')) exclude.push('max_tokens');
  payload.custom_exclude_body = YAML.stringify(exclude);
  if (tokens !== undefined) {
    payload.max_completion_tokens = tokens;
    const include = parseBodyObject(payload.custom_include_body);
    if (include.max_completion_tokens === undefined) include.max_completion_tokens = tokens;
    payload.custom_include_body = YAML.stringify(include);
  }
}

/** Apply the pinned native provider/model rules to the request's own stop snapshot. */
function applyStoppingStrings(payload: Record<string, any>, strings: string[]) {
  const source = payload.chat_completion_source, model = payload.model;
  const gptSource = ['openai', 'azure_openai', 'openrouter', 'custom'].includes(source);
  const disabled = source === 'perplexity'
    || (gptSource && model.includes('gpt') && model.includes('vision'))
    || (gptSource && /gpt-(?:[5-9]|[1-9]\d)/i.test(model) && !/gpt-5-chat-latest/i.test(model))
    || (['openai', 'azure_openai', 'custom'].includes(source) && /^(?:openai\/)?o[1-9]\d*(?:$|[\s\-./:])/i.test(model))
    || (source === 'openrouter' && /^openai\/o[1-9]\d*(?:$|[\s\-./:])/i.test(model))
    || (source === 'xai' && (model.includes('grok-3-mini')
      || ((model.includes('grok-4') || model.includes('grok-code')) && !model.includes('grok-4-fast-non-reasoning'))));
  if (disabled) { delete payload.stop; return; }
  const isGeminiCustom = source === 'custom' && /^(?:models\/|google\/)?gemini-/i.test(model || '');
  const limit = ['claude', 'mistralai', 'chutes'].includes(source) ? undefined
    : ['makersuite', 'vertexai', 'cohere'].includes(source) || isGeminiCustom ? 5 : source === 'zai' ? 1 : 4;
  const selected = strings.slice(0, limit);
  const stops = ['makersuite', 'vertexai'].includes(source) || isGeminiCustom
    ? selected.filter(text => text.length >= 1 && text.length <= 16) : selected;
  if (stops.length) payload.stop = stops;
  else delete payload.stop;
}

// The plugin numbers native runs from zero and uses -1 for slash commands.
let nextTemplateRunId = -2;

async function evaluatePromptTemplates(native: NativeModules, messages: any[], signal: AbortSignal) {
  const template = native.host.EjsTemplate;
  if (!template) return;
  const features = template.getFeatures();
  if (!features.enabled || !features.generate_enabled) return;
  const context = await template.prepareContext({ runID: nextTemplateRunId--, runType: 'generate', generateType: 'normal', generateData: messages,
    isDryRun: false, message_id: undefined, swipe_id: undefined, is_last: undefined,
    is_user: undefined, is_system: undefined, name: undefined });
  const evaluate = (text: string) => {
    signal.throwIfAborted();
    if (!text.includes('<%')) return text;
    // prepareContext and earlier messages can await extension callbacks. Respect the
    // current execution setting immediately before handing code to the public API.
    const current = template.getFeatures();
    if (!current.enabled || !current.generate_enabled) return text;
    if (current.sandbox) {
      throw Error('提示词模板已启用沙盒，当前插件的公开接口无法在沙盒中展开本次出站 EJS。请移除或预先展开对应模板后重试。');
    }
    return template.evalTemplate(text, context);
  };
  for (const message of messages) {
    signal.throwIfAborted();
    if (typeof message.content === 'string') message.content = await evaluate(message.content);
    else if (Array.isArray(message.content)) {
      for (const content of message.content) {
        if (content.type === 'text' && typeof content.text === 'string') content.text = await evaluate(content.text);
      }
    }
  }
}

function customConnection(native: NativeModules, config?: CustomApiConfig) {
  if (!config) return;
  const custom = structuredClone(config);
  if (!custom.proxy_preset) return custom;
  const preset = (native.openai.proxies ?? []).find((item: { name: string }) => item.name === custom.proxy_preset!.trim());
  if (preset) return { ...custom, apiurl: preset.url, key: preset.password ?? '' };
  console.warn('[瓦洛兰生成] 代理预设未找到，沿用本次连接', custom.proxy_preset);
  return custom;
}

function applyConnection(payload: Record<string, any>, custom: CustomApiConfig) {
  if (custom.apiurl) {
    const url = custom.apiurl.trim().replace(/\/+$/, '');
    payload.reverse_proxy = url;
    payload.proxy_password = custom.key || '';
    if (payload.chat_completion_source === 'custom') {
      payload.custom_url = url;
      if (custom.key) {
        const headers = YAML.parse(payload.custom_include_headers || '{}') ?? {};
        for (const key of Object.keys(headers)) if (key.toLowerCase() === 'authorization') delete headers[key];
        headers.Authorization = `Bearer ${custom.key}`;
        payload.custom_include_headers = YAML.stringify(headers);
      }
    }
  }
  if (custom.model) payload.model = custom.model;
  const defaults = { max_tokens: null, temperature: 1, frequency_penalty: 0, presence_penalty: 0, top_p: 1, top_k: 0 };
  for (const [key, defaultValue] of Object.entries(defaults)) {
    const value = custom[key as keyof typeof defaults] ?? 'same_as_preset';
    if (value === 'unset' || value === defaultValue) delete payload[key];
    else if (value !== 'same_as_preset') payload[key] = value;
  }
  if (custom.source === 'custom') {
    for (const key of ['custom_include_body', 'custom_exclude_body', 'custom_include_headers'] as const) {
      if (custom[key]) payload[key] = YAML.stringify(custom[key]);
    }
  }
}

export async function sendResponse(
  native: NativeModules, messages: any[], config: GenerateConfig, signal: AbortSignal,
  options: ResponseOptions = {},
): Promise<string> {
  signal.throwIfAborted();
  const settings = structuredClone(options.settings ?? native.openai.oai_settings);
  const stoppingStrings = options.stoppingStrings ?? (typeof native.powerUser.getCustomStoppingStrings === 'function' ? native.powerUser.getCustomStoppingStrings() : []);
  const custom = customConnection(native, config.custom_api);
  const vertex = (custom as (CustomApiConfig & { vertex?: VertexRequestProfile }) | undefined)?.vertex;
  const googleStudio = (custom as (CustomApiConfig & { googleStudio?: GoogleStudioProfile }) | undefined)?.googleStudio;
  const source = custom?.source ?? (custom?.apiurl ? 'openai' : settings.chat_completion_source);
  settings.chat_completion_source = source;
  const assistantPrefill = source === 'claude' ? callSubstituteParams(native.script, settings.assistant_prefill, {
    dynamicMacros: options.scenario === undefined ? {} : { scenario: options.scenario },
  }) : undefined;
  // The native builder expands this field using the active character's scenario.
  // Supply the request expansion after parameter construction instead.
  if (source === 'claude') settings.assistant_prefill = '';
  settings.stream_openai = config.should_stream ?? false;
  const schema = config.json_schema && structuredClone(config.json_schema);
  const tools = config.tools?.length ? structuredClone(config.tools) : undefined;
  const toolChoice = config.tool_choice;
  const id = config.generation_id;
  const biasPreset = settings.bias_presets?.[settings.bias_preset_selected];
  const bias = biasSources.includes(source) && Array.isArray(biasPreset) && biasPreset.length ? biasPreset : undefined;
  const model = custom?.model || resolveChatCompletionModel(native.openai, settings);
  const tokenizer = bias
    ? source === 'openai' ? model : (options.tokenizerModel ?? native.tokenizers.getTokenizerModel())
    : undefined;
  const reverseProxy = settings.reverse_proxy;
  const proxyPassword = settings.proxy_password;
  // Native bias calculation and proxy validation read module globals. Keep those
  // two inputs in this request instead of consulting a later UI configuration.
  settings.bias_preset_selected = '';
  settings.reverse_proxy = '';
  const { generate_data: payload } = await createGenerationParametersCompat(
    native, settings, model, 'normal', structuredClone(messages), { jsonSchema: schema },
  );
  signal.throwIfAborted();
  applyStoppingStrings(payload, stoppingStrings);
  if (source === 'claude') payload.assistant_prefill = assistantPrefill;
  if (!vertex && !googleStudio && reverseProxy && proxySources.includes(source)) {
    new URL(reverseProxy);
    payload.reverse_proxy = reverseProxy;
    payload.proxy_password = proxyPassword;
  }
  if (bias && Object.hasOwn(payload, 'logit_bias')) {
    const response = await native.host.fetch(`/api/backends/chat-completions/bias?model=${encodeURIComponent(tokenizer)}`, {
      method: 'POST', headers: native.script.getRequestHeaders(), body: JSON.stringify(bias), signal,
    });
    if (!response.ok) throw Error(`词元偏置计算失败（HTTP ${response.status}）`);
    const calculated = await response.json();
    if (calculated.error) throw Error(String(calculated.error.message ?? calculated.error));
    payload.logit_bias = Object.keys(calculated).length ? calculated : undefined;
  }
  if (custom) applyConnection(payload, custom);
  if (tools) {
    payload.tools = tools;
    payload.tool_choice = toolChoice ?? 'auto';
  }
  payload.include_reasoning = true;
  await evaluatePromptTemplates(native, payload.messages, signal);
  signal.throwIfAborted();
  if (googleStudio && custom) {
    const transport = googleStudioTransport(googleStudio);
    applyGoogleStudioGenerationOptions(payload, transport.model, googleStudio.thinkingLevel);
    custom.key = transport.key;
    payload.chat_completion_source = 'custom';
    payload.custom_url = transport.url;
    payload.model = transport.model;
    delete payload.reverse_proxy;
    delete payload.proxy_password;
    payload.custom_include_headers = JSON.stringify({ Authorization: 'Bearer ' + transport.key });
  }
  // Resolve the short-lived credential only after building the prompt and running its hooks.
  if (vertex && custom) {
    applyVertexGenerationOptions(payload, model, vertex.vertexThinkingLevel);
    const transport = await withApiProviderError(signal, () => vertexTransport(vertex, model, signal));
    custom.key = transport.key;
    payload.chat_completion_source = 'custom';
    payload.custom_url = transport.url;
    payload.model = transport.model;
    payload.custom_include_headers = JSON.stringify({ Authorization: 'Bearer ' + transport.key });
  }
  // OpenAI gpt-5+ / o1 / o3 / o4+ 系列要求使用 max_completion_tokens 代替 max_tokens。
  // 额外 API（OpenAI 兼容）或 custom 源直接走 custom_exclude/include_body + 删去 max_tokens 双保险改写。
  let rewroteMaxCompletionTokens = false;
  const initialMaxTokens =
    typeof payload.max_tokens === 'number' && Number.isFinite(payload.max_tokens) && payload.max_tokens > 0
      ? Math.floor(payload.max_tokens)
      : undefined;
  if (!vertex && !googleStudio && usesMaxCompletionTokens(payload.model || model)) {
    if (payload.chat_completion_source === 'custom') {
      rewritePayloadMaxCompletionTokens(payload, initialMaxTokens);
      delete payload.stop;
      rewroteMaxCompletionTokens = true;
    } else if (custom?.apiurl && payload.chat_completion_source === 'openai') {
      ensureCustomOpenAiTransport(payload, custom.apiurl, custom.key);
      rewritePayloadMaxCompletionTokens(payload, initialMaxTokens);
      delete payload.stop;
      rewroteMaxCompletionTokens = true;
    }
  }
  // This public transport accepts this payload directly. It does not consume
  // another Helper request's shared CHAT_COMPLETION_SETTINGS_READY once callback.
  const sendWith = (requestPayload: Record<string, any>) => {
    const run = () => sendChatCompletionCompat(native, requestPayload, signal);
    return custom ? withApiProviderError(signal, run, custom.key) : run();
  };
  let response: any;
  try {
    response = await sendWith(payload);
  } catch (error) {
    signal.throwIfAborted();
    const explicitMaxTokensError = isMaxTokensUnsupportedError(error);
    // 酒馆前端收到后端 400 时有时只抛出简短的 "Bad Request"（详细 JSON 仅打印在 PS 后台）。
    // 若是尚未改写过 max_completion_tokens 的 OpenAI 兼容请求且带 max_tokens，收到 400 时尝试单次改写重试。
    const canBlindBadRequestFallback =
      !rewroteMaxCompletionTokens &&
      initialMaxTokens !== undefined &&
      Boolean(custom?.apiurl) &&
      payload.chat_completion_source === 'openai' &&
      isBadRequestError(error);
    if (vertex || googleStudio || (!explicitMaxTokensError && !canBlindBadRequestFallback)) throw error;
    const retryPayload = structuredClone(payload);
    const canSwitchToCustom =
      retryPayload.chat_completion_source === 'custom' ||
      Boolean(custom?.apiurl) ||
      Boolean(retryPayload.reverse_proxy && retryPayload.proxy_password);
    const fallbackUrl = retryPayload.custom_url || custom?.apiurl || retryPayload.reverse_proxy;
    const fallbackKey = custom?.key || retryPayload.proxy_password || undefined;
    if (!rewroteMaxCompletionTokens && canSwitchToCustom && fallbackUrl) {
      ensureCustomOpenAiTransport(retryPayload, fallbackUrl, fallbackKey);
      rewritePayloadMaxCompletionTokens(retryPayload, initialMaxTokens);
    } else {
      rewritePayloadMaxCompletionTokens(retryPayload, initialMaxTokens);
    }
    delete retryPayload.stop;
    console.info('[瓦洛兰生成] 检测到模型不支持 max_tokens，已自动改用 max_completion_tokens 重试', {
      model: retryPayload.model,
      source: retryPayload.chat_completion_source,
    });
    response = await sendWith(retryPayload);
  }
  signal.throwIfAborted();
  if (!payload.stream) return native.script.extractMessageFromData(response, 'openai');
  let text = '', reasoning = '';
  for await (const chunk of response()) {
    signal.throwIfAborted();
    const increment = chunk.text.slice(text.length);
    const reasoningIncrement = (chunk.state?.reasoning ?? '').slice(reasoning.length);
    text = chunk.text;
    reasoning = chunk.state?.reasoning ?? '';
    await native.script.eventSource.emit('js_stream_token_received_fully', text, id);
    await native.script.eventSource.emit('js_stream_token_received_incrementally', increment, id);
    await native.script.eventSource.emit('js_reasoning_token_received_fully', reasoning, id);
    await native.script.eventSource.emit('js_reasoning_token_received_incrementally', reasoningIncrement, id);
  }
  signal.throwIfAborted();
  return native.script.cleanUpMessage({ getMessage: text, isImpersonate: false, isContinue: false });
}
