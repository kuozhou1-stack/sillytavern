<template>
  <div class="cw-tab-pane cw-player-goals-pane">
    <!-- 1. 生活与心愿目标 -->
    <div class="cw-goals-section">
      <h4 class="cw-section-title">
        <SvgIcon name="target" :size="16" />
        <span>生活与心愿目标</span>
      </h4>

      <div v-if="hasGoals" class="cw-goals-list">
        <div v-for="(goal, id) in player?.生活?.目标" :key="id" class="cw-goal-card">
          <div class="cw-goal-header">
            <span class="cw-goal-title">{{ goal.内容 ?? '未知' }}</span>
          </div>
          <div class="cw-goal-meta">
            <span>当前进展：{{ goal.进展 ?? '未知' }}</span>
          </div>
        </div>
      </div>
      <div v-else class="cw-empty-compact">
        <SvgIcon name="target" :size="16" class="cw-empty-icon" />
        <span>当前暂无特别登记的目标</span>
      </div>
    </div>

    <!-- 2. NPC 委托与事务（与约定、奇遇任务严格分开） -->
    <div class="cw-commissions-section">
      <div class="cw-section-header-row">
        <h4 class="cw-section-title cw-title-inline">
          <SvgIcon name="bookmark" :size="16" />
          <span>NPC 委托与事务</span>
          <span class="cw-section-count">({{ visibleCommissions.length }})</span>
        </h4>
        <button class="cw-btn cw-btn-ghost cw-btn-xs" @click="commissionHistory = !commissionHistory">
          {{ commissionHistory ? '查看进行中' : '查看已结束' }}
        </button>
      </div>
      <p class="cw-section-hint">记录剧情中玩家明确答应 NPC 或组织办理的具体请求，独立于碰面「约定」与奇遇系统赏金。</p>

      <div v-if="visibleCommissions.length" class="cw-commissions-list">
        <div v-for="item in visibleCommissions" :key="item.id" class="cw-commission-card">
          <div class="cw-cov-header">
            <span class="cw-cov-title">{{ item.标题 || item.内容 || '未命名委托' }}</span>
            <span class="cw-badge" :class="commissionStatusClass(item.状态)">
              {{ item.状态 ?? '进行中' }}
            </span>
          </div>
          <p v-if="item.内容 && item.标题 && item.内容 !== item.标题" class="cw-commission-desc">{{ item.内容 }}</p>
          <div class="cw-cov-meta">
            <span>委托人：{{ clientName(item) }}</span>
            <span v-if="item.报酬说明">报酬：{{ item.报酬说明 }}</span>
            <span v-if="item.截止说明">时限：{{ item.截止说明 }}</span>
            <span v-if="item.进展">进展：{{ item.进展 }}</span>
          </div>
          <button v-if="runtime && item.状态 === '进行中'" class="cw-btn cw-btn-ghost cw-btn-xs"
            :disabled="runtime.view.readOnly || runtime.view.busy || runtime.view.updating"
            @click="abandon(item.id)">{{ abandonId === item.id ? '确认放弃' : '放弃委托' }}</button>
        </div>
      </div>
      <p v-if="commissionError" role="alert">{{ commissionError }}</p>
      <div v-if="!visibleCommissions.length" class="cw-empty-compact">
        <SvgIcon name="bookmark" :size="16" class="cw-empty-icon" />
        <span>{{ commissionHistory ? '暂无已完成、放弃或失败的委托。' : '暂无进行中的 NPC 委托。' }}</span>
      </div>
    </div>

    <!-- 3. 约定与邀约 -->
    <div class="cw-covenants-section">
      <div class="cw-section-header-row">
        <h4 class="cw-section-title cw-title-inline">
          <SvgIcon name="calendar" :size="16" />
          <span>约定与邀约</span>
          <span class="cw-section-count">({{ visibleCovenants.length }})</span>
        </h4>
        <button class="cw-btn cw-btn-ghost cw-btn-xs" @click="history = !history">
          {{ history ? '查看进行中' : '查看已完成 / 已取消' }}
        </button>
      </div>
      <div v-if="visibleCovenants.length" class="cw-covenants-list">
        <div v-for="cov in visibleCovenants" :key="cov.id" class="cw-covenant-card">
          <div class="cw-cov-header">
            <span class="cw-cov-title">{{ cov.内容 ?? '未知' }}</span>
            <span class="cw-badge" :class="covStatusClass(cov.状态)">
              {{ cov.状态 ?? '未知' }}
            </span>
          </div>
          <div class="cw-cov-meta">
            <span
              >参与者：{{
                Object.entries(cov.参与者 ?? {})
                  .map(
                    ([id, v]: any) =>
                      (state?.角色?.[id]?.姓名 ?? v.称呼 ?? (id === player.id ? player.姓名 : '未知')) +
                      '：' +
                      (v.响应 ?? '未知'),
                  )
                  .join('、')
              }}</span
            >
            <span>时间：{{ formatTime(cov.时间) }} {{ cov.时间说明 ?? '' }}</span>
            <span>地点：{{ place(cov.地点id) }}</span>
          </div>
        </div>
      </div>
      <div v-else class="cw-empty-compact">
        <SvgIcon name="calendar" :size="16" class="cw-empty-icon" />
        <span>{{ history ? '暂无已完成或已取消的约定。' : '暂无进行中的约定。' }}</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, inject, onBeforeUnmount, ref } from 'vue';
import { RuntimeKey, type Runtime } from '../../../../运行/host';
import { abandonCommission } from '../../../../运行/commissions';
import { useWorldState } from '../../utils/context';
import { resolveLocationName, resolveOrganizationName } from '../../utils/entity';
import { subscribeExternalSettings } from '../../../../运行/external-settings';
import SvgIcon from '../icons/SvgIcon.vue';

const state = useWorldState();
const runtime = inject<Runtime | null>(RuntimeKey, null);
const abandonId = ref<string | null>(null);
const commissionError = ref('');
async function abandon(id: string) {
  if (!runtime) return;
  commissionError.value = '';
  if (abandonId.value !== id) { abandonId.value = id; return; }
  try {
    await runtime.commit(state => abandonCommission(state, id));
    abandonId.value = null;
  } catch (error) { commissionError.value = String(error); }
}
const history = ref(false);
const commissionHistory = ref(false);
const externalRevision = ref(0);
const stopExternal = subscribeExternalSettings(() => {
  externalRevision.value++;
});
onBeforeUnmount(stopExternal);
const place = (id: any) => {
  void externalRevision.value;
  return resolveLocationName(state?.value, id);
};

const props = defineProps<{
  player: any;
  worldCovenants?: Record<string, any>;
  worldCommissions?: Record<string, any>;
}>();

const hasGoals = computed(() => {
  return props.player?.生活?.目标 && Object.keys(props.player.生活.目标).length > 0;
});

const commissionsList = computed(() => {
  const source = props.worldCommissions ?? state?.value?.委托 ?? {};
  return Object.entries(source).map(([id, item]: [string, any]) => ({ id, ...item }));
});

const visibleCommissions = computed(() =>
  commissionsList.value.filter(item =>
    commissionHistory.value ? item.状态 !== '进行中' : item.状态 === '进行中' || !item.状态,
  ),
);

function clientName(item: any) {
  if (item.委托人id && state?.value?.角色?.[item.委托人id]?.姓名) return state.value.角色[item.委托人id].姓名;
  if (item.委托组织id) {
    void externalRevision.value;
    return item.委托人称呼 || resolveOrganizationName(state.value, item.委托组织id);
  }
  return item.委托人称呼 || item.委托人id || '未知';
}

function commissionStatusClass(status?: string) {
  switch (status) {
    case '已完成':
      return 'cw-badge-success';
    case '已失败':
    case '已放弃':
      return 'cw-badge-danger';
    default:
      return 'cw-badge-accent';
  }
}

const covenantsList = computed(() => {
  const ids = new Set<string>(props.player?.生活?.约定 ?? []);
  for (const [id, c] of Object.entries(props.worldCovenants ?? {}) as any[])
    if (c.参与者?.[props.player.id]) ids.add(id);
  return [...ids]
    .filter(id => Boolean(props.worldCovenants?.[id]))
    .map(id => ({ id, ...props.worldCovenants![id] }));
});
const visibleCovenants = computed(() =>
  covenantsList.value.filter(c => history.value === ['完成', '取消'].includes(c.状态)),
);
function formatTime(t: any) {
  if (!t) return '未知';
  if (typeof t === 'string') return t;
  if (typeof t.年 === 'number' && typeof t.月 === 'number' && typeof t.日 === 'number') {
    const pad = (n: number) => String(n).padStart(2, '0');
    const date = `${t.年}-${pad(t.月)}-${pad(t.日)}`;
    return typeof t.时 === 'number' && typeof t.分 === 'number' ? `${date} ${pad(t.时)}:${pad(t.分)}` : date;
  }
  return '未知';
}

function covStatusClass(status?: string) {
  switch (status) {
    case '完成':
    case '已履约':
      return 'cw-badge-success';
    case '取消':
      return 'cw-badge-danger';
    case '待确认':
      return 'cw-badge-warning';
    default:
      return 'cw-badge-accent';
  }
}
</script>

<style scoped lang="scss">
.cw-player-goals-pane {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cw-goals-section,
.cw-commissions-section,
.cw-covenants-section {
  padding: 16px 20px;
  border-radius: var(--cw-radius);
  background: var(--cw-bg-card);
  border: 1px solid var(--cw-border);
}

.cw-section-header-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 10px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);
}

.cw-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  font-size: 14px;
  font-weight: 600;
  color: var(--cw-text-primary);
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cw-border);

  &.cw-title-inline {
    margin: 0;
    padding-bottom: 0;
    border-bottom: none;
  }
}

.cw-section-count {
  font-size: 12px;
  font-weight: 500;
  color: var(--cw-text-muted);
}

.cw-section-hint {
  margin: 0 0 12px;
  font-size: 12px;
  color: var(--cw-text-muted);
  line-height: 1.45;
}

.cw-goals-list,
.cw-commissions-list,
.cw-covenants-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cw-goal-card,
.cw-commission-card,
.cw-covenant-card {
  padding: 12px 14px;
  border-radius: var(--cw-radius-sm);
  background: var(--cw-bg-card-subtle);
  border: 1px solid var(--cw-border);
  display: flex;
  flex-direction: column;
  gap: 6px;

  .cw-goal-header,
  .cw-cov-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 6px 10px;

    .cw-goal-title,
    .cw-cov-title {
      font-weight: 600;
      font-size: 14px;
      color: var(--cw-text-primary);
      min-width: 0;
      word-break: break-word;
    }
  }

  .cw-commission-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.5;
    color: var(--cw-text-secondary);
  }

  .cw-goal-meta,
  .cw-cov-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 14px;
    font-size: 12px;
    color: var(--cw-text-muted);
  }
}

.cw-empty-compact {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 4px;
  font-size: 12.5px;
  color: var(--cw-text-muted);

  .cw-empty-icon {
    opacity: 0.55;
  }
}
</style>
