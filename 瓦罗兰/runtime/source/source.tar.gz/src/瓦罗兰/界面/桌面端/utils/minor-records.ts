export const MINOR_RECORD_KEYS = {
  currentState: 'npc_current_state',
  history: 'npc_history',
  onlineHabits: 'npc_online_habits',
  currentPractice: 'current_practice',
} as const;

export const recordTitles: Record<string, string> = {
  [MINOR_RECORD_KEYS.currentState]: '当前近况',
  [MINOR_RECORD_KEYS.onlineHabits]: '网络往来',
  [MINOR_RECORD_KEYS.history]: '个人经历与今年生活',
  [MINOR_RECORD_KEYS.currentPractice]: '近期兴趣与实践',
  当前近况: '当前近况',
  持续近况: '当前近况',
  个人经历: '个人经历与今年生活',
};

/** 模板记录沿用 MVU 重要记录字典，保留稳定键；界面用标题与正文展示，同时兼容常见中文键名。 */
export function minorRecordSections(character: any) {
  return Object.entries(character?.重要记录 ?? {}).flatMap(([id, record]: [string, any]) => {
    const text = record?.内容;
    if (typeof text !== 'string' || !text.trim()) return [];
    return [{ id, title: recordTitles[id] ?? text.split('\n')[0].slice(0, 36), text,
      eventId: record.事件id, covenantId: record.约定id }];
  });
}
