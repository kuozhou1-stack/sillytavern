/*! Adapted from StageDog/tavern_resource util/mvu_zod.ts. Local change: schema-aware readonly paths for record IDs. License: PolyForm Noncommercial 1.0.0 https://polyformproject.org/licenses/noncommercial/1.0.0/ */
import { prettifyErrorWithInput } from '../../../util/common';
import { isPrivateModelPath } from './model-fields';
import type { ZodType } from 'zod';

// Schema and settlement run in separate card iframes. Keep the error on the exact
// candidate, outside enumerable/save data, rather than relying on UI notifications.
const commandErrors = Symbol.for('valoran.mvu.commandErrors');
export function assertMvuCommandResult(candidate: Mvu.MvuData) {
  const errors: string[] | undefined = (candidate as any)[commandErrors];
  if (!errors?.length) return;
  delete (candidate as any)[commandErrors];
  throw Error(errors.join('\n'));
}

export function registerMvuSchema(input: ZodType<Record<string, any>> | (() => ZodType<Record<string, any>>)) {
  const unwrapSchema = () => {
    const original_schema = typeof input === 'function' ? input() : input;
    const schema = original_schema instanceof z.ZodObject ? z.looseObject(original_schema.shape) : original_schema;
    if (typeof registerVariableSchema === 'function') {
      registerVariableSchema(z.object({ stat_data: schema }), { type: 'message' });
    }
    return schema;
  };

  unwrapSchema();

  eventOn('mag_variable_initialized', (variables, swipe_id) => {
    const schema = unwrapSchema();
    try {
      const result = schema.safeParse(_.get(variables, 'stat_data', {}), { reportInput: true });
      if (result.success) {
        variables.stat_data = { ...variables.stat_data, ...result.data };
        return;
      }
      reportError('error', z.prettifyError(result.error), `开局 '${swipe_id + 1}' 变量初始化失败`);
    } catch (e) {
      const error = e as Error;
      reportError(
        'error',
        error.stack ? error.stack : error.name + ': ' + error.message,
        `第 ${swipe_id + 1} 条开场白的变量初始化失败`,
      );
    }
  });

  // on_error 是 MVU 收集模式追加的第四个参数；旧版调用方不传时继续使用原有错误通知。
  const on_command_parsed = (
    variables: Mvu.MvuData,
    commands: Mvu.CommandInfo[],
    _message_content?: string,
    on_error?: (error_info: string) => void,
  ) => {
    const schema = unwrapSchema();
    const notification_enabled = Boolean($('#mvu_notification_error').prop('checked'));

    /** 收集模式不受通知开关影响，并由调用方负责展示；未提供回调时保留原有通知。 */
    const report_command_error = (content: string, command: Mvu.CommandInfo) => {
      const title = `发生变量更新错误, 可能需要重Roll: ${command.full_match}`;
      if (!Object.hasOwn(variables, commandErrors))
        Object.defineProperty(variables, commandErrors, { value: [], configurable: true });
      (variables as any)[commandErrors].push(`${title}\n${content}`);
      if (on_error) {
        on_error(`${title}\n${content}`);
      } else if (notification_enabled) {
        reportError('warn', content, title);
      }
    };

    const checkSchema = (data: any, command: Mvu.CommandInfo, should_report: boolean) => {
      let error_message = '';
      try {
        const result = schema.safeParse(data, { reportInput: true });
        if (result.success) {
          return result.data;
        }
        error_message = prettifyErrorWithInput(result.error);
      } catch (e) {
        const error = e as Error;
        error_message = error.stack ? error.stack : error.name + ': ' + error.message;
      }

      // 插入时可能先尝试对象再尝试数组，仅报告最终失败，避免收集到已恢复的探测错误。
      if (should_report) {
        report_command_error(error_message, command);
      }
      return null;
    };

    const isReadonlyPath = (path: string | string[]) => {
      if (typeof path === 'string') {
        path = _.toPath(path);
      }
      return isPrivateModelPath(path);
    };

    const applyCommand = (data: any, command: Mvu.CommandInfo): Record<string, any> | null => {
      switch (command.type) {
        case 'set': {
          if (command.args.length === 3) {
            command.args.splice(1, 1);
          }
          const path = parsePath(command.args[0]);
          if (isReadonlyPath(path)) {
            return null;
          }
          if (path) {
            _.set(data, path, parseCommandValue(command.args[1]));
          } else {
            data = parseCommandValue(command.args[1]);
          }
          return checkSchema(data, command, true);
        }
        case 'add': {
          const path = parsePath(command.args[0]);
          if (!path || isReadonlyPath(path)) {
            return null;
          }
          const old_value = _.get(data, path);
          const old_value_type = typeof old_value;
          if (old_value_type !== 'number') {
            report_command_error(
              [
                `✖ 不能对非数字类型 '${old_value_type}' 进行加减运算`,
                `  → 路径: ${path}`,
                `  → 原值: ${JSON.stringify(old_value)}`,
              ].join('\n'),
              command,
            );
            return null;
          }
          const delta_value = parseCommandValue(command.args[1]);
          _.update(data, path, value => value + Number(delta_value));
          return checkSchema(data, command, true);
        }
        case 'insert': {
          const path = parsePath(command.args[0]);
          if (isReadonlyPath(path)) {
            return null;
          }
          const key_or_index = parseCommandValue(command.args[1]);
          const value = parseCommandValue(command.args.at(-1)!);

          const insert = (data: any, should_report: boolean) => {
            const collection = path === '' ? data : _.get(data, path);
            const is_array = _.isArray(collection);
            if (command.args.length === 2) {
              if (is_array) {
                collection.push(value);
              } else {
                _.assign(collection, value);
              }
            } else if (is_array) {
              collection.splice(key_or_index === '-' ? collection.length : key_or_index, 0, value);
            } else {
              collection[String(key_or_index)] = value;
            }
            return checkSchema(data, command, should_report);
          };

          const collection = path === '' ? data : _.get(data, path);
          const is_nil = _.isNil(collection);
          if (!is_nil && !_.isArray(collection) && !_.isPlainObject(collection)) {
            return null;
          }
          if (!is_nil) {
            return insert(data, true);
          }
          const filled = _(klona(data));
          const result_as_object = insert(filled.set(path, {}).value(), false);
          if (result_as_object) {
            return result_as_object;
          }
          return insert(filled.set(path, []).value(), true);
        }
        case 'delete': {
          const path = command.args.map(parsePath).join('.');
          const path_array = _.toPath(path);
          if (isReadonlyPath(path_array)) {
            return null;
          }
          // 保留路径分段，避免 `inventory.v2` 这类带点号的键被重新解释成多层路径。
          const parent_path = _.dropRight(path_array);
          const parent = _.get(data, parent_path);
          if (_.isArray(parent)) {
            _.pullAt(parent, Number(_(path_array).last()));
          } else {
            _.unset(data, path_array);
          }
          return checkSchema(data, command, true);
        }
      }
      return null;
    };

    const consumed_indices: number[] = [];
    commands.forEach((command, index) => {
      let data: Record<string, any> | null = klona(variables.stat_data);
      if (command.type === 'move') {
        const from_path = parsePath(command.args[0]);
        if (!_.has(data, from_path)) {
          report_command_error(`移动源路径不存在: ${from_path}`, command);
          return;
        }
        const value = _.get(data, from_path);
        const to_path = parsePath(command.args[1]);

        data = applyCommand(data, { ...command, type: 'delete', args: [from_path] });
        data = applyCommand(data, { ...command, type: 'set', args: [to_path, value] });
      } else {
        data = applyCommand(data, command);
      }

      // 顶层 delete/move 会让 data 少一个键，仅按 data 现有键比较会误判为没有变化；
      // 对象展开也不会删除旧键，因此合并前需要显式清理被移除的源路径。
      const removed_paths =
        command.type === 'delete'
          ? [_.toPath(command.args.map(parsePath).join('.'))]
          : command.type === 'move'
            ? [_.toPath(parsePath(command.args[0]))]
            : [];
      const has_removed_value =
        data !== null && removed_paths.some(path => _.has(variables.stat_data, path) && !_.has(data, path));

      if (data !== null && (has_removed_value || !_.isEqual(data, _.pick(variables.stat_data, Object.keys(data))))) {
        removed_paths.forEach(path => {
          if (!_.has(data, path)) {
            _.unset(variables.stat_data, path);
          }
        });
        variables.stat_data = { ...variables.stat_data, ...data };
        consumed_indices.push(index);
      }
    });

    _.pullAt(commands, consumed_indices);
  };
  eventOn('mag_command_parsed_for_zod', on_command_parsed);

  eventOn('mag_command_parsed_ended_for_zod', (_variables, commands: Mvu.CommandInfo[]) => {
    commands.length = 0;
  });

  eventOn('mag_variable_update_ended_for_zod', variables => {
    _.set(variables, 'schema', '没有用别管这个');
    _.unset(variables, 'display_data');
    _.unset(variables, 'delta_data');
  });

  console.info('变量结构注册成功');
}

function reportError(level: 'error' | 'warn', content: string, title: string) {
  toastr[level === 'warn' ? 'warning' : 'error'](content.replaceAll('\n', '<br>'), `[MVU zod]` + title, {
    escapeHtml: false,
  });
  console[level](`${title}\n${content}`);
}

function trimQuotesAndBackslashes(string: string): string {
  return string.replace(/^[\\"'` ]*(.*?)[\\"'` ]*$/, '$1');
}

function parsePath(string: string): string {
  return (
    trimQuotesAndBackslashes(string)
      // 一些错误提示词写法会导致 AI 在更新变量时带上 `stat_data.` 或 `status_current_variables.` 前缀, 这里将它去掉
      .replace(/^(?:stat_data|status_current_variables)\./, '')
  );
}

function parseCommandValue(string: any): any {
  if (typeof string !== 'string') {
    return string;
  }

  const value = parseCommandValueImpl(string);
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (Array.isArray(value)) {
    return value.map(item => (item instanceof Date ? item.toISOString() : item));
  }
  return value;
}

function parseCommandValueImpl(string: string): any {
  const trimmed = string.trim();

  if (trimmed === 'true') {
    return true;
  }
  if (trimmed === 'false') {
    return false;
  }
  if (trimmed === 'null') {
    return null;
  }
  if (trimmed === 'undefined') {
    return undefined;
  }

  try {
    return JSON.parse(trimmed);
  } catch (e) {
    if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
      try {
        const result = new Function(`return ${trimmed};`)();
        if (_.isObject(result) || Array.isArray(result)) {
          return result;
        }
      } catch (err) {
        // 如果解析失败，说明它可能是一个未加引号的字符串，继续往下走
      }
    }
  }

  try {
    return YAML.parse(trimmed);
  } catch (e) {
    /** empty */
  }

  return trimQuotesAndBackslashes(string);
}
