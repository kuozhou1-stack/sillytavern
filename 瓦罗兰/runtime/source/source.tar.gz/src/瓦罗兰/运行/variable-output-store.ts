import {
  extractEditableVariableOutput,
  type StoredVariableOutput,
  type VariableOutputChannel,
  type VariableOutputIndexEntry,
  type VariableOutputRecord,
} from './variable-inspector';
import type { VariableReplyFormat } from './variable-response';

export const VARIABLE_OUTPUTS_KEY = '澄湾最近变量输出';
export const MAX_STORED_VARIABLE_OUTPUTS = 12;

export type VariableOutputTarget = {
  floor?: number;
  swipe?: number;
  id?: string;
  channel?: VariableOutputChannel;
};

export type PendingStoryVariableSnapshot = {
  id: string;
  mode: 'main' | 'extra';
  replyFloor?: number;
  replySwipe?: number;
  reply?: string;
  replyFormat?: VariableReplyFormat;
  failedReply?: string;
  failedReplyFormat?: VariableReplyFormat;
  useEditedReply?: boolean;
};

export type PendingPhoneVariableSnapshot = {
  id: string;
  context: { floor: number; swipe: number };
  reply?: string;
  replyFormat?: VariableReplyFormat;
  failedReply?: string;
  failedReplyFormat?: VariableReplyFormat;
  editedReply?: boolean;
};

export type FailedParseLogSnapshot = {
  id?: string;
  at?: string;
  error?: string;
  response?: string;
};

export function normalizeStoredVariableRaw(rawText: string, channel: VariableOutputChannel): string {
  if (channel === 'story-main') {
    const extracted = extractEditableVariableOutput(rawText, 'story-main');
    return extracted.missingUpdateBlock ? '' : extracted.rawText;
  }
  return rawText;
}

export function parseStoredVariableOutputs(raw: unknown): StoredVariableOutput[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (item): item is StoredVariableOutput =>
      !!item &&
      typeof item === 'object' &&
      typeof item.id === 'string' &&
      (item.channel === 'story-main' || item.channel === 'story-extra' || item.channel === 'phone') &&
      (item.state === 'failed' || item.state === 'pending' || item.state === 'saved') &&
      typeof item.rawText === 'string' &&
      typeof item.updatedAt === 'string',
  );
}

export function appendStoredVariableOutput(
  existingList: readonly StoredVariableOutput[],
  entry: StoredVariableOutput,
): StoredVariableOutput[] {
  const normalized: StoredVariableOutput = {
    ...entry,
    rawText: normalizeStoredVariableRaw(entry.rawText, entry.channel),
  };
  const existing = existingList.filter(item => {
    if (item.id === normalized.id) return false;
    if (
      normalized.channel !== 'phone' &&
      item.channel !== 'phone' &&
      normalized.floor !== undefined &&
      item.floor === normalized.floor &&
      (item.swipe ?? 0) === (normalized.swipe ?? 0)
    )
      return false;
    return true;
  });
  existing.push(normalized);
  return existing.slice(-MAX_STORED_VARIABLE_OUTPUTS);
}

export function toVariableOutputRecord(
  stored: StoredVariableOutput,
  opts: { editable: boolean; canResummarize?: boolean; canReRequestApi?: boolean },
): VariableOutputRecord {
  const extracted = extractEditableVariableOutput(stored.rawText, stored.channel, stored.replyFormat);
  return {
    id: stored.id,
    channel: stored.channel,
    state: stored.state,
    floor: stored.floor,
    swipe: stored.swipe,
    updatedAt: stored.updatedAt,
    patchText: extracted.patchText,
    rawText: extracted.rawText,
    unwrapped: extracted.unwrapped,
    replyFormat: stored.replyFormat,
    error: stored.error,
    editable: opts.editable,
    canResummarize: opts.canResummarize,
    canReRequestApi: opts.canReRequestApi,
    edited: stored.edited,
    missingUpdateBlock: extracted.missingUpdateBlock,
    missingClosingTag: extracted.missingClosingTag,
  };
}

export function buildActivePendingVariableRecord(params: {
  storedList: readonly StoredVariableOutput[];
  pending: PendingStoryVariableSnapshot | null;
  pendingPhone: PendingPhoneVariableSnapshot | null;
  failedLog?: FailedParseLogSnapshot;
  viewState: { readOnly: boolean; busy: boolean; updating: boolean; error: string };
}): VariableOutputRecord | null {
  const { storedList, pending, pendingPhone, failedLog, viewState } = params;
  const interactive = !viewState.readOnly && !viewState.busy && !viewState.updating;

  if (pending) {
    const channel: VariableOutputChannel = pending.mode === 'main' ? 'story-main' : 'story-extra';
    const stored = [...storedList].reverse().find(item => item.id === pending.id);
    const matchingFailure = failedLog?.id === pending.id ? failedLog : undefined;
    const rawText =
      pending.mode === 'main'
        ? (pending.reply ?? stored?.rawText ?? matchingFailure?.response ?? '')
        : (pending.failedReply ?? pending.reply ?? stored?.rawText ?? matchingFailure?.response ?? '');
    const replyFormat =
      pending.mode === 'main'
        ? undefined
        : (pending.failedReplyFormat ?? pending.replyFormat ?? stored?.replyFormat);
    if (pending.mode === 'extra' && !rawText.trim()) return null;
    const errorText =
      stored?.error ??
      (typeof matchingFailure?.error === 'string' ? matchingFailure.error : undefined) ??
      (viewState.error || undefined);
    const state: StoredVariableOutput['state'] = viewState.updating ? 'pending' : errorText ? 'failed' : 'pending';
    return toVariableOutputRecord(
      {
        id: pending.id,
        channel,
        state,
        floor: pending.replyFloor,
        swipe: pending.replySwipe ?? 0,
        updatedAt: stored?.updatedAt ?? matchingFailure?.at ?? new Date().toISOString(),
        rawText,
        replyFormat,
        error: state === 'failed' ? errorText : undefined,
        edited: stored?.edited ?? pending.useEditedReply,
      },
      {
        editable: interactive,
        // 独立变量模式可直接重新请求独立变量 API；同轮模式允许显式展开缺失资料并单次补算变量（不重写正文）。
        canReRequestApi: interactive && (pending.mode === 'extra' || pending.replyFloor !== undefined),
      },
    );
  }

  if (pendingPhone) {
    const stored = [...storedList].reverse().find(item => item.id === pendingPhone.id);
    const matchingFailure = failedLog?.id === pendingPhone.id ? failedLog : undefined;
    const rawText = pendingPhone.failedReply ?? pendingPhone.reply ?? stored?.rawText ?? matchingFailure?.response ?? '';
    if (!rawText.trim()) return null;
    const replyFormat = pendingPhone.failedReplyFormat ?? pendingPhone.replyFormat ?? stored?.replyFormat;
    const errorText =
      stored?.error ??
      (typeof matchingFailure?.error === 'string' ? matchingFailure.error : undefined) ??
      (viewState.error || undefined);
    const state: StoredVariableOutput['state'] = viewState.updating || viewState.busy ? 'pending' : errorText ? 'failed' : 'pending';
    return toVariableOutputRecord(
      {
        id: pendingPhone.id,
        channel: 'phone',
        state,
        floor: pendingPhone.context.floor,
        swipe: pendingPhone.context.swipe,
        updatedAt: stored?.updatedAt ?? matchingFailure?.at ?? new Date().toISOString(),
        rawText,
        replyFormat,
        error: state === 'failed' ? errorText : undefined,
        edited: stored?.edited ?? pendingPhone.editedReply,
      },
      {
        editable: interactive,
        canReRequestApi: interactive,
      },
    );
  }

  return null;
}

function toIndexEntry(
  item: Pick<StoredVariableOutput, 'id' | 'channel' | 'state' | 'floor' | 'swipe' | 'updatedAt' | 'edited'>,
): VariableOutputIndexEntry {
  return {
    id: item.id,
    channel: item.channel,
    state: item.state,
    floor: item.floor,
    swipe: item.swipe,
    updatedAt: item.updatedAt,
    edited: item.edited,
  };
}

function indexKey(item: Pick<StoredVariableOutput, 'id' | 'channel' | 'floor' | 'swipe'>): string {
  return item.channel === 'phone'
    ? 'latest-phone'
    : item.floor !== undefined
      ? `${item.floor}:${item.swipe ?? 0}`
      : item.id;
}

function matchesTarget(
  item: Pick<StoredVariableOutput, 'id' | 'channel' | 'floor' | 'swipe'>,
  target: VariableOutputTarget,
): boolean {
  if (target.id === undefined && target.channel === undefined && target.floor === undefined) return false;
  if (target.id !== undefined && item.id !== target.id) return false;
  if (target.channel !== undefined && item.channel !== target.channel) return false;
  if (target.floor !== undefined) {
    if (target.channel === undefined && item.channel === 'phone') return false;
    if (item.floor !== target.floor) return false;
    if (target.swipe !== undefined && (item.swipe ?? 0) !== target.swipe) return false;
  }
  return true;
}

export function buildVariableOutputIndex(
  storedList: readonly StoredVariableOutput[],
  active: VariableOutputRecord | null,
): Record<string, VariableOutputIndexEntry> {
  const index: Record<string, VariableOutputIndexEntry> = {};
  for (const item of storedList) {
    index[indexKey(item)] = toIndexEntry(item);
  }
  if (active) {
    index[indexKey(active)] = toIndexEntry(active);
  }
  return index;
}

export function selectVariableOutputRecord(params: {
  storedList: readonly StoredVariableOutput[];
  active: VariableOutputRecord | null;
  target?: VariableOutputTarget;
  canResummarizeFloor: (floor?: number, swipe?: number) => boolean;
}): VariableOutputRecord | null {
  const { storedList, active, target, canResummarizeFloor } = params;
  if (!target) {
    if (active) return active;
    const latest = storedList.at(-1);
    if (!latest) return null;
    return toVariableOutputRecord(latest, {
      editable: false,
      canResummarize: latest.channel !== 'phone' && canResummarizeFloor(latest.floor, latest.swipe),
    });
  }
  if (active && matchesTarget(active, target)) return active;
  for (let i = storedList.length - 1; i >= 0; i--) {
    const item = storedList[i];
    if (matchesTarget(item, target)) {
      return toVariableOutputRecord(item, {
        editable: false,
        canResummarize: item.channel !== 'phone' && canResummarizeFloor(item.floor, item.swipe),
      });
    }
  }
  return null;
}

export function listVariableOutputEntries(
  storedList: readonly StoredVariableOutput[],
  active: VariableOutputRecord | null,
): VariableOutputIndexEntry[] {
  const result: VariableOutputIndexEntry[] = [];
  const seen = new Set<string>();
  if (active) {
    seen.add(active.id);
    result.push(toIndexEntry(active));
  }
  for (let i = storedList.length - 1; i >= 0; i--) {
    const item = storedList[i];
    if (seen.has(item.id)) continue;
    seen.add(item.id);
    result.push(toIndexEntry(item));
  }
  return result;
}
