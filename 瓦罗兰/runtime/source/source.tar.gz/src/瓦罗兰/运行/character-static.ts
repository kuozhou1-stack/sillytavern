import {
  CharacterStaticProfileSchema,
  Schema,
  type CharacterStaticProfile,
} from '../schema';
import { copy, uid, type State } from './core';
import type { PromptPurpose } from './prompt-context';
import {
  formatPublicIdentity,
  hiddenIdentityTags,
  normalizeIdentityInput,
  publicIdentityTags,
  resolveEffectiveCharacterIdentity,
  mentionsRecordId,
} from './character-identity';

export { formatPublicIdentity, hiddenIdentityTags, normalizeIdentityInput, publicIdentityTags, resolveEffectiveCharacterIdentity };

export const STATIC_PROFILE_KEY = '瓦罗兰静态档案库';

type SharedStaticStore = {
  profiles: Map<string, CharacterStaticProfile>;
  listeners: Set<() => void>;
};

const LOCAL_STATIC_STORE: SharedStaticStore = {
  profiles: new Map<string, CharacterStaticProfile>(),
  listeners: new Set<() => void>(),
};

function getStaticStore(): SharedStaticStore {
  try {
    if (typeof window !== 'undefined') {
      const host = (window.parent && window.parent !== window ? window.parent : window) as any;
      if (host && typeof host === 'object') {
        if (!host.__valoranStaticProfileStore) {
          host.__valoranStaticProfileStore = {
            profiles: new Map<string, CharacterStaticProfile>(),
            listeners: new Set<() => void>(),
          } satisfies SharedStaticStore;
        }
        return host.__valoranStaticProfileStore as SharedStaticStore;
      }
    }
  } catch {
    // 跨域或受限宿主下回退到当前模块内存
  }
  return LOCAL_STATIC_STORE;
}

// 批量准备在独立映射中完成，通过全部校验后再通知其他界面。
let stagedProfiles: Map<string, CharacterStaticProfile> | undefined;
const profilesForRead = () => stagedProfiles ?? getStaticStore().profiles;
export function stageCharacterProfiles<T>(prepare: () => T): T {
  if (stagedProfiles) return prepare();
  const store = getStaticStore();
  stagedProfiles = new Map(store.profiles);
  try {
    const result = prepare();
    store.profiles = stagedProfiles;
    return result;
  } finally {
    const committed = store.profiles === stagedProfiles;
    stagedProfiles = undefined;
    if (committed) notify();
  }
}

function notify() {
  if (stagedProfiles) return;
  for (const fn of getStaticStore().listeners) {
    try {
      fn();
    } catch (error) {
      console.warn('[瓦罗兰静态档案] 通知异常', error);
    }
  }
}

export function subscribeStaticProfiles(listener: () => void): () => void {
  const { listeners } = getStaticStore();
  listeners.add(listener);
  let active = true;
  const unsub = () => {
    if (!active) return;
    active = false;
    listeners.delete(listener);
    if (typeof window !== 'undefined') window.removeEventListener?.('pagehide', unsub);
  };
  if (typeof window !== 'undefined') window.addEventListener?.('pagehide', unsub, { once: true });
  return unsub;
}

/** 递归剔除 null / undefined / 空数组 / 空对象，避免向提示词发送无意义空壳。 */
export function pruneEmptyFields(value: unknown): any {
  if (value === null || value === undefined) return undefined;
  if (typeof value === 'string') return value.trim() ? value : undefined;
  if (Array.isArray(value)) {
    const items = value.map(pruneEmptyFields).filter(item => item !== undefined);
    return items.length ? items : undefined;
  }
  if (typeof value === 'object') {
    const entries = Object.entries(value as Record<string, unknown>)
      .map(([k, v]) => [k, pruneEmptyFields(v)] as const)
      .filter(([, v]) => v !== undefined);
    return entries.length ? Object.fromEntries(entries) : undefined;
  }
  return value;
}

function normalizeStaticPersonality(raw: unknown, layer: '主要' | '次要') {
  if (layer === '次要') {
    if (typeof raw === 'string') return raw;
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      const obj = raw as Record<string, unknown>;
      return typeof obj.表性格 === 'string' ? obj.表性格 : null;
    }
    return null;
  }
  if (typeof raw === 'string') {
    return { 表性格: raw };
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const src = copy(raw) as Record<string, any>;
  // 兼容旧版 语言习惯 -> 语言指纹.句法与口吻
  if (typeof src.语言习惯 === 'string' && src.语言习惯.trim()) {
    src.语言指纹 = {
      ...(src.语言指纹 && typeof src.语言指纹 === 'object' ? src.语言指纹 : {}),
      句法与口吻: src.语言指纹?.句法与口吻 ?? src.语言习惯,
    };
    delete src.语言习惯;
  }
  return src;
}

function normalizeSignature(raw: unknown) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out = copy(raw) as Record<string, any>;
  for (const key of ['身体印记', '随身信物']) {
    if (typeof out[key] === 'string') out[key] = out[key].trim() ? [out[key].trim()] : [];
  }
  return out;
}

const VALID_NETWORK_KEYS = new Set(['网络身份', '网络用户名', '发布偏好', '活跃习惯', '互动风格', '公开边界']);

function normalizeNetworkPrefs(raw: unknown) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out: Record<string, Record<string, string | null>> = {};
  for (const [scope, entry] of Object.entries(raw as Record<string, unknown>)) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
    const cleaned: Record<string, string | null> = {};
    for (const [k, v] of Object.entries(entry as Record<string, unknown>)) {
      // 兼容旧版「常用平台」键：自动忽略防止旧角色包解析报错，由新版「网络用户名」承接。
      if (k === '常用平台' || !VALID_NETWORK_KEYS.has(k)) continue;
      cleaned[k] = v == null ? null : String(v);
    }
    if (Object.keys(cleaned).length) out[scope] = cleaned;
  }
  return out;
}

/**
 * 将完整创作 JSON（或旧版全量角色 JSON）拆分为动态 MVU 状态与只读静态档案。
 */
export function splitCharacterAuthoring(
  rawInput: Record<string, any>,
  id?: string,
  defaultLayer: '主要' | '次要' = '主要',
): {
  dynamic: State['角色'][string];
  staticProfile: CharacterStaticProfile;
  recognizedFields: string[];
} {
  const raw = copy(rawInput ?? {});
  const layer: '主要' | '次要' = raw.层级 === '次要' ? '次要' : raw.层级 === '主要' ? '主要' : defaultLayer;
  const identity = normalizeIdentityInput(raw.身份);
  const wardrobe = raw.形态衣橱 && typeof raw.形态衣橱 === 'object' && !Array.isArray(raw.形态衣橱) ? copy(raw.形态衣橱) : {};
  const wardrobeKeys = Object.keys(wardrobe);
  const defaultForm =
    (typeof raw.默认形态 === 'string' && raw.默认形态.trim()) ||
    (typeof raw.当前形态 === 'string' && raw.当前形态.trim()) ||
    wardrobeKeys[0] ||
    null;
  const currentForm = (typeof raw.当前形态 === 'string' && raw.当前形态.trim()) || defaultForm;

  const rawAppearance = raw.外貌 && typeof raw.外貌 === 'object' ? raw.外貌 : {};
  const rawLife = raw.生活 && typeof raw.生活 === 'object' ? raw.生活 : {};
  const rawHistory = raw.经历 && typeof raw.经历 === 'object' ? raw.经历 : {};
  const rawSex = raw.性特征 && typeof raw.性特征 === 'object' ? raw.性特征 : undefined;
  const rawSexExp = raw.性经验 ?? rawSex?.性经验;

  const dynamicCandidate: Record<string, any> = {
    姓名: raw.姓名 ?? null,
    性别: raw.性别 ?? null,
    种族: raw.种族 ?? null,
    当前形态: currentForm,
    年龄: raw.年龄 ?? null,
    身份: identity,
    组织id: Array.isArray(raw.组织id) ? raw.组织id : [],
    关系网: raw.关系网 && typeof raw.关系网 === 'object' ? raw.关系网 : {},
    认知: raw.认知 && typeof raw.认知 === 'object' ? raw.认知 : {},
    当前状态: raw.当前状态 ?? null,
    当前地点id: raw.当前地点id ?? null,
    外貌: {
      今日穿搭: rawAppearance.今日穿搭 ?? null,
    },
    生活: {
      住处id: rawLife.住处id ?? null,
      工作地点id: Array.isArray(rawLife.工作地点id) ? rawLife.工作地点id : [],
      常去地点id: Array.isArray(rawLife.常去地点id) ? rawLife.常去地点id : [],
      日常活动: rawLife.日常活动 ?? null,
      目标: rawLife.目标 && typeof rawLife.目标 === 'object' ? rawLife.目标 : {},
    },
    重要记录: raw.重要记录 && typeof raw.重要记录 === 'object' ? raw.重要记录 : {},
    _管理: raw._管理 && typeof raw._管理 === 'object' ? raw._管理 : {},
    层级: layer,
  };

  const genderText = String(raw.性别 ?? '').trim();
  const isMale = ['男', '男性'].includes(genderText);
  const sexualApplicable = layer === '主要' && raw.性特征适用 !== false && !isMale;

  if (layer === '主要') {
    dynamicCandidate.即时状态 = raw.即时状态 && typeof raw.即时状态 === 'object' ? raw.即时状态 : {};
    dynamicCandidate.性特征适用 = isMale ? false : (raw.性特征适用 ?? null);
    if (sexualApplicable && rawSexExp && typeof rawSexExp === 'object') {
      dynamicCandidate.性经验 = {
        性次数: rawSexExp.性次数 ?? {},
        性人群: rawSexExp.性人群 ?? null,
      };
    }
    dynamicCandidate.经历 = {
      最近经历: rawHistory.最近经历 ?? {},
      生活摘要: rawHistory.生活摘要 ?? {},
      阶段概述: rawHistory.阶段概述 ?? {},
      _待归档经历: rawHistory._待归档经历 ?? {},
    };
    dynamicCandidate._更新循环 = raw._更新循环 && typeof raw._更新循环 === 'object' ? raw._更新循环 : {};
  }

  const parsedDynamic = Schema.parse({ 角色: { [id ?? 'temp']: dynamicCandidate } }).角色[id ?? 'temp'];

  const staticSexInput = sexualApplicable
    ? (raw.静态性特征 ??
      (rawSex
        ? {
            奶子信息: rawSex.奶子信息 ?? null,
            蜜穴信息: rawSex.蜜穴信息 ?? null,
            敏感与特殊体质: rawSex.敏感与特殊体质 ?? rawSex.其他 ?? null,
            亲密反应模式: rawSex.亲密反应模式 ?? {},
          }
        : undefined))
    : undefined;

  const staticCandidate: Record<string, any> = {
    id,
    姓名: parsedDynamic.姓名,
    性别: parsedDynamic.性别,
    层级: layer,
    默认形态: defaultForm,
    身份: identity,
    简介: raw.简介 ?? null,
    超凡能力: raw.超凡能力 && typeof raw.超凡能力 === 'object' ? raw.超凡能力 : {},
    外貌: {
      身高: rawAppearance.身高 ?? null,
      体重: rawAppearance.体重 ?? null,
      整体体型: rawAppearance.整体体型 ?? null,
      ...(rawAppearance.三围信息 ? { 三围信息: rawAppearance.三围信息 } : {}),
      ...(rawAppearance.罩杯 !== undefined ? { 罩杯: rawAppearance.罩杯 } : {}),
      主色调与高光焦点: rawAppearance.主色调与高光焦点 ?? null,
      详细外表: rawAppearance.详细外表 ?? null,
    },
    形态衣橱: wardrobe,
    性格: normalizeStaticPersonality(raw.性格, layer),
    专属标识: normalizeSignature(raw.专属标识),
    网络倾向: normalizeNetworkPrefs(raw.网络倾向),
    认知边界: raw.认知边界 && typeof raw.认知边界 === 'object' ? raw.认知边界 : {},
    财力与消费观: rawLife.财力与消费观 ?? raw.财力与消费观 ?? null,
    性特征适用: layer === '主要' ? (raw.性特征适用 ?? null) : null,
    静态关系锚点: raw.静态关系锚点 && typeof raw.静态关系锚点 === 'object' ? raw.静态关系锚点 : {},
    人生经历: rawHistory.人生经历 && typeof rawHistory.人生经历 === 'object' ? rawHistory.人生经历 : {},
  };

  if (typeof raw.称呼 === 'string' && raw.称呼.trim()) staticCandidate.称呼 = raw.称呼;
  if (raw.心理年龄 != null) staticCandidate.心理年龄 = raw.心理年龄;
  if (raw.伴生体 != null) staticCandidate.伴生体 = raw.伴生体;
  const seasonal = rawLife.季节驻留 ?? raw.季节驻留;
  if (seasonal && typeof seasonal === 'object') staticCandidate.季节驻留 = seasonal;
  if (staticSexInput) staticCandidate.静态性特征 = staticSexInput;

  const staticProfile = CharacterStaticProfileSchema.parse(staticCandidate);

  return {
    dynamic: parsedDynamic,
    staticProfile,
    recognizedFields: Object.keys(raw),
  };
}

export function getCharacterStaticProfile(id: string): CharacterStaticProfile | undefined {
  return profilesForRead().get(id);
}

export function getAllCharacterStaticProfiles(): Record<string, CharacterStaticProfile> {
  return Object.fromEntries([...getStaticStore().profiles.entries()].map(([id, profile]) => [id, copy(profile)]));
}

export function parseStaticProfileEntry(entry: unknown, id: string): CharacterStaticProfile {
  const rawEntry = copy(entry ?? {}) as Record<string, any>;
  if (rawEntry.网络倾向) rawEntry.网络倾向 = normalizeNetworkPrefs(rawEntry.网络倾向);
  return CharacterStaticProfileSchema.parse({ ...rawEntry, id });
}

export function setCharacterStaticProfile(id: string, profile: CharacterStaticProfile) {
  profilesForRead().set(id, parseStaticProfileEntry(profile, id));
  notify();
}

/** 旧楼层继续引用原档。仅在同一人物的档案内容改变时分配新的静态键。 */
export function bindCharacterStaticProfile(id: string, person: State['角色'][string], profile: CharacterStaticProfile) {
  const entry = parseStaticProfileEntry(profile, id);
  const profiles = profilesForRead();
  const key = person._管理.静态档案id ?? id;
  const current = profiles.get(key);
  if (current?.id === id && _.isEqual(current, entry)) return;
  const next = current || key !== id ? uid('profile') : id;
  profiles.set(next, entry);
  if (next !== id) person._管理.静态档案id = next;
  else delete person._管理.静态档案id;
  notify();
}

export function deleteCharacterStaticProfile(id: string) {
  if (getStaticStore().profiles.delete(id)) notify();
}

export function clearCharacterStaticProfiles() {
  getStaticStore().profiles.clear();
  notify();
}

export function loadStaticProfilesFromObject(raw: unknown) {
  const { profiles } = getStaticStore();
  profiles.clear();
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    for (const [id, entry] of Object.entries(raw as Record<string, unknown>)) {
      if (!entry || typeof entry !== 'object') continue;
      try {
        profiles.set(id, parseStaticProfileEntry(entry, (entry as CharacterStaticProfile).id ?? id));
      } catch (error) {
        console.warn('[瓦罗兰静态档案] 跳过无法解析的静态档案：', id, error);
      }
    }
  }
  notify();
}

export function exportStaticProfilesObject(): Record<string, CharacterStaticProfile> {
  return getAllCharacterStaticProfiles();
}

function readSavedStaticProfiles(): Record<string, unknown> | undefined {
  if (typeof getVariables !== 'function') return;
  const saved = getVariables({ type: 'chat' })?.[STATIC_PROFILE_KEY];
  if (saved && typeof saved === 'object' && !Array.isArray(saved)) return saved;
  return undefined;
}

/** 在酒馆环境中从聊天级变量同步静态档案（切聊天时清空上一聊天残留缓存）。 */
export function syncStaticProfilesFromChat() {
  try {
    if (typeof getVariables !== 'function') return;
    loadStaticProfilesFromObject(readSavedStaticProfiles());
  } catch (error) {
    console.warn('[瓦罗兰静态档案] 读取聊天变量失败', error);
  }
}

/** 从跨 iframe 共享档案库、聊天级变量或存档来源快照中按需取回静态档案（兼容热重载与旧版本字段迁移）。 */
export function resolveCharacterStaticProfile(
  state: State | undefined,
  id: string,
  readSaved = readSavedStaticProfiles,
): CharacterStaticProfile | undefined {
  const profiles = profilesForRead();
  const key = state?.角色?.[id]?._管理?.静态档案id ?? id;
  const cached = profiles.get(key);
  if (cached) return cached;

  // 1. 优先尝试从酒馆聊天级变量恢复
  try {
    const saved = readSaved();
    const savedEntry = saved && Object.hasOwn(saved, key) ? saved[key] : undefined;
    if (savedEntry && typeof savedEntry === 'object') {
      const profile = parseStaticProfileEntry(savedEntry, id);
      profiles.set(key, profile);
      return profile;
    }
  } catch (error) {
    console.warn('[瓦罗兰静态档案] 从聊天变量恢复静态档案失败：', id, error);
  }

  // 2. 兜底从当前存档的 来源档案 原始快照恢复（仅当快照显式带静态档案时写回全局缓存，避免裸角色包产生导出副作用）
  const sourceId = state?.角色?.[id]?._管理?.来源档案id;
  const source = sourceId ? state?._系统?.来源档案?.[sourceId] : undefined;
  if (source?.原始快照JSON) {
    try {
      const packet = JSON.parse(source.原始快照JSON);
      if (packet?.静态档案 && typeof packet.静态档案 === 'object') {
        const profile = parseStaticProfileEntry(packet.静态档案, id);
        profiles.set(key, profile);
        return profile;
      }
      const raw = packet?.角色 ?? packet;
      if (raw && typeof raw === 'object') {
        return splitCharacterAuthoring(raw, id, state?.角色?.[id]?.层级 ?? '主要').staticProfile;
      }
    } catch (error) {
      console.warn('[瓦罗兰静态档案] 从来源快照恢复静态档案失败：', id, error);
    }
  }
  return undefined;
}

/** 每次批处理只读取一次聊天档案索引，缺失或失败结果也仅在本次处理内复用。 */
export function createCharacterStaticProfileResolver() {
  let saved: Record<string, unknown> | undefined;
  const readOnce = () => {
    if (saved) return saved;
    saved = {};
    return (saved = readSavedStaticProfiles() ?? saved);
  };
  return (state: State | undefined, id: string) => resolveCharacterStaticProfile(state, id, readOnce);
}

export function characterPublicIdentity(state: State | undefined, id: string | null | undefined, fallback?: unknown) {
  if (!id) return formatPublicIdentity(fallback);
  const dynamic = state?.角色[id]?.身份 ?? fallback;
  return formatPublicIdentity(resolveEffectiveCharacterIdentity(dynamic, resolveCharacterStaticProfile(state, id)?.身份));
}

/** 供前端界面使用的完整人物视图合并器：将动态 MVU 与静态档案无缝整合。 */
export function mergeCharacterDisplay(
  dynamic: Record<string, any> | null | undefined,
  staticProfile?: CharacterStaticProfile | null,
): Record<string, any> | null {
  if (!dynamic && !staticProfile) return null;
  const dyn = dynamic ?? {};
  const stat = staticProfile ?? ({} as Partial<CharacterStaticProfile>);
  const identity = resolveEffectiveCharacterIdentity(dyn.身份, stat.身份);
  const mergedAppearance = {
    ...(stat.外貌 ?? {}),
    ...(dyn.外貌 ?? {}),
    今日穿搭: dyn.外貌?.今日穿搭 ?? null,
  };
  const mergedLife = {
    ...(dyn.生活 ?? {}),
    财力与消费观: stat.财力与消费观 ?? dyn.生活?.财力与消费观 ?? null,
    ...(stat.季节驻留 ? { 季节驻留: stat.季节驻留 } : {}),
  };
  const mergedHistory =
    (dyn.层级 ?? stat.层级) === '主要'
      ? {
          人生经历: stat.人生经历 ?? dyn.经历?.人生经历 ?? {},
          最近经历: dyn.经历?.最近经历 ?? {},
          生活摘要: dyn.经历?.生活摘要 ?? {},
          阶段概述: dyn.经历?.阶段概述 ?? {},
          _待归档经历: dyn.经历?._待归档经历 ?? {},
        }
      : undefined;
  const mergedSex =
    dyn.性经验 || stat.静态性特征
      ? {
          ...(stat.静态性特征 ?? {}),
          性经验: dyn.性经验 ?? { 性次数: { 确数: null, 概数说明: null, 已知新增说明: null }, 性人群: null },
        }
      : undefined;

  const result: Record<string, any> = {
    ...dyn,
    姓名: dyn.姓名 ?? stat.姓名 ?? null,
    性别: dyn.性别 ?? stat.性别 ?? null,
    层级: dyn.层级 ?? stat.层级 ?? '主要',
    默认形态: stat.默认形态 ?? dyn.当前形态 ?? null,
    当前形态: dyn.当前形态 ?? stat.默认形态 ?? null,
    身份: identity,
    简介: stat.简介 ?? dyn.简介 ?? null,
    超凡能力: stat.超凡能力 ?? null,
    外貌: mergedAppearance,
    形态衣橱: stat.形态衣橱 ?? {},
    性格: stat.性格 ?? dyn.性格 ?? null,
    专属标识: stat.专属标识 ?? dyn.专属标识 ?? null,
    网络倾向: stat.网络倾向 ?? dyn.网络倾向 ?? {},
    认知边界: stat.认知边界 ?? null,
    静态关系锚点: stat.静态关系锚点 ?? {},
    生活: mergedLife,
    ...(mergedHistory ? { 经历: mergedHistory } : {}),
    ...(mergedSex ? { 性特征: mergedSex } : {}),
  };

  // 彻底可选：只有确实存在伴生体时才挂在展示对象上，无则完全不出现。
  if (stat.称呼) result.称呼 = stat.称呼;
  if (stat.心理年龄 != null) result.心理年龄 = stat.心理年龄;
  if (stat.伴生体) result.伴生体 = stat.伴生体;
  return result;
}

const PHONE_SIGNAL_RE = /手机|星讯|星声|发帖|动态|热搜|朋友圈|点赞|评论|转发|私聊|消息|群聊|直播|网购|语音|视频通话/;
const INTIMACY_SIGNAL_RE =
  /亲吻|接吻|热吻|轻吻|深吻|拥抱|抱紧|怀里|脱衣|解衣|宽衣|贴近耳边|耳畔低语|娇喘|喘息|滚床单|同床|共浴|混浴|亲密接触|亲热|爱抚|抚摸|调情|撩拨|情欲|酥麻|私密|做爱|欢好|缠绵|湿润|揉捏|胸部|胸乳|蜜穴|私处/;

export type CharacterFormSpec = {
  defaultForm: string | null;
  forms: string[];
  hasWardrobe: boolean;
};

function normalizeFormToken(value: string): string {
  return value.replace(/[\s/\\·・\-_—]+/g, '').toLowerCase();
}

/** 精确或忽略大小写/常见分隔符（如 K/DA -> KDA）匹配合法形态名，不对普通句子做子串误匹配。 */
export function matchLegalCharacterForm(
  requested: string | null | undefined,
  legalForms: readonly string[],
): string | null {
  const clean = requested?.trim();
  if (!clean || !legalForms.length) return null;
  const exact = legalForms.find(name => name === clean);
  if (exact) return exact;
  const lower = clean.toLowerCase();
  const ci = legalForms.find(name => name.toLowerCase() === lower);
  if (ci) return ci;
  const token = normalizeFormToken(clean);
  if (!token) return null;
  return legalForms.find(name => normalizeFormToken(name) === token) ?? null;
}

/** 从活跃缓存、聊天静态库或停用快照包中解析角色静态档案（兼容休眠角色）。 */
export function resolveDormantOrActiveStaticProfile(
  state: State | undefined,
  id: string,
  snapshotPack?: any,
): CharacterStaticProfile | undefined {
  if (snapshotPack?.静态档案) return parseStaticProfileEntry(snapshotPack.静态档案, id);
  const snapshotKey = snapshotPack?.角色?._管理?.静态档案id;
  if (snapshotKey) {
    const profile = profilesForRead().get(snapshotKey);
    if (!profile) throw Error('停用快照缺少对应静态档案：' + id);
    return profile;
  }
  const sources = snapshotPack?.来源档案;
  if (sources && typeof sources === 'object') {
    for (const source of Object.values(sources) as any[]) {
      if (source?.人物id !== id || typeof source?.原始快照JSON !== 'string') continue;
      try {
        const packet = JSON.parse(source.原始快照JSON);
        if (packet?.静态档案 && typeof packet.静态档案 === 'object') {
          const parsed = parseStaticProfileEntry(packet.静态档案, id);
          return parsed;
        }
      } catch {
        // 忽略损坏旧快照，回退其他来源
      }
    }
  }
  return resolveCharacterStaticProfile(state, id);
}

/** 作者衣橱决定合法形态。旧档只有一个已知形态时沿用它。 */
export function getLegalCharacterForms(
  state: State | undefined,
  id: string,
  personOverride?: { 姓名?: string | null; 当前形态?: string | null } | null,
  staticOverride?: CharacterStaticProfile | null,
): CharacterFormSpec {
  const person = personOverride ?? state?.角色?.[id] ?? null;
  const profile = staticOverride === undefined ? resolveCharacterStaticProfile(state, id) : staticOverride;
  const rawForms = Object.keys(profile?.形态衣橱 ?? {}).map(key => key.trim()).filter(Boolean);
  if (!rawForms.length) {
    const singleDefault = person?.当前形态?.trim() || profile?.默认形态?.trim() || null;
    return {
      defaultForm: singleDefault,
      forms: singleDefault ? [singleDefault] : [],
      hasWardrobe: false,
    };
  }

  const preferredDefault =
    (profile?.默认形态 && matchLegalCharacterForm(profile.默认形态, rawForms)) ||
    rawForms[0];
  const ordered = [preferredDefault, ...rawForms.filter(item => item !== preferredDefault)];
  return {
    defaultForm: preferredDefault,
    forms: ordered,
    hasWardrobe: true,
  };
}

/**
 * 将资料选择或初始化给定的目标形态应用到活跃角色，并妥善衔接 `外貌.今日穿搭`：
 * - 形态未变时保留既有 `今日穿搭`；
 * - 形态实际切换时清空旧形态残留的 `今日穿搭`（置 `null`，由 `<character_static_context>.当前形态详情` 提供新形态装束基准）。
 */
export function applyCharacterFormSelections(
  state: State,
  requestedForms?: Record<string, string> | null,
): State {
  let mutated: State | null = null;
  const ensureDraft = () => (mutated ??= copy(state));
  const profileFor = createCharacterStaticProfileResolver();

  for (const [id, person] of Object.entries(state.角色)) {
    if (!person || state._系统.角色停用标识[id]) continue;
    const spec = getLegalCharacterForms(state, id, person, profileFor(state, id) ?? null);
    if (!spec.forms.length) continue;

    const prevForm = person.当前形态?.trim() || null;
    const validPrevForm = prevForm ? matchLegalCharacterForm(prevForm, spec.forms) : null;
    const rawRequested = requestedForms && Object.hasOwn(requestedForms, id) ? requestedForms[id] : undefined;
    const matchedRequested = rawRequested !== undefined ? matchLegalCharacterForm(rawRequested, spec.forms) : null;
    if (rawRequested !== undefined && !matchedRequested) {
      throw Error('资料选择返回了非法形态：' + id + '/' + rawRequested);
    }

    const nextForm = matchedRequested ?? validPrevForm ?? spec.defaultForm;
    if (!nextForm) continue;

    if (person.当前形态 !== nextForm) {
      const draft = ensureDraft();
      draft.角色[id].当前形态 = nextForm;
      // 仅当从一个已确立的旧形态切换到另一形态时清空残留穿搭；首次补齐同系默认形态时保留作者初值。
      if (prevForm && validPrevForm !== nextForm && draft.角色[id].外貌.今日穿搭 !== null) {
        draft.角色[id].外貌.今日穿搭 = null;
      }
    }
  }
  return mutated ?? state;
}

/** 临时服饰只由今日穿搭承接，非法形态交回原结算的可编辑重试流程。 */
export function normalizeSettledCharacterForms(before: State, after: State): State {
  const profileFor = createCharacterStaticProfileResolver();
  for (const [id, person] of Object.entries(after.角色)) {
    const old = before.角色[id];
    const profile = profileFor(after, id) ?? profileFor(before, id);
    const spec = getLegalCharacterForms(before, id, old, profile ?? null);
    const raw = person.当前形态?.trim();
    if (!spec.forms.length) {
      if (raw) throw Error('当前形态不在人物衣橱内：' + id + '/' + raw);
      continue;
    }
    const next = raw ? matchLegalCharacterForm(raw, spec.forms) : spec.defaultForm;
    if (!next) throw Error('当前形态不在人物衣橱内：' + id + '/' + raw);
    person.当前形态 = next;
    if (old?.当前形态 && old.当前形态 !== next && person.外貌.今日穿搭 === old.外貌.今日穿搭) {
      person.外貌.今日穿搭 = null;
    }
  }
  return after;
}

/**
 * 供变量更新通道（`variables` 与 `inline`）使用的本轮已开启多形态角色极简枚举提示；
 * 若本轮开启角色均为单形态角色，返回空串（0 token）。
 */
export function characterFormEnumPrompt(state: State, text: string, targets: readonly string[] = []): string {
  const enumMap: Record<string, string[]> = {};
  const profileFor = createCharacterStaticProfileResolver();
  for (const [id, person] of Object.entries(state.角色 ?? {})) {
    if (!person || state._系统.角色停用标识[id]) continue;
    if (!targets.includes(id) && !state.世界.当前场景.在场人物.includes(id) &&
        !mentionsRecordId(text, id) && !(person.姓名 && text.includes(person.姓名))) continue;
    const spec = getLegalCharacterForms(state, id, person, profileFor(state, id) ?? null);
    if (spec.forms.length > 1) {
      enumMap[id] = spec.forms;
    }
  }
  if (!Object.keys(enumMap).length) return '';
  return (
    '角色形态与穿搭区分：普通换装、脱衣、睡衣或局部衣饰变化只更新 外貌.今日穿搭，严禁把临时衣物名写入 当前形态；' +
    '仅当正文中角色实际切换了预设形态时，才从其合法形态列表中原样取值更新 当前形态（切换形态无额外衣饰改动时可将 外貌.今日穿搭 置 null），未列出的单形态角色保持原 当前形态 不变：' +
    JSON.stringify(enumMap)
  );
}

export type StaticContextProjectionOptions = {
  purpose: PromptPurpose;
  input?: string;
  recentText?: string;
  phoneActive?: boolean;
};

/** 只有本场已显现的秘密形态才使用战衣描写。其他人的行动和上一楼的变身不改变此人装束。 */
function showsHiddenForm(state: State, id: string, input: string) {
  const person = state.角色[id];
  const placeId = person.当前地点id ?? state.玩家.当前状态.当前地点id;
  const area = placeId && state.地点[placeId]?.片区id;
  if (area && state.世界.片区[area]?.图层 === '里世界') return true;
  const transformation = /变身(?!星核|道具|装置|器|能力|秘密)|变装完成|解除伪装|进入战斗|星陨警报|秘密集会/;
  const activeNames = Object.values(state.角色).flatMap(other => other.姓名 ? [other.姓名] : []);
  const segments = [input, state.世界.当前场景.正在进行的事, person.当前状态]
    .filter((text): text is string => !!text).flatMap(text => text.split(/[。！？；\n]/));
  return segments.some(text => {
    if (!transformation.test(text) || /(?:没有|并未|尚未|无需|取消|解除|结束)变身/.test(text)) return false;
    if (person.姓名 && text.includes(person.姓名) || mentionsRecordId(text, id)) return true;
    return !activeNames.some(name => text.includes(name)) &&
      (text === person.当前状态 || state.世界.当前场景.在场人物.includes(id) || activeNames.length === 1);
  });
}

/**
 * 按场景条件投影已开启角色的静态设定（仅用于 story/inline 通道，variables/knowledge/novel 不发送）。
 */
export function projectCharacterStaticContext(
  state: State,
  activeIds: readonly string[],
  options: StaticContextProjectionOptions,
): Record<string, any> | null {
  if (options.purpose === 'variables' || options.purpose === 'knowledge' || options.purpose === 'novel') return null;

  const signalText = [
    options.input ?? '',
    options.recentText ?? '',
    state.世界.当前场景.正在进行的事 ?? '',
    state.世界.当前场景.环境状态 ?? '',
  ].join('\n');

  const phoneTriggered = Boolean(options.phoneActive) || PHONE_SIGNAL_RE.test(signalText);
  const globalIntimacySignal = INTIMACY_SIGNAL_RE.test(signalText);
  const playerId = state.玩家.id;

  const projected: Record<string, any> = {};
  const profileFor = createCharacterStaticProfileResolver();

  for (const id of activeIds) {
    const dynamic = state.角色[id];
    if (!dynamic || state._系统.角色停用标识[id]) continue;
    const profile = profileFor(state, id);
    const recoveryNote = dynamic._管理?.恢复说明?.trim() || null;
    const formSpec = getLegalCharacterForms(state, id, dynamic, profile ?? null);
    if (!profile && !recoveryNote && formSpec.forms.length <= 1) continue;

    const card: Record<string, any> = {};
    const effectiveIdentity = resolveEffectiveCharacterIdentity(dynamic.身份, profile?.身份);
    if (profile) {
      if (profile.称呼) card.称呼 = profile.称呼;
      if (profile.心理年龄 != null) card.心理年龄 = profile.心理年龄;
      if (profile.姓名) card.姓名 = profile.姓名;
      const identity = pruneEmptyFields(effectiveIdentity);
      if (identity) card.身份 = identity;
      if (profile.简介) card.简介 = profile.简介;

      const magic = pruneEmptyFields(profile.超凡能力);
      if (magic) card.超凡能力 = magic;

      // 彻底可选：无伴生体时绝对不输出此键。
      const companion = pruneEmptyFields(profile.伴生体);
      if (companion) card.伴生体 = companion;

      const appearance = pruneEmptyFields(profile.外貌);
      if (appearance) card.外貌静态 = appearance;
    }

    // 永远只投影当前选中的 1 个形态详情，不展开全量形态衣橱，节省正文上下文。
    const wardrobe = profile?.形态衣橱 ?? {};
    const matchedDynamicForm = dynamic.当前形态
      ? formSpec.forms.length === 0
        ? dynamic.当前形态
        : matchLegalCharacterForm(dynamic.当前形态, formSpec.forms)
      : null;
    const currentForm: string | null =
      matchedDynamicForm ?? formSpec.defaultForm ?? dynamic.当前形态 ?? null;
    if (currentForm) {
      const detail = wardrobe[currentForm];
      const activeFormDetail = pruneEmptyFields(detail);
      if (activeFormDetail) {
        const hiddenUniform = /星之守护者|黑色玫瑰/.test(currentForm) && effectiveIdentity.隐秘.length > 0;
        if (hiddenUniform && formSpec.forms.length === 1 && !showsHiddenForm(state, id, options.input ?? '')) {
          const publicOutfit = detail.对应身份?.match(/(?:平日|日常)[^；;，,（）()。]*(?:服|穿)[^；;，,（）()。]*/)?.[0];
          card.当前形态详情 = {
            公开身份: effectiveIdentity.公开,
            ...(publicOutfit ? { 日常衣着: publicOutfit } : {}),
            表现: '按公开身份描写本场，战衣与变身仅在实际显现时可见。',
          };
        } else {
          card.当前形态详情 = { 形态名: currentForm, ...activeFormDetail };
        }
      } else if (formSpec.forms.length > 1) {
        card.当前形态 = currentForm;
      }
    }

    if (profile) {

      const personality = pruneEmptyFields(profile.性格);
      if (personality) card.性格 = personality;

      const signature = pruneEmptyFields(profile.专属标识);
      if (signature) card.专属标识 = signature;

      const knowledgeBoundary = pruneEmptyFields(profile.认知边界);
      if (knowledgeBoundary) card.认知边界 = knowledgeBoundary;

      if (profile.财力与消费观?.trim()) card.财力与消费观 = profile.财力与消费观;

      const seasonal = pruneEmptyFields(profile.季节驻留);
      if (seasonal) card.季节驻留 = seasonal;

      const anchors = pruneEmptyFields(profile.静态关系锚点);
      if (anchors) card.静态关系锚点 = anchors;

      const backgroundHistory = pruneEmptyFields(profile.人生经历);
      if (backgroundHistory) card.人生经历 = backgroundHistory;

      // 网络倾向：仅当手机/社交回合触发时按需注入。
      if (phoneTriggered) {
        const network = pruneEmptyFields(profile.网络倾向);
        if (network) card.网络倾向 = network;
      }

      if (profile.静态性特征 && dynamic.层级 === '主要' && dynamic.性特征适用 !== false) {
        const playerRelation = playerId ? dynamic.关系网[playerId] : undefined;
        const highAffinity =
          (playerRelation?.好感度 ?? -100) >= 50 ||
          (playerRelation?.破壁阶段 ?? 0) >= 3;
        const personalIntimacy =
          globalIntimacySignal ||
          INTIMACY_SIGNAL_RE.test(dynamic.当前状态 ?? '') ||
          INTIMACY_SIGNAL_RE.test(dynamic.即时状态?.心境基调 ?? '') ||
          INTIMACY_SIGNAL_RE.test(dynamic.即时状态?.生理状态 ?? '');
        if (highAffinity || personalIntimacy) {
          const intimacy = pruneEmptyFields(profile.静态性特征);
          if (intimacy) card.性特征与亲密反应 = intimacy;
        }
      }
    }

    if (recoveryNote) card.恢复衔接说明 = recoveryNote;

    if (Object.keys(card).length) projected[id] = card;
  }

  return Object.keys(projected).length ? projected : null;
}
