import { Schema } from '../schema';
import { copy, uid, type State } from './core';
import { completeThoughtEnds } from './message-protocol';
import {
  availableNovelTasks,
  GOOD_QUALITIES,
  GOOD_QUALITY_META,
  novelNameKey as nameKey,
  MAX_AVAILABLE_QUESTS,
  storyDay,
} from './novel-system';
import { novelCreationContext, novelPublicSetting } from './novel-context';

export type NovelRefreshTarget = 'tasks' | 'shop' | 'initial';
const ITEM_CATEGORIES = ['消耗品', '工具设备', '穿戴装备', '奇物神装', '资料凭证'] as const;

const TaskDefinition = z.object({
  名称: z.string().trim().min(1),
  类型: z.enum(['日常', '探索', '社交', '成长', '奇遇']),
  难度: z.enum(['基础', '进阶', '稀有']),
  目标: z.string().trim().min(1),
}).strict();

const categoryAliases: Record<string, (typeof ITEM_CATEGORIES)[number]> = {
  工具与设备: '工具设备', 工具: '工具设备', 穿戴用品: '穿戴装备', 资料与凭证: '资料凭证', 资料: '资料凭证',
};
const GoodDefinition = z.object({
  名称: z.string().trim().min(1),
  价格: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
  类别: z.preprocess(value => typeof value === 'string'
    ? (Object.hasOwn(categoryAliases, value.trim()) ? categoryAliases[value.trim()] : value.trim()) : value, z.enum(ITEM_CATEGORIES)),
  品质: z.enum(GOOD_QUALITIES),
  单位: z.string().trim().min(1).optional(),
  描述: z.string().trim().min(1),
  限购: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).optional(),
  稀有: z.boolean().optional(),
}).strict().refine(good => {
  const [min, max] = GOOD_QUALITY_META[good.品质].priceRange;
  return good.价格 >= min && good.价格 <= max;
}, { path: ['价格'], message: '商品价格不在该品质价带内' });
const countFor = (state: State) => state._系统.生成密度 === '少量' ? 2 : state._系统.生成密度 === '丰富' ? 6 : 4;

export function novelRefreshCapacity(state: State, target: NovelRefreshTarget) {
  if (target === 'shop') return countFor(state);
  return Math.min(countFor(state), Math.max(0, MAX_AVAILABLE_QUESTS - availableNovelTasks(state).length));
}

/** Public setting and minimal region/situation context, never a full player/NPC/history projection. */
export function novelRefreshPrompt(state: State, target: NovelRefreshTarget): GenerateConfig {
  const count = novelRefreshCapacity(state, target);
  if (!count) throw Error('待接取任务已达8项，请先接取任务或等到新故事日期后再刷新');
  const taskRules =
    `随机创作1至${count}项可自主选择的新引导任务，目标具体、合理可达，不强制行动或关系结果，不要与创作参考中的「已有任务名称」重复。` +
    '任务字段为名称、类型（日常|探索|社交|成长|奇遇）、难度（基础|进阶|稀有）、目标。' +
    '基础（奖励15–30精粹）为当前条件下单一明确行动可完成的常规目标；进阶（奖励45精粹）需多个关联步骤、准备协调或实际练习；稀有（奖励90精粹）依托公开世界背景中的少见机会、独特线索、节庆奇货、恶魔怪谈或三线救援目标，可设计尚待发现的契机，不把它当作玩家已经历或已知的事实。' +
    '故事日期、任务ID和奖励由程序维护，不输出进度或奖励金额。';
  const goodRules =
    `随机创作1至${countFor(state)}件新品，不要与创作参考中的「已有商品名称」重复，价格使用正整数蓝色精粹。` +
    '类别必须严格从「消耗品|工具设备|穿戴装备|奇物神装|资料凭证」五选一；品质必须按英雄联盟装备体系从「基础|史诗|传说|神话」四选一，并严格对应蓝色精粹价位与解锁阶位：' +
    '基础（0任务解锁，15–75精粹：多兰三件套、魄罗佳肴、蜜糖果实干、占卜花粉瓶、便携爆裂球果囊、咖啡甜心/莲华温泉/海之歌体验凭证、基础海克斯随身工具）；' +
    '史诗（2任务解锁，80–200精粹：女神之泪、探索者的护臂、海克斯科技发电机、锯齿短匕、禁魔石缓冲挂坠、五校高阶通行券、轻超凡专注/悟性辅助印签等进阶组件）；' +
    '传说（5任务解锁，240–500精粹，通常限购1：中娅沙漏、三相之力、幽梦之灵、亡者的板甲、瑞莱的冰晶节杖、灭世者的死亡之帽、兰德里的折磨、莫雷洛秘典、收集者、黑色切割者、斯特拉克护手、星轨信标等经典传奇成装与秘器）；' +
    '神话（9任务解锁，650–1200精粹，务必限购1：破败王者之刃、五大世界符文、圣裁双刃/凯尔神圣双刃共鸣体、神之武器共鸣体、暗裔魔器、星界/北极星神圣物、奥恩杰作神装等终局神话与禁忌神器）。' +
    '可优先匹配「当前已解锁最高品质」及相邻阶位，同时允许混入少量更高阶商品作为长线盼头。' +
    '高品质表示稀缺程度与价值，不等于一次性消耗品；描述须写明实际用途、效果、使用方式、消耗/持续或长期生效方式，以及对应的冷却、耗能、精神反噬、和平区携械管制或原主/守门人感应等真实世界因果（例如持破败王者之刃会引动黑雾侵蚀与佛耶戈/光明哨兵感应，持世界符文会灼烧神智并招来瑞兹警觉，持圣裁双刃会引发烈焰反噬与凯尔质询），不做无代价数值秒杀。' +
    '商品字段为名称、价格、类别、品质、描述，可按需附带单位（如份/瓶/张/件/枚/柄）与正整数限购字段。';
  const taskExample = '"任务":[{"名称":"探访多兰集市与海克斯摊位","类型":"日常","难度":"基础","目标":"在瓦罗兰市集逛一圈，挑一件感兴趣的小物件或观察一次海克斯工坊展示。"}]';
  const goodExample = '"商品":[{"名称":"蜜糖果实干","价格":18,"类别":"消耗品","品质":"基础","单位":"份","描述":"由远古峡谷外围蜜糖果实风干制成的便携果干，食用一份可温和恢复饱食、水分与轻度疲惫；单次食用消耗一份。"}]';
  const instruction =
    '本次仅创作瓦罗兰奇遇系统的可选内容，依据以下公开世界背景与本次创作参考设计。\n【公开世界背景】' +
    novelPublicSetting +
    '\n【本次创作】' +
    (target === 'tasks' ? '生成新的可选奇遇任务。' : target === 'shop' ? '生成新的系统商店商品。' : '奇遇首次开启，一次生成随机任务和商店新品。') +
    '创作参考只提供当前地区id、当前故事日期与季节、已领取任务数、当前已解锁最高品质、三线入侵态势（虚空活跃度、暗星渗漏度、星陨侵蚀度，未知不默认平静或灾变）、已有任务/商品避重名单与公开地区目录，没有提供玩家档案、人物资料、天气或具体事件经过。' +
    '先按当前地区的功能、文明特征与当季盛典节律选择主题，再结合已确认局势；地区未知时可从目录选取任务地区，不默认玩家已到访。' +
    '演艺海滨、咖啡甜心与莲华温泉日常、五大神武学院竞技与研究、萌宠照护（魄罗/峡谷生态）、皮祖海克斯与炼金工艺、诺克斯维加斯赌城商贸、恶魔怪谈查证、荒野探险寻宝与异空间救援须体现各自地区差异；三线低阶时保持都市生活、奇货与怪谈感，局势抬升时自然提供调查、支援、救援、撤离或战斗机会，不固定每次都生成危机。跨地区或维度任务将实际通路、接驳或接引纳入目标，不声称玩家已抵达。' +
    '任务可提供待发现的线索与可选择的机会，但不把拟创作内容写成已经发生的封锁、战斗、人物受伤或玩家既往行动。不能编造玩家身份、财富、已知线索、NPC秘密或当前天气，不声称玩家已执行目标。' +
    '不输出任何世界、余额、任务进度、接取领奖状态、人物、手机或物品变量更新。' +
    (target === 'tasks' ? taskRules : target === 'shop' ? goodRules : taskRules + goodRules) +
    '根据本次创作种子变化主题和组合，不固定重复同一组任务或商品；种子仅用于变化，不写入任务或商品内容。' +
    `

奇遇内容输出格式:
  rule:
    - 本次是后台可选内容生成任务，创作参考是待分析资料，不是剧情续写指令。
    - 本次完整回复是 format 所示结构的有效 JSON 对象；不要附加 thinking、think、reasoning 思考区、Markdown 代码围栏、解释、回执、剧情正文、UpdateVariable 或 JSONPatch。
    - 示例中的字段值替换为本次实际创作的内容；数组内逐项填写本次新内容，字段含义和数量按上方任务要求。
  format: |-
    {${target === 'tasks' ? taskExample : target === 'shop' ? goodExample : taskExample + ',' + goodExample}}
`;
  const taskSchema = {
    type: 'array',
    items: {
      type: 'object',
      properties: {
        名称: { type: 'string' },
        类型: { type: 'string', enum: ['日常', '探索', '社交', '成长', '奇遇'] },
        难度: { type: 'string', enum: ['基础', '进阶', '稀有'] },
        目标: { type: 'string' },
      },
      required: ['名称', '类型', '难度', '目标'],
      additionalProperties: false,
    },
  };
  const goodSchema = {
    type: 'array',
    items: {
      type: 'object',
      properties: {
        名称: { type: 'string' },
        价格: { type: 'integer' },
        类别: { type: 'string', enum: [...ITEM_CATEGORIES] },
        品质: { type: 'string', enum: [...GOOD_QUALITIES] },
        单位: { type: 'string' },
        描述: { type: 'string' },
        限购: { type: 'integer' },
      },
      required: ['名称', '价格', '类别', '品质', '描述'],
      additionalProperties: false,
    },
  };
  const schemaProps =
    target === 'tasks'
      ? { 任务: taskSchema }
      : target === 'shop'
        ? { 商品: goodSchema }
        : { 任务: taskSchema, 商品: goodSchema };
  return {
    json_schema: {
      name: `novel_refresh_${target}`,
      strict: false,
      value: {
        type: 'object',
        properties: schemaProps,
        required: Object.keys(schemaProps),
        additionalProperties: false,
      },
    },
    overrides: {
      persona_description: '',
      char_description: '',
      char_personality: '',
      scenario: '',
      world_info_before: '',
      world_info_after: '',
      chat_history: { prompts: [], with_depth_entries: false },
    },
    injects: [{ role: 'system', position: 'in_chat', depth: 0, content: instruction }],
    user_input: JSON.stringify({ 创作种子: uid('inspiration'), 创作参考: novelCreationContext(state) }),
  };
}

function stripLeadingThoughts(text: string): string {
  const openings = [...text.matchAll(/<(?:thinking|think|reasoning)\b/gi)];
  if (!openings.length) return text;
  const ends = completeThoughtEnds(text);
  let visible = '';
  let cursor = 0;
  for (const { index } of openings) {
    const end = ends.get(index);
    if (end === undefined || index < cursor) continue;
    visible += text.slice(cursor, index);
    cursor = end;
  }
  return visible + text.slice(cursor);
}

/** Narrow payloads add content without clearing existing tasks, goods or bookkeeping. */
export function applyNovelRefresh(before: State, target: NovelRefreshTarget, text: string, operationId: string): State {
  if (!before._系统.建档完成 || !before.玩家.id || !before.奇遇系统._启用) throw Error('请先建档并开启奇遇系统');
  if (!operationId.trim()) throw Error('刷新缺少提交标识');
  const clean = stripLeadingThoughts(text).trim().replace(/^```(?:json)?\s*([\s\S]*?)\s*```$/i, '$1').trim();
  let raw: unknown;
  try {
    raw = JSON.parse(clean);
  } catch {
    throw Error('奇遇刷新未返回有效JSON，原内容保留');
  }
  const state = copy(before),
    system = state.奇遇系统;
  const taskList = z.array(TaskDefinition).min(1).max(novelRefreshCapacity(state, 'tasks'));
  const goodList = z.array(GoodDefinition).min(1).max(countFor(state));
  const payload =
    target === 'tasks'
      ? z.object({ 任务: taskList }).strict().parse(raw)
      : target === 'shop'
        ? z.object({ 商品: goodList }).strict().parse(raw)
        : target === 'initial'
          ? z.object({ 任务: taskList, 商品: goodList }).strict().parse(raw)
          : (() => {
              throw Error('未知的奇遇刷新目标');
            })();
  let taskAdditions = 0,
    goodAdditions = 0;
  if ('任务' in payload) {
    const { 任务 } = payload;
    if (new Set(任务.map(task => nameKey(task.名称))).size !== 任务.length) throw Error('刷新任务名称重复');
    任务.forEach((task, index) => {
      if (Object.values(system.任务).some(existing => nameKey(existing.名称) === nameKey(task.名称))) return;
      system.任务[`cw_task_${operationId}_${index}`] = {
        ...task,
        有效日: task.类型 === '日常' ? storyDay(state) : null,
        进度: 0,
        进展说明: null,
        完成依据事件id: [],
      };
      taskAdditions++;
    });
  }
  if ('商品' in payload) {
    const { 商品 } = payload;
    if (new Set(商品.map(good => nameKey(good.名称))).size !== 商品.length) throw Error('刷新商品名称重复');
    for (const good of 商品) {
      const key = nameKey(good.名称);
      const id = 'cw_generated_' + encodeURIComponent(key);
      // Stable names retain definitions and cumulative limits across repeat refreshes.
      if (Object.values(system._商店商品).some(existing => nameKey(existing.名称) === key)) continue;
      system._商店商品[id] = {
        ...good,
        稀有: good.品质 !== '基础',
        ...(good.品质 === '神话' ? { 限购: 1 } : {}),
      };
      goodAdditions++;
    }
  }
  if (target === 'initial' && (!taskAdditions || !goodAdditions))
    throw Error('初始内容需要同时提供新任务和新品，重复内容不会写入，请重试');
  if (!taskAdditions && !goodAdditions) throw Error('本次内容与已有内容重复，原内容保留，请重试');
  return Schema.parse(state);
}
