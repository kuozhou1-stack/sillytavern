import { computed, ref, shallowRef } from 'vue';
import { characterPublicIdentity, resolveCharacterStaticProfile } from '../../../../运行/character-static';
import { resolveEffectiveCharacterIdentity } from '../../../../运行/character-identity';
import { playerOccupation } from '../../../../运行/character-read';
import type {
  CharacterCategory,
  CharacterItemData,
  CategoryStats,
  CharacterManagementContracts,
} from './category-types';

/** 系统内置保留的默认分类 */
export const DEFAULT_CATEGORY_ID = 'uncategorized';
export const DEFAULT_CATEGORY: CharacterCategory = {
  id: DEFAULT_CATEGORY_ID,
  name: '未分类',
  isDefault: true,
  collapsed: false,
};

/** 全局共享响应式状态实例，确保主、次要角色界面及角色管理使用同一套分类归属与排序规则 */
const globalCategories = ref<CharacterCategory[]>([{ ...DEFAULT_CATEGORY }]);

/** 角色元数据映射：Record<charId, { categoryId: string; order: number; enabled: boolean }> */
type CharacterMetaMap = Record<string, { categoryId: string; order: number; enabled: boolean }>;
const globalCharMetaMap = ref<CharacterMetaMap>({});
// UI-only intent. Never written into stat_data or used as an acknowledgement.
const immediateMeta = ref<CharacterMetaMap>({});
const displayedMeta = computed(() => ({ ...globalCharMetaMap.value, ...immediateMeta.value }));
let contractVersion = 0;
let managementScope: string | undefined;

/** 正在处理中的操作标记：Record<actionKey, boolean> */
const operationPending = ref<Record<string, boolean>>({});

/** 最近一次操作的提示反馈信息 */
const lastFeedback = ref<{ type: 'info' | 'success' | 'warning' | 'error'; message: string; timestamp: number } | null>(
  null,
);

/** 数据层外部接入契约回调存储 */
const activeContracts = shallowRef<CharacterManagementContracts | null>(null);

export function useCharacterDisplayState() {
  function setContracts(contracts: CharacterManagementContracts | null) {
    if (activeContracts.value !== contracts) {
      contractVersion++;
      managementScope = undefined;
      immediateMeta.value = {};
      operationPending.value = {};
      lastFeedback.value = null;
    }
    activeContracts.value = contracts;
  }

  function syncManagement(
    categories: CharacterCategory[],
    meta: Record<string, { categoryId: string; order: number; enabled: boolean }>,
    scope?: string,
  ) {
    if (scope !== undefined && scope !== managementScope) {
      if (managementScope !== undefined) {
        contractVersion++;
        immediateMeta.value = {};
        operationPending.value = {};
      }
      managementScope = scope;
    }
    const collapsed = new Map(globalCategories.value.map(c => [c.id, c.collapsed]));
    globalCategories.value = categories.map(c => ({ ...c, collapsed: collapsed.get(c.id) ?? false }));
    globalCharMetaMap.value = JSON.parse(JSON.stringify(meta));
  }

  async function persisted(
    key: string,
    action: (contracts: CharacterManagementContracts) => Promise<unknown>,
    message = '已保存',
    project?: (meta: CharacterMetaMap) => CharacterMetaMap,
  ): Promise<boolean> {
    if (Object.values(operationPending.value).some(Boolean)) {
      if (!operationPending.value[key]) setFeedback('warning', '上一项操作尚未保存，请稍后重试');
      return false;
    }
    const contracts = activeContracts.value!;
    const version = contractVersion;
    const isCurrent = () => activeContracts.value === contracts && version === contractVersion;
    const readback = async () => {
      if (contracts.getCategories && contracts.getCharacterMetaMap) {
        const [categories, meta] = await Promise.all([contracts.getCategories(), contracts.getCharacterMetaMap()]);
        if (isCurrent()) syncManagement(categories, meta);
      }
    };
    operationPending.value[key] = true;
    lastFeedback.value = null;
    try {
      if (project) immediateMeta.value = project(globalCharMetaMap.value);
      const result = await action(contracts);
      if (result === false) throw Error('操作未被数据层确认');
      if (!isCurrent()) return false;
      await readback();
      if (!isCurrent()) return false;
      setFeedback('success', message);
      return true;
    } catch (error) {
      if (!isCurrent()) return false;
      // The bridge has already refreshed any rollback or newly selected branch.
      try {
        await readback();
      } catch {
        /* Keep the last confirmed projection. */
      }
      if (isCurrent()) setFeedback('error', `操作未保存，已恢复当前存档状态：${String(error)}`);
      return false;
    } finally {
      if (isCurrent()) {
        operationPending.value[key] = false;
        immediateMeta.value = {};
      }
    }
  }

  function setFeedback(type: 'info' | 'success' | 'warning' | 'error', message: string) {
    lastFeedback.value = { type, message, timestamp: Date.now() };
  }

  /**
   * 初始化/同步角色数据到本地视图投影
   * @param rawCharacters 从运行服务或 props 传入的角色字典
   */
  function syncCharacters(rawCharacters: Record<string, any>) {
    if (!rawCharacters || typeof rawCharacters !== 'object') return;
    const currentMeta = { ...globalCharMetaMap.value };
    let hasChanges = false;
    let autoOrder = Object.keys(currentMeta).length;

    for (const [id] of Object.entries(rawCharacters)) {
      if (!currentMeta[id]) {
        currentMeta[id] = {
          categoryId: DEFAULT_CATEGORY_ID,
          order: autoOrder++,
          enabled: true,
        };
        hasChanges = true;
      }
    }

    if (hasChanges) {
      globalCharMetaMap.value = currentMeta;
    }
  }

  /**
   * 组装指定角色列表并结合元数据排序
   */
  function formatCharacterItem(id: string, raw: any, playerView = false): CharacterItemData {
    const meta = displayedMeta.value[id] || {
      categoryId: DEFAULT_CATEGORY_ID,
      order: 999,
      enabled: true,
    };

    const occupation = playerView
      ? playerOccupation(resolveEffectiveCharacterIdentity(raw.身份, resolveCharacterStaticProfile(undefined, id)?.身份)).join('、')
      : characterPublicIdentity(undefined, id, raw.身份);
    return {
      id,
      name: raw.姓名 || id,
      gender: raw.性别,
      age: raw.年龄,
      occupation: occupation || null,
      tier: raw.层级 === '次要' ? '次要' : '主要',
      categoryId: meta.categoryId,
      order: meta.order,
      enabled: meta.enabled,
      statusState:
        operationPending.value[`char:${id}`] || operationPending.value[`cat:${meta.categoryId}`] ? 'pending' : 'idle',
      raw,
    };
  }

  /**
   * 获取某个分类下的角色列表（支持层级筛选、状态筛选、关键词搜索与独立排序）
   */
  function getCategoryCharacters(
    categoryId: string,
    allCharacters: Record<string, any>,
    options: {
      tierFilter?: 'all' | '主要' | '次要';
      statusFilter?: 'all' | 'enabled' | 'disabled';
      keyword?: string;
      playerView?: boolean;
    } = {},
  ): CharacterItemData[] {
    const { tierFilter = 'all', statusFilter = 'all', keyword = '', playerView = false } = options;
    const kw = keyword.trim().toLowerCase();

    const result: CharacterItemData[] = [];

    for (const [id, raw] of Object.entries(allCharacters || {})) {
      const item = formatCharacterItem(id, raw, playerView);
      if (item.categoryId !== categoryId) continue;
      if (tierFilter !== 'all' && item.tier !== tierFilter) continue;
      if (statusFilter === 'enabled' && !item.enabled) continue;
      if (statusFilter === 'disabled' && item.enabled) continue;

      if (kw) {
        const nameMatch = item.name.toLowerCase().includes(kw);
        const occStr = typeof item.occupation === 'string' ? item.occupation : JSON.stringify(item.occupation || '');
        const occMatch = occStr.toLowerCase().includes(kw);
        if (!nameMatch && !occMatch) continue;
      }

      result.push(item);
    }

    // 按 order 升序排序
    return result.sort((a, b) => a.order - b.order);
  }

  /**
   * 计算指定分类的统计信息（总数、开启数、批量开关勾选状态）
   */
  function getCategoryStats(
    categoryId: string,
    allCharacters: Record<string, any>,
    tierFilter: 'all' | '主要' | '次要' = 'all',
  ): CategoryStats {
    // 分类跨主要／次要层级；正式开关始终汇总整类，列表筛选只影响显示。
    if (activeContracts.value) tierFilter = 'all';
    let total = 0;
    let enabled = 0;

    for (const [id, raw] of Object.entries(allCharacters || {})) {
      const item = formatCharacterItem(id, raw);
      if (item.categoryId !== categoryId) continue;
      if (tierFilter !== 'all' && item.tier !== tierFilter) continue;

      total++;
      if (item.enabled) enabled++;
    }

    let checkState: 'all' | 'none' | 'mixed' = 'none';
    if (total > 0) {
      if (enabled === total) checkState = 'all';
      else if (enabled === 0) checkState = 'none';
      else checkState = 'mixed';
    }

    return {
      categoryId,
      total,
      enabled,
      disabled: total - enabled,
      checkState,
    };
  }

  // ========================== 交互动作执行器 ==========================

  function requireContract<K extends keyof CharacterManagementContracts>(method: K, actionLabel: string): boolean {
    if (activeContracts.value?.[method]) return true;
    setFeedback('warning', `数据层未连接，无法执行「${actionLabel}」。`);
    return false;
  }

  /** 新建分类 */
  async function createCategory(name: string): Promise<boolean> {
    const trimmed = name.trim();
    if (!trimmed) {
      setFeedback('warning', '分类名称不能为空');
      return false;
    }
    if (globalCategories.value.some(c => c.name === trimmed)) {
      setFeedback('warning', `已存在名为“${trimmed}”的分类`);
      return false;
    }
    if (!requireContract('createCategory', '新建分类')) return false;
    return persisted('categories', c => c.createCategory!(trimmed), '分类已保存');
  }

  /** 重命名分类 */
  async function renameCategory(categoryId: string, newName: string): Promise<boolean> {
    const trimmed = newName.trim();
    if (!trimmed) {
      setFeedback('warning', '分类名称不能为空');
      return false;
    }
    const cat = globalCategories.value.find(c => c.id === categoryId);
    if (!cat) return false;
    if (cat.isDefault) {
      setFeedback('warning', '系统默认“未分类”不支持重命名');
      return false;
    }
    if (globalCategories.value.some(c => c.id !== categoryId && c.name === trimmed)) {
      setFeedback('warning', `已存在名为“${trimmed}”的分类`);
      return false;
    }
    if (!requireContract('renameCategory', '分类重命名')) return false;
    return persisted(
      'categories',
      async c => {
        await c.renameCategory!(categoryId, trimmed);
        cat.name = trimmed;
      },
      '分类名称已保存',
    );
  }

  /** 删除分类（角色安全归入“未分类”，不删除或关闭角色） */
  async function deleteCategory(categoryId: string): Promise<boolean> {
    const cat = globalCategories.value.find(c => c.id === categoryId);
    if (!cat) return false;
    if (cat.isDefault) {
      setFeedback('warning', '系统内置的“未分类”不能删除');
      return false;
    }
    if (!requireContract('deleteCategory', '删除分类')) return false;
    return persisted('categories', c => c.deleteCategory!(categoryId), '分类已删除，成员已移至未分类');
  }

  /** 分类排序 */
  async function reorderCategories(fromIndex: number, toIndex: number): Promise<boolean> {
    if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0 || fromIndex >= globalCategories.value.length || toIndex >= globalCategories.value.length)
      return false;
    if (!requireContract('reorderCategories', '分类排序')) return false;
    const list = [...globalCategories.value];
    const [moved] = list.splice(fromIndex, 1);
    list.splice(toIndex, 0, moved);
    return persisted('categories', c => c.reorderCategories!(list.map(item => item.id)));
  }

  /** 移动角色至目标分类（支持指定位置，兼顾拖拽与选择框交互） */
  async function moveCharacter(charId: string, targetCategoryId: string, targetIndex?: number): Promise<boolean> {
    const meta = globalCharMetaMap.value[charId];
    if (!meta || !globalCategories.value.some(c => c.id === targetCategoryId)) return false;
    if (meta.categoryId === targetCategoryId && targetIndex === undefined) return true;
    if (!requireContract('moveCharacterToCategory', '移动角色')) return false;
    return persisted(
      `char:${charId}`,
      c => c.moveCharacterToCategory!(charId, targetCategoryId, targetIndex),
      '角色位置已保存',
      current => {
        if (!current[charId] || !globalCategories.value.some(c => c.id === targetCategoryId))
          throw Error('角色或分类已变化');
        const ids = Object.keys(current)
          .filter(id => id !== charId && current[id].categoryId === targetCategoryId)
          .sort((a, b) => current[a].order - current[b].order);
        ids.splice(Math.max(0, Math.min(targetIndex ?? ids.length, ids.length)), 0, charId);
        return Object.fromEntries(ids.map((id, order) => [id, { ...current[id], categoryId: targetCategoryId, order }]));
      },
    );
  }

  /** 分类内角色重新排序 */
  async function reorderCharacters(categoryId: string, orderedCharIds: string[]): Promise<boolean> {
    if (!orderedCharIds.length) return false;
    if (!requireContract('reorderCharactersInCategory', '角色排序')) return false;
    return persisted(`cat:${categoryId}`, c => c.reorderCharactersInCategory!(categoryId, orderedCharIds));
  }

  /**
   * 单人启停切换
   * 界面立即切换；完整快照和活动状态仍由后台保存，失败撤销显示投影。
   */
  async function toggleCharacterEnabled(charId: string, targetEnabled?: boolean): Promise<boolean> {
    const meta = globalCharMetaMap.value[charId];
    if (!meta) return false;
    if (!requireContract('toggleCharacterEnabled', '角色启停')) return false;
    const enabled = targetEnabled ?? !meta.enabled;
    return persisted(
      `char:${charId}`,
      c => c.toggleCharacterEnabled!(charId, enabled),
      enabled ? '已恢复关闭时资料' : '已保存快照并关闭角色',
      current => ({ [charId]: { ...current[charId], enabled } }),
    );
  }

  /**
   * 分类批量启停
   * 部分开启时点击转为全开；全开时点击转为全关
   */
  async function batchToggleCategory(
    categoryId: string,
    allCharacters: Record<string, any>,
    targetEnabled?: boolean,
    tierFilter: 'all' | '主要' | '次要' = 'all',
  ): Promise<boolean> {
    if (activeContracts.value) tierFilter = 'all';
    const stats = getCategoryStats(categoryId, allCharacters, tierFilter);
    if (stats.total === 0) return false;
    if (!requireContract('batchToggleCategoryEnabled', '批量启停')) return false;

    const nextState = targetEnabled !== undefined ? targetEnabled : stats.checkState !== 'all';
    const targetCharIds: string[] = [];

    for (const [id, raw] of Object.entries(allCharacters || {})) {
      const item = formatCharacterItem(id, raw);
      if (item.categoryId !== categoryId) continue;
      if (tierFilter !== 'all' && item.tier !== tierFilter) continue;
      targetCharIds.push(id);
    }

    return persisted(
      `cat:${categoryId}`,
      c => c.batchToggleCategoryEnabled!(categoryId, nextState, targetCharIds),
      `已确认 ${targetCharIds.length} 位角色${nextState ? '开启' : '关闭'}（整批保存）`,
      current => Object.fromEntries(targetCharIds.map(id => [id, { ...current[id], enabled: nextState }])),
    );
  }

  return {
    categories: globalCategories,
    charMetaMap: displayedMeta,
    confirmedCharMetaMap: globalCharMetaMap,
    operationPending,
    lastFeedback,
    setContracts,
    syncManagement,
    connected: computed(() => !!activeContracts.value),
    setFeedback,
    syncCharacters,
    formatCharacterItem,
    getCategoryCharacters,
    getCategoryStats,
    createCategory,
    renameCategory,
    deleteCategory,
    reorderCategories,
    moveCharacter,
    reorderCharacters,
    toggleCharacterEnabled,
    batchToggleCategory,
  };
}
